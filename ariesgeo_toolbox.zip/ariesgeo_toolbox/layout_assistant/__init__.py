"""
Aries Map Layout Assistant module for QGIS.
"""

"""
Native QgsPrintLayout composer engine for Aries Map Layout Assistant.
"""

import os
import datetime
from typing import Optional, List, Tuple
from qgis.core import (
    QgsProject,
    QgsPrintLayout,
    QgsLayoutItemMap,
    QgsLayoutItemLabel,
    QgsLayoutItemLegend,
    QgsLayoutItemScaleBar,
    QgsLayoutItemPicture,
    QgsLayoutItemMapGrid,
    QgsLayoutItemMapOverview,
    QgsLayoutItemShape,
    QgsLayoutSize,
    QgsLayoutPoint,
    QgsLayoutMeasurement,
    QgsUnitTypes,
    QgsRectangle,
    QgsCoordinateReferenceSystem,
    QgsLayerTree,
)
from qgis.PyQt.QtGui import QFont, QColor
from qgis.PyQt.QtCore import Qt
from ..resources import get_icon_path
from .models import LayoutConfig, PAGE_DIMENSIONS_MM
from .templates import get_template

class LayoutComposer:
    """Builds native QgsPrintLayout objects from configuration models and templates."""

    @classmethod
    def create_layout(
        cls,
        config: LayoutConfig,
        project: Optional[QgsProject] = None,
        canvas_extent: Optional[QgsRectangle] = None
    ) -> QgsPrintLayout:
        """Create and populate a native QgsPrintLayout."""
        proj = project or QgsProject.instance()
        layout_manager = proj.layoutManager()

        # Remove existing layout with same name if exists
        existing = layout_manager.layoutByName(config.layout_name)
        if existing:
            layout_manager.removeLayout(existing)

        layout = QgsPrintLayout(proj)
        layout.initializeDefaults()
        layout.setName(config.layout_name)

        # 1. Page Dimensions
        base_w, base_h = PAGE_DIMENSIONS_MM.get(config.page_size_name, (297.0, 210.0))
        if config.orientation.lower() == "portrait":
            page_w, page_h = min(base_w, base_h), max(base_w, base_h)
        else:
            page_w, page_h = max(base_w, base_h), min(base_w, base_h)

        page = layout.pageCollection().page(0)
        page.setPageSize(QgsLayoutSize(page_w, page_h, QgsUnitTypes.LayoutUnit.Millimeters))

        template = get_template(config.template_name)
        m = config.margins

        # Geometry calculations
        # Header banner at top
        header_h = 22.0
        footer_h = template.footer_height_mm
        sidebar_w = template.legend_sidebar_width_mm if config.include_legend else 0.0
        gap = 4.0

        # Main Map Dimensions
        map_x = m.left
        map_y = m.top + header_h + gap
        map_w = page_w - m.left - m.right - (sidebar_w + gap if sidebar_w > 0 else 0.0)
        map_h = page_h - map_y - m.bottom - footer_h - gap

        # 2. Main Map Item
        main_map = QgsLayoutItemMap(layout)
        main_map.setId("main_map")
        main_map.setRect(0, 0, map_w, map_h)
        main_map.attemptMove(QgsLayoutPoint(map_x, map_y, QgsUnitTypes.LayoutUnit.Millimeters))
        main_map.attemptResize(QgsLayoutSize(map_w, map_h, QgsUnitTypes.LayoutUnit.Millimeters))
        main_map.setFrameEnabled(True)
        main_map.setFrameStrokeWidth(QgsLayoutMeasurement(template.border_width_mm, QgsUnitTypes.LayoutUnit.Millimeters) if hasattr(QgsLayoutMeasurement, 'Unit') else QgsLayoutMeasurement(template.border_width_mm))

        if canvas_extent and not canvas_extent.isEmpty():
            main_map.setExtent(canvas_extent)
        else:
            main_map.zoomToExtent(proj.viewExtent() if hasattr(proj, 'viewExtent') else QgsRectangle(-180, -90, 180, 90))

        layout.addLayoutItem(main_map)

        # 3. Header: Title & Subtitle
        title_label = QgsLayoutItemLabel(layout)
        title_label.setId("title_label")
        title_text = config.metadata.title or proj.title() or "Project Map"
        if config.metadata.subtitle:
            title_text += f"\n{config.metadata.subtitle}"
        title_label.setText(title_text)
        title_font = QFont(template.title_font_family, template.title_font_size, QFont.Weight.Bold)
        title_label.setFont(title_font)
        title_label.attemptMove(QgsLayoutPoint(m.left, m.top, QgsUnitTypes.LayoutUnit.Millimeters))
        title_label.attemptResize(QgsLayoutSize(page_w - m.left - m.right, header_h, QgsUnitTypes.LayoutUnit.Millimeters))
        layout.addLayoutItem(title_label)

        # 4. Legend
        if config.include_legend and sidebar_w > 0:
            legend = QgsLayoutItemLegend(layout)
            legend.setTitle("Legend")
            legend.setLinkedMap(main_map)
            legend.setAutoUpdateModel(True)
            legend_x = map_x + map_w + gap
            legend_y = map_y
            legend.attemptMove(QgsLayoutPoint(legend_x, legend_y, QgsUnitTypes.LayoutUnit.Millimeters))
            legend.attemptResize(QgsLayoutSize(sidebar_w, map_h, QgsUnitTypes.LayoutUnit.Millimeters))
            legend.setFrameEnabled(True)
            layout.addLayoutItem(legend)

        # 5. Scale Bar
        if config.include_scalebar:
            scalebar = QgsLayoutItemScaleBar(layout)
            scalebar.setLinkedMap(main_map)
            scalebar.setStyle("Single Box")
            scalebar.setUnits(QgsUnitTypes.DistanceUnit.DistanceKilometers if config.scalebar_units == "km" else QgsUnitTypes.DistanceUnit.DistanceMeters)
            scalebar.setNumberOfSegments(2)
            scalebar.setNumberOfSegmentsLeft(0)
            scalebar.attemptMove(QgsLayoutPoint(map_x + 4.0, map_y + map_h - 14.0, QgsUnitTypes.LayoutUnit.Millimeters))
            layout.addLayoutItem(scalebar)

        # 6. North Arrow
        if config.include_north_arrow:
            north_arrow = QgsLayoutItemPicture(layout)
            svg_path = get_icon_path("layout.svg")
            north_arrow.setPicturePath(svg_path)
            north_arrow.setLinkedMap(main_map)
            arrow_size = 14.0
            north_arrow.attemptMove(QgsLayoutPoint(map_x + map_w - arrow_size - 4.0, map_y + 4.0, QgsUnitTypes.LayoutUnit.Millimeters))
            north_arrow.attemptResize(QgsLayoutSize(arrow_size, arrow_size, QgsUnitTypes.LayoutUnit.Millimeters))
            layout.addLayoutItem(north_arrow)

        # 7. Coordinate Grid / Graticule
        if config.grid.enabled:
            grid = QgsLayoutItemMapGrid("Coordinate Grid", main_map)
            grid.setEnabled(True)
            if config.grid.interval_x > 0 and config.grid.interval_y > 0:
                grid.setIntervalX(config.grid.interval_x)
                grid.setIntervalY(config.grid.interval_y)
            else:
                # Auto-interval: divide extent into ~5 grid intervals
                ext = main_map.extent()
                grid.setIntervalX(ext.width() / 5.0)
                grid.setIntervalY(ext.height() / 5.0)

            grid.setStyle(QgsLayoutItemMapGrid.GridStyle.Solid)
            if config.grid.frame_style == "Zebra":
                grid.setFrameStyle(QgsLayoutItemMapGrid.FrameStyle.Zebra)
            if config.grid.draw_annotations:
                grid.setAnnotationEnabled(True)
                grid.setAnnotationPosition(QgsLayoutItemMapGrid.AnnotationPosition.OutsideMapFrame, QgsLayoutItemMapGrid.BorderSide.Left)
                grid.setAnnotationPosition(QgsLayoutItemMapGrid.AnnotationPosition.OutsideMapFrame, QgsLayoutItemMapGrid.BorderSide.Bottom)
            main_map.grids().addGrid(grid)

        # 8. Inset / Overview Map
        if config.inset.enabled:
            inset_map = QgsLayoutItemMap(layout)
            iw, ih = config.inset.width_mm, config.inset.height_mm
            ix = map_x + map_w - iw - 4.0
            iy = map_y + map_h - ih - 4.0
            inset_map.attemptMove(QgsLayoutPoint(ix, iy, QgsUnitTypes.LayoutUnit.Millimeters))
            inset_map.attemptResize(QgsLayoutSize(iw, ih, QgsUnitTypes.LayoutUnit.Millimeters))
            inset_map.setFrameEnabled(True)
            # Add overview extent indicator
            if config.inset.show_extent_indicator:
                overview = QgsLayoutItemMapOverview("Main Map Extent", inset_map)
                overview.setLinkedMap(main_map)
                overview.setEnabled(True)
                inset_map.overviews().addOverview(overview)
            layout.addLayoutItem(inset_map)

        # 9. Footer: Metadata, Author, CRS & Disclaimer
        footer_label = QgsLayoutItemLabel(layout)
        date_val = config.metadata.date_str or datetime.date.today().strftime("%B %d, %Y")
        crs_val = config.metadata.crs_str or proj.crs().authid() or "WGS 84"
        author_val = config.metadata.author or "GIS Analyst"
        org_val = config.metadata.organization or "AriesPlus"

        meta_lines = [
            f"<b>Author:</b> {author_val} | <b>Organisation:</b> {org_val} | <b>Date:</b> {date_val} | <b>CRS:</b> {crs_val}",
            f"<span style='color: gray; font-size: 7pt;'>{config.metadata.disclaimer}</span>"
        ]
        footer_label.setText("<br/>".join(meta_lines))
        footer_label.setMode(QgsLayoutItemLabel.Mode.ModeHtml)
        footer_y = page_h - m.bottom - footer_h
        footer_label.attemptMove(QgsLayoutPoint(m.left, footer_y, QgsUnitTypes.LayoutUnit.Millimeters))
        footer_label.attemptResize(QgsLayoutSize(page_w - m.left - m.right, footer_h, QgsUnitTypes.LayoutUnit.Millimeters))
        layout.addLayoutItem(footer_label)

        # Register layout with QGIS Layout Manager
        layout_manager.addLayout(layout)
        return layout

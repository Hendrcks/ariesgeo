"""
Layout export manager for PDF, PNG, JPEG, and SVG formats.
"""

import os
from typing import Tuple
from qgis.core import (
    QgsPrintLayout,
    QgsLayoutExporter,
)

class LayoutExporter:
    """Exports native QgsPrintLayout to image or document files."""

    @classmethod
    def export_pdf(
        cls,
        layout: QgsPrintLayout,
        output_pdf_path: str,
        dpi: int = 300,
        georeferenced: bool = True
    ) -> Tuple[bool, str]:
        """Export layout to PDF file."""
        try:
            os.makedirs(os.path.dirname(os.path.abspath(output_pdf_path)), exist_ok=True)
            exporter = QgsLayoutExporter(layout)

            settings = QgsLayoutExporter.PdfExportSettings()
            settings.dpi = dpi
            if hasattr(settings, "writeGeoPdf"):
                settings.writeGeoPdf = georeferenced

            res = exporter.exportToPdf(output_pdf_path, settings)
            if res != QgsLayoutExporter.ExportResult.Success:
                return False, f"Export error code: {res}"
            return True, output_pdf_path
        except Exception as e:
            return False, str(e)

    @classmethod
    def export_image(
        cls,
        layout: QgsPrintLayout,
        output_image_path: str,
        dpi: int = 300,
        world_file: bool = False
    ) -> Tuple[bool, str]:
        """Export layout to PNG / JPEG image file."""
        try:
            os.makedirs(os.path.dirname(os.path.abspath(output_image_path)), exist_ok=True)
            exporter = QgsLayoutExporter(layout)

            settings = QgsLayoutExporter.ImageExportSettings()
            settings.dpi = dpi
            if hasattr(settings, "generateWorldFile"):
                settings.generateWorldFile = world_file

            res = exporter.exportToImage(output_image_path, settings)
            if res != QgsLayoutExporter.ExportResult.Success:
                return False, f"Export error code: {res}"
            return True, output_image_path
        except Exception as e:
            return False, str(e)

    @classmethod
    def export_svg(
        cls,
        layout: QgsPrintLayout,
        output_svg_path: str,
        dpi: int = 300
    ) -> Tuple[bool, str]:
        """Export layout to SVG vector file."""
        try:
            os.makedirs(os.path.dirname(os.path.abspath(output_svg_path)), exist_ok=True)
            exporter = QgsLayoutExporter(layout)

            settings = QgsLayoutExporter.SvgExportSettings()
            settings.dpi = dpi

            res = exporter.exportToSvg(output_svg_path, settings)
            if res != QgsLayoutExporter.ExportResult.Success:
                return False, f"Export error code: {res}"
            return True, output_svg_path
        except Exception as e:
            return False, str(e)

    # Aliases
    export_to_pdf = export_pdf
    export_to_image = export_image
    export_to_svg = export_svg

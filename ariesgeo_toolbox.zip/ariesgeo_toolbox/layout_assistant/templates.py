"""
Cartographic layout templates and styling definitions for Aries Map Layout Assistant.
"""

from dataclasses import dataclass
from typing import Dict, Any, List
from .models import LayoutConfig, Margins, TextMetadata

@dataclass
class LayoutTemplate:
    """Template configuration defining layout structure and styling."""
    name: str
    description: str
    title_font_family: str = "Arial"
    title_font_size: int = 16
    subtitle_font_size: int = 10
    body_font_size: int = 8
    accent_color_hex: str = "#16A36A"
    header_background_hex: str = "#F8FAFC"
    border_color_hex: str = "#0B1F33"
    border_width_mm: float = 0.5
    legend_sidebar_width_mm: float = 65.0
    footer_height_mm: float = 16.0


TEMPLATES: Dict[str, LayoutTemplate] = {
    "Modern Report": LayoutTemplate(
        name="Modern Report",
        description="Clean, contemporary cartographic report with right-hand legend sidebar and footer metadata card.",
        title_font_family="Arial",
        title_font_size=16,
        subtitle_font_size=11,
        body_font_size=8,
        accent_color_hex="#16A36A",
        header_background_hex="#F8FAFC",
        border_color_hex="#E2E8F0",
        border_width_mm=0.3,
        legend_sidebar_width_mm=65.0,
        footer_height_mm=16.0
    ),
    "Academic & Research": LayoutTemplate(
        name="Academic & Research",
        description="Classical formal layout with strict neatline border, coordinate graticule, and projection citation.",
        title_font_family="Times New Roman",
        title_font_size=15,
        subtitle_font_size=10,
        body_font_size=8,
        accent_color_hex="#0B1F33",
        header_background_hex="#FFFFFF",
        border_color_hex="#000000",
        border_width_mm=0.6,
        legend_sidebar_width_mm=60.0,
        footer_height_mm=18.0
    ),
    "Field Survey & Planning": LayoutTemplate(
        name="Field Survey & Planning",
        description="High-contrast layout with large main map view, heavy title block, and integrated north arrow & scale.",
        title_font_family="Arial",
        title_font_size=18,
        subtitle_font_size=11,
        body_font_size=9,
        accent_color_hex="#F2A51A",
        header_background_hex="#0B1F33",
        border_color_hex="#0B1F33",
        border_width_mm=0.8,
        legend_sidebar_width_mm=55.0,
        footer_height_mm=20.0
    ),
    "Landscape Executive": LayoutTemplate(
        name="Landscape Executive",
        description="Panoramic ratio layout tailored for executive presentations, environmental overviews, and boards.",
        title_font_family="Helvetica",
        title_font_size=17,
        subtitle_font_size=11,
        body_font_size=8,
        accent_color_hex="#0284C7",
        header_background_hex="#F0F9FF",
        border_color_hex="#0284C7",
        border_width_mm=0.4,
        legend_sidebar_width_mm=70.0,
        footer_height_mm=15.0
    ),
}

def get_template(name: str) -> LayoutTemplate:
    """Retrieve template by name, defaulting to Modern Report."""
    return TEMPLATES.get(name, TEMPLATES["Modern Report"])

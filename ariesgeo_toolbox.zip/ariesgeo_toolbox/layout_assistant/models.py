"""
Data structures and configuration models for Aries Map Layout Assistant.
"""

from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any, Tuple

PAGE_DIMENSIONS_MM: Dict[str, Tuple[float, float]] = {
    "A4": (297.0, 210.0),       # Landscape default (width, height)
    "A3": (420.0, 297.0),
    "A2": (594.0, 420.0),
    "A1": (841.0, 594.0),
    "A0": (1189.0, 841.0),
    "Letter": (279.4, 215.9),
    "Legal": (355.6, 215.9),
}

@dataclass
class Margins:
    """Page margins in millimeters."""
    top: float = 10.0
    bottom: float = 10.0
    left: float = 10.0
    right: float = 10.0


@dataclass
class TextMetadata:
    """Text annotations and project metadata for map layout."""
    title: str = "Project Map"
    subtitle: str = ""
    author: str = ""
    organization: str = "AriesPlus"
    date_str: str = ""
    crs_str: str = ""
    disclaimer: str = "For planning and reference purposes only."
    logo_path: str = ""


@dataclass
class GridConfig:
    """Coordinate grid / graticule configuration."""
    enabled: bool = False
    interval_x: float = 0.0
    interval_y: float = 0.0
    frame_style: str = "Zebra"   # Zebra, LineBorder, Ticks, None
    crs_auth_id: Optional[str] = None
    draw_annotations: bool = True
    annotation_format: str = "Decimal"  # Decimal, DegreeMinuteSecond, Projected


@dataclass
class InsetConfig:
    """Overview / Inset map configuration."""
    enabled: bool = False
    overview_layer_id: Optional[str] = None
    show_extent_indicator: bool = True
    position: str = "TopRight"  # TopRight, BottomRight, TopLeft, BottomLeft
    width_mm: float = 60.0
    height_mm: float = 45.0


@dataclass
class LayoutConfig:
    """Complete layout configuration for composer."""
    layout_name: str = "Aries_Print_Layout"
    page_size_name: str = "A4"
    orientation: str = "Landscape"  # Landscape, Portrait
    margins: Margins = field(default_factory=Margins)
    template_name: str = "Modern Report"
    metadata: TextMetadata = field(default_factory=TextMetadata)
    grid: GridConfig = field(default_factory=GridConfig)
    inset: InsetConfig = field(default_factory=InsetConfig)
    include_legend: bool = True
    include_scalebar: bool = True
    include_north_arrow: bool = True
    scalebar_units: str = "km"     # km, m, miles, feet
    export_dpi: int = 300

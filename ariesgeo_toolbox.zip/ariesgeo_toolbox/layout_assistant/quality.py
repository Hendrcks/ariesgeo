"""
Layout Quality Checker and Cartographic Preflight Analyzer.
"""

from dataclasses import dataclass, field
from typing import List, Dict, Any
from qgis.core import (
    QgsPrintLayout,
    QgsLayoutItem,
    QgsLayoutItemMap,
    QgsLayoutItemScaleBar,
    QgsLayoutItemLabel,
    QgsLayoutItemPicture,
    QgsLayoutItemLegend
)

@dataclass
class QualityIssue:
    """An issue identified during layout quality check."""
    severity: str   # "ERROR", "WARNING", "SUGGESTION"
    title: str
    description: str

    @property
    def message(self) -> str:
        return f"{self.title}: {self.description}"


@dataclass
class QualityReport:
    """Consolidated audit report."""
    issues: List[QualityIssue] = field(default_factory=list)
    score: int = 100
    has_critical_errors: bool = False

    def __iter__(self):
        return iter(self.issues)

    def __len__(self):
        return len(self.issues)


class LayoutQualityChecker:
    """Audits a QgsPrintLayout for cartographic integrity, overlaps, and missing items."""

    @classmethod
    def check_layout(cls, layout: QgsPrintLayout) -> QualityReport:
        issues: List[QualityIssue] = []

        # 1. Check Main Map Frame
        maps = [item for item in layout.items() if isinstance(item, QgsLayoutItemMap)]
        if not maps:
            issues.append(QualityIssue("ERROR", "Missing Map Frame", "The layout does not contain any map frame."))
        else:
            main_map = maps[0]
            if main_map.extent().isEmpty():
                issues.append(QualityIssue("ERROR", "Empty Map Extent", "The main map has an empty or invalid spatial extent."))

        # 2. Check Title
        labels = [item for item in layout.items() if isinstance(item, QgsLayoutItemLabel)]
        has_title = False
        for l in labels:
            text = l.text().strip()
            if text and ("map" in text.lower() or len(text) > 3):
                has_title = True
                break
        if not has_title:
            issues.append(QualityIssue("WARNING", "Missing or Short Title", "No clear map title was identified on the page."))

        # 3. Check Scale Bar
        scalebars = [item for item in layout.items() if isinstance(item, QgsLayoutItemScaleBar)]
        if not scalebars:
            issues.append(QualityIssue("WARNING", "Missing Scale Bar", "Professional maps should include a scale bar."))
        else:
            for sb in scalebars:
                if not sb.linkedMap():
                    issues.append(QualityIssue("ERROR", "Unlinked Scale Bar", "Scale bar is not connected to a map frame."))

        # 4. Check Resolution / DPI
        page = layout.pageCollection().page(0) if layout.pageCollection().pageCount() > 0 else None
        render_context = layout.renderContext()
        dpi = render_context.dpi()
        if dpi < 150:
            issues.append(QualityIssue("WARNING", "Low Export DPI", f"Current DPI is {dpi:.0f}. 300 DPI is recommended for print."))

        # 5. Check Items within Page Margins
        if page:
            pw = page.pageSize().width()
            ph = page.pageSize().height()
            for item in layout.items():
                if isinstance(item, QgsLayoutItem) and hasattr(item, "sizeWithUnits") and hasattr(item, "pos"):
                    pos = item.pos()
                    size = item.sizeWithUnits()
                    if pos.x() < 0 or pos.y() < 0 or (pos.x() + size.width() > pw + 1) or (pos.y() + size.height() > ph + 1):
                        name = item.displayName() if hasattr(item, "displayName") else "Layout Item"
                        issues.append(QualityIssue("WARNING", "Item Exceeds Page Margins", f"Item '{name}' extends beyond the page boundary."))

        # Calculate Score
        score = 100
        has_err = False
        for iss in issues:
            if iss.severity == "ERROR":
                score -= 25
                has_err = True
            elif iss.severity == "WARNING":
                score -= 10
            else:
                score -= 5

        score = max(0, min(100, score))
        return QualityReport(issues=issues, score=score, has_critical_errors=has_err)

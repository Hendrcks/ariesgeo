"""
Continuous validation metrics: MAE, RMSE, Bias, and R^2 evaluation.
"""

import math
from typing import List, Tuple, Dict, Any, Optional
import numpy as np
from osgeo import gdal

def compute_validation_statistics(
    reference_values: List[float],
    estimated_values: List[float]
) -> Dict[str, Any]:
    """
    Compute rigorous statistical validation metrics between reference truth and continuous model estimates:
    - MAE: Mean Absolute Error
    - RMSE: Root Mean Squared Error
    - Bias: Mean Error (under/over-estimation)
    - R²: Coefficient of Determination
    """
    if len(reference_values) != len(estimated_values):
        raise ValueError("Reference and estimated arrays must have identical length.")
        
    y_true = np.array(reference_values, dtype=np.float64)
    y_pred = np.array(estimated_values, dtype=np.float64)
    
    valid = ~np.isnan(y_true) & ~np.isnan(y_pred) & ~np.isinf(y_true) & ~np.isinf(y_pred)
    y_t = y_true[valid]
    y_p = y_pred[valid]
    
    n = int(y_t.size)
    if n == 0:
        raise ValueError("No valid overlapping reference/estimate sample pairs.")
        
    errors = y_p - y_t
    mae = float(np.mean(np.abs(errors)))
    rmse = float(np.sqrt(np.mean(errors ** 2)))
    bias = float(np.mean(errors))
    
    # R^2
    ss_res = np.sum(errors ** 2)
    ss_tot = np.sum((y_t - np.mean(y_t)) ** 2)
    r2 = float(1.0 - (ss_res / ss_tot)) if ss_tot > 0 else 0.0
    
    return {
        "sample_count": n,
        "mae": mae,
        "rmse": rmse,
        "bias": bias,
        "r_squared": max(0.0, r2),
        "min_error": float(np.min(errors)),
        "max_error": float(np.max(errors)),
        "std_error": float(np.std(errors))
    }


"""
Integrity, alignment, and geometry audit engines for raster and vector data.
"""

import os
import shutil
from typing import List, Dict, Any, Optional
from osgeo import gdal, ogr, osr

def audit_layer_integrity(layer_path: str) -> Dict[str, Any]:
    """
    Audit file integrity, format driver, spatial reference, and geometry/band validity.
    """
    if not os.path.exists(layer_path):
        return {"valid": False, "error": f"File does not exist: {layer_path}"}
        
    ext = os.path.splitext(layer_path)[1].lower()
    is_raster = ext in (".tif", ".tiff", ".vrt", ".img", ".asc")
    
    issues = []
    metadata = {"path": layer_path, "file_size_bytes": os.path.getsize(layer_path)}
    
    if is_raster:
        ds = gdal.Open(layer_path, gdal.GA_ReadOnly)
        if not ds:
            return {"valid": False, "error": "GDAL could not open raster file (corrupted or unsupported format)."}
            
        proj = ds.GetProjection()
        if not proj:
            issues.append("Missing coordinate reference system (CRS / Projection WKT is empty).")
        gt = ds.GetGeoTransform(can_return_null=True)
        if not gt:
            issues.append("Missing affine geotransform.")
            
        metadata["driver"] = ds.GetDriver().ShortName
        metadata["dimensions"] = (ds.RasterXSize, ds.RasterYSize)
        metadata["bands"] = ds.RasterCount
        
        for b_idx in range(1, ds.RasterCount + 1):
            band = ds.GetRasterBand(b_idx)
            nd = band.GetNoDataValue()
            if nd is None:
                issues.append(f"Band {b_idx} has no designated NoData value.")
        ds = None
    else:
        v_ds = ogr.Open(layer_path, 0)
        if not v_ds:
            return {"valid": False, "error": "OGR could not open vector dataset."}
        metadata["driver"] = v_ds.GetDriver().GetName()
        metadata["layer_count"] = v_ds.GetLayerCount()
        
        lyr = v_ds.GetLayer(0)
        if lyr:
            metadata["feature_count"] = lyr.GetFeatureCount()
            srs = lyr.GetSpatialRef()
            if not srs:
                issues.append("Vector layer missing spatial reference system (SRS).")
            # Sample first 100 features for geometry nulls
            null_count = 0
            for i, f in enumerate(lyr):
                if i >= 100:
                    break
                geom = f.GetGeometryRef()
                if not geom or geom.IsEmpty():
                    null_count += 1
            if null_count > 0:
                issues.append(f"{null_count} null or empty geometries detected in first 100 features.")
        v_ds = None
        
    return {
        "valid": len(issues) == 0,
        "is_raster": is_raster,
        "metadata": metadata,
        "issues_count": len(issues),
        "issues": issues
    }

def audit_raster_alignment(raster_paths: List[str]) -> Dict[str, Any]:
    """
    Audit multiple rasters for identical grid cell sizes, dimensions, and CRS.
    """
    if len(raster_paths) < 2:
        return {"compatible": True, "details": "Fewer than 2 rasters; nothing to align."}
        
    ref_path = raster_paths[0]
    ref_ds = gdal.Open(ref_path, gdal.GA_ReadOnly)
    if not ref_ds:
        return {"compatible": False, "error": f"Could not open reference raster: {ref_path}"}
        
    ref_gt = ref_ds.GetGeoTransform()
    ref_w, ref_h = ref_ds.RasterXSize, ref_ds.RasterYSize
    ref_proj = ref_ds.GetProjection()
    ref_srs = osr.SpatialReference(ref_proj)
    ref_auth = f"{ref_srs.GetAuthorityName(None)}:{ref_srs.GetAuthorityCode(None)}" if ref_srs else "UNKNOWN"
    ref_ds = None
    
    mismatches = []
    for p in raster_paths[1:]:
        ds = gdal.Open(p, gdal.GA_ReadOnly)
        if not ds:
            mismatches.append(f"{p}: Could not open dataset.")
            continue
        gt = ds.GetGeoTransform()
        w, h = ds.RasterXSize, ds.RasterYSize
        srs = osr.SpatialReference(ds.GetProjection())
        auth = f"{srs.GetAuthorityName(None)}:{srs.GetAuthorityCode(None)}" if srs else "UNKNOWN"
        
        if w != ref_w or h != ref_h:
            mismatches.append(f"{os.path.basename(p)}: Dimensions mismatch ({w}x{h} vs {ref_w}x{ref_h}).")
        if abs(gt[1] - ref_gt[1]) > 1e-5 or abs(gt[5] - ref_gt[5]) > 1e-5:
            mismatches.append(f"{os.path.basename(p)}: Pixel resolution mismatch ({gt[1]},{gt[5]} vs {ref_gt[1]},{ref_gt[5]}).")
        if abs(gt[0] - ref_gt[0]) > 1e-4 or abs(gt[3] - ref_gt[3]) > 1e-4:
            mismatches.append(f"{os.path.basename(p)}: Origin extent mismatch ({gt[0]},{gt[3]} vs {ref_gt[0]},{ref_gt[3]}).")
        if auth != ref_auth:
            mismatches.append(f"{os.path.basename(p)}: CRS mismatch ({auth} vs {ref_auth}).")
        ds = None
        
    return {
        "compatible": len(mismatches) == 0,
        "reference": {
            "path": ref_path,
            "dimensions": (ref_w, ref_h),
            "cell_size": (ref_gt[1], abs(ref_gt[5])),
            "crs": ref_auth
        },
        "mismatches_count": len(mismatches),
        "mismatches": mismatches
    }

def audit_vector_geometry(vector_path: str) -> Dict[str, Any]:
    """
    Check vector topology: invalid geometries, self-intersections, slivers, duplicate vertices.
    """
    v_ds = ogr.Open(vector_path, 0)
    if not v_ds:
        return {"valid": False, "error": f"Could not open vector dataset: {vector_path}"}
    lyr = v_ds.GetLayer(0)
    
    invalid_ids = []
    empty_ids = []
    sliver_ids = []
    
    for feat in lyr:
        fid = feat.GetFID()
        geom = feat.GetGeometryRef()
        if not geom:
            empty_ids.append(fid)
            continue
        if geom.IsEmpty():
            empty_ids.append(fid)
            continue
        if not geom.IsValid():
            invalid_ids.append(fid)
            
        # Sliver test for polygons: thin elongation metric P^2 / A > 1000
        if geom.GetGeometryType() in (ogr.wkbPolygon, ogr.wkbMultiPolygon):
            area = geom.GetArea()
            perimeter = geom.Boundary().Length() if geom.Boundary() else 0.0
            if area > 0 and (perimeter ** 2 / area) > 1000.0:
                sliver_ids.append(fid)
                
    v_ds = None
    return {
        "total_features": lyr.GetFeatureCount() if lyr else 0,
        "invalid_geometry_count": len(invalid_ids),
        "invalid_feature_fids": invalid_ids[:50],
        "empty_geometry_count": len(empty_ids),
        "sliver_geometry_count": len(sliver_ids),
        "is_topologically_clean": len(invalid_ids) == 0 and len(empty_ids) == 0
    }

def algorithm_preflight(
    algorithm_id: str,
    parameters: Dict[str, Any],
    check_disk_space_mb: float = 100.0
) -> Dict[str, Any]:
    """
    Preflight validator for input parameters, file existence, and disk storage.
    """
    issues = []
    # Check disk space on default temp drive
    try:
        total, used, free = shutil.disk_usage(".")
        free_mb = free / (1024 * 1024)
        if free_mb < check_disk_space_mb:
            issues.append(f"Low disk space on workspace: {free_mb:.1f} MB remaining (recommended at least {check_disk_space_mb} MB).")
    except Exception:
        pass
        
    # Check input paths
    for k, v in parameters.items():
        if isinstance(v, str) and ("path" in k.lower() or "input" in k.lower() or "raster" in k.lower() or "vector" in k.lower()):
            if not v.startswith("memory:") and not os.path.exists(v):
                issues.append(f"Parameter '{k}' specifies a file that does not exist: {v}")
                
    return {
        "algorithm_id": algorithm_id,
        "ready_to_run": len(issues) == 0,
        "issues_count": len(issues),
        "issues": issues
    }


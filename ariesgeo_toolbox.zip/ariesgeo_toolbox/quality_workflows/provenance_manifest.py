"""
Scientific manifest exporter and JSON audit trail generation.
"""

import os
import json
from typing import Dict, Any, Optional
from ..core.provenance import create_provenance_record, write_provenance_json

def export_provenance_manifest(
    workflow_name: str,
    steps_records: list,
    output_path: str,
    extra_metadata: Optional[Dict[str, Any]] = None
) -> str:
    """
    Export a structured workflow execution manifest containing all steps,
    parameters, input/output file hashes, and reproducibility details.
    """
    manifest = {
        "workflow_name": workflow_name,
        "format_version": "AriesGeo-Manifest-v4",
        "total_steps": len(steps_records),
        "steps": steps_records,
        "environment": {
            "os": os.name,
            "platform": "QGIS Desktop / PyQGIS"
        },
        "metadata": extra_metadata or {}
    }
    
    os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2, ensure_ascii=False)
        
    return output_path


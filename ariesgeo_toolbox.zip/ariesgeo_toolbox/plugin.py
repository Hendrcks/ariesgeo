"""
Main plugin lifecycle class for AriesGeo Toolbox v4.0.
"""

from typing import List
from qgis.PyQt.QtWidgets import (
    QAction, QMenu, QMessageBox, QDialog, QVBoxLayout,
    QHBoxLayout, QLabel, QPushButton, QTextBrowser
)
from qgis.PyQt.QtCore import Qt
from qgis.gui import QgisInterface
from qgis.core import QgsApplication
from .resources import get_icon, get_logo_pixmap
from .ui.place_finder_dock import PlaceFinderDock
from .ui.mosaic_wizard import MosaicWizardDialog
from .ui.gapfill_wizard import AriesGapfillWizardDialog
from .ui.cloud_remover_dialog import CloudRemoverDialog
from .ui.terrain_hydrology_dialog import TerrainHydrologyDialog
from .ui.settings_dialog import SettingsDialog
from .processing_provider.provider import AriesGeoProcessingProvider
from .core.logging import log_info


class AriesGeoPlugin:
    """Main QGIS plugin class for AriesGeo Toolbox v4.0."""

    def __init__(self, iface: QgisInterface):
        self.iface = iface
        self.actions: List[QAction] = []
        self.menu: QMenu = None
        self.toolbar = None
        self.dock_widget: PlaceFinderDock = None
        self.provider: AriesGeoProcessingProvider = None

    def initGui(self):
        """Create the menu entries, toolbar actions, and dock widgets."""
        # 1. Processing Provider (Registers 100 Scientific Algorithms)
        self.provider = AriesGeoProcessingProvider()
        QgsApplication.processingRegistry().addProvider(self.provider)

        # 2. Toolbar
        self.toolbar = self.iface.addToolBar("AriesGeo Toolbox")
        self.toolbar.setObjectName("AriesGeoToolboxToolbar")

        # 3. Actions
        # Action: Place Finder
        self.act_place_finder = QAction(
            get_icon("place_finder"),
            "Aries Place Finder",
            self.iface.mainWindow()
        )
        self.act_place_finder.setToolTip("Open Aries Place Finder search dock")
        self.act_place_finder.triggered.connect(self.toggle_place_finder_dock)
        self._add_action(self.act_place_finder)

        # Action: Mosaic Wizard
        self.act_mosaic = QAction(
            get_icon("mosaic"),
            "Aries Mosaic Wizard...",
            self.iface.mainWindow()
        )
        self.act_mosaic.setToolTip("Open guided Raster Mosaic Wizard")
        self.act_mosaic.triggered.connect(self.open_mosaic_wizard)
        self._add_action(self.act_mosaic)

        # Action: AriesGapfill (Landsat 7 SLC-off & Spatial)
        self.act_gapfill = QAction(
            get_icon("gapfill"),
            "AriesGapfill (Landsat & Raster)...",
            self.iface.mainWindow()
        )
        self.act_gapfill.setToolTip("Open AriesGapfill: Single Triangulation, Global/Local Matching, and Multi-Donor Composite")
        self.act_gapfill.triggered.connect(self.open_gapfill_wizard)
        self._add_action(self.act_gapfill)

        # Action: Cloud Remover
        self.act_cloud = QAction(
            get_icon("cloud"),
            "Aries Cloud Remover...",
            self.iface.mainWindow()
        )
        self.act_cloud.setToolTip("Detect and remove clouds and shadows from imagery")
        self.act_cloud.triggered.connect(self.open_cloud_dialog)
        self._add_action(self.act_cloud)

        # Action: Terrain & Hydrology Toolkit
        self.act_terrain = QAction(
            get_icon("terrain"),
            "Aries Terrain & Hydrology...",
            self.iface.mainWindow()
        )
        self.act_terrain.setToolTip("Preflight elevation diagnostics, slope/aspect/hillshade, flow routing, and watershed delineation")
        self.act_terrain.triggered.connect(self.open_terrain_dialog)
        self._add_action(self.act_terrain)

        # Action: Open Processing Toolbox
        self.act_toolbox = QAction(
            get_icon("icon"),
            "AriesGeo Processing Toolbox (100 Algorithms)...",
            self.iface.mainWindow()
        )
        self.act_toolbox.setToolTip("Open QGIS Processing Toolbox with AriesGeo 100 algorithms")
        self.act_toolbox.triggered.connect(self.open_processing_toolbox)
        self._add_action(self.act_toolbox)

        # Action: Settings
        self.act_settings = QAction(
            get_icon("settings"),
            "Settings & Preferences...",
            self.iface.mainWindow()
        )
        self.act_settings.setToolTip("Configure AriesGeo Toolbox settings")
        self.act_settings.triggered.connect(self.open_settings_dialog)
        self._add_action(self.act_settings)

        # Action: About
        self.act_about = QAction(
            get_icon("icon"),
            "About AriesGeo Toolbox",
            self.iface.mainWindow()
        )
        self.act_about.triggered.connect(self.show_about_dialog)
        self.actions.append(self.act_about)

        # 4. Main Menu Bar entry: "AriesGeo"
        self.menu = QMenu("&AriesGeo", self.iface.mainWindow())
        self.menu.addAction(self.act_place_finder)
        self.menu.addSeparator()
        self.menu.addAction(self.act_mosaic)
        self.menu.addAction(self.act_gapfill)
        self.menu.addAction(self.act_cloud)
        self.menu.addAction(self.act_terrain)
        self.menu.addSeparator()
        self.menu.addAction(self.act_toolbox)
        self.menu.addSeparator()
        self.menu.addAction(self.act_settings)
        self.menu.addAction(self.act_about)
        self.iface.mainWindow().menuBar().addMenu(self.menu)

        # 5. Place Finder Dock
        self.dock_widget = PlaceFinderDock(self.iface.mapCanvas(), self.iface.mainWindow())
        self.iface.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, self.dock_widget)
        self.dock_widget.hide()

        log_info("AriesGeo Toolbox v4.0 (100 Scientific Algorithms) initialized successfully.")

    def _add_action(self, action: QAction):
        self.toolbar.addAction(action)
        self.actions.append(action)

    def toggle_place_finder_dock(self):
        """Toggle visibility of the Place Finder dock widget."""
        if self.dock_widget:
            if self.dock_widget.isVisible():
                self.dock_widget.hide()
            else:
                self.dock_widget.show()
                self.dock_widget.raise_()

    def open_mosaic_wizard(self):
        """Open the guided Mosaic Wizard dialog."""
        dlg = MosaicWizardDialog(self.iface.mainWindow())
        dlg.exec()

    def open_gapfill_wizard(self):
        """Open the guided AriesGapfill Wizard dialog."""
        dlg = AriesGapfillWizardDialog(self.iface.mainWindow())
        dlg.exec()

    open_gapfill_dialog = open_gapfill_wizard

    def open_cloud_dialog(self):
        """Open the Cloud Cover Remover dialog."""
        dlg = CloudRemoverDialog(self.iface.mainWindow())
        dlg.exec()

    def open_terrain_dialog(self):
        """Open the Terrain & Hydrology Toolkit dialog."""
        dlg = TerrainHydrologyDialog(canvas=self.iface.mapCanvas(), parent=self.iface.mainWindow())
        dlg.exec()

    def open_processing_toolbox(self):
        """Open and focus QGIS Processing Toolbox."""
        try:
            from qgis.utils import iface
            # Trigger standard Processing Toolbox action in QGIS
            for act in iface.mainWindow().findChildren(QAction):
                if act.objectName() == "mActionShowProcessingToolbox" or "Processing Toolbox" in act.text():
                    act.trigger()
                    return
        except Exception:
            pass

    def open_settings_dialog(self):
        """Open plugin settings dialog."""
        dlg = SettingsDialog(self.iface.mainWindow())
        dlg.exec()

    def show_about_dialog(self):
        """Display modernized About dialog with new AriesGeo branding and v4.0 details."""
        dlg = QDialog(self.iface.mainWindow())
        dlg.setWindowTitle("About AriesGeo Toolbox")
        dlg.resize(520, 560)

        layout = QVBoxLayout(dlg)

        # Brand Banner Logo
        logo_label = QLabel()
        logo_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        pix = get_logo_pixmap(width=340)
        if not pix.isNull():
            logo_label.setPixmap(pix)
        layout.addWidget(logo_label)

        # Details text browser
        browser = QTextBrowser()
        browser.setOpenExternalLinks(True)
        html = """
        <div style="font-family: -apple-system, sans-serif; text-align: center; margin-top: 8px;">
            <h2 style="margin: 0; color: #0284c7;">AriesGeo Toolbox</h2>
            <p style="margin: 4px 0; color: #64748b; font-size: 13px;"><b>Version:</b> 4.0.0 · <b>Brand:</b> AriesPlus Geospatial Solutions</p>
            <p style="margin: 4px 0; font-size: 12px;"><a href="https://ariesplus.com">https://ariesplus.com</a> · <a href="https://github.com/Hendrcks/ariesgeo">GitHub Repository</a></p>
        </div>
        <hr style="border: 0; border-top: 1px solid #e2e8f0; margin: 12px 0;"/>
        <p style="font-size: 13px; line-height: 1.5; color: #334155;">
        AriesGeo Toolbox v4.0 provides <b>100 modular Processing Toolbox algorithms</b> organized into 7 specialized scientific suites:
        </p>
        <ul style="font-size: 12px; color: #334155; line-height: 1.6; padding-left: 20px;">
            <li><b>01 · Place Finder & Geocoding:</b> Forward, reverse, batch table search, coordinate parsing (DMS/DD/UTM), proximity, and offline gazetteer.</li>
            <li><b>02 · Landsat 7 SLC-off Gapfill:</b> ETM+ metadata inspection, gap masking, donor ranking, co-registration, radiometric matching, IDW/TIN filling, multi-donor compositing, and holdout validation.</li>
            <li><b>03 · Raster Preprocessing & Cloud Removal:</b> Sensor recognition, reflectance scaling, USGS/ESA QA masks, grid alignment, multi-temporal cloud replacement, and Cloud Optimized GeoTIFF (COG) export.</li>
            <li><b>04 · Terrain & Hydrology:</b> DEM diagnostics, depression conditioning (Wang & Liu), slope, aspect, hillshade, TRI, TPI, D8/MFD routing, stream extraction, watershed delineation, and morphometry.</li>
            <li><b>05 · Spatial Statistics & Suitability:</b> Criteria standardization, Analytic Hierarchy Process (AHP) weighting, weighted/fuzzy overlay, KDE, IDW, Global & Local Moran's I (LISA), and Getis-Ord Gi*.</li>
            <li><b>06 · Data Hub & Acquisition:</b> STAC search, Landsat/Sentinel catalog discovery, OpenStreetMap extraction, and verified chunked downloads.</li>
            <li><b>07 · Quality Control & Workflows:</b> Layer integrity audits, alignment verification, preflight checks, DAG recipe execution, and SHA-256 provenance manifests.</li>
        </ul>
        <p style="font-size: 11px; color: #64748b; background: #f1f5f9; padding: 8px; border-radius: 4px; margin-top: 12px;">
        <b>Scope Note:</b> Map Layout Assistant was retired in v4.0 to focus strictly on reproducible scientific geoprocessing. Standalone spectral indices (NDVI/NDWI/etc.) reside exclusively in the separate AriesLegacy plugin.
        </p>
        """
        browser.setHtml(html)
        layout.addWidget(browser)

        btn_box = QHBoxLayout()
        btn_box.addStretch()
        ok_btn = QPushButton("Close")
        ok_btn.clicked.connect(dlg.accept)
        btn_box.addWidget(ok_btn)
        layout.addLayout(btn_box)

        dlg.exec()

    def unload(self):
        """Clean up GUI components when plugin is uninstalled or deactivated."""
        if self.provider:
            QgsApplication.processingRegistry().removeProvider(self.provider)

        for action in self.actions:
            self.iface.removePluginMenu("&AriesGeo", action)
            self.iface.removeToolBarIcon(action)

        if self.menu:
            self.menu.deleteLater()
            self.menu = None

        if self.toolbar:
            self.toolbar.deleteLater()
            self.toolbar = None

        if self.dock_widget:
            self.iface.removeDockWidget(self.dock_widget)
            self.dock_widget.deleteLater()
            self.dock_widget = None

        log_info("AriesGeo Toolbox v4.0 unloaded cleanly.")

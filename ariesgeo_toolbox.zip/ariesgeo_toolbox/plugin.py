"""
Main plugin lifecycle class for AriesGeo Toolbox v4.0.
"""

from typing import List
from qgis.PyQt.QtWidgets import (
    QAction,
    QMenu,
    QDialog,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QTextBrowser,
    QDockWidget,
)
from qgis.PyQt.QtCore import Qt
from qgis.gui import QgisInterface
from qgis.core import QgsApplication
from .resources import get_icon, get_logo_pixmap
from .ui.place_finder_dock import PlaceFinderDock
from .ui.mosaic_wizard import MosaicWizardDialog
from .ui.gapfill_wizard import AriesGapfillWizardDialog
from .ui.cloud_remover_dialog import CloudRemoverDialog
from .ui.terrain_hydrology_dialog import TerrainHydrologyDialog
from .ui.settings_dialog import SettingsDialog
from .processing_provider.provider import AriesGeoProcessingProvider
from .core.settings import settings
from .core.logging import log_info, log_warning


_AREA_MAP = {
    "left": Qt.DockWidgetArea.LeftDockWidgetArea,
    "right": Qt.DockWidgetArea.RightDockWidgetArea,
    "top": Qt.DockWidgetArea.TopDockWidgetArea,
    "bottom": Qt.DockWidgetArea.BottomDockWidgetArea,
}
_AREA_REV = {v: k for k, v in _AREA_MAP.items()}


class AriesGeoPlugin:
    """Main QGIS plugin class for AriesGeo Toolbox v4.0."""

    def __init__(self, iface: QgisInterface):
        self.iface = iface
        self.actions: List[QAction] = []
        self.menu: QMenu = None
        self.toolbar = None
        self.dock_widget: PlaceFinderDock = None
        self.provider: AriesGeoProcessingProvider = None
        self._cloud_dialog: CloudRemoverDialog = None
        self._gapfill_dialog: AriesGapfillWizardDialog = None

    def initGui(self):
        """Create the menu entries, toolbar actions, and tabified Place Finder dock."""
        # 1. Processing Provider (Registers 100 Scientific Algorithms)
        self.provider = AriesGeoProcessingProvider()
        QgsApplication.processingRegistry().addProvider(self.provider)

        # 2. Toolbar
        self.toolbar = self.iface.addToolBar("AriesGeo Toolbox")
        self.toolbar.setObjectName("AriesGeoToolboxToolbar")

        # 3. Actions
        # Action: Place Finder (checkable & synced with dock tab visibility)
        self.act_place_finder = QAction(
            get_icon("place_finder"),
            "Place Finder",
            self.iface.mainWindow()
        )
        self.act_place_finder.setCheckable(True)
        self.act_place_finder.setToolTip("Show or raise the Place Finder tab")
        self._add_action(self.act_place_finder)

        # Action: Mosaic Wizard
        self.act_mosaic = QAction(
            get_icon("mosaic"),
            "Aries Mosaic Wizard...",
            self.iface.mainWindow()
        )
        self.act_mosaic.setToolTip("Open guided Raster Mosaic Wizard")
        self.act_mosaic.triggered.connect(self.open_mosaic_wizard)
        self._add_action(self.act_mosaic)

        # Action: AriesGapfill (Landsat 7 SLC-off & Spatial)
        self.act_gapfill = QAction(
            get_icon("gapfill"),
            "AriesGapfill (Landsat & Raster)...",
            self.iface.mainWindow()
        )
        self.act_gapfill.setToolTip("Open AriesGapfill: Single Triangulation, Global/Local Matching, and Multi-Donor Composite")
        self.act_gapfill.triggered.connect(self.open_gapfill_wizard)
        self._add_action(self.act_gapfill)

        # Action: Cloud Remover
        self.act_cloud = QAction(
            get_icon("cloud"),
            "Aries Cloud Remover...",
            self.iface.mainWindow()
        )
        self.act_cloud.setToolTip("Detect and remove clouds and shadows from imagery")
        self.act_cloud.triggered.connect(self.open_cloud_dialog)
        self._add_action(self.act_cloud)

        # Action: Terrain & Hydrology Toolkit
        self.act_terrain = QAction(
            get_icon("terrain"),
            "Aries Terrain & Hydrology...",
            self.iface.mainWindow()
        )
        self.act_terrain.setToolTip("Preflight elevation diagnostics, slope/aspect/hillshade, flow routing, and watershed delineation")
        self.act_terrain.triggered.connect(self.open_terrain_dialog)
        self._add_action(self.act_terrain)

        # Action: Open Processing Toolbox
        self.act_toolbox = QAction(
            get_icon("icon"),
            "AriesGeo Processing Toolbox (100 Algorithms)...",
            self.iface.mainWindow()
        )
        self.act_toolbox.setToolTip("Open QGIS Processing Toolbox with AriesGeo 100 algorithms")
        self.act_toolbox.triggered.connect(self.open_processing_toolbox)
        self._add_action(self.act_toolbox)

        # Action: Settings
        self.act_settings = QAction(
            get_icon("settings"),
            "Settings & Preferences...",
            self.iface.mainWindow()
        )
        self.act_settings.setToolTip("Configure AriesGeo Toolbox settings")
        self.act_settings.triggered.connect(self.open_settings_dialog)
        self._add_action(self.act_settings)

        # Action: About
        self.act_about = QAction(
            get_icon("icon"),
            "About AriesGeo Toolbox",
            self.iface.mainWindow()
        )
        self.act_about.triggered.connect(self.show_about_dialog)
        self.actions.append(self.act_about)

        # 4. Main Menu Bar entry: "AriesGeo"
        self.menu = QMenu("&AriesGeo", self.iface.mainWindow())
        self.menu.addAction(self.act_place_finder)
        self.menu.addSeparator()
        self.menu.addAction(self.act_mosaic)
        self.menu.addAction(self.act_gapfill)
        self.menu.addAction(self.act_cloud)
        self.menu.addAction(self.act_terrain)
        self.menu.addSeparator()
        self.menu.addAction(self.act_toolbox)
        self.menu.addSeparator()
        self.menu.addAction(self.act_settings)
        self.menu.addAction(self.act_about)
        self.iface.mainWindow().menuBar().addMenu(self.menu)

        # 5. Place Finder Dock — Added directly ON THE QGIS DOCK TABS from startup
        self.dock_widget = PlaceFinderDock(self.iface.mapCanvas(), self.iface.mainWindow())
        if hasattr(self.dock_widget, "setToggleVisibilityAction"):
            self.dock_widget.setToggleVisibilityAction(self.act_place_finder)
        else:
            self.act_place_finder.triggered.connect(self.toggle_place_finder_dock)

        self._register_tabified_place_finder()
        self.dock_widget.dockLocationChanged.connect(self._on_dock_location_changed)

        log_info("AriesGeo Toolbox v4.0 (100 Scientific Algorithms) initialized successfully.")

    def _register_tabified_place_finder(self):
        """
        Place the Place Finder panel directly onto QGIS's active dock tab strip
        (alongside Layers / Browser or Processing Toolbox) from the beginning.
        """
        main_win = self.iface.mainWindow()
        saved_area_key = settings.dock_area.lower().strip()

        right_candidates = [
            "ProcessingToolbox",
            "LayerStyling",
            "IdentifyResultsDock",
            "StatisticalSummaryDockWidget",
        ]
        left_candidates = [
            "Layers",
            "Browser",
            "Browser2",
            "SpatialBookmarks",
            "LayerOrder",
        ]

        # Determine target dock area & tab peers
        target_area = None
        tab_peers: List[str] = []

        if saved_area_key in _AREA_MAP:
            target_area = _AREA_MAP[saved_area_key]
            tab_peers = right_candidates if target_area == Qt.DockWidgetArea.RightDockWidgetArea else left_candidates
        elif main_win is not None:
            # Check if Right dock area already has visible dock panels; otherwise join Left dock tabs (Layers / Browser)
            existing_docks = [
                d for d in main_win.findChildren(QDockWidget)
                if d is not self.dock_widget and not d.isFloating() and d.isVisible()
            ]
            right_visible = [
                d.objectName() for d in existing_docks
                if main_win.dockWidgetArea(d) == Qt.DockWidgetArea.RightDockWidgetArea and d.objectName()
            ]
            left_visible = [
                d.objectName() for d in existing_docks
                if main_win.dockWidgetArea(d) == Qt.DockWidgetArea.LeftDockWidgetArea and d.objectName()
            ]

            if right_visible:
                target_area = Qt.DockWidgetArea.RightDockWidgetArea
                tab_peers = right_candidates + right_visible
            elif left_visible:
                target_area = Qt.DockWidgetArea.LeftDockWidgetArea
                tab_peers = left_candidates + left_visible
            else:
                target_area = Qt.DockWidgetArea.LeftDockWidgetArea
                tab_peers = left_candidates
        else:
            target_area = Qt.DockWidgetArea.LeftDockWidgetArea
            tab_peers = left_candidates

        if hasattr(self.iface, "addTabifiedDockWidget"):
            self.iface.addTabifiedDockWidget(
                target_area,
                self.dock_widget,
                tabifyWith=tab_peers,
                raiseTab=True,
            )
        else:
            self.iface.addDockWidget(target_area, self.dock_widget)
            if main_win is not None:
                for peer_name in tab_peers:
                    peer = main_win.findChild(QDockWidget, peer_name)
                    if peer is not None and peer is not self.dock_widget:
                        main_win.tabifyDockWidget(peer, self.dock_widget)
                        break

        if settings.show_on_startup:
            self.dock_widget.show()
            if hasattr(self.dock_widget, "setUserVisible"):
                self.dock_widget.setUserVisible(True)
        else:
            self.dock_widget.hide()

    def _on_dock_location_changed(self, area: Qt.DockWidgetArea):
        area_name = _AREA_REV.get(area)
        if area_name:
            settings.dock_area = area_name

    def _add_action(self, action: QAction):
        self.toolbar.addAction(action)
        self.actions.append(action)

    def toggle_place_finder_dock(self):
        """Toggle user visibility of the tabified Place Finder dock widget."""
        if not self.dock_widget:
            return
        if hasattr(self.dock_widget, "toggleUserVisible"):
            self.dock_widget.toggleUserVisible()
        elif self.dock_widget.isVisible():
            self.dock_widget.hide()
        else:
            self.dock_widget.show()
            self.dock_widget.raise_()

    def open_mosaic_wizard(self):
        """Open the guided Mosaic Wizard dialog."""
        dlg = MosaicWizardDialog(self.iface.mainWindow())
        dlg.exec()

    def open_gapfill_wizard(self):
        """Open the guided AriesGapfill Wizard non-modally so user can interact with QGIS canvas."""
        if self._gapfill_dialog is None:
            self._gapfill_dialog = AriesGapfillWizardDialog(self.iface.mainWindow())
        else:
            self._gapfill_dialog.refresh_project_layers()
        self._gapfill_dialog.show()
        self._gapfill_dialog.raise_()
        self._gapfill_dialog.activateWindow()

    open_gapfill_dialog = open_gapfill_wizard

    def open_cloud_dialog(self):
        """Open the Cloud & SLC-Off Remover dialog non-modally."""
        if self._cloud_dialog is None:
            self._cloud_dialog = CloudRemoverDialog(self.iface.mainWindow())
        else:
            self._cloud_dialog.refresh_project_layers()
        self._cloud_dialog.show()
        self._cloud_dialog.raise_()
        self._cloud_dialog.activateWindow()

    def open_terrain_dialog(self):
        """Open the Terrain & Hydrology Toolkit dialog."""
        dlg = TerrainHydrologyDialog(canvas=self.iface.mapCanvas(), parent=self.iface.mainWindow())
        dlg.exec()

    def open_processing_toolbox(self):
        """Open and focus QGIS Processing Toolbox."""
        try:
            for act in self.iface.mainWindow().findChildren(QAction):
                if act.objectName() == "mActionShowProcessingToolbox" or "Processing Toolbox" in act.text():
                    act.trigger()
                    return
        except (AttributeError, RuntimeError) as exc:
            log_warning(f"Could not trigger Processing Toolbox action: {exc}")

    def open_settings_dialog(self):
        """Open plugin settings dialog."""
        dlg = SettingsDialog(self.iface.mainWindow())
        dlg.exec()

    def show_about_dialog(self):
        """Display theme-adaptive About dialog with AriesGeo branding and v4.0 details."""
        dlg = QDialog(self.iface.mainWindow())
        dlg.setWindowTitle("About AriesGeo Toolbox")
        dlg.resize(520, 560)

        layout = QVBoxLayout(dlg)

        logo_label = QLabel()
        logo_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        pix = get_logo_pixmap(width=340)
        if not pix.isNull():
            logo_label.setPixmap(pix)
        layout.addWidget(logo_label)

        browser = QTextBrowser()
        browser.setOpenExternalLinks(True)
        html = """
        <div style="text-align: center; margin-top: 6px;">
            <h2 style="margin: 0;">AriesGeo Toolbox</h2>
            <p style="margin: 4px 0; font-size: 13px;"><b>Version:</b> 4.0.0 · <b>Brand:</b> AriesPlus Geospatial Solutions</p>
            <p style="margin: 4px 0; font-size: 12px;"><a href="https://ariesplus.com">https://ariesplus.com</a> · <a href="https://github.com/Hendrcks/ariesgeo">GitHub Repository</a></p>
        </div>
        <hr/>
        <p style="font-size: 13px; line-height: 1.5;">
        AriesGeo Toolbox v4.0 provides <b>100 modular Processing Toolbox algorithms</b> organized into 7 specialized scientific suites:
        </p>
        <ul style="font-size: 12px; line-height: 1.6; padding-left: 20px;">
            <li><b>01 · Place Finder & Geocoding:</b> Native tabbed Place Finder panel plus forward, reverse, batch geocoding, coordinate parsing (DMS/DD/UTM), proximity, and offline gazetteer.</li>
            <li><b>02 · Landsat 7 SLC-off Gapfill:</b> ETM+ metadata inspection, gap masking, donor ranking, co-registration, radiometric matching, IDW/TIN filling, multi-donor compositing, and holdout validation.</li>
            <li><b>03 · Raster Preprocessing & Cloud Removal:</b> Sensor recognition, reflectance scaling, USGS/ESA QA masks, grid alignment, multi-temporal cloud replacement, and Cloud Optimized GeoTIFF (COG) export.</li>
            <li><b>04 · Terrain & Hydrology:</b> DEM diagnostics, depression conditioning, slope, aspect, hillshade, TRI, TPI, D8/MFD routing, stream extraction, watershed delineation, and morphometry.</li>
            <li><b>05 · Spatial Statistics & Suitability:</b> Criteria standardization, Analytic Hierarchy Process (AHP) weighting, weighted/fuzzy overlay, KDE, IDW, Global & Local Moran's I (LISA), and Getis-Ord Gi*.</li>
            <li><b>06 · Data Hub & Acquisition:</b> STAC search, Landsat/Sentinel catalog discovery, OpenStreetMap extraction, and verified chunked downloads.</li>
            <li><b>07 · Quality Control & Workflows:</b> Layer integrity audits, alignment verification, preflight checks, recipe execution, and SHA-256 provenance manifests.</li>
        </ul>
        """
        browser.setHtml(html)
        layout.addWidget(browser)

        btn_box = QHBoxLayout()
        btn_box.addStretch()
        ok_btn = QPushButton("Close")
        ok_btn.clicked.connect(dlg.accept)
        btn_box.addWidget(ok_btn)
        layout.addLayout(btn_box)

        dlg.exec()

    def unload(self):
        """Clean up GUI components when plugin is uninstalled or deactivated."""
        if self.provider:
            QgsApplication.processingRegistry().removeProvider(self.provider)

        for action in self.actions:
            self.iface.removePluginMenu("&AriesGeo", action)
            self.iface.removeToolBarIcon(action)

        if self.menu:
            self.menu.deleteLater()
            self.menu = None

        if self.toolbar:
            self.toolbar.deleteLater()
            self.toolbar = None

        if self._cloud_dialog:
            self._cloud_dialog.close()
            self._cloud_dialog.deleteLater()
            self._cloud_dialog = None

        if self._gapfill_dialog:
            self._gapfill_dialog.close()
            self._gapfill_dialog.deleteLater()
            self._gapfill_dialog = None

        if self.dock_widget:
            self.iface.removeDockWidget(self.dock_widget)
            self.dock_widget.deleteLater()
            self.dock_widget = None

        log_info("AriesGeo Toolbox v4.0 unloaded cleanly.")

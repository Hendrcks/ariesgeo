"""
Main plugin lifecycle class for AriesGeo Toolbox.
"""

from typing import List
from qgis.PyQt.QtWidgets import QAction, QMenu, QMessageBox
from qgis.PyQt.QtCore import Qt
from qgis.gui import QgisInterface
from qgis.core import QgsApplication
from .resources import get_icon
from .ui.place_finder_dock import PlaceFinderDock
from .ui.mosaic_wizard import MosaicWizardDialog
from .ui.gapfill_wizard import AriesGapfillWizardDialog
from .ui.cloud_remover_dialog import CloudRemoverDialog
from .ui.layout_assistant_wizard import MapLayoutWizardDialog
from .ui.terrain_hydrology_dialog import TerrainHydrologyDialog
from .ui.settings_dialog import SettingsDialog
from .processing_provider.provider import AriesGeoProcessingProvider
from .core.logging import log_info


class AriesGeoPlugin:
    """Main QGIS plugin class for AriesGeo Toolbox."""

    def __init__(self, iface: QgisInterface):
        self.iface = iface
        self.actions: List[QAction] = []
        self.menu: QMenu = None
        self.toolbar = None
        self.dock_widget: PlaceFinderDock = None
        self.provider: AriesGeoProcessingProvider = None

    def initGui(self):
        """Create the menu entries, toolbar actions, and dock widgets."""
        # 1. Processing Provider
        self.provider = AriesGeoProcessingProvider()
        QgsApplication.processingRegistry().addProvider(self.provider)

        # 2. Toolbar
        self.toolbar = self.iface.addToolBar("AriesGeo Toolbox")
        self.toolbar.setObjectName("AriesGeoToolboxToolbar")

        # 3. Actions
        # Action: Place Finder
        self.act_place_finder = QAction(
            get_icon("place_finder"),
            "Aries Place Finder",
            self.iface.mainWindow()
        )
        self.act_place_finder.setToolTip("Open Aries Place Finder search dock")
        self.act_place_finder.triggered.connect(self.toggle_place_finder_dock)
        self._add_action(self.act_place_finder)

        # Action: Mosaic Wizard
        self.act_mosaic = QAction(
            get_icon("mosaic"),
            "Aries Mosaic Wizard...",
            self.iface.mainWindow()
        )
        self.act_mosaic.setToolTip("Open guided Raster Mosaic Wizard")
        self.act_mosaic.triggered.connect(self.open_mosaic_wizard)
        self._add_action(self.act_mosaic)

        # Action: AriesGapfill (Landsat 7 SLC-off & Spatial)
        self.act_gapfill = QAction(
            get_icon("gapfill"),
            "AriesGapfill (Landsat & Raster)...",
            self.iface.mainWindow()
        )
        self.act_gapfill.setToolTip("Open AriesGapfill: Single Triangulation, Global/Local Matching, and Multi-Donor Composite")
        self.act_gapfill.triggered.connect(self.open_gapfill_wizard)
        self._add_action(self.act_gapfill)

        # Action: Cloud Remover
        self.act_cloud = QAction(
            get_icon("cloud"),
            "Aries Cloud Remover...",
            self.iface.mainWindow()
        )
        self.act_cloud.setToolTip("Detect and remove clouds and shadows from imagery")
        self.act_cloud.triggered.connect(self.open_cloud_dialog)
        self._add_action(self.act_cloud)

        # Action: Map Layout Assistant
        self.act_layout = QAction(
            get_icon("layout"),
            "Aries Map Layout Assistant...",
            self.iface.mainWindow()
        )
        self.act_layout.setToolTip("Create publication-ready map layouts with automated styling and quality audit")
        self.act_layout.triggered.connect(self.open_layout_wizard)
        self._add_action(self.act_layout)

        # Action: Terrain & Hydrology Toolkit
        self.act_terrain = QAction(
            get_icon("terrain"),
            "Aries Terrain & Hydrology...",
            self.iface.mainWindow()
        )
        self.act_terrain.setToolTip("Preflight elevation diagnostics, slope/aspect/hillshade, flow routing, and watershed delineation")
        self.act_terrain.triggered.connect(self.open_terrain_dialog)
        self._add_action(self.act_terrain)

        # Action: Settings
        self.act_settings = QAction(
            get_icon("settings"),
            "Settings & Preferences...",
            self.iface.mainWindow()
        )
        self.act_settings.setToolTip("Configure AriesGeo Toolbox settings")
        self.act_settings.triggered.connect(self.open_settings_dialog)
        self._add_action(self.act_settings)

        # Action: About
        self.act_about = QAction(
            get_icon("icon"),
            "About AriesGeo Toolbox",
            self.iface.mainWindow()
        )
        self.act_about.triggered.connect(self.show_about_dialog)
        self.actions.append(self.act_about)

        # 4. Main Menu Bar entry: "AriesGeo"
        self.menu = QMenu("&AriesGeo", self.iface.mainWindow())
        self.menu.addAction(self.act_place_finder)
        self.menu.addSeparator()
        self.menu.addAction(self.act_mosaic)
        self.menu.addAction(self.act_gapfill)
        self.menu.addAction(self.act_cloud)
        self.menu.addSeparator()
        self.menu.addAction(self.act_layout)
        self.menu.addAction(self.act_terrain)
        self.menu.addSeparator()
        self.menu.addAction(self.act_settings)
        self.menu.addAction(self.act_about)
        self.iface.mainWindow().menuBar().addMenu(self.menu)

        # 5. Place Finder Dock
        self.dock_widget = PlaceFinderDock(self.iface.mapCanvas(), self.iface.mainWindow())
        self.iface.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, self.dock_widget)
        self.dock_widget.hide()

        log_info("AriesGeo Toolbox & AriesGapfill initialized successfully.")

    def _add_action(self, action: QAction):
        self.toolbar.addAction(action)
        self.actions.append(action)

    def toggle_place_finder_dock(self):
        """Toggle visibility of the Place Finder dock widget."""
        if self.dock_widget:
            if self.dock_widget.isVisible():
                self.dock_widget.hide()
            else:
                self.dock_widget.show()
                self.dock_widget.raise_()

    def open_mosaic_wizard(self):
        """Open the guided Mosaic Wizard dialog."""
        dlg = MosaicWizardDialog(self.iface.mainWindow())
        dlg.exec()

    def open_gapfill_wizard(self):
        """Open the guided AriesGapfill Wizard dialog."""
        dlg = AriesGapfillWizardDialog(self.iface.mainWindow())
        dlg.exec()

    # Alias for backwards compatibility
    open_gapfill_dialog = open_gapfill_wizard

    def open_cloud_dialog(self):
        """Open the Cloud Cover Remover dialog."""
        dlg = CloudRemoverDialog(self.iface.mainWindow())
        dlg.exec()

    def open_layout_wizard(self):
        """Open the Map Layout Assistant 5-step wizard."""
        dlg = MapLayoutWizardDialog(iface=self.iface, parent=self.iface.mainWindow())
        dlg.exec()

    def open_terrain_dialog(self):
        """Open the Terrain & Hydrology Toolkit dialog."""
        dlg = TerrainHydrologyDialog(canvas=self.iface.mapCanvas(), parent=self.iface.mainWindow())
        dlg.exec()

    def open_settings_dialog(self):
        """Open plugin settings dialog."""
        dlg = SettingsDialog(self.iface.mainWindow())
        dlg.exec()

    def show_about_dialog(self):
        """Display About dialog."""
        QMessageBox.about(
            self.iface.mainWindow(),
            "About AriesGeo Toolbox",
            "<h3>AriesGeo Toolbox</h3>"
            "<p><b>Version:</b> 0.2.0<br/>"
            "<b>Brand:</b> AriesPlus<br/>"
            "<b>Website:</b> <a href='https://ariesplus.com'>https://ariesplus.com</a></p>"
            "<p>A precision geospatial productivity suite for QGIS Desktop providing:</p>"
            "<ul>"
            "<li><b>Aries Place Finder:</b> Forward & reverse geocoding, extent biasing, batch table search.</li>"
            "<li><b>AriesGapfill:</b> State-of-the-art Landsat 7 ETM+ SLC-off recovery and raster gap filling (Single Triangulation, Global Matching, Local Moving Window, Multi-Donor Smart Composite).</li>"
            "<li><b>Aries Mosaic & Cloud Remover:</b> Preflight raster inspector, VRT & permanent GeoTIFF mosaics, and multi-temporal cloud & shadow removal.</li>"
            "<li><b>Aries Map Layout Assistant:</b> 5-step layout composer, professional cartographic templates, coordinate grids, and preflight quality auditor.</li>"
            "<li><b>Aries Terrain & Hydrology:</b> Preflight DEM diagnostics, terrain derivatives (slope, aspect, hillshade, contours, TRI), depression filling, D8 flow routing, and watershed delineation.</li>"
            "<li><b>Processing Toolbox Integration:</b> 20 reusable batch algorithms.</li>"
            "</ul>"
            "<p><i>Find faster. Mosaic better. Repair seamlessly. Map with elegance. Flow with precision.</i></p>"
        )

    def unload(self):
        """Clean up GUI components when plugin is uninstalled or deactivated."""
        if self.provider:
            QgsApplication.processingRegistry().removeProvider(self.provider)

        for action in self.actions:
            self.iface.removePluginMenu("&AriesGeo", action)
            self.iface.removeToolBarIcon(action)

        if self.menu:
            self.menu.deleteLater()
            self.menu = None

        if self.toolbar:
            self.toolbar.deleteLater()
            self.toolbar = None

        if self.dock_widget:
            self.iface.removeDockWidget(self.dock_widget)
            self.dock_widget.deleteLater()
            self.dock_widget = None

        log_info("AriesGeo Toolbox unloaded cleanly.")

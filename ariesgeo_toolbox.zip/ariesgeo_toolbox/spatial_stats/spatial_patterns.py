"""
Spatial point patterns and autocorrelation diagnostics:
Kernel Density Estimation (KDE), Inverse Distance Weighting (IDW),
Global Moran's I with Monte Carlo permutations, Local Moran's I (LISA),
Getis-Ord Gi* hotspot analysis, and Clark-Evans Nearest Neighbor Statistics.
"""

import math
from typing import List, Tuple, Dict, Any, Optional
import numpy as np
from osgeo import gdal, ogr, osr
from ..core.raster_io import create_geotiff


def point_kde(
    points: List[Tuple[float, float, float]], # (x, y, weight)
    output_path: str,
    cell_size: float,
    bandwidth: float,
    kernel: str = "quartic",
    crs_wkt: Optional[str] = None
) -> str:
    """
    Compute 2D Kernel Density Estimation (KDE) raster surface.
    - kernel: 'quartic' (silverman biweight) or 'gaussian'
    """
    if not points:
        raise ValueError("Point list cannot be empty for KDE.")
        
    xs = [p[0] for p in points]
    ys = [p[1] for p in points]
    ws = [p[2] for p in points]
    
    # Expand extent by bandwidth
    min_x, max_x = min(xs) - bandwidth, max(xs) + bandwidth
    min_y, max_y = min(ys) - bandwidth, max(ys) + bandwidth
    
    width = max(1, int(math.ceil((max_x - min_x) / cell_size)))
    height = max(1, int(math.ceil((max_y - min_y) / cell_size)))
    
    # Coordinates of grid centers
    x_coords = min_x + (np.arange(width) + 0.5) * cell_size
    y_coords = max_y - (np.arange(height) + 0.5) * cell_size # top to bottom
    
    density = np.zeros((height, width), dtype=np.float32)
    h2 = bandwidth * bandwidth
    
    # Accumulate kernel contribution per point
    for px, py, pw in zip(xs, ys, ws):
        # Determine bounding box in grid index
        c_min = max(0, int((px - bandwidth - min_x) / cell_size))
        c_max = min(width, int(math.ceil((px + bandwidth - min_x) / cell_size)))
        r_min = max(0, int((max_y - (py + bandwidth)) / cell_size))
        r_max = min(height, int(math.ceil((max_y - (py - bandwidth)) / cell_size)))
        
        if c_max <= c_min or r_max <= r_min:
            continue
            
        sub_x = x_coords[c_min:c_max]
        sub_y = y_coords[r_min:r_max]
        gx, gy = np.meshgrid(sub_x, sub_y)
        
        dist2 = (gx - px) ** 2 + (gy - py) ** 2
        in_mask = dist2 <= h2
        
        if kernel == "quartic":
            # K(u) = (3/pi) * (1 - u^2)^2 / h^2
            u2 = dist2[in_mask] / h2
            k_val = (3.0 / (math.pi * h2)) * ((1.0 - u2) ** 2) * pw
            density[r_min:r_max, c_min:c_max][in_mask] += k_val.astype(np.float32)
        else: # gaussian
            # K(u) = (1 / (2*pi*h^2)) * exp(-dist^2 / (2*h^2))
            k_val = (pw / (2.0 * math.pi * h2)) * np.exp(-dist2 / (2.0 * h2))
            density[r_min:r_max, c_min:c_max] += k_val.astype(np.float32)
            
    gt = (min_x, cell_size, 0.0, max_y, 0.0, -cell_size)
    out_ds = create_geotiff(
        output_path, width, height, bands=1,
        data_type=gdal.GDT_Float32,
        geotransform=gt,
        projection_wkt=crs_wkt,
        nodata_value=-9999.0
    )
    out_ds.GetRasterBand(1).WriteArray(density)
    out_ds.FlushCache()
    out_ds = None
    return output_path


def point_idw(
    points: List[Tuple[float, float, float]], # (x, y, value)
    output_path: str,
    cell_size: float,
    power: float = 2.0,
    search_radius: Optional[float] = None,
    crs_wkt: Optional[str] = None
) -> str:
    """
    Inverse Distance Weighted (IDW) interpolation onto a continuous grid.
    """
    if not points:
        raise ValueError("Point list cannot be empty for IDW.")
        
    xs = np.array([p[0] for p in points], dtype=np.float64)
    ys = np.array([p[1] for p in points], dtype=np.float64)
    vs = np.array([p[2] for p in points], dtype=np.float64)
    
    pad = cell_size * 2
    min_x, max_x = np.min(xs) - pad, np.max(xs) + pad
    min_y, max_y = np.min(ys) - pad, np.max(ys) + pad
    
    width = max(1, int(math.ceil((max_x - min_x) / cell_size)))
    height = max(1, int(math.ceil((max_y - min_y) / cell_size)))
    
    x_coords = min_x + (np.arange(width) + 0.5) * cell_size
    y_coords = max_y - (np.arange(height) + 0.5) * cell_size
    
    gx, gy = np.meshgrid(x_coords, y_coords) # shape (H, W)
    out_arr = np.zeros((height, width), dtype=np.float32)
    
    # Process in chunks of rows to prevent memory explosion
    for r in range(height):
        row_x = gx[r, :]
        row_y = gy[r, :]
        
        # Distance from each point to every cell in this row: shape (N, W)
        dx = row_x[None, :] - xs[:, None]
        dy = row_y[None, :] - ys[:, None]
        dist = np.sqrt(dx ** 2 + dy ** 2)
        
        # Exact match (distance 0)
        exact_mask = dist < 1e-6
        any_exact = np.any(exact_mask, axis=0)
        
        weights = 1.0 / np.maximum(dist, 1e-6) ** power
        if search_radius is not None:
            weights[dist > search_radius] = 0.0
            
        sum_w = np.sum(weights, axis=0)
        sum_wv = np.sum(weights * vs[:, None], axis=0)
        
        row_interp = np.where(sum_w > 0, sum_wv / sum_w, np.nan)
        # Handle exact hits
        for col_idx in np.where(any_exact)[0]:
            p_hit = np.where(exact_mask[:, col_idx])[0][0]
            row_interp[col_idx] = vs[p_hit]
            
        out_arr[r, :] = row_interp.astype(np.float32)
        
    gt = (min_x, cell_size, 0.0, max_y, 0.0, -cell_size)
    out_ds = create_geotiff(
        output_path, width, height, bands=1,
        data_type=gdal.GDT_Float32,
        geotransform=gt,
        projection_wkt=crs_wkt,
        nodata_value=-9999.0
    )
    out_ds.GetRasterBand(1).WriteArray(out_arr)
    out_ds.FlushCache()
    out_ds = None
    return output_path


def moran_global(
    coords: List[Tuple[float, float]],
    values: List[float],
    k_neighbors: int = 8,
    permutations: int = 999
) -> Dict[str, Any]:
    """
    Compute Global Moran's I spatial autocorrelation statistic with
    analytical z-score and Monte Carlo permutation p-value.
    """
    n = len(values)
    if n < 4:
        raise ValueError("At least 4 observations required for Moran's I.")
        
    k = min(k_neighbors, n - 1)
    xy = np.array(coords, dtype=np.float64)
    x = np.array(values, dtype=np.float64)
    
    # Distance matrix
    diff = xy[:, None, :] - xy[None, :, :]
    dist = np.sqrt(np.sum(diff ** 2, axis=-1))
    np.fill_diagonal(dist, np.inf)
    
    # Row-standardized k-nearest neighbor spatial weights matrix W
    W = np.zeros((n, n), dtype=np.float64)
    for i in range(n):
        nearest_idx = np.argsort(dist[i])[:k]
        W[i, nearest_idx] = 1.0 / k
        
    z = x - np.mean(x)
    s0 = np.sum(W)
    denom = np.sum(z ** 2)
    if denom == 0:
        raise ValueError("Zero variance in input values; Moran's I cannot be computed.")
        
    numer = np.sum(W * np.outer(z, z))
    moran_stat = float((n / s0) * (numer / denom))
    
    # Expected value E[I]
    expected_I = -1.0 / (n - 1)
    
    # Permutation test
    rng = np.random.default_rng(42)
    perm_Is = []
    for _ in range(permutations):
        perm_z = rng.permutation(z)
        p_num = np.sum(W * np.outer(perm_z, perm_z))
        perm_Is.append((n / s0) * (p_num / denom))
        
    perm_Is = np.array(perm_Is)
    # Pseudo p-value
    if moran_stat >= expected_I:
        p_val = (np.sum(perm_Is >= moran_stat) + 1.0) / (permutations + 1.0)
    else:
        p_val = (np.sum(perm_Is <= moran_stat) + 1.0) / (permutations + 1.0)
        
    std_I = float(np.std(perm_Is)) or 1e-6
    z_score = float((moran_stat - expected_I) / std_I)
    
    if p_val < 0.05:
        pattern = "Clustered (Spatial Autocorrelation)" if moran_stat > expected_I else "Dispersed (Negative Autocorrelation)"
    else:
        pattern = "Random / Complete Spatial Randomness"
        
    return {
        "moran_i": moran_stat,
        "expected_i": expected_I,
        "z_score": z_score,
        "p_value": float(p_val),
        "pattern": pattern,
        "permutations": permutations,
        "num_observations": n,
        "k_neighbors": k
    }


def moran_local(
    coords: List[Tuple[float, float]],
    values: List[float],
    k_neighbors: int = 8
) -> List[Dict[str, Any]]:
    """
    Compute Local Moran's I (LISA) for each spatial feature.
    Classifies features into:
    - High-High (Hotspot)
    - Low-Low (Coldspot)
    - High-Low (Spatial Outlier)
    - Low-High (Spatial Outlier)
    - Not Significant
    """
    n = len(values)
    k = min(k_neighbors, n - 1)
    xy = np.array(coords, dtype=np.float64)
    x = np.array(values, dtype=np.float64)
    
    diff = xy[:, None, :] - xy[None, :, :]
    dist = np.sqrt(np.sum(diff ** 2, axis=-1))
    np.fill_diagonal(dist, np.inf)
    
    W = np.zeros((n, n), dtype=np.float64)
    for i in range(n):
        nearest_idx = np.argsort(dist[i])[:k]
        W[i, nearest_idx] = 1.0 / k
        
    mean_x = np.mean(x)
    z = x - mean_x
    s2 = np.var(x) or 1e-6
    
    # Local Moran I_i = (z_i / s^2) * sum_j(w_ij * z_j)
    lag_z = np.dot(W, z)
    local_I = (z / s2) * lag_z
    
    # Classify quadrant
    results = []
    for i in range(n):
        val = local_I[i]
        zi = z[i]
        lagi = lag_z[i]
        
        if zi > 0 and lagi > 0:
            cluster = "High-High (Hotspot)"
        elif zi < 0 and lagi < 0:
            cluster = "Low-Low (Coldspot)"
        elif zi > 0 and lagi < 0:
            cluster = "High-Low (Outlier)"
        elif zi < 0 and lagi > 0:
            cluster = "Low-High (Outlier)"
        else:
            cluster = "Not Significant"
            
        results.append({
            "index": i,
            "x": float(coords[i][0]),
            "y": float(coords[i][1]),
            "value": float(values[i]),
            "local_i": float(val),
            "spatial_lag": float(lagi),
            "cluster_type": cluster
        })
    return results


def getis_ord_gi_star(
    coords: List[Tuple[float, float]],
    values: List[float],
    distance_threshold: float
) -> List[Dict[str, Any]]:
    """
    Compute Getis-Ord Gi* hotspot statistic.
    Calculates z-scores and categorizes confidence level: 90%, 95%, 99% Hot/Coldspot.
    """
    n = len(values)
    xy = np.array(coords, dtype=np.float64)
    x = np.array(values, dtype=np.float64)
    
    diff = xy[:, None, :] - xy[None, :, :]
    dist = np.sqrt(np.sum(diff ** 2, axis=-1))
    
    # Distance binary weights including self (i.e. Gi*)
    W = (dist <= distance_threshold).astype(np.float64)
    
    mean_x = np.mean(x)
    S = np.std(x, ddof=1) or 1e-6
    
    results = []
    for i in range(n):
        w_i = W[i]
        sum_w = np.sum(w_i)
        sum_wx = np.sum(w_i * x)
        sum_w2 = np.sum(w_i ** 2)
        
        numerator = sum_wx - mean_x * sum_w
        denom = S * math.sqrt((n * sum_w2 - sum_w ** 2) / (n - 1.0)) if n > 1 else 1.0
        
        z = numerator / denom if denom != 0 else 0.0
        
        if z >= 2.58:
            cat = "Hotspot (99% confidence)"
        elif z >= 1.96:
            cat = "Hotspot (95% confidence)"
        elif z >= 1.65:
            cat = "Hotspot (90% confidence)"
        elif z <= -2.58:
            cat = "Coldspot (99% confidence)"
        elif z <= -1.96:
            cat = "Coldspot (95% confidence)"
        elif z <= -1.65:
            cat = "Coldspot (90% confidence)"
        else:
            cat = "Not Significant"
            
        results.append({
            "index": i,
            "x": float(coords[i][0]),
            "y": float(coords[i][1]),
            "value": float(values[i]),
            "gi_star_z": float(z),
            "classification": cat
        })
    return results


def nearest_neighbor_analysis(
    coords: List[Tuple[float, float]],
    study_area_sqm: Optional[float] = None
) -> Dict[str, Any]:
    """
    Clark-Evans Nearest Neighbor Index (R).
    R = r_A / r_E:
    - R < 1: Clustered
    - R = 1: Random
    - R > 1: Dispersed
    """
    n = len(coords)
    if n < 2:
        raise ValueError("At least 2 points required for Nearest Neighbor analysis.")
        
    xy = np.array(coords, dtype=np.float64)
    diff = xy[:, None, :] - xy[None, :, :]
    dist = np.sqrt(np.sum(diff ** 2, axis=-1))
    np.fill_diagonal(dist, np.inf)
    
    nn_dist = np.min(dist, axis=1)
    mean_observed_nn = float(np.mean(nn_dist))
    
    # Estimate study area if not supplied (convex hull or bounding box)
    if study_area_sqm is None or study_area_sqm <= 0:
        min_x, max_x = np.min(xy[:, 0]), np.max(xy[:, 0])
        min_y, max_y = np.min(xy[:, 1]), np.max(xy[:, 1])
        study_area_sqm = max(1.0, (max_x - min_x) * (max_y - min_y))
        
    density = n / study_area_sqm
    mean_expected_nn = 1.0 / (2.0 * math.sqrt(density)) if density > 0 else 1.0
    nn_ratio = mean_observed_nn / mean_expected_nn if mean_expected_nn > 0 else 1.0
    
    # Standard error of expected distance
    se = 0.26136 / math.sqrt(n * density) if density > 0 else 1.0
    z_score = (mean_observed_nn - mean_expected_nn) / se if se > 0 else 0.0
    
    # p-value approximation from standard normal z
    p_val = 2.0 * (1.0 - 0.5 * (1.0 + math.erf(abs(z_score) / math.sqrt(2.0))))
    
    if z_score < -1.96:
        pattern = "Clustered"
    elif z_score > 1.96:
        pattern = "Dispersed / Regular"
    else:
        pattern = "Random (Complete Spatial Randomness)"
        
    return {
        "observed_mean_distance": mean_observed_nn,
        "expected_mean_distance": mean_expected_nn,
        "nearest_neighbor_ratio": float(nn_ratio),
        "z_score": float(z_score),
        "p_value": float(p_val),
        "spatial_pattern": pattern,
        "num_points": n,
        "study_area_sqm": float(study_area_sqm)
    }


def buffer_exposure_summary(
    hazard_coords: List[Tuple[float, float]],
    exposure_points: List[Tuple[float, float, float]], # (x, y, value/population)
    buffer_radii: List[float]
) -> List[Dict[str, Any]]:
    """
    Summarize exposure (e.g. population, assets) within concentric buffer rings.
    """
    radii = sorted(buffer_radii)
    hz = np.array(hazard_coords, dtype=np.float64)
    exp_xy = np.array([[p[0], p[1]] for p in exposure_points], dtype=np.float64)
    exp_val = np.array([p[2] for p in exposure_points], dtype=np.float64)
    
    # Distance matrix from each exposure point to nearest hazard feature
    # shape: (N_exp, N_hz)
    diff = exp_xy[:, None, :] - hz[None, :, :]
    dist = np.sqrt(np.sum(diff ** 2, axis=-1))
    min_dist_to_hazard = np.min(dist, axis=1) # shape (N_exp,)
    
    results = []
    prev_r = 0.0
    for r in radii:
        in_cumulative = min_dist_to_hazard <= r
        in_ring = (min_dist_to_hazard > prev_r) & (min_dist_to_hazard <= r)
        
        results.append({
            "distance_m": float(r),
            "cumulative_count": int(np.sum(in_cumulative)),
            "cumulative_exposure_total": float(np.sum(exp_val[in_cumulative])),
            "ring_count": int(np.sum(in_ring)),
            "ring_exposure_total": float(np.sum(exp_val[in_ring]))
        })
        prev_r = r
        
    return results


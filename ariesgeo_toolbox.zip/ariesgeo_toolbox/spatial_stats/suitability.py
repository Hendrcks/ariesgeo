"""
Suitability analysis and Multi-Criteria Evaluation (MCE) engines:
Criteria standardization, AHP pairwise weight calculation, Weighted Overlay,
Fuzzy membership and overlay, Sensitivity simulation, and Zonal distributions.
"""

import os
import math
import json
from typing import List, Tuple, Dict, Any, Optional
import numpy as np
from osgeo import gdal, ogr, osr
from ..core.raster_io import open_raster_dataset, create_geotiff

# Saaty Random Consistency Index (RI) table for matrix sizes 1..15
SAATY_RI = {
    1: 0.00, 2: 0.00, 3: 0.58, 4: 0.90, 5: 1.12,
    6: 1.24, 7: 1.32, 8: 1.41, 9: 1.45, 10: 1.49,
    11: 1.51, 12: 1.54, 13: 1.56, 14: 1.57, 15: 1.59
}


def calculate_ahp_weights(matrix: List[List[float]]) -> Dict[str, Any]:
    """
    Calculate Analytic Hierarchy Process (AHP) weights using the principal eigenvector.
    Also computes the Consistency Index (CI) and Consistency Ratio (CR).
    """
    n = len(matrix)
    if n == 0:
        raise ValueError("Comparison matrix cannot be empty.")
    
    A = np.array(matrix, dtype=np.float64)
    if A.shape[0] != A.shape[1]:
        raise ValueError("Pairwise comparison matrix must be square (n x n).")
    
    # Verify reciprocity: A[i][j] ~ 1 / A[j][i]
    for i in range(n):
        for j in range(n):
            if i == j and abs(A[i, j] - 1.0) > 1e-4:
                raise ValueError(f"Diagonal element ({i},{i}) must be 1.0.")
            if abs(A[i, j] * A[j, i] - 1.0) > 0.05:
                raise ValueError(f"Matrix is not reciprocal at ({i},{j}) and ({j},{i}): {A[i, j]} vs {A[j, i]}")

    # Compute eigenvalues and eigenvectors
    eigenvals, eigenvecs = np.linalg.eig(A)
    max_idx = np.argmax(np.real(eigenvals))
    lambda_max = float(np.real(eigenvals[max_idx]))
    principal_vec = np.real(eigenvecs[:, max_idx])
    
    # Normalize weights so sum = 1.0
    principal_vec = np.abs(principal_vec)
    weights = principal_vec / np.sum(principal_vec)
    
    # Consistency Index (CI)
    ci = (lambda_max - n) / (n - 1) if n > 1 else 0.0
    ri = SAATY_RI.get(n, 1.59)
    cr = ci / ri if ri > 0 else 0.0
    
    is_consistent = cr < 0.10 or n <= 2
    
    return {
        "weights": [float(w) for w in weights],
        "lambda_max": lambda_max,
        "consistency_index": float(ci),
        "random_index": float(ri),
        "consistency_ratio": float(cr),
        "is_consistent": bool(is_consistent),
        "num_criteria": n,
        "recommendation": "Weights acceptable (CR < 0.10)" if is_consistent else "Review pairwise judgments: Consistency Ratio exceeds 0.10."
    }


def standardize_raster(
    input_path: str,
    output_path: str,
    method: str = "linear",
    direction: str = "benefit",
    custom_min: Optional[float] = None,
    custom_max: Optional[float] = None,
    nodata_value: float = -9999.0
) -> str:
    """
    Standardize a criterion raster to the [0.0, 1.0] interval.
    - direction='benefit': higher input value -> higher suitability
    - direction='cost': higher input value -> lower suitability
    - method='linear', 'log', or 'sigmoid'
    """
    ds = open_raster_dataset(input_path)
    band = ds.GetRasterBand(1)
    nodata = band.GetNoDataValue()
    arr = band.ReadAsArray().astype(np.float32)
    
    valid_mask = np.ones_like(arr, dtype=bool)
    if nodata is not None:
        valid_mask &= (arr != nodata)
    valid_mask &= ~np.isnan(arr) & ~np.isinf(arr)
    
    if not np.any(valid_mask):
        raise ValueError("Input raster has no valid non-NoData pixels.")
        
    v_min = float(custom_min) if custom_min is not None else float(np.min(arr[valid_mask]))
    v_max = float(custom_max) if custom_max is not None else float(np.max(arr[valid_mask]))
    
    if v_max <= v_min:
        v_max = v_min + 1e-6
        
    out_arr = np.full_like(arr, nodata_value, dtype=np.float32)
    val = arr[valid_mask]
    
    if method == "linear":
        norm = (val - v_min) / (v_max - v_min)
        norm = np.clip(norm, 0.0, 1.0)
    elif method == "log":
        shifted = np.maximum(val - v_min + 1.0, 1.0)
        norm = np.log(shifted) / np.log(v_max - v_min + 1.0)
        norm = np.clip(norm, 0.0, 1.0)
    elif method == "sigmoid":
        mid = (v_min + v_max) / 2.0
        scale = (v_max - v_min) / 6.0 or 1.0
        norm = 1.0 / (1.0 + np.exp(-(val - mid) / scale))
    else:
        norm = np.clip((val - v_min) / (v_max - v_min), 0.0, 1.0)
        
    if direction == "cost":
        norm = 1.0 - norm
        
    out_arr[valid_mask] = norm.astype(np.float32)
    
    out_ds = create_geotiff(
        output_path,
        ds.RasterXSize,
        ds.RasterYSize,
        bands=1,
        data_type=gdal.GDT_Float32,
        geotransform=ds.GetGeoTransform(),
        projection_wkt=ds.GetProjection(),
        nodata_value=nodata_value
    )
    out_ds.GetRasterBand(1).WriteArray(out_arr)
    out_ds.FlushCache()
    out_ds = None
    ds = None
    return output_path


def weighted_linear_combination(
    criteria_weights: List[Tuple[str, float]],
    output_path: str,
    nodata_value: float = -9999.0
) -> str:
    """
    Weighted Linear Combination (WLC) overlay:
    Suitability S(x) = sum(w_i * c_i(x)) where sum(w_i) = 1.0.
    """
    if not criteria_weights:
        raise ValueError("Criteria weights list cannot be empty.")
        
    # Normalize weights so sum is 1.0
    total_w = sum(w for _, w in criteria_weights)
    if total_w <= 0:
        raise ValueError("Sum of weights must be positive.")
    norm_cw = [(p, w / total_w) for p, w in criteria_weights]
    
    # Read first raster as reference
    ref_path = norm_cw[0][0]
    ref_ds = open_raster_dataset(ref_path)
    width, height = ref_ds.RasterXSize, ref_ds.RasterYSize
    gt = ref_ds.GetGeoTransform()
    proj = ref_ds.GetProjection()
    ref_ds = None
    
    composite = np.zeros((height, width), dtype=np.float32)
    valid_any = np.ones((height, width), dtype=bool)
    
    for path, weight in norm_cw:
        ds = open_raster_dataset(path)
        if ds.RasterXSize != width or ds.RasterYSize != height:
            raise ValueError(f"Raster {path} dimensions ({ds.RasterXSize}x{ds.RasterYSize}) mismatch reference ({width}x{height}). Align grids first.")
        band = ds.GetRasterBand(1)
        nd = band.GetNoDataValue()
        arr = band.ReadAsArray().astype(np.float32)
        
        m = np.ones_like(arr, dtype=bool)
        if nd is not None:
            m &= (arr != nd)
        m &= ~np.isnan(arr) & ~np.isinf(arr)
        
        valid_any &= m
        composite += np.where(m, arr * weight, 0.0)
        ds = None
        
    out_arr = np.where(valid_any, composite, nodata_value).astype(np.float32)
    
    out_ds = create_geotiff(
        output_path,
        width,
        height,
        bands=1,
        data_type=gdal.GDT_Float32,
        geotransform=gt,
        projection_wkt=proj,
        nodata_value=nodata_value
    )
    out_ds.GetRasterBand(1).WriteArray(out_arr)
    out_ds.FlushCache()
    out_ds = None
    return output_path


def fuzzy_membership(
    input_path: str,
    output_path: str,
    function_type: str = "linear",
    a: float = 0.0,
    b: float = 1.0,
    c: Optional[float] = None,
    d: Optional[float] = None,
    nodata_value: float = -9999.0
) -> str:
    """
    Transform raster to fuzzy membership [0.0, 1.0].
    Functions: 'linear', 'sigmoid', 'gaussian', 'trapezoidal'
    """
    ds = open_raster_dataset(input_path)
    band = ds.GetRasterBand(1)
    nd = band.GetNoDataValue()
    arr = band.ReadAsArray().astype(np.float32)
    
    valid = np.ones_like(arr, dtype=bool)
    if nd is not None:
        valid &= (arr != nd)
    valid &= ~np.isnan(arr) & ~np.isinf(arr)
    
    mu = np.zeros_like(arr, dtype=np.float32)
    x = arr[valid]
    
    if function_type == "linear":
        denom = b - a if b != a else 1e-6
        mu_val = (x - a) / denom
        mu_val = np.clip(mu_val, 0.0, 1.0)
    elif function_type == "sigmoid":
        # a = inflection point, b = slope
        slope = b if b != 0 else 1.0
        mu_val = 1.0 / (1.0 + np.exp(-slope * (x - a)))
    elif function_type == "gaussian":
        # a = midpoint (mean), b = spread (sigma)
        sigma = b if b != 0 else 1.0
        mu_val = np.exp(-((x - a) ** 2) / (2.0 * sigma * sigma))
    elif function_type == "trapezoidal":
        c_val = c if c is not None else b
        d_val = d if d is not None else c_val + 1.0
        mu_val = np.zeros_like(x)
        # ascending slope
        m1 = (x >= a) & (x < b)
        if b > a:
            mu_val[m1] = (x[m1] - a) / (b - a)
        # plateau
        m2 = (x >= b) & (x <= c_val)
        mu_val[m2] = 1.0
        # descending slope
        m3 = (x > c_val) & (x <= d_val)
        if d_val > c_val:
            mu_val[m3] = (d_val - x[m3]) / (d_val - c_val)
        mu_val = np.clip(mu_val, 0.0, 1.0)
    else:
        mu_val = np.clip((x - a) / (b - a or 1.0), 0.0, 1.0)
        
    mu[valid] = mu_val.astype(np.float32)
    mu[~valid] = nodata_value
    
    out_ds = create_geotiff(
        output_path,
        ds.RasterXSize,
        ds.RasterYSize,
        bands=1,
        data_type=gdal.GDT_Float32,
        geotransform=ds.GetGeoTransform(),
        projection_wkt=ds.GetProjection(),
        nodata_value=nodata_value
    )
    out_ds.GetRasterBand(1).WriteArray(mu)
    out_ds.FlushCache()
    out_ds = None
    ds = None
    return output_path


def fuzzy_overlay(
    input_paths: List[str],
    output_path: str,
    operator: str = "gamma",
    gamma: float = 0.9,
    nodata_value: float = -9999.0
) -> str:
    """
    Combine multiple fuzzy membership rasters using fuzzy operators:
    'and' (min), 'or' (max), 'product', 'sum', 'gamma'.
    """
    if not input_paths:
        raise ValueError("At least one input raster required for fuzzy overlay.")
        
    ref_ds = open_raster_dataset(input_paths[0])
    w, h = ref_ds.RasterXSize, ref_ds.RasterYSize
    gt = ref_ds.GetGeoTransform()
    proj = ref_ds.GetProjection()
    ref_ds = None
    
    layers = []
    valid_mask = np.ones((h, w), dtype=bool)
    
    for path in input_paths:
        ds = open_raster_dataset(path)
        if ds.RasterXSize != w or ds.RasterYSize != h:
            raise ValueError(f"Raster dimensions {path} do not match {input_paths[0]}.")
        b = ds.GetRasterBand(1)
        nd = b.GetNoDataValue()
        arr = b.ReadAsArray().astype(np.float32)
        m = (arr != nd) & ~np.isnan(arr) if nd is not None else ~np.isnan(arr)
        valid_mask &= m
        layers.append(np.clip(arr, 0.0, 1.0))
        ds = None
        
    stack = np.stack(layers, axis=0) # shape (N, H, W)
    op = operator.lower()
    
    if op == "and":
        res = np.min(stack, axis=0)
    elif op == "or":
        res = np.max(stack, axis=0)
    elif op == "product":
        res = np.prod(stack, axis=0)
    elif op == "sum":
        res = 1.0 - np.prod(1.0 - stack, axis=0)
    elif op == "gamma":
        prod_val = np.prod(stack, axis=0)
        sum_val = 1.0 - np.prod(1.0 - stack, axis=0)
        res = (sum_val ** gamma) * (prod_val ** (1.0 - gamma))
    else:
        res = np.mean(stack, axis=0)
        
    out_arr = np.where(valid_mask, res, nodata_value).astype(np.float32)
    
    out_ds = create_geotiff(
        output_path, w, h, bands=1,
        data_type=gdal.GDT_Float32,
        geotransform=gt, projection_wkt=proj,
        nodata_value=nodata_value
    )
    out_ds.GetRasterBand(1).WriteArray(out_arr)
    out_ds.FlushCache()
    out_ds = None
    return output_path


def suitability_sensitivity(
    criteria_paths: List[str],
    base_weights: List[float],
    output_dir: str,
    perturbation_pct: float = 10.0
) -> Dict[str, Any]:
    """
    Conduct weight sensitivity analysis by perturbing criteria weights by +/- perturbation_pct
    and assessing the mean absolute score deviation and rank stability.
    """
    os.makedirs(output_dir, exist_ok=True)
    num_c = len(criteria_paths)
    if num_c != len(base_weights):
        raise ValueError("Number of criteria rasters must match number of weights.")
        
    base_out = os.path.join(output_dir, "suitability_baseline.tif")
    weighted_linear_combination(list(zip(criteria_paths, base_weights)), base_out)
    
    # Read baseline values
    b_ds = open_raster_dataset(base_out)
    b_arr = b_ds.GetRasterBand(1).ReadAsArray().astype(np.float32)
    b_nd = b_ds.GetRasterBand(1).GetNoDataValue()
    b_valid = (b_arr != b_nd) if b_nd is not None else ~np.isnan(b_arr)
    b_vals = b_arr[b_valid]
    b_ds = None
    
    sensitivity_results = []
    
    for i in range(num_c):
        perturbed_w = list(base_weights)
        delta = perturbed_w[i] * (perturbation_pct / 100.0)
        perturbed_w[i] += delta
        
        # Adjust other weights proportionally
        sum_others = sum(perturbed_w[j] for j in range(num_c) if j != i)
        if sum_others > 0:
            factor = (1.0 - perturbed_w[i]) / sum_others
            for j in range(num_c):
                if j != i:
                    perturbed_w[j] *= factor
                    
        p_out = os.path.join(output_dir, f"scenario_crit_{i+1}_plus_{int(perturbation_pct)}pct.tif")
        weighted_linear_combination(list(zip(criteria_paths, perturbed_w)), p_out)
        
        # Read perturbed
        p_ds = open_raster_dataset(p_out)
        p_arr = p_ds.GetRasterBand(1).ReadAsArray().astype(np.float32)
        p_vals = p_arr[b_valid]
        p_ds = None
        
        mae = float(np.mean(np.abs(p_vals - b_vals)))
        max_diff = float(np.max(np.abs(p_vals - b_vals)))
        
        sensitivity_results.append({
            "criterion_index": i + 1,
            "criterion_path": os.path.basename(criteria_paths[i]),
            "base_weight": base_weights[i],
            "perturbed_weight": perturbed_w[i],
            "mean_absolute_difference": mae,
            "max_absolute_difference": max_diff,
            "scenario_raster": p_out
        })
        
    report = {
        "baseline_raster": base_out,
        "perturbation_percent": perturbation_pct,
        "scenarios": sensitivity_results,
        "most_sensitive_criterion": max(sensitivity_results, key=lambda x: x["mean_absolute_difference"])["criterion_path"]
    }
    
    with open(os.path.join(output_dir, "sensitivity_report.json"), "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2)
        
    return report


def zonal_distribution(
    raster_path: str,
    zones_vector_path: str,
    zone_id_field: str,
    output_csv_path: str
) -> str:
    """
    Calculate zonal summary statistics (count, min, max, mean, stddev, median, Q25, Q75)
    for a continuous raster across polygonal zones.
    """
    from osgeo import ogr
    
    r_ds = open_raster_dataset(raster_path)
    band = r_ds.GetRasterBand(1)
    r_arr = band.ReadAsArray().astype(np.float32)
    nd = band.GetNoDataValue()
    gt = r_ds.GetGeoTransform()
    inv_gt = gdal.InvGeoTransform(gt)
    
    v_ds = ogr.Open(zones_vector_path)
    if v_ds is None:
        raise RuntimeError(f"Could not open vector layer: {zones_vector_path}")
    layer = v_ds.GetLayer(0)
    
    results = []
    
    for feat in layer:
        zid = feat.GetField(zone_id_field)
        geom = feat.GetGeometryRef()
        if not geom:
            continue
            
        env = geom.GetEnvelope() # (minX, maxX, minY, maxY)
        px_min, py_min = gdal.ApplyGeoTransform(inv_gt, env[0], env[3])
        px_max, py_max = gdal.ApplyGeoTransform(inv_gt, env[1], env[2])
        
        col_start = max(0, int(math.floor(min(px_min, px_max))))
        col_end = min(r_ds.RasterXSize, int(math.ceil(max(px_min, px_max))))
        row_start = max(0, int(math.floor(min(py_min, py_max))))
        row_end = min(r_ds.RasterYSize, int(math.ceil(max(py_min, py_max))))
        
        if col_end <= col_start or row_end <= row_start:
            continue
            
        sub = r_arr[row_start:row_end, col_start:col_end]
        valid = (sub != nd) & ~np.isnan(sub) if nd is not None else ~np.isnan(sub)
        vals = sub[valid]
        
        if vals.size == 0:
            results.append({
                "zone_id": zid, "count": 0, "mean": None, "std": None,
                "min": None, "max": None, "median": None, "q25": None, "q75": None
            })
        else:
            results.append({
                "zone_id": zid,
                "count": int(vals.size),
                "mean": float(np.mean(vals)),
                "std": float(np.std(vals)),
                "min": float(np.min(vals)),
                "max": float(np.max(vals)),
                "median": float(np.median(vals)),
                "q25": float(np.percentile(vals, 25)),
                "q75": float(np.percentile(vals, 75))
            })
            
    os.makedirs(os.path.dirname(os.path.abspath(output_csv_path)), exist_ok=True)
    with open(output_csv_path, "w", encoding="utf-8") as f:
        f.write("zone_id,count,min,max,mean,std,median,q25,q75\n")
        for r in results:
            f.write(f"{r['zone_id']},{r['count']},{r['min']},{r['max']},{r['mean']},{r['std']},{r['median']},{r['q25']},{r['q75']}\n")
            
    v_ds = None
    r_ds = None
    return output_csv_path


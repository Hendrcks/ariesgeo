"""
Resource and icon management for AriesGeo Toolbox.
"""

import os
from qgis.PyQt.QtGui import QIcon, QPixmap
from qgis.PyQt.QtCore import QSize

def get_icon_path(name: str) -> str:
    """Get absolute path to an icon file, preferring SVG then PNG."""
    base_dir = os.path.dirname(os.path.abspath(__file__))
    icons_dir = os.path.join(base_dir, "icons")
    
    # Check if name has extension
    if "." in name:
        target = os.path.join(icons_dir, name)
        if os.path.exists(target):
            return target
            
    # Try .svg first
    svg_path = os.path.join(icons_dir, f"{name}.svg")
    if os.path.exists(svg_path):
        return svg_path
        
    # Try .png fallback
    png_path = os.path.join(icons_dir, f"{name}.png")
    if os.path.exists(png_path):
        return png_path
        
    # Fallback to main icon
    return os.path.join(icons_dir, "icon.png")

def get_icon(name: str) -> QIcon:
    """Return a QIcon for the given icon name."""
    path = get_icon_path(name)
    if os.path.exists(path):
        return QIcon(path)
    return QIcon()

"""
Single-image spatial gap filling via local inverse distance weighting and Delaunay triangulation (Method A).
"""

import numpy as np
from typing import Tuple, Optional
from ..core.logging import log_info, log_warning


class TriangulationGapFiller:
    """
    Interpolates missing pixels from surrounding valid boundary pixels
    using smooth local inverse distance weighting (IDW) and edge-constrained Delaunay triangulation.
    """

    @classmethod
    def fill_band(
        cls,
        band_array: np.ndarray,
        gap_mask: np.ndarray,
        max_gap_distance: int = 50,
        support_sampling: int = 1,
        enable_nearest_fallback: bool = True,
        seam_feather_width: int = 0
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        Fill gaps in a single 2D band array.
        
        Args:
            band_array: 2D float/int numpy array of the target band.
            gap_mask: 2D boolean array where True = gap pixel to fill.
            max_gap_distance: Maximum distance from valid data to interpolate.
            support_sampling: Step size when sampling boundary support points.
            enable_nearest_fallback: Fill outer convex hull edges with nearest neighbor.
            seam_feather_width: Width in pixels for boundary smoothing.

        Returns:
            Tuple of (filled_array, provenance_mask, confidence_array).
            - filled_array: Original array with gaps filled. Original valid pixels untouched.
            - provenance_mask: 0 for original, 1 for spatial/triangulation-filled.
            - confidence_array: 0-100 score for filled pixels.
        """
        filled = band_array.copy().astype(np.float32)
        rows, cols = band_array.shape
        
        provenance = np.zeros((rows, cols), dtype=np.uint8)
        confidence = np.full((rows, cols), 100, dtype=np.uint8)
        
        gap_count = int(np.sum(gap_mask))
        if gap_count == 0:
            return filled, provenance, confidence

        valid_mask = ~gap_mask & ~np.isnan(band_array)

        # 1. Extract boundary support pixels (valid pixels directly neighboring gaps)
        up = np.pad(gap_mask[1:, :], ((0, 1), (0, 0)), constant_values=False)
        down = np.pad(gap_mask[:-1, :], ((1, 0), (0, 0)), constant_values=False)
        left = np.pad(gap_mask[:, 1:], ((0, 0), (0, 1)), constant_values=False)
        right = np.pad(gap_mask[:, :-1], ((0, 0), (1, 0)), constant_values=False)
        
        boundary_mask = valid_mask & (up | down | left | right)
        
        # Subsample if requested
        if support_sampling > 1:
            step_grid = np.zeros((rows, cols), dtype=bool)
            step_grid[::support_sampling, ::support_sampling] = True
            support_mask = boundary_mask & step_grid
            if np.sum(support_mask) < 10:
                support_mask = boundary_mask
        else:
            support_mask = boundary_mask

        support_coords = np.argwhere(support_mask)  # (N, 2) -> [r, c]
        gap_coords = np.argwhere(gap_mask)          # (M, 2) -> [r, c]

        if len(support_coords) < 3:
            # Not enough points to interpolate; fallback
            if len(support_coords) > 0:
                fallback_val = float(np.mean(band_array[support_mask]))
            else:
                fallback_val = float(np.nanmean(band_array[valid_mask])) if np.any(valid_mask) else 0.0
            
            filled[gap_mask] = fallback_val
            provenance[gap_mask] = 1
            confidence[gap_mask] = 30
            return filled, provenance, confidence

        support_values = band_array[support_mask].astype(np.float64)

        # 2. Fast & Smooth Local KD-Tree Inverse Distance Weighting (IDW)
        interpolated_values = None
        conf_scores = np.full(len(gap_coords), 60, dtype=np.uint8)

        try:
            from scipy.spatial import cKDTree
            
            tree = cKDTree(support_coords)
            # Query k nearest boundary support points within max_gap_distance
            k_neighbors = min(16, len(support_coords))
            dists, indices = tree.query(
                gap_coords,
                k=k_neighbors,
                distance_upper_bound=float(max_gap_distance),
                workers=-1
            )
            
            # If k=1, ensure 2D array shape
            if k_neighbors == 1:
                dists = dists[:, None]
                indices = indices[:, None]
                
            interpolated_values = np.full(len(gap_coords), np.nan, dtype=np.float64)
            
            for i in range(len(gap_coords)):
                d_row = dists[i]
                idx_row = indices[i]
                
                # Filter out infinity / out of bound indices
                valid_k = (d_row < max_gap_distance) & (idx_row < len(support_values))
                if not np.any(valid_k):
                    continue
                    
                v_d = d_row[valid_k]
                v_idx = idx_row[valid_k]
                v_vals = support_values[v_idx]
                
                # Check for exact zero distance
                zero_mask = (v_d < 1e-4)
                if np.any(zero_mask):
                    interpolated_values[i] = v_vals[zero_mask][0]
                    conf_scores[i] = 95
                else:
                    # Inverse distance squared weighting
                    weights = 1.0 / (v_d ** 2)
                    interpolated_values[i] = np.sum(weights * v_vals) / np.sum(weights)
                    
                    # Confidence based on distance to closest support pixel
                    min_d = float(np.min(v_d))
                    conf_scores[i] = int(max(30, min(95, 95 - (min_d / max_gap_distance) * 50)))
            
        except ImportError:
            log_warning("SciPy cKDTree not found. Using high-performance NumPy IDW spatial interpolation.")
        except Exception as e:
            log_warning(f"Spatial KD-Tree interpolation error: {e}. Falling back to chunked IDW.")

        # 3. Fallback: Pure NumPy Chunked IDW & Nearest Neighbor for any un-interpolated gap pixels
        if interpolated_values is None or (enable_nearest_fallback and np.any(np.isnan(interpolated_values))):
            nan_gap_indices = np.where(np.isnan(interpolated_values))[0] if interpolated_values is not None else np.arange(len(gap_coords))
            if len(nan_gap_indices) > 0:
                k_neighbors = min(8, len(support_coords))
                chunk_size = 5000
                
                if interpolated_values is None:
                    interpolated_values = np.full(len(gap_coords), np.nan, dtype=np.float64)
                
                for start_idx in range(0, len(nan_gap_indices), chunk_size):
                    end_idx = min(len(nan_gap_indices), start_idx + chunk_size)
                    target_sub_idx = nan_gap_indices[start_idx:end_idx]
                    chunk_gaps = gap_coords[target_sub_idx]  # (C, 2)
                    
                    # Distance matrix (C, N)
                    dists = np.sqrt(np.sum((chunk_gaps[:, None, :] - support_coords[None, :, :]) ** 2, axis=2))
                    dists = np.maximum(dists, 1e-4)
                    
                    k_indices = np.argpartition(dists, min(k_neighbors - 1, dists.shape[1] - 1), axis=1)[:, :k_neighbors]
                    row_indices = np.arange(len(chunk_gaps))[:, None]
                    k_dists = dists[row_indices, k_indices]
                    k_vals = support_values[k_indices]
                    
                    # Only consider points within max_gap_distance
                    valid_dist_mask = k_dists <= (max_gap_distance * 1.5)
                    weights = 1.0 / (k_dists ** 2)
                    weights[~valid_dist_mask] = 0.0
                    weights_sum = np.sum(weights, axis=1)
                    
                    # Compute IDW
                    has_weights = weights_sum > 0
                    chunk_idw = np.zeros(len(chunk_gaps), dtype=np.float64)
                    chunk_idw[has_weights] = np.sum(weights[has_weights] * k_vals[has_weights], axis=1) / weights_sum[has_weights]
                    
                    # For points with no weights within distance, use nearest support point if fallback enabled
                    if enable_nearest_fallback and np.any(~has_weights):
                        nearest_idx = np.argmin(dists[~has_weights], axis=1)
                        chunk_idw[~has_weights] = support_values[nearest_idx]
                    
                    interpolated_values[target_sub_idx] = chunk_idw

        # 4. Final safety pass: if any NaNs remain and enable_nearest_fallback is True, fill with global mean or nearest
        if enable_nearest_fallback and np.any(np.isnan(interpolated_values)):
            nan_mask = np.isnan(interpolated_values)
            fallback_fill = float(np.mean(support_values)) if len(support_values) > 0 else 0.0
            interpolated_values[nan_mask] = fallback_fill

        # 4. Insert interpolated values into filled array
        for idx, (r, c) in enumerate(gap_coords):
            val = interpolated_values[idx]
            if not np.isnan(val):
                filled[r, c] = val
                provenance[r, c] = 1  # 1 = Spatial/Triangulation fill
                confidence[r, c] = conf_scores[idx]

        return filled, provenance, confidence

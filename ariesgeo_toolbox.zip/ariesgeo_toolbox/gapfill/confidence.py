"""
Confidence raster calculation and reliability scoring for AriesGapfill.
"""

import numpy as np
from typing import Dict, Any


class ConfidenceCalculator:
    """
    Computes normalized confidence scores (0-100) based on:
    - Target-donor correlation
    - Overlapping sample count
    - Regression residual error
    - Distance to valid support pixels
    - Processing method used (Local > Global > Triangulation > Fallback)
    """

    @classmethod
    def calculate_composite_confidence(
        cls,
        method_name: str,
        correlation: float,
        sample_count: int,
        is_fallback: bool = False
    ) -> int:
        """
        Calculates normalized confidence score (0-100).
        
        Classes:
        - 80-100: High confidence
        - 60-79: Moderate confidence
        - 40-59: Low confidence
        - 1-39: Very low confidence
        - 0: Unfilled / Invalid
        """
        base_score = 0.0

        if method_name == "local_matching":
            base_score = 40.0
        elif method_name == "global_matching":
            base_score = 30.0
        elif method_name == "triangulation":
            base_score = 25.0
        else:
            base_score = 20.0

        if is_fallback:
            base_score -= 10.0

        # Correlation component: 0 to 40 pts
        corr_pts = max(0.0, min(1.0, correlation)) * 40.0

        # Sample density component: 0 to 20 pts
        sample_pts = min(20.0, (sample_count / 200.0) * 20.0)

        total = base_score + corr_pts + sample_pts
        return int(min(100, max(10, round(total))))

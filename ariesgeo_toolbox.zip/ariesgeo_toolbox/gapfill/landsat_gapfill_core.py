"""
Core scientific implementation of the USGS / ENVI Landsat Gapfill methodology
(Scaramuzza, Micijevic, & Chander, 2004 — Phase 1 & Phase 2 Local Linear Histogram Matching,
Global Linear Histogram Matching, Single-File Delaunay Triangulation, Automated Grid Co-Registration,
and Unified SLC-off + Cloud + Cloud Shadow Detection & Restoration).
"""

import os
from typing import List, Optional, Tuple, Dict, Any, Callable
import numpy as np
from osgeo import gdal

from ..core.exceptions import GapFillError
from ..core.logging import log_info, log_warning


# Mapping of GDAL integer data types to valid numeric clamp bounds
_GDAL_DTYPE_BOUNDS = {
    gdal.GDT_Byte: (0.0, 255.0, np.uint8),
    gdal.GDT_UInt16: (0.0, 65535.0, np.uint16),
    gdal.GDT_Int16: (-32768.0, 32767.0, np.int16),
    gdal.GDT_UInt32: (0.0, 4294967295.0, np.uint32),
    gdal.GDT_Int32: (-2147483648.0, 2147483647.0, np.int32),
    gdal.GDT_Float32: (None, None, np.float32),
    gdal.GDT_Float64: (None, None, np.float64),
}


def clamp_and_cast(
    arr: np.ndarray,
    gdal_dtype: int,
    nodata_val: Optional[float] = None,
    nodata_mask: Optional[np.ndarray] = None,
) -> np.ndarray:
    """Safely clamp floating-point array to target GDAL dtype bounds without integer overflow."""
    lo, hi, np_dtype = _GDAL_DTYPE_BOUNDS.get(gdal_dtype, (None, None, np.float32))
    work = np.nan_to_num(arr, nan=nodata_val if nodata_val is not None else 0.0).astype(np.float64)

    if lo is not None and hi is not None:
        # Avoid colliding valid pixels with reserved integer nodata (e.g., 0 or 65535) if desired
        work = np.clip(np.rint(work), lo, hi)

    out = work.astype(np_dtype)
    if nodata_mask is not None and np.any(nodata_mask):
        fill_v = nodata_val if nodata_val is not None and not np.isnan(nodata_val) else 0
        if lo is not None and hi is not None:
            fill_v = int(np.clip(fill_v, lo, hi))
        out[nodata_mask] = fill_v
    return out


def align_raster_to_reference(
    source_path_or_ds: Any,
    ref_ds: gdal.Dataset,
    resample_alg: int = gdal.GRA_Bilinear,
) -> gdal.Dataset:
    """
    Ensure `source_path_or_ds` matches `ref_ds` exact CRS, GeoTransform, cols, and rows.
    If already aligned within sub-pixel tolerance, returns opened read-only Dataset;
    otherwise warps on the fly into an in-memory GDAL dataset (`MEM`).
    """
    if isinstance(source_path_or_ds, str):
        if not os.path.exists(source_path_or_ds):
            raise GapFillError(f"Raster file not found: {source_path_or_ds}")
        src_ds = gdal.Open(source_path_or_ds, gdal.GA_ReadOnly)
    else:
        src_ds = source_path_or_ds

    if src_ds is None:
        raise GapFillError(f"Cannot open raster dataset: {source_path_or_ds}")

    ref_cols = ref_ds.RasterXSize
    ref_rows = ref_ds.RasterYSize
    ref_gt = ref_ds.GetGeoTransform()
    ref_proj = ref_ds.GetProjection() or ""

    src_gt = src_ds.GetGeoTransform()
    src_proj = src_ds.GetProjection() or ""

    same_dims = (src_ds.RasterXSize == ref_cols and src_ds.RasterYSize == ref_rows)
    same_gt = all(abs(a - b) <= 1e-5 for a, b in zip(src_gt, ref_gt))
    same_proj = (src_proj == ref_proj) or (not ref_proj and not src_proj)

    if same_dims and same_gt and same_proj:
        return src_ds

    # Compute exact target bounding box in reference CRS
    min_x = ref_gt[0]
    max_y = ref_gt[3]
    max_x = min_x + ref_cols * ref_gt[1]
    min_y = max_y + ref_rows * ref_gt[5]
    if min_x > max_x:
        min_x, max_x = max_x, min_x
    if min_y > max_y:
        min_y, max_y = max_y, min_y

    warp_kwargs: Dict[str, Any] = {
        "format": "MEM",
        "width": ref_cols,
        "height": ref_rows,
        "outputBounds": (min_x, min_y, max_x, max_y),
        "resampleAlg": resample_alg,
    }
    if ref_proj and src_proj:
        warp_kwargs["dstSRS"] = ref_proj

    warped_ds = gdal.Warp("", src_ds, **warp_kwargs)
    if warped_ds is None:
        raise GapFillError("Failed to co-register/warp donor raster onto target grid.")
    return warped_ds


def _box_sum_2d(arr: np.ndarray, radius: int) -> np.ndarray:
    """
    Exact 2D moving-window sum with window size (2*radius + 1) x (2*radius + 1)
    computed in O(1) per pixel via 2D Integral Image (Summed-Area Table),
    clamped cleanly at image borders.
    """
    rows, cols = arr.shape
    if radius <= 0:
        return arr.astype(np.float64, copy=True)

    # Pad integral image with 1 leading zero row & col
    sat = np.zeros((rows + 1, cols + 1), dtype=np.float64)
    np.cumsum(np.cumsum(arr.astype(np.float64), axis=0), axis=1, out=sat[1:, 1:])

    r_idx = np.arange(rows)
    c_idx = np.arange(cols)

    r0 = np.maximum(0, r_idx - radius)
    r1 = np.minimum(rows, r_idx + radius + 1)
    c0 = np.maximum(0, c_idx - radius)
    c1 = np.minimum(cols, c_idx + radius + 1)

    return (
        sat[r1[:, None], c1[None, :]]
        - sat[r0[:, None], c1[None, :]]
        - sat[r1[:, None], c0[None, :]]
        + sat[r0[:, None], c0[None, :]]
    )


def decode_landsat_qa_pixel(
    qa_arr: np.ndarray,
    mask_dilated_cloud: bool = True,
    mask_cirrus: bool = True,
    mask_cloud: bool = True,
    mask_shadow: bool = True,
    mask_snow: bool = False,
) -> np.ndarray:
    """
    Decode USGS Landsat Collection 2 QA_PIXEL 16-bit bitmask.
    Bit 0: Fill, Bit 1: Dilated Cloud, Bit 2: Cirrus, Bit 3: Cloud, Bit 4: Cloud Shadow, Bit 5: Snow.
    """
    qa = qa_arr.astype(np.uint32)
    mask = (qa & (1 << 0)) != 0
    if mask_dilated_cloud:
        mask |= (qa & (1 << 1)) != 0
    if mask_cirrus:
        mask |= (qa & (1 << 2)) != 0
    if mask_cloud:
        mask |= (qa & (1 << 3)) != 0
    if mask_shadow:
        mask |= (qa & (1 << 4)) != 0
    if mask_snow:
        mask |= (qa & (1 << 5)) != 0
    return mask


def decode_sentinel_scl(
    scl_arr: np.ndarray,
    mask_shadow: bool = True,
    mask_cirrus: bool = True,
    mask_snow: bool = False,
) -> np.ndarray:
    """
    Decode ESA Sentinel-2 L2A Scene Classification Layer (SCL).
    0=NoData, 1=Saturated, 3=Cloud Shadow, 8=Cloud Medium, 9=Cloud High, 10=Thin Cirrus, 11=Snow.
    """
    classes = [0, 1, 8, 9]
    if mask_shadow:
        classes.append(3)
    if mask_cirrus:
        classes.append(10)
    if mask_snow:
        classes.append(11)
    return np.isin(scl_arr, classes)


def detect_spectral_cloud_and_shadow_mask(
    bands_arr: np.ndarray,
    nodata_val: Optional[float] = None,
    brightness_threshold: float = 0.65,
    whiteness_tolerance: float = 0.28,
    detect_shadows: bool = True,
    shadow_threshold: float = 0.25,
    shadow_search_px: int = 35,
    dilation_radius: int = 2,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Robust multi-sensor cloud & cast-shadow detector across 8-bit, 16-bit (Landsat C2 / Sentinel-2),
    and floating-point reflectance imagery.

    Args:
        bands_arr: shape (bands, rows, cols) or (rows, cols)
    Returns:
        Tuple of (cloud_mask, shadow_mask) as 2D boolean arrays.
    """
    if bands_arr.ndim == 2:
        bands_arr = bands_arr[np.newaxis, :, :]

    b_count, rows, cols = bands_arr.shape
    vis_count = min(3, b_count)

    # 1. Build valid data footprint (excluding NaN, nodata_val, 0 border fill, and uint16 65535 fill)
    valid = np.ones((rows, cols), dtype=bool)
    for i in range(vis_count):
        b = bands_arr[i]
        valid &= ~np.isnan(b)
        if nodata_val is not None and not np.isnan(nodata_val):
            valid &= (b != nodata_val)
    # If all bands are 0 simultaneously, treat as outer background NoData
    all_zero = np.all(bands_arr[:vis_count] == 0, axis=0)
    if np.any(all_zero) and not np.all(all_zero):
        valid &= ~all_zero
    # Check uint16 65535 fill
    if bands_arr.dtype == np.uint16:
        all_max16 = np.all(bands_arr[:vis_count] == 65535, axis=0)
        if np.any(all_max16) and not np.all(all_max16):
            valid &= ~all_max16

    if not np.any(valid):
        empty = np.zeros((rows, cols), dtype=bool)
        return empty, empty

    # 2. Robust radiometric normalization to [0, 1] scale
    # Determine physical ceiling vs robust P99.5 ceiling so hot/fill pixels never crush cloud brightness
    norm_vis = []
    for i in range(vis_count):
        b = bands_arr[i].astype(np.float32)
        v_vals = b[valid]
        p01 = float(np.percentile(v_vals, 1.0))
        p995 = float(np.percentile(v_vals, 99.5))
        raw_max = float(np.max(v_vals))

        # Infer physical scale ceiling to avoid false positives on completely clear dark scenes
        if raw_max <= 1.5:
            phys_ceil = 1.0
            phys_floor = 0.0
        elif raw_max <= 255.0:
            phys_ceil = max(p995, 200.0)
            phys_floor = min(p01, 15.0)
        elif raw_max <= 12000.0:
            # Sentinel-2 L2A / TOA (10000 = 1.0 reflectance)
            phys_ceil = max(p995, 5500.0)
            phys_floor = min(p01, 300.0)
        else:
            # Landsat Collection 2 Level-1 / Level-2 uint16 (7273..43636+)
            phys_ceil = max(p995, 24000.0)
            phys_floor = min(p01, 7500.0 if p01 > 5000 else 0.0)

        denom = max(1e-6, phys_ceil - phys_floor)
        nb = np.clip((b - phys_floor) / denom, 0.0, 1.5)
        norm_vis.append(nb)

    if vis_count == 1:
        mean_bright = norm_vis[0]
        cloud_mask = valid & (mean_bright > brightness_threshold)
    else:
        vis_stack = np.stack(norm_vis, axis=0)
        mean_bright = np.mean(vis_stack, axis=0)
        color_spread = np.max(vis_stack, axis=0) - np.min(vis_stack, axis=0)
        rel_whiteness_diff = color_spread / np.maximum(mean_bright, 0.15)

        # Thick bright clouds + thin high-whiteness clouds
        cloud_mask = valid & (
            ((mean_bright > brightness_threshold) & (color_spread < whiteness_tolerance))
            | ((mean_bright > brightness_threshold * 0.85) & (rel_whiteness_diff < whiteness_tolerance * 0.65) & (color_spread < whiteness_tolerance * 0.6))
        )

    # 3. Cloud Shadow Detection (dark regions cast near detected clouds)
    shadow_mask = np.zeros((rows, cols), dtype=bool)
    if detect_shadows and np.any(cloud_mask) and np.sum(~cloud_mask & valid) >= 50:
        try:
            from scipy.ndimage import distance_transform_edt, binary_opening

            # Use NIR band (band 4) if available for crisp shadow contrast, else mean visible brightness
            if b_count >= 4:
                nir = bands_arr[3].astype(np.float32)
                clear_nir = nir[valid & ~cloud_mask]
                med_nir = float(np.median(clear_nir))
                p_low = float(np.percentile(clear_nir, max(2.0, shadow_threshold * 35.0)))
                shadow_cut = min(med_nir * (0.45 + 0.35 * shadow_threshold), p_low * 1.15)
                dark_candidates = valid & ~cloud_mask & (nir < shadow_cut)
            else:
                clear_b = mean_bright[valid & ~cloud_mask]
                med_b = float(np.median(clear_b))
                shadow_cut = med_b * (0.35 + 0.35 * shadow_threshold)
                dark_candidates = valid & ~cloud_mask & (mean_bright < shadow_cut)

            # Restrict shadows to neighborhood within shadow_search_px of detected clouds
            dist_to_cloud = distance_transform_edt(~cloud_mask)
            shadow_mask = dark_candidates & (dist_to_cloud <= max(5, shadow_search_px))
            # Remove isolated 1-pixel dark speckle
            if rows >= 16 and cols >= 16 and np.any(shadow_mask):
                opened = binary_opening(shadow_mask, structure=np.ones((2, 2), dtype=bool))
                if np.any(opened):
                    shadow_mask = opened
        except Exception as e:
            log_warning(f"Shadow detection note: {e}")

    # 4. Morphological halo dilation around clouds & shadows
    if dilation_radius > 0:
        try:
            from scipy.ndimage import binary_dilation
            r = int(dilation_radius)
            y, x = np.ogrid[-r:r + 1, -r:r + 1]
            disk = (x * x + y * y <= r * r)
            if np.any(cloud_mask):
                cloud_mask = binary_dilation(cloud_mask, structure=disk) & valid
            if np.any(shadow_mask):
                s_disk = np.ones((max(1, r) * 2 + 1, max(1, r) * 2 + 1), dtype=bool)
                shadow_mask = binary_dilation(shadow_mask, structure=s_disk) & valid & ~cloud_mask
        except Exception as e:
            log_warning(f"Cloud/shadow dilation note: {e}")

    return cloud_mask, shadow_mask


def stable_overlap_mask(
    target_band: np.ndarray,
    donor_band: np.ndarray,
    target_valid: np.ndarray,
    donor_valid: np.ndarray,
    sigma_clip: float = 2.5,
) -> np.ndarray:
    """
    USGS Phase-2 Outlier Rejection: exclude transient unmasked clouds, shadows, glint,
    or abrupt land-cover change from the calibration sample before computing gain & bias.
    """
    mutual = target_valid & donor_valid
    count = int(np.sum(mutual))
    if count < 40:
        return mutual

    diff = target_band[mutual].astype(np.float64) - donor_band[mutual].astype(np.float64)
    med = float(np.median(diff))
    mad = float(np.median(np.abs(diff - med)))
    robust_sd = 1.4826 * mad if mad > 1e-6 else float(np.std(diff))
    if robust_sd <= 1e-6:
        return mutual

    out = np.zeros_like(mutual, dtype=bool)
    inliers = np.abs(diff - med) <= (sigma_clip * robust_sd)
    if int(np.sum(inliers)) >= 20:
        out[mutual] = inliers
        return out
    return mutual


def usgs_llhm_fill_band(
    target_band: np.ndarray,
    target_gap_mask: np.ndarray,
    donor_band: np.ndarray,
    donor_invalid_mask: Optional[np.ndarray] = None,
    target_nodata: Optional[float] = None,
    donor_nodata: Optional[float] = None,
    min_window_size: int = 17,
    max_window_size: int = 257,
    min_valid_pairs: int = 20,
    gain_bounds: Tuple[float, float] = (0.25, 4.0),
    seam_feather_width: int = 2,
    donor_id: int = 2,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, Dict[str, Any]]:
    """
    Exact Vectorized USGS / ENVI `landsat_gapfill` Local Linear Histogram Matching (LLHM)
    using O(1) Integral Image moving windows with multi-scale adaptive window expansion
    (Scaramuzza et al., 2004).

    Equation:
        Gain(x,y) = sigma_T(W) / sigma_D(W)
        Bias(x,y) = mu_T(W) - Gain(x,y) * mu_D(W)
        T_hat(x,y) = Gain(x,y) * D(x,y) + Bias(x,y)
    """
    rows, cols = target_band.shape
    filled = target_band.astype(np.float32, copy=True)
    provenance = np.zeros((rows, cols), dtype=np.uint8)
    confidence = np.full((rows, cols), 100, dtype=np.uint8)

    # Valid pixel masks
    t_valid = ~target_gap_mask & ~np.isnan(target_band)
    if target_nodata is not None and not np.isnan(target_nodata):
        t_valid &= (target_band != target_nodata)
    else:
        t_valid &= (target_band != 0)

    d_valid = ~np.isnan(donor_band)
    if donor_nodata is not None and not np.isnan(donor_nodata):
        d_valid &= (donor_band != donor_nodata)
    else:
        d_valid &= (donor_band != 0)
    if donor_invalid_mask is not None:
        d_valid &= ~donor_invalid_mask

    fillable = target_gap_mask & d_valid
    if not np.any(fillable):
        confidence[target_gap_mask] = 0
        return filled, provenance, confidence, {
            "slope": 1.0,
            "intercept": 0.0,
            "correlation": 0.0,
            "r_squared": 0.0,
            "paired_samples": 0,
            "local_fill_count": 0,
            "fallback_fill_count": 0,
            "method_used": "usgs_llhm",
        }

    # Stable mutually clear calibration mask (USGS 2-sigma residual filter)
    cal_mask = stable_overlap_mask(target_band, donor_band, t_valid, d_valid, sigma_clip=2.5)
    paired_count = int(np.sum(cal_mask))

    # Global Histogram Matching baseline (GLHM)
    g_lo, g_hi = gain_bounds
    if paired_count >= 10:
        t_cal = target_band[cal_mask].astype(np.float64)
        d_cal = donor_band[cal_mask].astype(np.float64)
        mu_t_glob = float(np.mean(t_cal))
        sd_t_glob = float(np.std(t_cal))
        mu_d_glob = float(np.mean(d_cal))
        sd_d_glob = float(np.std(d_cal))
        glob_gain = float(np.clip(sd_t_glob / sd_d_glob, g_lo, g_hi)) if sd_d_glob > 1e-6 else 1.0
        glob_bias = mu_t_glob - glob_gain * mu_d_glob
        if sd_t_glob > 1e-6 and sd_d_glob > 1e-6:
            corr = float(np.corrcoef(d_cal, t_cal)[0, 1])
            if np.isnan(corr):
                corr = 0.0
        else:
            corr = 1.0
    else:
        glob_gain = 1.0
        glob_bias = 0.0
        corr = 0.0

    # Build adaptive window schedule: e.g. 17 -> 35 -> 71 -> 143 -> 287
    w_start = max(5, int(min_window_size) | 1)
    w_limit = max(w_start, int(max_window_size) | 1)
    radii: List[int] = []
    w_curr = w_start
    while w_curr <= w_limit:
        radii.append(w_curr // 2)
        w_curr = w_curr * 2 + 1
    if not radii or (w_limit // 2) > radii[-1]:
        radii.append(w_limit // 2)

    # Pre-masked arrays for O(1) Integral Image evaluation
    m_float = cal_mask.astype(np.float64)
    t_masked = np.where(cal_mask, target_band.astype(np.float64), 0.0)
    d_masked = np.where(cal_mask, donor_band.astype(np.float64), 0.0)
    t2_masked = t_masked * t_masked
    d2_masked = d_masked * d_masked

    gain_surface = np.full((rows, cols), np.nan, dtype=np.float32)
    bias_surface = np.full((rows, cols), np.nan, dtype=np.float32)
    conf_surface = np.zeros((rows, cols), dtype=np.uint8)

    unresolved = fillable.copy()
    local_fills = 0

    for scale_idx, rad in enumerate(radii):
        if not np.any(unresolved):
            break

        cnt = _box_sum_2d(m_float, rad)
        enough = unresolved & (cnt >= min_valid_pairs)
        if not np.any(enough):
            continue

        sum_t = _box_sum_2d(t_masked, rad)[enough]
        sum_d = _box_sum_2d(d_masked, rad)[enough]
        sum_t2 = _box_sum_2d(t2_masked, rad)[enough]
        sum_d2 = _box_sum_2d(d2_masked, rad)[enough]
        n = cnt[enough]

        mu_t = sum_t / n
        mu_d = sum_d / n
        var_t = np.maximum(0.0, (sum_t2 / n) - (mu_t * mu_t))
        var_d = np.maximum(0.0, (sum_d2 / n) - (mu_d * mu_d))

        sd_t = np.sqrt(var_t)
        sd_d = np.sqrt(var_d)

        loc_gain = np.where(sd_d > 1e-5, np.clip(sd_t / np.maximum(sd_d, 1e-5), g_lo, g_hi), glob_gain)
        loc_bias = mu_t - loc_gain * mu_d

        gain_surface[enough] = loc_gain.astype(np.float32)
        bias_surface[enough] = loc_bias.astype(np.float32)
        # Tighter windows earn higher local spatial confidence (92 down to 74)
        scale_conf = max(72, 92 - scale_idx * 5)
        conf_surface[enough] = scale_conf

        local_fills += int(np.sum(enough))
        unresolved[enough] = False

    # Global fallback for any deep interior cloud pixels beyond max_window_size
    fallback_fills = int(np.sum(unresolved))
    if fallback_fills > 0:
        gain_surface[unresolved] = glob_gain
        bias_surface[unresolved] = glob_bias
        conf_surface[unresolved] = max(55, int(60 + max(0.0, corr) * 25))

    # Apply LLHM equation on all fillable pixels
    predicted = gain_surface[fillable] * donor_band[fillable].astype(np.float32) + bias_surface[fillable]
    filled[fillable] = predicted
    provenance[fillable] = donor_id
    confidence[fillable] = conf_surface[fillable]
    confidence[target_gap_mask & ~fillable] = 0

    # Gentle boundary seam feathering across 1..seam_feather_width pixels inside gap perimeter
    if seam_feather_width > 0 and np.any(t_valid) and np.any(fillable):
        try:
            from scipy.ndimage import distance_transform_edt, uniform_filter

            # Smooth filled boundary transitions while keeping 100% of original valid target pixels intact!
            dist_inside_gap = distance_transform_edt(target_gap_mask)
            rim = fillable & (dist_inside_gap >= 1) & (dist_inside_gap <= seam_feather_width)
            if np.any(rim):
                smoothed = uniform_filter(filled, size=3, mode="nearest")
                alpha = np.clip(dist_inside_gap[rim] / float(seam_feather_width + 1), 0.25, 1.0).astype(np.float32)
                filled[rim] = alpha * filled[rim] + (1.0 - alpha) * smoothed[rim]
        except Exception as e:
            log_info(f"Seam feather note: {e}")

    total_filled = local_fills + fallback_fills
    stats = {
        "slope": round(float(glob_gain), 4),
        "intercept": round(float(glob_bias), 4),
        "correlation": round(float(corr), 4),
        "r_squared": round(float(max(0.0, corr * corr)), 4),
        "paired_samples": paired_count,
        "local_fill_count": local_fills,
        "fallback_fill_count": fallback_fills,
        "local_fill_percentage": round((local_fills / max(1, total_filled)) * 100.0, 1),
        "method_used": "usgs_llhm",
    }
    return filled, provenance, confidence, stats


def usgs_glhm_fill_band(
    target_band: np.ndarray,
    target_gap_mask: np.ndarray,
    donor_band: np.ndarray,
    donor_invalid_mask: Optional[np.ndarray] = None,
    target_nodata: Optional[float] = None,
    donor_nodata: Optional[float] = None,
    gain_bounds: Tuple[float, float] = (0.25, 4.0),
    donor_id: int = 2,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, Dict[str, Any]]:
    """
    USGS / ENVI Phase-1 Global Linear Histogram Matching (GLHM) with 2.5-sigma outlier rejection.
    """
    rows, cols = target_band.shape
    filled = target_band.astype(np.float32, copy=True)
    provenance = np.zeros((rows, cols), dtype=np.uint8)
    confidence = np.full((rows, cols), 100, dtype=np.uint8)

    t_valid = ~target_gap_mask & ~np.isnan(target_band)
    if target_nodata is not None and not np.isnan(target_nodata):
        t_valid &= (target_band != target_nodata)
    else:
        t_valid &= (target_band != 0)

    d_valid = ~np.isnan(donor_band)
    if donor_nodata is not None and not np.isnan(donor_nodata):
        d_valid &= (donor_band != donor_nodata)
    else:
        d_valid &= (donor_band != 0)
    if donor_invalid_mask is not None:
        d_valid &= ~donor_invalid_mask

    fillable = target_gap_mask & d_valid
    cal_mask = stable_overlap_mask(target_band, donor_band, t_valid, d_valid, sigma_clip=2.5)
    paired_count = int(np.sum(cal_mask))

    g_lo, g_hi = gain_bounds
    if paired_count >= 10:
        t_cal = target_band[cal_mask].astype(np.float64)
        d_cal = donor_band[cal_mask].astype(np.float64)
        mu_t = float(np.mean(t_cal))
        sd_t = float(np.std(t_cal))
        mu_d = float(np.mean(d_cal))
        sd_d = float(np.std(d_cal))
        gain = float(np.clip(sd_t / sd_d, g_lo, g_hi)) if sd_d > 1e-6 else 1.0
        bias = mu_t - gain * mu_d
        corr = float(np.corrcoef(d_cal, t_cal)[0, 1]) if (sd_t > 1e-6 and sd_d > 1e-6) else 1.0
        if np.isnan(corr):
            corr = 0.0
    else:
        gain, bias, corr = 1.0, 0.0, 0.0

    if np.any(fillable):
        filled[fillable] = gain * donor_band[fillable].astype(np.float32) + bias
        provenance[fillable] = donor_id
        confidence[fillable] = max(50, int(65 + max(0.0, corr) * 30))

    confidence[target_gap_mask & ~fillable] = 0
    stats = {
        "slope": round(float(gain), 4),
        "intercept": round(float(bias), 4),
        "correlation": round(float(corr), 4),
        "r_squared": round(float(max(0.0, corr * corr)), 4),
        "paired_samples": paired_count,
        "method_used": "usgs_glhm",
    }
    return filled, provenance, confidence, stats

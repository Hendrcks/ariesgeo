"""
Multiple-donor smart composite and optimal per-pixel donor selection (Method D).
"""

import numpy as np
from typing import List, Tuple, Dict, Optional, Any
from .matching import GlobalStatisticalMatcher
from .local_matching import LocalStatisticalMatcher
from .models import DonorSpec


class MultiDonorSmartFiller:
    """
    Ranks multiple donor candidates and selects the optimal donor for each missing pixel
    based on temporal proximity, valid overlap, cloud/shadow exclusion, and radiometric correlation.
    """

    @classmethod
    def rank_and_fill_band(
        cls,
        target_array: np.ndarray,
        target_gap_mask: np.ndarray,
        donor_arrays: List[np.ndarray],
        donor_specs: List[DonorSpec],
        donor_masks: Optional[List[np.ndarray]] = None,
        use_local_matching: bool = True,
        initial_window_size: int = 51,
        min_paired_samples: int = 100,
        correlation_threshold: float = 0.65
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray, Dict[str, Any]]:
        """
        Multi-donor composite filling.
        
        Args:
            target_array: 2D numpy array of the target band.
            target_gap_mask: 2D boolean array where True = gap to fill in target.
            donor_arrays: List of 2D numpy arrays for each donor candidate.
            donor_specs: List of DonorSpec objects with metadata.
            donor_masks: Optional list of boolean masks for invalid/cloud donor pixels.

        Returns:
            Tuple of (filled_array, provenance_mask, confidence_array, summary_stats).
        """
        filled = target_array.copy().astype(np.float32)
        rows, cols = target_array.shape

        provenance = np.zeros((rows, cols), dtype=np.uint8)
        confidence = np.full((rows, cols), 100, dtype=np.uint8)

        num_donors = len(donor_arrays)
        if num_donors == 0:
            return filled, provenance, confidence, {"donors_used": 0, "fill_rate_pct": 0.0}

        if donor_masks is None:
            donor_masks = [None] * num_donors

        # 1. Evaluate & Score each donor candidate across target
        scored_donors = []
        for i, (d_arr, d_spec, d_mask) in enumerate(zip(donor_arrays, donor_specs, donor_masks)):
            # Provenance code: Donor 1 -> 2, Donor 2 -> 3, etc.
            donor_id = i + 2
            
            # Check mutual valid overlap
            t_valid = ~target_gap_mask & ~np.isnan(target_array) & (target_array != 0)
            d_valid = ~np.isnan(d_arr) & (d_arr != 0)
            if d_mask is not None:
                d_valid = d_valid & ~d_mask

            mutual = t_valid & d_valid
            overlap_pct = (np.sum(mutual) / max(1, np.sum(t_valid))) * 100.0

            # Fit global model to test correlation
            _, _, _, stats = GlobalStatisticalMatcher.fit_and_fill_band(
                target_array=target_array,
                target_gap_mask=target_gap_mask,
                donor_array=d_arr,
                donor_mask=d_mask,
                donor_id=donor_id
            )

            corr = stats.get("correlation", 0.0)
            cloud_pct = d_spec.cloud_cover_percentage

            # Composite Score: higher is better
            # Score = (Correlation * 50) + (Overlap * 30) - (CloudPct * 20) + (Weight * 10)
            score = (corr * 50.0) + (min(100.0, overlap_pct) * 0.3) - (cloud_pct * 0.2) + (d_spec.weight * 10.0)

            scored_donors.append({
                "index": i,
                "donor_id": donor_id,
                "spec": d_spec,
                "array": d_arr,
                "mask": d_mask,
                "score": score,
                "correlation": corr,
                "overlap_pct": overlap_pct,
                "stats": stats
            })

        # Sort donors by descending score (best candidate first)
        scored_donors.sort(key=lambda x: x["score"], reverse=True)

        # 2. Sequential / optimal fill of remaining gaps
        remaining_gaps = target_gap_mask.copy()
        donor_contributions: Dict[str, int] = {}

        for donor_info in scored_donors:
            if not np.any(remaining_gaps):
                break  # All gaps filled!

            d_id = donor_info["donor_id"]
            d_arr = donor_info["array"]
            d_mask = donor_info["mask"]

            # Perform local or global matching for this donor
            if use_local_matching:
                d_filled, d_prov, d_conf, _ = LocalStatisticalMatcher.fit_and_fill_band(
                    target_array=target_array,
                    target_gap_mask=remaining_gaps,
                    donor_array=d_arr,
                    donor_mask=d_mask,
                    initial_window_size=initial_window_size,
                    min_paired_samples=min_paired_samples,
                    correlation_threshold=correlation_threshold,
                    donor_id=d_id
                )
            else:
                d_filled, d_prov, d_conf, _ = GlobalStatisticalMatcher.fit_and_fill_band(
                    target_array=target_array,
                    target_gap_mask=remaining_gaps,
                    donor_array=d_arr,
                    donor_mask=d_mask,
                    donor_id=d_id
                )

            # Check which remaining gap pixels were successfully filled by this donor
            filled_by_donor = (d_prov == d_id) & remaining_gaps
            fill_count = int(np.sum(filled_by_donor))

            if fill_count > 0:
                filled[filled_by_donor] = d_filled[filled_by_donor]
                provenance[filled_by_donor] = d_id
                confidence[filled_by_donor] = d_conf[filled_by_donor]
                remaining_gaps[filled_by_donor] = False
                
                donor_name = donor_info["spec"].filepath
                donor_contributions[donor_name] = fill_count

        total_original_gaps = int(np.sum(target_gap_mask))
        total_remaining_gaps = int(np.sum(remaining_gaps))
        total_filled_gaps = total_original_gaps - total_remaining_gaps
        fill_rate = (total_filled_gaps / max(1, total_original_gaps)) * 100.0

        summary = {
            "total_donors_provided": num_donors,
            "donors_contributed": len(donor_contributions),
            "original_gaps": total_original_gaps,
            "filled_gaps": total_filled_gaps,
            "remaining_gaps": total_remaining_gaps,
            "fill_rate_pct": round(float(fill_rate), 2),
            "donor_contributions": donor_contributions,
            "ranked_donors": [
                {
                    "filepath": d["spec"].filepath,
                    "score": round(d["score"], 2),
                    "correlation": round(d["correlation"], 3),
                    "overlap_pct": round(d["overlap_pct"], 1)
                }
                for d in scored_donors
            ]
        }

        return filled, provenance, confidence, summary

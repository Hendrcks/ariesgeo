"""
Two-image local statistical matching via USGS Phase-2 Local Linear Histogram Matching (LLHM)
with O(1) Integral Image adaptive moving windows and global fallback (Method C).
"""

import numpy as np
from typing import Tuple, Optional, Dict, Any
from .landsat_gapfill_core import usgs_llhm_fill_band


class LocalStatisticalMatcher:
    """
    Computes spatially continuous radiometric matching coefficients within an adaptive local moving
    neighborhood around each gap/cloud pixel (USGS `landsat_gapfill` LLHM, Scaramuzza et al. 2004).
    """

    @classmethod
    def fit_and_fill_band(
        cls,
        target_array: np.ndarray,
        target_gap_mask: np.ndarray,
        donor_array: np.ndarray,
        donor_mask: Optional[np.ndarray] = None,
        initial_window_size: int = 33,
        max_window_size: int = 257,
        min_paired_samples: int = 25,
        correlation_threshold: float = 0.70,
        use_robust_regression: bool = True,
        mad_threshold: float = 3.0,
        seam_feather_width: int = 2,
        donor_id: int = 2,
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray, Dict[str, Any]]:
        """
        Fill target gaps/clouds using vectorized USGS Local Linear Histogram Matching (LLHM).
        """
        eff_max_win = max(max_window_size, initial_window_size * 3 + 1)
        eff_min_samples = max(15, min(min_paired_samples, (initial_window_size * initial_window_size) // 4))

        filled, provenance, confidence, llhm_stats = usgs_llhm_fill_band(
            target_band=target_array,
            target_gap_mask=target_gap_mask,
            donor_band=donor_array,
            donor_invalid_mask=donor_mask,
            min_window_size=max(9, initial_window_size),
            max_window_size=eff_max_win,
            min_valid_pairs=eff_min_samples,
            seam_feather_width=seam_feather_width,
            donor_id=donor_id,
        )

        stats = {
            **llhm_stats,
            "method_used": "local_matching",
            "initial_window_size": initial_window_size,
            "max_window_size": eff_max_win,
        }
        return filled, provenance, confidence, stats

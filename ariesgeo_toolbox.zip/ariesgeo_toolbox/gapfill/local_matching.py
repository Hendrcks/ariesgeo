"""
Two-image local statistical matching via adaptive moving window / tile regression with global fallback (Method C).
"""

import numpy as np
from typing import Tuple, Optional, Dict, Any
from .matching import GlobalStatisticalMatcher


class LocalStatisticalMatcher:
    """
    Computes spatially variable radiometric matching coefficients within a local moving
    neighborhood around each gap pixel, with adaptive window expansion and global fallback.
    """

    @classmethod
    def fit_and_fill_band(
        cls,
        target_array: np.ndarray,
        target_gap_mask: np.ndarray,
        donor_array: np.ndarray,
        donor_mask: Optional[np.ndarray] = None,
        initial_window_size: int = 51,
        max_window_size: int = 101,
        min_paired_samples: int = 100,
        correlation_threshold: float = 0.70,
        use_robust_regression: bool = True,
        mad_threshold: float = 3.0,
        seam_feather_width: int = 3,
        donor_id: int = 2
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray, Dict[str, Any]]:
        """
        Fill target gaps using local moving-window radiometric regression.
        """
        filled = target_array.copy().astype(np.float32)
        rows, cols = target_array.shape

        provenance = np.zeros((rows, cols), dtype=np.uint8)
        confidence = np.full((rows, cols), 100, dtype=np.uint8)

        # 1. Compute baseline global model for fallback and stats
        _, _, _, global_stats = GlobalStatisticalMatcher.fit_and_fill_band(
            target_array=target_array,
            target_gap_mask=target_gap_mask,
            donor_array=donor_array,
            donor_mask=donor_mask,
            use_robust_regression=use_robust_regression,
            mad_threshold=mad_threshold,
            donor_id=donor_id
        )

        global_slope = global_stats.get("slope", 1.0)
        global_intercept = global_stats.get("intercept", 0.0)

        # Build mutual valid mask
        t_valid = ~target_gap_mask & ~np.isnan(target_array) & (target_array != 0)
        d_valid = ~np.isnan(donor_array) & (donor_array != 0)
        if donor_mask is not None:
            d_valid = d_valid & ~donor_mask

        mutual_valid = t_valid & d_valid

        # Identify gap pixels to fill where donor is valid
        gaps_to_fill = target_gap_mask & d_valid
        gap_indices = np.argwhere(gaps_to_fill)

        if len(gap_indices) == 0:
            return filled, provenance, confidence, global_stats

        # Block-based local matching for high computational efficiency
        # We divide the raster into blocks of initial_window_size
        block_size = max(16, initial_window_size // 2)
        half_init = initial_window_size // 2
        half_max = max_window_size // 2

        local_fills = 0
        fallback_fills = 0

        # Arrays to hold locally computed slope and intercept maps for gap pixels
        slope_map = np.full((rows, cols), np.nan, dtype=np.float32)
        intercept_map = np.full((rows, cols), np.nan, dtype=np.float32)
        conf_map = np.full((rows, cols), 0, dtype=np.uint8)

        # Iterate through unique block coordinates containing gaps
        block_r_coords = np.unique(gap_indices[:, 0] // block_size) * block_size
        block_c_coords = np.unique(gap_indices[:, 1] // block_size) * block_size

        for br in block_r_coords:
            for bc in block_c_coords:
                # Check if block contains gap pixels
                b_rmin = br
                b_rmax = min(rows, br + block_size)
                b_cmin = bc
                b_cmax = min(cols, bc + block_size)

                block_gaps = gaps_to_fill[b_rmin:b_rmax, b_cmin:b_cmax]
                if not np.any(block_gaps):
                    continue

                # Local window centered on this block
                center_r = (b_rmin + b_rmax) // 2
                center_c = (b_cmin + b_cmax) // 2

                # Try initial window
                w_rmin = max(0, center_r - half_init)
                w_rmax = min(rows, center_r + half_init + 1)
                w_cmin = max(0, center_c - half_init)
                w_cmax = min(cols, center_c + half_init + 1)

                win_valid = mutual_valid[w_rmin:w_rmax, w_cmin:w_cmax]
                sample_count = int(np.sum(win_valid))

                # Expand window if needed
                if sample_count < min_paired_samples and max_window_size > initial_window_size:
                    w_rmin = max(0, center_r - half_max)
                    w_rmax = min(rows, center_r + half_max + 1)
                    w_cmin = max(0, center_c - half_max)
                    w_cmax = min(cols, center_c + half_max + 1)
                    win_valid = mutual_valid[w_rmin:w_rmax, w_cmin:w_cmax]
                    sample_count = int(np.sum(win_valid))

                loc_slope = global_slope
                loc_intercept = global_intercept
                is_local = False
                loc_conf = 70

                if sample_count >= min_paired_samples:
                    t_win = target_array[w_rmin:w_rmax, w_cmin:w_cmax][win_valid].astype(np.float64)
                    d_win = donor_array[w_rmin:w_rmax, w_cmin:w_cmax][win_valid].astype(np.float64)

                    var_d = np.var(d_win)
                    var_t = np.var(t_win)

                    if var_d > 1e-4 and var_t > 1e-4:
                        corr = np.corrcoef(d_win, t_win)[0, 1]
                        if not np.isnan(corr) and corr >= correlation_threshold:
                            # Fit local OLS or robust
                            cov = np.cov(d_win, t_win)[0, 1]
                            s = cov / var_d
                            # Sanity bound slope (0.2 to 4.0)
                            if 0.2 <= s <= 4.0:
                                loc_slope = s
                                loc_intercept = float(np.mean(t_win) - s * np.mean(d_win))
                                is_local = True
                                loc_conf = int(min(100, max(60, 60 + corr * 35)))

                if is_local:
                    local_fills += np.sum(block_gaps)
                else:
                    fallback_fills += np.sum(block_gaps)
                    loc_conf = global_stats.get("confidence_score", 65)

                slope_map[b_rmin:b_rmax, b_cmin:b_cmax] = loc_slope
                intercept_map[b_rmin:b_rmax, b_cmin:b_cmax] = loc_intercept
                conf_map[b_rmin:b_rmax, b_cmin:b_cmax] = loc_conf

        # 2. Fill gaps using local coefficient surfaces: F = slope * D + intercept
        gap_mask_bool = gaps_to_fill
        filled[gap_mask_bool] = (
            slope_map[gap_mask_bool] * donor_array[gap_mask_bool].astype(np.float32)
            + intercept_map[gap_mask_bool]
        )
        provenance[gap_mask_bool] = donor_id
        confidence[gap_mask_bool] = conf_map[gap_mask_bool]

        total_filled = local_fills + fallback_fills
        local_pct = (local_fills / max(1, total_filled)) * 100.0

        stats = {
            **global_stats,
            "method_used": "local_matching",
            "local_fill_count": int(local_fills),
            "fallback_fill_count": int(fallback_fills),
            "local_fill_percentage": round(float(local_pct), 1),
            "initial_window_size": initial_window_size,
            "max_window_size": max_window_size
        }

        return filled, provenance, confidence, stats

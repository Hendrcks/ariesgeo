"""
HTML and JSON provenance report generator for AriesGapfill.
"""

import os
import json
import datetime
from typing import Dict, Any, Optional
from .models import GapFillResult, GapFillConfig


class GapFillReportGenerator:
    """Generates styled HTML provenance audits and JSON metadata sidecars."""

    @classmethod
    def generate_report(
        cls,
        config: GapFillConfig,
        result: GapFillResult,
        output_html_path: str,
        output_json_path: Optional[str] = None
    ) -> str:
        """Writes HTML report and optional JSON sidecar."""
        os.makedirs(os.path.dirname(os.path.abspath(output_html_path)), exist_ok=True)
        now_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        # 1. Write JSON metadata sidecar
        if output_json_path:
            os.makedirs(os.path.dirname(os.path.abspath(output_json_path)), exist_ok=True)
            meta = {
                "generator": "AriesGapfill v0.2.0 (AriesPlus)",
                "timestamp": now_str,
                "method": config.method.value,
                "target_scene": config.target_path,
                "donors": [d.filepath for d in config.donors],
                "output_filled": result.output_filled_path,
                "original_gap_count": result.original_gap_count,
                "filled_gap_count": result.filled_gap_count,
                "remaining_gap_count": result.remaining_gap_count,
                "overall_fill_rate_pct": result.overall_fill_rate_pct,
                "mean_confidence_score": result.mean_confidence_score,
                "donor_contributions": result.donor_contributions,
                "band_stats": [
                    {
                        "band_index": b.band_index,
                        "band_name": b.band_name,
                        "slope": b.slope,
                        "intercept": b.intercept,
                        "correlation": b.correlation,
                        "r_squared": b.r_squared,
                        "original_gaps": b.original_gaps,
                        "filled_pixels": b.filled_pixels,
                        "remaining_gaps": b.remaining_gaps,
                        "fill_rate_pct": b.fill_rate_pct
                    }
                    for b in result.band_stats
                ]
            }
            with open(output_json_path, "w", encoding="utf-8") as jf:
                json.dump(meta, jf, indent=2)

        # 2. Build Band Rows HTML
        band_rows_html = ""
        for b in result.band_stats:
            band_rows_html += f"""
            <tr>
                <td><b>Band {b.band_index}</b> ({b.band_name})</td>
                <td>{b.original_gaps:,}</td>
                <td style="color: #16A36A; font-weight: bold;">{b.filled_pixels:,}</td>
                <td style="color: {'#DC2626' if b.remaining_gaps > 0 else '#16A36A'};">{b.remaining_gaps:,}</td>
                <td><b>{b.fill_rate_pct:.1f}%</b></td>
                <td><code>T = {b.slope:.4f}·D + {b.intercept:.2f}</code></td>
                <td>{b.correlation:.3f}</td>
                <td>{b.r_squared:.3f}</td>
            </tr>
            """

        # 3. Donor Breakdown HTML
        donor_rows_html = ""
        if result.donor_contributions:
            for d_name, count in result.donor_contributions.items():
                pct = (count / max(1, result.filled_gap_count)) * 100.0
                donor_rows_html += f"<li><b>{os.path.basename(d_name)}:</b> {count:,} pixels ({pct:.1f}%)</li>"
        else:
            donor_rows_html = "<li>Single-Image Triangulation (100% spatial interpolation)</li>"

        # 4. Generate Full HTML Document
        html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>AriesGapfill Provenance & Quality Report</title>
    <style>
        body {{
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            background-color: #F8FAFC;
            color: #0B1F33;
            margin: 0;
            padding: 24px;
        }}
        .container {{
            max-width: 960px;
            margin: 0 auto;
            background: #FFFFFF;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.06);
            padding: 32px;
            border: 1px solid #E2E8F0;
        }}
        .header {{
            border-bottom: 2px solid #10B981;
            padding-bottom: 16px;
            margin-bottom: 24px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }}
        .header h1 {{
            margin: 0;
            font-size: 24px;
            color: #0B1F33;
        }}
        .badge {{
            background: #D1FAE5;
            color: #065F46;
            padding: 6px 12px;
            border-radius: 20px;
            font-weight: bold;
            font-size: 12px;
        }}
        .summary-grid {{
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 16px;
            margin-bottom: 24px;
        }}
        .card {{
            background: #F8FAFC;
            border: 1px solid #E2E8F0;
            border-radius: 6px;
            padding: 16px;
            text-align: center;
        }}
        .card .value {{
            font-size: 22px;
            font-weight: bold;
            color: #0284C7;
            margin-top: 4px;
        }}
        .card .label {{
            font-size: 11px;
            color: #64748B;
            text-transform: uppercase;
        }}
        table {{
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            font-size: 13px;
        }}
        th, td {{
            padding: 10px 12px;
            text-align: left;
            border-bottom: 1px solid #E2E8F0;
        }}
        th {{
            background: #F1F5F9;
            color: #475569;
            font-weight: 600;
        }}
        .disclaimer {{
            background: #FEF3C7;
            border-left: 4px solid #F59E0B;
            padding: 12px 16px;
            border-radius: 4px;
            font-size: 12px;
            color: #92400E;
            margin-top: 24px;
        }}
        .footer {{
            margin-top: 32px;
            border-top: 1px solid #E2E8F0;
            padding-top: 12px;
            font-size: 11px;
            color: #94A3B8;
            text-align: center;
        }}
    </style>
</head>
<body>
<div class="container">
    <div class="header">
        <div>
            <h1>AriesGapfill Provenance & Quality Report</h1>
            <p style="color: #64748B; margin: 4px 0 0 0; font-size: 13px;">Landsat 7 ETM+ SLC-Off & Spatial Gap Filling Audit</p>
        </div>
        <div class="badge">AriesPlus Precision Suite</div>
    </div>

    <div class="summary-grid">
        <div class="card">
            <div class="label">Processing Method</div>
            <div class="value" style="font-size: 16px; color: #0B1F33; text-transform: capitalize;">{config.method.value.replace('_', ' ')}</div>
        </div>
        <div class="card">
            <div class="label">Original Missing</div>
            <div class="value" style="color: #E11D48;">{result.original_gap_count:,} px</div>
        </div>
        <div class="card">
            <div class="label">Fill Success Rate</div>
            <div class="value" style="color: #10B981;">{result.overall_fill_rate_pct:.1f}%</div>
        </div>
        <div class="card">
            <div class="label">Mean Confidence</div>
            <div class="value">{result.mean_confidence_score:.0f} / 100</div>
        </div>
    </div>

    <h3>Input Provenance & Donors</h3>
    <ul>
        <li><b>Target Scene:</b> <code>{config.target_path}</code></li>
        <li><b>Donors:</b></li>
        <ul>{donor_rows_html}</ul>
        <li><b>Output Filled File:</b> <code>{result.output_filled_path}</code></li>
    </ul>

    <h3>Per-Band Radiometric Calibration & Statistics</h3>
    <table>
        <thead>
            <tr>
                <th>Band</th>
                <th>Original Gaps</th>
                <th>Filled</th>
                <th>Remaining</th>
                <th>Fill Rate</th>
                <th>Model Equation</th>
                <th>Pearson r</th>
                <th>R²</th>
            </tr>
        </thead>
        <tbody>
            {band_rows_html}
        </tbody>
    </table>

    <div class="disclaimer">
        <b>Scientific Integrity Notice:</b> Observed pixels were preserved bit-for-bit without alteration. 
        Filled pixels represent estimated values derived from spatial interpolation or radiometrically matched donor scenes. 
        Please inspect the accompanying <i>Provenance Mask</i> and <i>Confidence Raster</i> for mission-critical analysis.
    </div>

    <div class="footer">
        Generated on {now_str} by <b>AriesGapfill v0.2.0</b> — Powered by AriesPlus.
    </div>
</div>
</body>
</html>
"""
        with open(output_html_path, "w", encoding="utf-8") as f:
            f.write(html)

        return output_html_path

"""
Two-image global statistical matching and radiometric linear regression (Method B).
"""

import numpy as np
from typing import Tuple, Optional, Dict, Any


class GlobalStatisticalMatcher:
    """
    Fits global radiometric transformation between a target scene and a donor scene
    across mutually valid overlap, then transforms donor values into target gaps.
    """

    @classmethod
    def fit_and_fill_band(
        cls,
        target_array: np.ndarray,
        target_gap_mask: np.ndarray,
        donor_array: np.ndarray,
        donor_mask: Optional[np.ndarray] = None,
        use_robust_regression: bool = True,
        mad_threshold: float = 3.0,
        donor_id: int = 2
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray, Dict[str, Any]]:
        """
        Fit global matching between target and donor, and fill target gaps.

        Args:
            target_array: 2D numpy array of the target band.
            target_gap_mask: 2D boolean array where True = gap to fill in target.
            donor_array: 2D numpy array of the aligned donor band.
            donor_mask: 2D boolean array where True = invalid/cloud in donor.
            use_robust_regression: If True, uses linear regression with MAD outlier filter.
            mad_threshold: MAD multiplier for outlier rejection.
            donor_id: Provenance code for this donor (default 2 for Donor 1).

        Returns:
            Tuple of (filled_array, provenance_mask, confidence_array, stats_dict).
        """
        filled = target_array.copy().astype(np.float32)
        rows, cols = target_array.shape

        provenance = np.zeros((rows, cols), dtype=np.uint8)
        confidence = np.full((rows, cols), 100, dtype=np.uint8)

        # Build mutual valid mask: valid in target and valid in donor
        t_valid = ~target_gap_mask & ~np.isnan(target_array) & (target_array != 0)
        d_valid = ~np.isnan(donor_array) & (donor_array != 0)
        if donor_mask is not None:
            d_valid = d_valid & ~donor_mask

        mutual_valid = t_valid & d_valid
        paired_count = int(np.sum(mutual_valid))

        if paired_count < 10:
            # Insufficient overlap to compute radiometric relation; direct donor copy
            gaps_to_fill = target_gap_mask & d_valid
            filled[gaps_to_fill] = donor_array[gaps_to_fill]
            provenance[gaps_to_fill] = donor_id
            confidence[gaps_to_fill] = 40
            stats = {
                "slope": 1.0, "intercept": 0.0, "correlation": 0.0, "r_squared": 0.0,
                "paired_samples": paired_count, "mean_target": 0.0, "mean_donor": 0.0,
                "method_used": "direct_copy"
            }
            return filled, provenance, confidence, stats

        t_samples = target_array[mutual_valid].astype(np.float64)
        d_samples = donor_array[mutual_valid].astype(np.float64)

        mean_t = float(np.mean(t_samples))
        std_t = float(np.std(t_samples))
        mean_d = float(np.mean(d_samples))
        std_d = float(np.std(d_samples))

        if use_robust_regression and paired_count >= 30 and std_d > 1e-4:
            # 1. Initial Ordinary Least Squares (OLS)
            cov = np.cov(d_samples, t_samples)[0, 1]
            var_d = np.var(d_samples)
            slope = cov / var_d if var_d > 1e-8 else 1.0
            intercept = mean_t - slope * mean_d

            # 2. Outlier Rejection via Median Absolute Deviation (MAD) of residuals
            residuals = t_samples - (slope * d_samples + intercept)
            med_res = np.median(residuals)
            mad = np.median(np.abs(residuals - med_res))
            
            if mad > 1e-6:
                inlier_mask = np.abs(residuals - med_res) <= (mad_threshold * 1.4826 * mad)
                if np.sum(inlier_mask) >= 20:
                    t_inliers = t_samples[inlier_mask]
                    d_inliers = d_samples[inlier_mask]
                    cov_in = np.cov(d_inliers, t_inliers)[0, 1]
                    var_in = np.var(d_inliers)
                    slope = cov_in / var_in if var_in > 1e-8 else slope
                    intercept = float(np.mean(t_inliers) - slope * np.mean(d_inliers))
            
            method_used = "robust_regression"
        else:
            # Classical mean/std matching: F = mean_T + (std_T / std_D) * (D - mean_D)
            slope = (std_t / std_d) if std_d > 1e-6 else 1.0
            # Bound slope to prevent catastrophic contrast explosion
            slope = max(0.1, min(5.0, slope))
            intercept = mean_t - slope * mean_d
            method_used = "mean_std_matching"

        # Compute correlation and R² on paired samples
        if std_t > 1e-6 and std_d > 1e-6:
            corr = float(np.corrcoef(d_samples, t_samples)[0, 1])
            r_sq = max(0.0, corr ** 2)
        else:
            corr = 1.0
            r_sq = 1.0

        # Transform donor values: F = a + b * D
        transformed_donor = slope * donor_array.astype(np.float32) + intercept

        # Apply transformation only to target gaps where donor is valid
        gaps_to_fill = target_gap_mask & d_valid
        filled[gaps_to_fill] = transformed_donor[gaps_to_fill]
        provenance[gaps_to_fill] = donor_id

        # Compute confidence (0-100) based on correlation, sample density, and slope realism
        corr_score = max(0.0, corr) * 70.0  # 0 to 70 pts
        sample_score = min(20.0, (paired_count / 500.0) * 20.0)  # 0 to 20 pts
        slope_score = 10.0 if (0.5 <= slope <= 2.0) else 5.0    # 5 to 10 pts
        overall_conf = int(min(100, max(10, corr_score + sample_score + slope_score)))
        confidence[gaps_to_fill] = overall_conf

        stats = {
            "slope": round(float(slope), 4),
            "intercept": round(float(intercept), 4),
            "correlation": round(float(corr), 4),
            "r_squared": round(float(r_sq), 4),
            "paired_samples": paired_count,
            "mean_target": round(mean_t, 2),
            "mean_donor": round(mean_d, 2),
            "std_target": round(std_t, 2),
            "std_donor": round(std_d, 2),
            "method_used": method_used,
            "confidence_score": overall_conf
        }

        return filled, provenance, confidence, stats

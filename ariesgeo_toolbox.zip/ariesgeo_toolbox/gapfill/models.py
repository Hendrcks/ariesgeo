"""
Data structures, configuration models, and enums for AriesGapfill.
"""

from enum import Enum
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Tuple, Any


class GapFillMethod(Enum):
    """Supported gap filling algorithms."""
    TRIANGULATION = "triangulation"         # Method A: Single-image triangulation
    GLOBAL_MATCHING = "global_matching"     # Method B: Two-image global statistical matching
    LOCAL_MATCHING = "local_matching"       # Method C: Two-image local moving-window matching
    MULTI_DONOR = "multi_donor"             # Method D: Multiple-donor smart composite


class GapMaskSource(Enum):
    """Method to identify gap / missing pixels in the target scene."""
    AUTO_QA = "auto_qa"                     # Landsat QA/BQA band detection
    NODATA = "nodata"                       # Standard raster NoData value
    ZERO_VALUE = "zero_value"               # Value = 0 treated as gap
    CUSTOM_MASK = "custom_mask"             # External user-supplied binary mask (1=gap, 0=valid)
    MANUAL_RANGE = "manual_range"           # User-defined pixel value range


@dataclass
class DonorSpec:
    """Specification for a candidate donor raster scene."""
    filepath: str
    acquisition_date: Optional[str] = None
    cloud_cover_percentage: float = 0.0
    qa_band_path: Optional[str] = None
    weight: float = 1.0
    valid_overlap_pct: float = 0.0
    score: float = 0.0


@dataclass
class BandMapping:
    """Mapping between target band and donor band(s)."""
    target_band: int
    donor_band: int
    band_name: str = ""


@dataclass
class MethodParameters:
    """Configurable numerical parameters for gapfill methods."""
    # Triangulation (Method A)
    max_triangulation_distance: int = 50        # Maximum gap pixel width to interpolate
    support_pixel_sampling: int = 1             # Step size for boundary support pixels
    enable_nearest_fallback: bool = True        # Nearest neighbor for un-triangulated voids
    
    # Matching (Method B & C)
    use_robust_regression: bool = True          # Robust linear regression with MAD outlier filter
    outlier_mad_threshold: float = 3.0          # Median Absolute Deviation multiplier
    
    # Local Moving Window (Method C)
    initial_window_size: int = 51               # Initial moving window size in pixels (e.g. 31, 51, 101)
    max_window_size: int = 101                  # Maximum expanded window size
    min_paired_samples: int = 100               # Minimum valid overlapping pixels required
    correlation_threshold: float = 0.70         # Minimum Pearson correlation before fallback
    fallback_to_global: bool = True             # Fall back to global model if local fit fails
    
    # Blending & Output
    seam_feather_width: int = 3                 # Boundary blending width in pixels
    output_dtype_name: str = "Preserve"         # "Preserve", "Float32", "Int16", "Byte"
    compress: str = "DEFLATE"                   # "DEFLATE", "LZW", "NONE"


@dataclass
class GapFillConfig:
    """Complete configuration for an AriesGapfill execution."""
    target_path: str
    method: GapFillMethod = GapFillMethod.LOCAL_MATCHING
    output_filled_path: str = ""
    
    # Donors
    donors: List[DonorSpec] = field(default_factory=list)
    band_mappings: List[BandMapping] = field(default_factory=list)
    
    # Gap Masking
    mask_source: GapMaskSource = GapMaskSource.NODATA
    custom_mask_path: Optional[str] = None
    manual_mask_value: float = 0.0
    
    # QA & Exclusion
    mask_clouds: bool = True
    mask_shadows: bool = True
    mask_snow: bool = True
    
    # Parameters
    parameters: MethodParameters = field(default_factory=MethodParameters)
    
    # Output Products
    generate_provenance: bool = True
    output_provenance_path: Optional[str] = None
    
    generate_confidence: bool = True
    output_confidence_path: Optional[str] = None
    
    generate_remaining_gap_mask: bool = True
    output_remaining_gap_path: Optional[str] = None
    
    generate_report: bool = True
    output_report_path: Optional[str] = None


@dataclass
class BandStatistics:
    """Per-band execution statistics and radiometric coefficients."""
    band_index: int
    band_name: str
    slope: float = 1.0
    intercept: float = 0.0
    correlation: float = 1.0
    r_squared: float = 1.0
    total_pixels: int = 0
    original_gaps: int = 0
    filled_pixels: int = 0
    remaining_gaps: int = 0
    fill_rate_pct: float = 100.0
    mae: Optional[float] = None
    rmse: Optional[float] = None


@dataclass
class GapFillResult:
    """Result summary of AriesGapfill execution."""
    success: bool
    output_filled_path: str
    output_provenance_path: Optional[str] = None
    output_confidence_path: Optional[str] = None
    output_remaining_gap_path: Optional[str] = None
    output_report_path: Optional[str] = None
    
    total_pixels: int = 0
    original_gap_count: int = 0
    filled_gap_count: int = 0
    remaining_gap_count: int = 0
    overall_fill_rate_pct: float = 0.0
    mean_confidence_score: float = 0.0
    
    band_stats: List[BandStatistics] = field(default_factory=list)
    donor_contributions: Dict[str, float] = field(default_factory=dict)
    execution_time_seconds: float = 0.0
    warnings: List[str] = field(default_factory=list)
    error_message: Optional[str] = None

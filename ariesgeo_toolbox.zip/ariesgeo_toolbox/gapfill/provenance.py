"""
Provenance raster generation, Remaining-Gap masking, and GeoTIFF output serialization.
"""

import os
import numpy as np
from osgeo import gdal, osr
from typing import Optional, List, Dict, Any, Tuple
from ..core.exceptions import GapFillError


class ProvenanceManager:
    """
    Manages provenance encoding, remaining-gap masks, confidence rasters,
    and writes spatial outputs with full GDAL GeoTransform and CRS preservation.
    """

    @classmethod
    def save_raster(
        cls,
        output_path: str,
        bands_data: List[np.ndarray],
        geotransform: Tuple,
        projection_wkt: str,
        nodata_val: Optional[float] = None,
        gdal_dtype: int = gdal.GDT_Float32,
        compress: str = "DEFLATE",
        metadata_dict: Optional[Dict[str, str]] = None
    ) -> str:
        """Saves a multiband raster with projection and metadata."""
        os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
        
        num_bands = len(bands_data)
        if num_bands == 0:
            raise GapFillError("No band data provided for raster export.")

        rows, cols = bands_data[0].shape

        opts = [f"COMPRESS={compress}"]
        if compress in ["DEFLATE", "LZW"]:
            opts.append("PREDICTOR=2")
            opts.append("TILED=YES")

        driver = gdal.GetDriverByName("GTiff")
        ds = driver.Create(output_path, cols, rows, num_bands, gdal_dtype, opts)
        if not ds:
            raise GapFillError(f"Cannot create output raster: {output_path}")

        ds.SetGeoTransform(geotransform)
        if projection_wkt:
            ds.SetProjection(projection_wkt)

        if metadata_dict:
            ds.SetMetadata(metadata_dict)

        for b_idx, b_arr in enumerate(bands_data, start=1):
            band = ds.GetRasterBand(b_idx)
            if nodata_val is not None:
                band.SetNoDataValue(nodata_val)
            band.WriteArray(b_arr)
            band.FlushCache()

        ds.FlushCache()
        ds = None
        return output_path

    @classmethod
    def save_mask_raster(
        cls,
        output_path: str,
        mask_array: np.ndarray,
        geotransform: Tuple,
        projection_wkt: str,
        description: str = "AriesGapfill Mask"
    ) -> str:
        """Saves a 1-band Byte mask raster (e.g. Provenance, Remaining Gaps, Confidence)."""
        os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
        rows, cols = mask_array.shape

        driver = gdal.GetDriverByName("GTiff")
        opts = ["COMPRESS=DEFLATE", "TILED=YES"]
        ds = driver.Create(output_path, cols, rows, 1, gdal.GDT_Byte, opts)
        ds.SetGeoTransform(geotransform)
        if projection_wkt:
            ds.SetProjection(projection_wkt)

        ds.SetMetadata({"DESCRIPTION": description, "GENERATOR": "AriesGapfill"})
        b = ds.GetRasterBand(1)
        b.SetNoDataValue(255)
        b.WriteArray(mask_array.astype(np.uint8))
        b.FlushCache()
        ds = None
        return output_path

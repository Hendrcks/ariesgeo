"""
Unified execution engine for AriesGapfill (USGS / ENVI `landsat_gapfill` methodology).
Coordinates grid co-registration, SLC-off & Cloud/Shadow masking, method dispatch
(LLHM, GLHM, Multi-Donor, Single-File Delaunay Triangulation), QA generation, and report export.
"""

import os
import time
import numpy as np
from osgeo import gdal
from typing import List, Optional, Callable, Tuple, Dict, Any

from .models import (
    GapFillConfig,
    GapFillResult,
    GapFillMethod,
    GapMaskSource,
    BandStatistics,
    DonorSpec,
)
from .triangulation import TriangulationGapFiller
from .matching import GlobalStatisticalMatcher
from .local_matching import LocalStatisticalMatcher
from .multi_donor import MultiDonorSmartFiller
from .landsat_gapfill_core import (
    align_raster_to_reference,
    detect_spectral_cloud_and_shadow_mask,
    decode_landsat_qa_pixel,
    clamp_and_cast,
)
from .provenance import ProvenanceManager
from .reports import GapFillReportGenerator
from ..core.exceptions import GapFillError
from ..core.logging import log_info, log_warning


_DTYPE_NAME_MAP = {
    "Float32": gdal.GDT_Float32,
    "UInt16": gdal.GDT_UInt16,
    "Int16": gdal.GDT_Int16,
    "Byte": gdal.GDT_Byte,
}


class AriesGapFillEngine:
    """
    Core pipeline orchestrator for AriesGapfill.
    Supports single-image triangulation, global histogram matching, local moving-window
    histogram matching (USGS Phase-2 LLHM), multi-donor smart composites, and unified
    SLC-off + Cloud/Shadow restoration.
    """

    @classmethod
    def isolate_internal_gaps(
        cls,
        valid_mask: np.ndarray,
        raw_gap_mask: np.ndarray,
        max_gap_distance: int = 50,
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        Separates internal missing scanlines/clouds/holes from exterior background NoData.

        Returns:
            Tuple of (internal_gap_mask, exterior_nodata_mask)
        """
        valid_count = int(np.sum(valid_mask))
        raw_gap_count = int(np.sum(raw_gap_mask))

        if valid_count == 0 or raw_gap_count == 0:
            return raw_gap_mask, np.zeros_like(raw_gap_mask)

        try:
            from scipy.ndimage import distance_transform_edt, binary_closing, binary_dilation

            dist = distance_transform_edt(~valid_mask)

            r = min(24, max(4, max_gap_distance // 2))
            y, x = np.ogrid[-r:r + 1, -r:r + 1]
            struct = (x * x + y * y <= r * r)
            footprint = binary_closing(valid_mask, structure=struct)
            footprint = binary_dilation(footprint, structure=np.ones((3, 3), dtype=bool))

            # If valid pixels touch all 4 edges (full-frame crop), all internal gaps/clouds within max_gap_distance are internal
            touches_all_edges = (
                np.any(valid_mask[0, :])
                and np.any(valid_mask[-1, :])
                and np.any(valid_mask[:, 0])
                and np.any(valid_mask[:, -1])
            )
            if touches_all_edges and np.mean(valid_mask) > 0.25:
                internal_gap_mask = raw_gap_mask & ((dist <= max_gap_distance) | footprint)
            else:
                internal_gap_mask = raw_gap_mask & (dist <= max_gap_distance) & footprint

            exterior_nodata_mask = raw_gap_mask & ~internal_gap_mask
            return internal_gap_mask, exterior_nodata_mask
        except Exception as e:
            log_warning(f"Footprint isolation error: {e}. Using distance filter on raw gap mask.")
            try:
                from scipy.ndimage import distance_transform_edt
                dist = distance_transform_edt(~valid_mask)
                internal_gap_mask = raw_gap_mask & (dist <= max_gap_distance)
                exterior_nodata_mask = raw_gap_mask & ~internal_gap_mask
                return internal_gap_mask, exterior_nodata_mask
            except Exception:
                return raw_gap_mask, np.zeros_like(raw_gap_mask)

    @classmethod
    def _build_scene_cloud_mask(
        cls,
        ds: gdal.Dataset,
        nodata_val: Optional[float],
        brightness_threshold: float,
        detect_shadows: bool,
    ) -> np.ndarray:
        """Compute combined cloud + shadow mask across the first 1..4 bands of a dataset."""
        b_cnt = min(4, ds.RasterCount)
        stack = np.array([ds.GetRasterBand(i).ReadAsArray() for i in range(1, b_cnt + 1)])
        c_mask, s_mask = detect_spectral_cloud_and_shadow_mask(
            stack,
            nodata_val=nodata_val,
            brightness_threshold=brightness_threshold,
            detect_shadows=detect_shadows,
            dilation_radius=2,
        )
        return c_mask | s_mask

    @classmethod
    def execute(
        cls,
        config: GapFillConfig,
        progress_callback: Optional[Callable[[float, str], None]] = None,
    ) -> GapFillResult:
        """
        Executes the full gap & cloud fill pipeline according to the configuration.
        """
        start_time = time.time()
        warnings: List[str] = []

        if not os.path.exists(config.target_path):
            raise GapFillError(f"Target raster not found: {config.target_path}")

        t_ds = gdal.Open(config.target_path, gdal.GA_ReadOnly)
        if not t_ds:
            raise GapFillError(f"Cannot open target raster: {config.target_path}")

        cols = t_ds.RasterXSize
        rows = t_ds.RasterYSize
        num_bands = t_ds.RasterCount
        gt = t_ds.GetGeoTransform()
        proj_wkt = t_ds.GetProjection()

        first_band = t_ds.GetRasterBand(1)
        native_gdal_dtype = first_band.DataType
        target_nodata_val = first_band.GetNoDataValue()

        if progress_callback:
            progress_callback(8, f"Target loaded ({cols}x{rows}, {num_bands} bands). Preparing scenes...")

        # 2. Open & Co-register Donor Datasets (warping automatically if grid/CRS differs)
        donor_datasets: List[gdal.Dataset] = []
        donor_cloud_masks: List[Optional[np.ndarray]] = []

        if config.method in (GapFillMethod.GLOBAL_MATCHING, GapFillMethod.LOCAL_MATCHING, GapFillMethod.MULTI_DONOR):
            if not config.donors:
                raise GapFillError("At least one donor scene is required for statistical matching methods.")

            for idx, d in enumerate(config.donors):
                if not os.path.exists(d.filepath):
                    raise GapFillError(f"Donor raster not found: {d.filepath}")
                if config.auto_resample_donors:
                    d_ds = align_raster_to_reference(d.filepath, t_ds, resample_alg=gdal.GRA_Bilinear)
                else:
                    d_ds = gdal.Open(d.filepath, gdal.GA_ReadOnly)
                    if not d_ds:
                        raise GapFillError(f"Cannot open donor raster: {d.filepath}")
                    if d_ds.RasterXSize != cols or d_ds.RasterYSize != rows:
                        d_ds = align_raster_to_reference(d_ds, t_ds, resample_alg=gdal.GRA_Bilinear)
                        warnings.append(f"Auto-aligned donor #{idx + 1} to target pixel grid.")

                donor_datasets.append(d_ds)

                # Screen clouds & shadows in donor scene if enabled
                if d.qa_band_path and os.path.exists(d.qa_band_path):
                    qa_ds = align_raster_to_reference(d.qa_band_path, t_ds, resample_alg=gdal.GRA_NearestNeighbour)
                    d_cmask = decode_landsat_qa_pixel(
                        qa_ds.GetRasterBand(1).ReadAsArray(),
                        mask_cloud=config.mask_clouds,
                        mask_shadow=config.mask_shadows,
                        mask_snow=config.mask_snow,
                    )
                    qa_ds = None
                    donor_cloud_masks.append(d_cmask)
                elif config.mask_clouds:
                    d_nd = d_ds.GetRasterBand(1).GetNoDataValue()
                    d_cmask = cls._build_scene_cloud_mask(
                        d_ds,
                        nodata_val=d_nd,
                        brightness_threshold=max(0.68, config.parameters.cloud_brightness_threshold),
                        detect_shadows=config.mask_shadows,
                    )
                    # Guard: only apply auto spectral mask on donor if < 80% of donor is flagged
                    if np.mean(d_cmask) < 0.80:
                        donor_cloud_masks.append(d_cmask)
                    else:
                        donor_cloud_masks.append(None)
                else:
                    donor_cloud_masks.append(None)

        # Precompute target spectral cloud/shadow mask or external custom mask if requested
        target_cloud_mask: Optional[np.ndarray] = None
        if config.mask_source in (GapMaskSource.SLC_AND_CLOUDS, GapMaskSource.CLOUDS_ONLY):
            target_cloud_mask = cls._build_scene_cloud_mask(
                t_ds,
                nodata_val=target_nodata_val,
                brightness_threshold=config.parameters.cloud_brightness_threshold,
                detect_shadows=config.mask_shadows,
            )

        aligned_custom_mask: Optional[np.ndarray] = None
        if config.mask_source == GapMaskSource.CUSTOM_MASK and config.custom_mask_path:
            m_ds = align_raster_to_reference(config.custom_mask_path, t_ds, resample_alg=gdal.GRA_NearestNeighbour)
            aligned_custom_mask = m_ds.GetRasterBand(1).ReadAsArray() > 0
            m_ds = None
        elif config.mask_source == GapMaskSource.AUTO_QA and config.custom_mask_path and os.path.exists(config.custom_mask_path):
            qa_ds = align_raster_to_reference(config.custom_mask_path, t_ds, resample_alg=gdal.GRA_NearestNeighbour)
            aligned_custom_mask = decode_landsat_qa_pixel(
                qa_ds.GetRasterBand(1).ReadAsArray(),
                mask_cloud=config.mask_clouds,
                mask_shadow=config.mask_shadows,
                mask_snow=config.mask_snow,
            )
            qa_ds = None

        # Determine output GDAL datatype
        dtype_pref = config.parameters.output_dtype_name
        out_gdal_dtype = _DTYPE_NAME_MAP.get(dtype_pref, native_gdal_dtype if dtype_pref == "Preserve" else gdal.GDT_Float32)

        # 3. Process each band
        filled_bands: List[np.ndarray] = []
        provenance_bands: List[np.ndarray] = []
        confidence_bands: List[np.ndarray] = []
        remaining_masks: List[np.ndarray] = []
        band_stats_list: List[BandStatistics] = []

        total_orig_gaps = 0
        total_filled_gaps = 0
        total_remaining_gaps = 0
        donor_contributions_accum: Dict[str, int] = {}

        for b_idx in range(1, num_bands + 1):
            pct = 15 + int((b_idx / num_bands) * 68)
            if progress_callback:
                progress_callback(pct, f"Processing Band {b_idx}/{num_bands} via {config.method.value}...")

            t_band = t_ds.GetRasterBand(b_idx)
            nodata_val = t_band.GetNoDataValue()
            t_arr = t_band.ReadAsArray().astype(np.float32)

            # Base NoData / Zero / SLC-off mask
            if nodata_val is not None and not np.isnan(nodata_val):
                slc_or_nd = (t_arr == nodata_val) | np.isnan(t_arr)
            else:
                slc_or_nd = np.isnan(t_arr) | (t_arr == 0)

            if config.mask_source == GapMaskSource.CUSTOM_MASK and aligned_custom_mask is not None:
                internal_gap_mask = aligned_custom_mask.copy()
                exterior_nodata_mask = slc_or_nd & ~internal_gap_mask
            elif config.mask_source == GapMaskSource.AUTO_QA and aligned_custom_mask is not None:
                raw_gap_mask = slc_or_nd | aligned_custom_mask
                valid_mask = ~raw_gap_mask
                internal_gap_mask, exterior_nodata_mask = cls.isolate_internal_gaps(
                    valid_mask=valid_mask,
                    raw_gap_mask=raw_gap_mask,
                    max_gap_distance=max(120, config.parameters.max_triangulation_distance),
                )
            elif config.mask_source == GapMaskSource.CLOUDS_ONLY and target_cloud_mask is not None:
                internal_gap_mask = target_cloud_mask.copy()
                exterior_nodata_mask = slc_or_nd & ~internal_gap_mask
            elif config.mask_source == GapMaskSource.SLC_AND_CLOUDS and target_cloud_mask is not None:
                slc_internal, exterior_nodata_mask = cls.isolate_internal_gaps(
                    valid_mask=~slc_or_nd,
                    raw_gap_mask=slc_or_nd,
                    max_gap_distance=config.parameters.max_triangulation_distance,
                )
                internal_gap_mask = slc_internal | target_cloud_mask
                exterior_nodata_mask = exterior_nodata_mask & ~internal_gap_mask
            elif config.mask_source == GapMaskSource.ZERO_VALUE:
                raw_gap_mask = (t_arr == 0) | np.isnan(t_arr)
                valid_mask = ~raw_gap_mask
                internal_gap_mask, exterior_nodata_mask = cls.isolate_internal_gaps(
                    valid_mask=valid_mask,
                    raw_gap_mask=raw_gap_mask,
                    max_gap_distance=config.parameters.max_triangulation_distance,
                )
            else:
                valid_mask = ~slc_or_nd
                internal_gap_mask, exterior_nodata_mask = cls.isolate_internal_gaps(
                    valid_mask=valid_mask,
                    raw_gap_mask=slc_or_nd,
                    max_gap_distance=config.parameters.max_triangulation_distance,
                )

            orig_gaps = int(np.sum(internal_gap_mask))
            total_orig_gaps += orig_gaps

            if orig_gaps == 0:
                cast_band = clamp_and_cast(t_arr, out_gdal_dtype, nodata_val=nodata_val, nodata_mask=exterior_nodata_mask)
                filled_bands.append(cast_band)
                p_arr = np.zeros((rows, cols), dtype=np.uint8)
                c_arr = np.full((rows, cols), 100, dtype=np.uint8)
                c_arr[exterior_nodata_mask] = 0
                provenance_bands.append(p_arr)
                confidence_bands.append(c_arr)
                remaining_masks.append(np.zeros((rows, cols), dtype=np.uint8))
                band_stats_list.append(
                    BandStatistics(
                        band_index=b_idx,
                        band_name=f"Band {b_idx}",
                        total_pixels=rows * cols,
                        original_gaps=0,
                        filled_pixels=0,
                        remaining_gaps=0,
                        fill_rate_pct=100.0,
                    )
                )
                continue

            # Method execution dispatch on internal_gap_mask
            if config.method == GapFillMethod.TRIANGULATION:
                f_arr, p_arr, c_arr = TriangulationGapFiller.fill_band(
                    band_array=t_arr,
                    gap_mask=internal_gap_mask,
                    max_gap_distance=max(config.parameters.max_triangulation_distance, 150),
                    support_sampling=config.parameters.support_pixel_sampling,
                    enable_nearest_fallback=config.parameters.enable_nearest_fallback,
                )
                slope, intercept, corr, r_sq = 1.0, 0.0, 1.0, 1.0

            elif config.method == GapFillMethod.GLOBAL_MATCHING:
                d_band = donor_datasets[0].GetRasterBand(min(b_idx, donor_datasets[0].RasterCount))
                d_arr = d_band.ReadAsArray().astype(np.float32)

                f_arr, p_arr, c_arr, stats = GlobalStatisticalMatcher.fit_and_fill_band(
                    target_array=t_arr,
                    target_gap_mask=internal_gap_mask,
                    donor_array=d_arr,
                    donor_mask=donor_cloud_masks[0],
                    use_robust_regression=config.parameters.use_robust_regression,
                    mad_threshold=config.parameters.outlier_mad_threshold,
                    donor_id=2,
                )
                slope = stats.get("slope", 1.0)
                intercept = stats.get("intercept", 0.0)
                corr = stats.get("correlation", 1.0)
                r_sq = stats.get("r_squared", 1.0)

            elif config.method == GapFillMethod.LOCAL_MATCHING:
                d_band = donor_datasets[0].GetRasterBand(min(b_idx, donor_datasets[0].RasterCount))
                d_arr = d_band.ReadAsArray().astype(np.float32)

                f_arr, p_arr, c_arr, stats = LocalStatisticalMatcher.fit_and_fill_band(
                    target_array=t_arr,
                    target_gap_mask=internal_gap_mask,
                    donor_array=d_arr,
                    donor_mask=donor_cloud_masks[0],
                    initial_window_size=config.parameters.initial_window_size,
                    max_window_size=config.parameters.max_window_size,
                    min_paired_samples=config.parameters.min_paired_samples,
                    correlation_threshold=config.parameters.correlation_threshold,
                    use_robust_regression=config.parameters.use_robust_regression,
                    seam_feather_width=config.parameters.seam_feather_width,
                    donor_id=2,
                )
                slope = stats.get("slope", 1.0)
                intercept = stats.get("intercept", 0.0)
                corr = stats.get("correlation", 1.0)
                r_sq = stats.get("r_squared", 1.0)

            elif config.method == GapFillMethod.MULTI_DONOR:
                d_arrays = [
                    ds.GetRasterBand(min(b_idx, ds.RasterCount)).ReadAsArray().astype(np.float32)
                    for ds in donor_datasets
                ]
                f_arr, p_arr, c_arr, stats = MultiDonorSmartFiller.rank_and_fill_band(
                    target_array=t_arr,
                    target_gap_mask=internal_gap_mask,
                    donor_arrays=d_arrays,
                    donor_specs=config.donors,
                    donor_masks=donor_cloud_masks,
                    use_local_matching=True,
                    initial_window_size=config.parameters.initial_window_size,
                    min_paired_samples=config.parameters.min_paired_samples,
                    correlation_threshold=config.parameters.correlation_threshold,
                )
                ranked = stats.get("ranked_donors", [])
                if ranked:
                    best_idx = ranked[0].get("index", 0)
                    corr = ranked[0].get("correlation", 1.0)
                    r_sq = round(max(0.0, corr * corr), 4)
                    slope, intercept = 1.0, 0.0
                    _ = best_idx
                else:
                    slope, intercept, corr, r_sq = 1.0, 0.0, 1.0, 1.0
                for d_name, count in stats.get("donor_contributions", {}).items():
                    donor_contributions_accum[d_name] = donor_contributions_accum.get(d_name, 0) + count

            # Optional residual Delaunay triangulation fallback for tiny unrecovered holes
            still_unfilled = internal_gap_mask & (p_arr == 0)
            if (
                config.method != GapFillMethod.TRIANGULATION
                and config.parameters.residual_triangulation_fallback
                and np.any(still_unfilled)
            ):
                tri_arr, tri_p, tri_c = TriangulationGapFiller.fill_band(
                    band_array=f_arr,
                    gap_mask=still_unfilled,
                    max_gap_distance=config.parameters.max_triangulation_distance,
                    support_sampling=max(1, config.parameters.support_pixel_sampling),
                    enable_nearest_fallback=False,
                )
                newly_filled = still_unfilled & (tri_p > 0)
                if np.any(newly_filled):
                    f_arr[newly_filled] = tri_arr[newly_filled]
                    p_arr[newly_filled] = 1  # 1 = Triangulation fallback
                    c_arr[newly_filled] = tri_c[newly_filled]

            # Enforce exterior NoData values remain strictly untouched
            out_fill_nd = nodata_val
            if out_fill_nd is None and config.mask_source == GapMaskSource.ZERO_VALUE:
                out_fill_nd = 0.0

            p_arr[exterior_nodata_mask] = 0
            c_arr[exterior_nodata_mask] = 0
            rem_band_mask = (internal_gap_mask & (p_arr == 0)).astype(np.uint8)

            cast_band = clamp_and_cast(
                f_arr,
                out_gdal_dtype,
                nodata_val=out_fill_nd,
                nodata_mask=exterior_nodata_mask,
            )

            filled_count = int(np.sum(internal_gap_mask & (p_arr > 0)))
            rem_gaps = orig_gaps - filled_count
            total_filled_gaps += filled_count
            total_remaining_gaps += rem_gaps
            b_fill_rate = (filled_count / max(1, orig_gaps)) * 100.0

            filled_bands.append(cast_band)
            provenance_bands.append(p_arr)
            confidence_bands.append(c_arr)
            remaining_masks.append(rem_band_mask)

            band_stats_list.append(
                BandStatistics(
                    band_index=b_idx,
                    band_name=f"Band {b_idx}",
                    slope=slope,
                    intercept=intercept,
                    correlation=corr,
                    r_squared=r_sq,
                    total_pixels=rows * cols,
                    original_gaps=orig_gaps,
                    filled_pixels=filled_count,
                    remaining_gaps=rem_gaps,
                    fill_rate_pct=round(b_fill_rate, 2),
                )
            )

        t_ds = None
        for d_ds in donor_datasets:
            d_ds = None

        # 4. Serialize Output Filled Raster
        if progress_callback:
            progress_callback(88, "Writing output filled GeoTIFF...")

        out_nodata = target_nodata_val
        if out_nodata is None and config.mask_source == GapMaskSource.ZERO_VALUE:
            out_nodata = 0.0

        base_root, ext = os.path.splitext(config.target_path)
        ext = ext or ".tif"
        out_path = config.output_filled_path or f"{base_root}_filled{ext}"
        out_root, _ = os.path.splitext(out_path)

        ProvenanceManager.save_raster(
            output_path=out_path,
            bands_data=filled_bands,
            geotransform=gt,
            projection_wkt=proj_wkt,
            nodata_val=out_nodata,
            gdal_dtype=out_gdal_dtype,
            compress=config.parameters.compress,
            metadata_dict={"MODULE": "AriesGapfill", "METHOD": config.method.value},
        )

        # 5. Output Provenance Raster
        out_prov_path = None
        if config.generate_provenance and provenance_bands:
            out_prov_path = config.output_provenance_path or f"{out_root}_provenance.tif"
            ProvenanceManager.save_mask_raster(
                output_path=out_prov_path,
                mask_array=provenance_bands[0],
                geotransform=gt,
                projection_wkt=proj_wkt,
                description="AriesGapfill Provenance: 0=Original, 1=Triangulation, 2+=Donor",
            )

        # 6. Output Confidence Raster
        out_conf_path = None
        if config.generate_confidence and confidence_bands:
            out_conf_path = config.output_confidence_path or f"{out_root}_confidence.tif"
            ProvenanceManager.save_mask_raster(
                output_path=out_conf_path,
                mask_array=confidence_bands[0],
                geotransform=gt,
                projection_wkt=proj_wkt,
                description="AriesGapfill Confidence Score (0-100)",
            )

        # 7. Output Remaining-Gap Mask
        out_rem_path = None
        if config.generate_remaining_gap_mask and remaining_masks:
            out_rem_path = config.output_remaining_gap_path or f"{out_root}_remaining_gaps.tif"
            ProvenanceManager.save_mask_raster(
                output_path=out_rem_path,
                mask_array=remaining_masks[0],
                geotransform=gt,
                projection_wkt=proj_wkt,
                description="AriesGapfill Remaining Gaps Mask: 1=Unfilled, 0=Valid/Filled",
            )

        overall_fill_rate = (total_filled_gaps / max(1, total_orig_gaps)) * 100.0 if total_orig_gaps > 0 else 100.0
        mean_conf = float(np.mean([np.mean(c) for c in confidence_bands])) if confidence_bands else 100.0

        res = GapFillResult(
            success=True,
            output_filled_path=out_path,
            output_provenance_path=out_prov_path,
            output_confidence_path=out_conf_path,
            output_remaining_gap_path=out_rem_path,
            total_pixels=rows * cols * num_bands,
            original_gap_count=total_orig_gaps,
            filled_gap_count=total_filled_gaps,
            remaining_gap_count=total_remaining_gaps,
            overall_fill_rate_pct=round(float(overall_fill_rate), 2),
            mean_confidence_score=round(mean_conf, 1),
            band_stats=band_stats_list,
            donor_contributions=donor_contributions_accum,
            execution_time_seconds=round(time.time() - start_time, 2),
            warnings=warnings,
        )

        # 8. Generate Provenance Reports
        if config.generate_report:
            if progress_callback:
                progress_callback(96, "Generating HTML & JSON audit report...")
            rep_path = config.output_report_path or f"{out_root}_report.html"
            json_path = os.path.splitext(rep_path)[0] + ".json"
            GapFillReportGenerator.generate_report(config, res, rep_path, json_path)
            res.output_report_path = rep_path

        if progress_callback:
            progress_callback(100, "Gap filling completed successfully.")

        return res

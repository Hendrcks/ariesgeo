"""
Unified execution engine for AriesGapfill. Coordinates reading, method dispatch, QA generation, and report export.
"""

import os
import time
import numpy as np
from osgeo import gdal
from typing import List, Optional, Callable, Tuple, Dict, Any

from .models import (
    GapFillConfig, GapFillResult, GapFillMethod, GapMaskSource,
    BandStatistics, DonorSpec
)
from .triangulation import TriangulationGapFiller
from .matching import GlobalStatisticalMatcher
from .local_matching import LocalStatisticalMatcher
from .multi_donor import MultiDonorSmartFiller
from .provenance import ProvenanceManager
from .reports import GapFillReportGenerator
from ..core.exceptions import GapFillError
from ..core.logging import log_info, log_error


class AriesGapFillEngine:
    """
    Core pipeline orchestrator for AriesGapfill.
    Supports single-image triangulation, global matching, local matching, and multi-donor composites.
    """

    @classmethod
    def isolate_internal_gaps(
        cls,
        valid_mask: np.ndarray,
        raw_gap_mask: np.ndarray,
        max_gap_distance: int = 50
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        Separates internal missing scanlines/holes from exterior background NoData.
        
        Returns:
            Tuple of (internal_gap_mask, exterior_nodata_mask)
        """
        valid_count = int(np.sum(valid_mask))
        raw_gap_count = int(np.sum(raw_gap_mask))
        
        if valid_count == 0 or raw_gap_count == 0:
            return raw_gap_mask, np.zeros_like(raw_gap_mask)

        try:
            from scipy.ndimage import distance_transform_edt, binary_closing, binary_dilation
            
            # 1. Distance transform: Euclidean distance in pixels to nearest valid pixel
            dist = distance_transform_edt(~valid_mask)
            
            # 2. Morphological footprint with isotropic circular disk kernel
            # Closes internal stripe gaps without distorting arbitrary curved/polygon borders
            r = min(20, max(4, max_gap_distance // 2))
            y, x = np.ogrid[-r:r+1, -r:r+1]
            struct = (x * x + y * y <= r * r)
            footprint = binary_closing(valid_mask, structure=struct)
            # Slight dilation to cover perimeter boundary apexes
            footprint = binary_dilation(footprint, structure=np.ones((3, 3), dtype=bool))
            
            # 3. Internal gaps must be within max_gap_distance AND inside the closed scene footprint
            internal_gap_mask = raw_gap_mask & (dist <= max_gap_distance) & footprint
            exterior_nodata_mask = raw_gap_mask & ~internal_gap_mask
            
            return internal_gap_mask, exterior_nodata_mask
        except Exception as e:
            log_warning(f"Footprint isolation error: {e}. Using distance filter on raw gap mask.")
            try:
                from scipy.ndimage import distance_transform_edt
                dist = distance_transform_edt(~valid_mask)
                internal_gap_mask = raw_gap_mask & (dist <= max_gap_distance)
                exterior_nodata_mask = raw_gap_mask & ~internal_gap_mask
                return internal_gap_mask, exterior_nodata_mask
            except Exception:
                return raw_gap_mask, np.zeros_like(raw_gap_mask)

    @classmethod
    def execute(
        cls,
        config: GapFillConfig,
        progress_callback: Optional[Callable[[float, str], None]] = None
    ) -> GapFillResult:
        """
        Executes the full gap fill pipeline according to the configuration.
        """
        start_time = time.time()
        warnings: List[str] = []

        if not os.path.exists(config.target_path):
            raise GapFillError(f"Target raster not found: {config.target_path}")

        # 1. Open Target Dataset
        t_ds = gdal.Open(config.target_path, gdal.GA_ReadOnly)
        if not t_ds:
            raise GapFillError(f"Cannot open target raster: {config.target_path}")

        cols = t_ds.RasterXSize
        rows = t_ds.RasterYSize
        num_bands = t_ds.RasterCount
        gt = t_ds.GetGeoTransform()
        proj_wkt = t_ds.GetProjection()

        # Capture target nodata value if available
        first_band = t_ds.GetRasterBand(1)
        target_nodata_val = first_band.GetNoDataValue()

        if progress_callback:
            progress_callback(10, f"Target loaded ({cols}x{rows}, {num_bands} bands). Validating donors...")

        # 2. Open Donor Datasets if donor-based method
        donor_datasets: List[gdal.Dataset] = []
        if config.method in [GapFillMethod.GLOBAL_MATCHING, GapFillMethod.LOCAL_MATCHING, GapFillMethod.MULTI_DONOR]:
            if not config.donors:
                raise GapFillError("Donor scene is required for statistical matching methods.")
            
            for d in config.donors:
                if not os.path.exists(d.filepath):
                    raise GapFillError(f"Donor raster not found: {d.filepath}")
                d_ds = gdal.Open(d.filepath, gdal.GA_ReadOnly)
                if not d_ds:
                    raise GapFillError(f"Cannot open donor raster: {d.filepath}")
                donor_datasets.append(d_ds)

        # 3. Process each band
        filled_bands: List[np.ndarray] = []
        provenance_bands: List[np.ndarray] = []
        confidence_bands: List[np.ndarray] = []
        band_stats_list: List[BandStatistics] = []

        total_orig_gaps = 0
        total_filled_gaps = 0
        total_remaining_gaps = 0
        donor_contributions_accum: dict = {}

        for b_idx in range(1, num_bands + 1):
            pct = 15 + int((b_idx / num_bands) * 65)
            if progress_callback:
                progress_callback(pct, f"Processing Band {b_idx}/{num_bands} via {config.method.value}...")

            t_band = t_ds.GetRasterBand(b_idx)
            nodata_val = t_band.GetNoDataValue()
            t_arr = t_band.ReadAsArray().astype(np.float32)

            # Determine valid and raw gap mask
            if config.mask_source == GapMaskSource.CUSTOM_MASK and config.custom_mask_path:
                m_ds = gdal.Open(config.custom_mask_path, gdal.GA_ReadOnly)
                raw_gap_mask = (m_ds.GetRasterBand(1).ReadAsArray() > 0)
                m_ds = None
                valid_mask = ~raw_gap_mask & ~np.isnan(t_arr)
            elif config.mask_source == GapMaskSource.ZERO_VALUE:
                raw_gap_mask = (t_arr == 0) | np.isnan(t_arr)
                valid_mask = (t_arr != 0) & ~np.isnan(t_arr)
            else:
                if nodata_val is not None and not np.isnan(nodata_val):
                    raw_gap_mask = (t_arr == nodata_val) | np.isnan(t_arr)
                    valid_mask = (t_arr != nodata_val) & ~np.isnan(t_arr)
                else:
                    raw_gap_mask = np.isnan(t_arr) | (t_arr == 0)
                    valid_mask = ~np.isnan(t_arr) & (t_arr != 0)

            # Isolate internal gaps (SLC-off lines, small missing patches) from exterior background NoData
            max_dist = config.parameters.max_triangulation_distance
            internal_gap_mask, exterior_nodata_mask = cls.isolate_internal_gaps(
                valid_mask=valid_mask,
                raw_gap_mask=raw_gap_mask,
                max_gap_distance=max_dist
            )

            orig_gaps = int(np.sum(internal_gap_mask))
            total_orig_gaps += orig_gaps

            if orig_gaps == 0:
                # No internal gaps to fill in this band
                filled_bands.append(t_arr)
                p_arr = np.zeros((rows, cols), dtype=np.uint8)
                c_arr = np.full((rows, cols), 100, dtype=np.uint8)
                c_arr[exterior_nodata_mask] = 0
                provenance_bands.append(p_arr)
                confidence_bands.append(c_arr)
                band_stats_list.append(BandStatistics(
                    band_index=b_idx,
                    band_name=f"Band {b_idx}",
                    total_pixels=rows * cols,
                    original_gaps=0,
                    filled_pixels=0,
                    remaining_gaps=0,
                    fill_rate_pct=100.0
                ))
                continue

            # Method execution dispatch on internal_gap_mask
            if config.method == GapFillMethod.TRIANGULATION:
                f_arr, p_arr, c_arr = TriangulationGapFiller.fill_band(
                    band_array=t_arr,
                    gap_mask=internal_gap_mask,
                    max_gap_distance=config.parameters.max_triangulation_distance,
                    support_sampling=config.parameters.support_pixel_sampling,
                    enable_nearest_fallback=config.parameters.enable_nearest_fallback
                )
                slope, intercept, corr, r_sq = 1.0, 0.0, 1.0, 1.0

            elif config.method == GapFillMethod.GLOBAL_MATCHING:
                # First donor band
                d_band = donor_datasets[0].GetRasterBand(min(b_idx, donor_datasets[0].RasterCount))
                d_arr = d_band.ReadAsArray().astype(np.float32)

                f_arr, p_arr, c_arr, stats = GlobalStatisticalMatcher.fit_and_fill_band(
                    target_array=t_arr,
                    target_gap_mask=internal_gap_mask,
                    donor_array=d_arr,
                    use_robust_regression=config.parameters.use_robust_regression,
                    mad_threshold=config.parameters.outlier_mad_threshold,
                    donor_id=2
                )
                slope = stats.get("slope", 1.0)
                intercept = stats.get("intercept", 0.0)
                corr = stats.get("correlation", 1.0)
                r_sq = stats.get("r_squared", 1.0)

            elif config.method == GapFillMethod.LOCAL_MATCHING:
                d_band = donor_datasets[0].GetRasterBand(min(b_idx, donor_datasets[0].RasterCount))
                d_arr = d_band.ReadAsArray().astype(np.float32)

                f_arr, p_arr, c_arr, stats = LocalStatisticalMatcher.fit_and_fill_band(
                    target_array=t_arr,
                    target_gap_mask=internal_gap_mask,
                    donor_array=d_arr,
                    initial_window_size=config.parameters.initial_window_size,
                    max_window_size=config.parameters.max_window_size,
                    min_paired_samples=config.parameters.min_paired_samples,
                    correlation_threshold=config.parameters.correlation_threshold,
                    use_robust_regression=config.parameters.use_robust_regression,
                    donor_id=2
                )
                slope = stats.get("slope", 1.0)
                intercept = stats.get("intercept", 0.0)
                corr = stats.get("correlation", 1.0)
                r_sq = stats.get("r_squared", 1.0)

            elif config.method == GapFillMethod.MULTI_DONOR:
                d_arrays = [
                    ds.GetRasterBand(min(b_idx, ds.RasterCount)).ReadAsArray().astype(np.float32)
                    for ds in donor_datasets
                ]
                f_arr, p_arr, c_arr, stats = MultiDonorSmartFiller.rank_and_fill_band(
                    target_array=t_arr,
                    target_gap_mask=internal_gap_mask,
                    donor_arrays=d_arrays,
                    donor_specs=config.donors,
                    use_local_matching=True,
                    initial_window_size=config.parameters.initial_window_size,
                    min_paired_samples=config.parameters.min_paired_samples,
                    correlation_threshold=config.parameters.correlation_threshold
                )
                slope, intercept, corr, r_sq = 1.0, 0.0, 1.0, 1.0
                for d_name, count in stats.get("donor_contributions", {}).items():
                    donor_contributions_accum[d_name] = donor_contributions_accum.get(d_name, 0) + count

            # Enforce exterior NoData values remain untouched
            if nodata_val is not None and not np.isnan(nodata_val):
                f_arr[exterior_nodata_mask] = nodata_val
            elif config.mask_source == GapMaskSource.ZERO_VALUE:
                f_arr[exterior_nodata_mask] = 0.0
            
            p_arr[exterior_nodata_mask] = 0
            c_arr[exterior_nodata_mask] = 0

            # Evaluate band results
            filled_count = int(np.sum(p_arr > 0))
            rem_gaps = orig_gaps - filled_count
            total_filled_gaps += filled_count
            total_remaining_gaps += rem_gaps
            b_fill_rate = (filled_count / max(1, orig_gaps)) * 100.0

            filled_bands.append(f_arr)
            provenance_bands.append(p_arr)
            confidence_bands.append(c_arr)

            band_stats_list.append(BandStatistics(
                band_index=b_idx,
                band_name=f"Band {b_idx}",
                slope=slope,
                intercept=intercept,
                correlation=corr,
                r_squared=r_sq,
                total_pixels=rows * cols,
                original_gaps=orig_gaps,
                filled_pixels=filled_count,
                remaining_gaps=rem_gaps,
                fill_rate_pct=round(b_fill_rate, 2)
            ))

        # Close reader datasets
        t_ds = None
        for d_ds in donor_datasets:
            d_ds = None

        # 4. Serialize Output Filled Raster
        if progress_callback:
            progress_callback(85, "Writing output filled GeoTIFF...")

        out_nodata = target_nodata_val
        if out_nodata is None and config.mask_source == GapMaskSource.ZERO_VALUE:
            out_nodata = 0.0

        out_path = config.output_filled_path or config.target_path.replace(".tif", "_filled.tif")
        ProvenanceManager.save_raster(
            output_path=out_path,
            bands_data=filled_bands,
            geotransform=gt,
            projection_wkt=proj_wkt,
            nodata_val=out_nodata,
            compress=config.parameters.compress,
            metadata_dict={"MODULE": "AriesGapfill", "METHOD": config.method.value}
        )

        # 5. Output Provenance Raster
        out_prov_path = None
        if config.generate_provenance:
            out_prov_path = config.output_provenance_path or out_path.replace(".tif", "_provenance.tif")
            ProvenanceManager.save_mask_raster(
                output_path=out_prov_path,
                mask_array=provenance_bands[0],
                geotransform=gt,
                projection_wkt=proj_wkt,
                description="AriesGapfill Provenance: 0=Original, 1=Triangulation, 2+=Donor"
            )

        # 6. Output Confidence Raster
        out_conf_path = None
        if config.generate_confidence:
            out_conf_path = config.output_confidence_path or out_path.replace(".tif", "_confidence.tif")
            ProvenanceManager.save_mask_raster(
                output_path=out_conf_path,
                mask_array=confidence_bands[0],
                geotransform=gt,
                projection_wkt=proj_wkt,
                description="AriesGapfill Confidence Score (0-100)"
            )

        # 7. Output Remaining-Gap Mask
        out_rem_path = None
        if config.generate_remaining_gap_mask:
            out_rem_path = config.output_remaining_gap_path or out_path.replace(".tif", "_remaining_gaps.tif")
            rem_mask = (provenance_bands[0] == 0) & (total_remaining_gaps > 0)
            ProvenanceManager.save_mask_raster(
                output_path=out_rem_path,
                mask_array=rem_mask,
                geotransform=gt,
                projection_wkt=proj_wkt,
                description="AriesGapfill Remaining Gaps Mask: 1=Unfilled, 0=Valid/Filled"
            )

        overall_fill_rate = (total_filled_gaps / max(1, total_orig_gaps)) * 100.0 if total_orig_gaps > 0 else 100.0
        mean_conf = float(np.mean([np.mean(c) for c in confidence_bands])) if confidence_bands else 100.0

        res = GapFillResult(
            success=True,
            output_filled_path=out_path,
            output_provenance_path=out_prov_path,
            output_confidence_path=out_conf_path,
            output_remaining_gap_path=out_rem_path,
            total_pixels=rows * cols * num_bands,
            original_gap_count=total_orig_gaps,
            filled_gap_count=total_filled_gaps,
            remaining_gap_count=total_remaining_gaps,
            overall_fill_rate_pct=round(float(overall_fill_rate), 2),
            mean_confidence_score=round(mean_conf, 1),
            band_stats=band_stats_list,
            donor_contributions=donor_contributions_accum,
            execution_time_seconds=round(time.time() - start_time, 2),
            warnings=warnings
        )

        # 8. Generate Provenance Reports
        if config.generate_report:
            if progress_callback:
                progress_callback(95, "Generating HTML & JSON audit report...")
            rep_path = config.output_report_path or out_path.replace(".tif", "_report.html")
            json_path = rep_path.replace(".html", ".json")
            GapFillReportGenerator.generate_report(config, res, rep_path, json_path)
            res.output_report_path = rep_path

        if progress_callback:
            progress_callback(100, "Gap filling completed successfully.")

        return res

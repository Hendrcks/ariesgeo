"""
AriesGeo Toolbox - Raster IO Utilities.
Safe windowed IO, GDAL creation options, COG drivers, and NoData management.
"""

import os
from typing import Optional, Tuple, List, Generator
import numpy as np
from osgeo import gdal, osr

# Configure GDAL defaults
gdal.UseExceptions()

DEFAULT_TILED_CREATION_OPTIONS = [
    "TILED=YES",
    "BLOCKXSIZE=256",
    "BLOCKYSIZE=256",
    "COMPRESS=DEFLATE",
    "PREDICTOR=2",
    "ZLEVEL=6",
    "BIGTIFF=IF_SAFER"
]

DEFAULT_COG_CREATION_OPTIONS = [
    "COMPRESS=DEFLATE",
    "PREDICTOR=2",
    "LEVEL=6",
    "OVERVIEWS=AUTO",
    "BIGTIFF=IF_SAFER"
]

def open_raster_dataset(path: str, write_mode: bool = False) -> gdal.Dataset:
    """Open a GDAL dataset safely."""
    if not os.path.exists(path):
        raise FileNotFoundError(f"Raster file not found: {path}")
    access = gdal.GA_Update if write_mode else gdal.GA_ReadOnly
    ds = gdal.Open(path, access)
    if ds is None:
        raise RuntimeError(f"GDAL could not open raster: {path}")
    return ds

def create_geotiff(
    output_path: str,
    width: int,
    height: int,
    bands: int = 1,
    data_type: int = gdal.GDT_Float32,
    geotransform: Optional[Tuple[float, ...]] = None,
    projection_wkt: Optional[str] = None,
    nodata_value: Optional[float] = -9999.0,
    options: Optional[List[str]] = None
) -> gdal.Dataset:
    """Create a new GeoTIFF dataset with standard compression and tiling."""
    os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
    driver = gdal.GetDriverByName("GTiff")
    opts = options if options is not None else DEFAULT_TILED_CREATION_OPTIONS
    
    ds = driver.Create(output_path, width, height, bands, data_type, opts)
    if geotransform:
        ds.SetGeoTransform(geotransform)
    if projection_wkt:
        ds.SetProjection(projection_wkt)
        
    if nodata_value is not None:
        for b in range(1, bands + 1):
            band = ds.GetRasterBand(b)
            band.SetNoDataValue(nodata_value)
            
    return ds

def iter_blocks(
    dataset: gdal.Dataset,
    block_size_x: int = 512,
    block_size_y: int = 512
) -> Generator[Tuple[int, int, int, int], None, None]:
    """Yield (x_offset, y_offset, x_size, y_size) for block-by-block streaming processing."""
    width = dataset.RasterXSize
    height = dataset.RasterYSize
    
    for y in range(0, height, block_size_y):
        y_size = min(block_size_y, height - y)
        for x in range(0, width, block_size_x):
            x_size = min(block_size_x, width - x)
            yield x, y, x_size, y_size

def export_as_cog(
    input_path: str,
    output_path: str,
    overview_resampling: str = "AVERAGE",
    compress: str = "DEFLATE",
    predictor: int = 2
) -> str:
    """Convert an input raster to a validated Cloud Optimized GeoTIFF (COG)."""
    os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
    src_ds = open_raster_dataset(input_path)
    
    # Try GDAL COG driver if available
    cog_driver = gdal.GetDriverByName("COG")
    if cog_driver:
        cog_opts = [
            f"COMPRESS={compress}",
            f"PREDICTOR={predictor}",
            f"RESAMPLING={overview_resampling}",
            "BIGTIFF=IF_SAFER"
        ]
        out_ds = cog_driver.CreateCopy(output_path, src_ds, options=cog_opts)
        out_ds.FlushCache()
        out_ds = None
        src_ds = None
        return output_path
        
    # Fallback: Create GeoTIFF, build internal overviews, then copy
    gtiff_driver = gdal.GetDriverByName("GTiff")
    opts = [
        f"COMPRESS={compress}",
        f"PREDICTOR={predictor}",
        "TILED=YES",
        "BLOCKXSIZE=512",
        "BLOCKYSIZE=512",
        "COPY_SRC_OVERVIEWS=YES"
    ]
    # Build overviews on source if not present
    src_ds.BuildOverviews(overview_resampling, [2, 4, 8, 16, 32])
    out_ds = gtiff_driver.CreateCopy(output_path, src_ds, options=opts)
    out_ds.FlushCache()
    out_ds = None
    src_ds = None
    return output_path


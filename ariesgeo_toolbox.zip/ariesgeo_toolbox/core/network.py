"""
Network request manager for AriesGeo Toolbox using QgsNetworkAccessManager
and scheme-validated HTTP/HTTPS transport (`http.client` + verified TLS).
"""

import http.client
import json
import os
import ssl
import urllib.parse
from typing import Any, Dict, Optional, Callable, Tuple
from qgis.PyQt.QtCore import QObject, pyqtSignal, QUrl, QEventLoop, QTimer
from qgis.PyQt.QtNetwork import QNetworkRequest, QNetworkReply
from qgis.core import QgsNetworkAccessManager
from .logging import log_warning, log_critical

USER_AGENT = "AriesGeoToolbox-QGIS/4.0.1 (AriesPlus; ariesplusgeo@gmail.com)"
ALLOWED_HTTP_SCHEMES = ("https", "http")
MAX_HTTP_REDIRECTS = 5


def validate_http_url(url: str) -> urllib.parse.SplitResult:
    """
    Validate that `url` uses an explicit `http` or `https` scheme and has a valid host.
    Explicitly blocks `file://`, `ftp://`, `data:`, custom schemes, and CRLF injection.
    """
    if not isinstance(url, str) or not url.strip():
        raise ValueError("URL must be a non-empty string.")
    cleaned = url.strip()
    if any(ch in cleaned for ch in ("\r", "\n", "\x00")):
        raise ValueError("URL contains disallowed control characters.")
    parsed = urllib.parse.urlsplit(cleaned)
    if parsed.scheme.lower() not in ALLOWED_HTTP_SCHEMES:
        raise ValueError(
            f"Disallowed URL scheme '{parsed.scheme or '<empty>'}'. Only http:// and https:// are permitted."
        )
    if not parsed.hostname:
        raise ValueError("URL must specify a valid hostname.")
    return parsed


def _open_validated_connection(parsed: urllib.parse.SplitResult, timeout: float) -> http.client.HTTPConnection:
    if parsed.scheme.lower() == "https":
        tls_context = ssl.create_default_context()
        return http.client.HTTPSConnection(
            parsed.hostname,
            port=parsed.port or 443,
            timeout=timeout,
            context=tls_context,
        )
    return http.client.HTTPConnection(
        parsed.hostname,
        port=parsed.port or 80,
        timeout=timeout,
    )


def _request_target(parsed: urllib.parse.SplitResult) -> str:
    path = parsed.path or "/"
    if parsed.query:
        return f"{path}?{parsed.query}"
    return path


def safe_http_request(
    url: str,
    method: str = "GET",
    body: Optional[bytes] = None,
    headers: Optional[Dict[str, str]] = None,
    timeout: float = 30.0,
) -> Tuple[int, Dict[str, str], bytes]:
    """
    Execute an HTTP/HTTPS request after strict scheme validation, following up to
    `MAX_HTTP_REDIRECTS` redirects (re-validating the scheme on every hop).
    """
    current_url = url
    current_method = method.upper()
    current_body = body

    req_headers: Dict[str, str] = {"User-Agent": USER_AGENT}
    if headers:
        req_headers.update(headers)

    for _ in range(MAX_HTTP_REDIRECTS + 1):
        parsed = validate_http_url(current_url)
        conn = _open_validated_connection(parsed, timeout=timeout)
        try:
            conn.request(current_method, _request_target(parsed), body=current_body, headers=req_headers)
            resp = conn.getresponse()
            status = int(resp.status)
            resp_headers = {k.lower(): v for k, v in resp.getheaders()}

            if status in (301, 302, 303, 307, 308):
                resp.read()
                location = resp_headers.get("location")
                if not location:
                    raise RuntimeError(f"HTTP {status} redirect missing Location header.")
                current_url = urllib.parse.urljoin(current_url, location)
                validate_http_url(current_url)
                if status == 303 or (status in (301, 302) and current_method == "POST"):
                    current_method = "GET"
                    current_body = None
                continue

            payload = resp.read()
            if status >= 400:
                raise RuntimeError(f"HTTP {status} {resp.reason} for {current_url}")
            return status, resp_headers, payload
        finally:
            conn.close()

    raise RuntimeError(f"Exceeded maximum redirects ({MAX_HTTP_REDIRECTS}) for {url}")

class NetworkClient(QObject):
    """Proxy-aware asynchronous and synchronous HTTP JSON client."""

    finished = pyqtSignal(dict, object)  # response_json, user_data
    error = pyqtSignal(str, object)      # error_message, user_data

    def __init__(self, parent: Optional[QObject] = None):
        super().__init__(parent)
        self.nam = QgsNetworkAccessManager.instance()

    def _prepare_request(self, url_str: str, headers: Optional[Dict[str, str]] = None) -> QNetworkRequest:
        url = QUrl(url_str)
        request = QNetworkRequest(url)
        request.setHeader(QNetworkRequest.KnownHeaders.UserAgentHeader, USER_AGENT)
        request.setRawHeader(b"Accept", b"application/json")
        if headers:
            for k, v in headers.items():
                request.setRawHeader(k.encode("utf-8"), v.encode("utf-8"))
        return request

    def get_json_async(
        self,
        url_str: str,
        on_success: Optional[Callable[[Dict[str, Any], Any], None]] = None,
        on_error: Optional[Callable[[str, Any], None]] = None,
        user_data: Any = None,
        timeout_ms: int = 10000,
    ) -> QNetworkReply:
        """Issue an asynchronous GET request expecting JSON."""
        request = self._prepare_request(url_str)
        reply = self.nam.get(request)

        timer = QTimer(reply)
        timer.setSingleShot(True)
        timer.setInterval(timeout_ms)

        def handle_timeout():
            if reply.isRunning():
                reply.abort()
                err_msg = f"Request timed out after {timeout_ms / 1000:.1f}s: {url_str}"
                log_warning(err_msg)
                if on_error:
                    on_error(err_msg, user_data)
                self.error.emit(err_msg, user_data)

        timer.timeout.connect(handle_timeout)
        timer.start()

        def handle_finished():
            timer.stop()
            if reply.error() != QNetworkReply.NetworkError.NoError:
                err_str = reply.errorString()
                # If aborted by timeout, already reported
                if "aborted" not in err_str.lower():
                    log_warning(f"Network error ({reply.error()}): {err_str} for {url_str}")
                    if on_error:
                        on_error(err_str, user_data)
                    self.error.emit(err_str, user_data)
                reply.deleteLater()
                return

            raw_data = reply.readAll().data()
            try:
                text = raw_data.decode("utf-8")
                parsed = json.loads(text)
                if on_success:
                    on_success(parsed, user_data)
                self.finished.emit(parsed, user_data)
            except Exception as e:
                err_msg = f"Failed to parse JSON response: {str(e)}"
                log_critical(err_msg)
                if on_error:
                    on_error(err_msg, user_data)
                self.error.emit(err_msg, user_data)
            finally:
                reply.deleteLater()

        reply.finished.connect(handle_finished)
        return reply

    def get_json_sync(self, url_str: str, timeout_ms: int = 10000) -> Dict[str, Any]:
        """Synchronously perform GET request and return parsed JSON."""
        loop = QEventLoop()
        result_holder = {"data": None, "error": None}

        def on_ok(data, _):
            result_holder["data"] = data
            loop.quit()

        def on_err(err, _):
            result_holder["error"] = err
            loop.quit()

        self.get_json_async(url_str, on_success=on_ok, on_error=on_err, timeout_ms=timeout_ms)
        loop.exec()

        if result_holder["error"]:
            raise RuntimeError(result_holder["error"])
        return result_holder["data"]

"""
Network request manager for AriesGeo Toolbox using QgsNetworkAccessManager.
"""

import json
import urllib.parse
from typing import Any, Dict, Optional, Callable
from qgis.PyQt.QtCore import QObject, pyqtSignal, QUrl, QEventLoop, QTimer
from qgis.PyQt.QtNetwork import QNetworkRequest, QNetworkReply
from qgis.core import QgsNetworkAccessManager
from .logging import log_warning, log_critical

USER_AGENT = "AriesGeoToolbox-QGIS/0.1.0 (AriesPlus; ariesplusgeo@gmail.com)"

class NetworkClient(QObject):
    """Proxy-aware asynchronous and synchronous HTTP JSON client."""

    finished = pyqtSignal(dict, object)  # response_json, user_data
    error = pyqtSignal(str, object)      # error_message, user_data

    def __init__(self, parent: Optional[QObject] = None):
        super().__init__(parent)
        self.nam = QgsNetworkAccessManager.instance()

    def _prepare_request(self, url_str: str, headers: Optional[Dict[str, str]] = None) -> QNetworkRequest:
        url = QUrl(url_str)
        request = QNetworkRequest(url)
        request.setHeader(QNetworkRequest.KnownHeaders.UserAgentHeader, USER_AGENT)
        request.setRawHeader(b"Accept", b"application/json")
        if headers:
            for k, v in headers.items():
                request.setRawHeader(k.encode("utf-8"), v.encode("utf-8"))
        return request

    def get_json_async(
        self,
        url_str: str,
        on_success: Optional[Callable[[Dict[str, Any], Any], None]] = None,
        on_error: Optional[Callable[[str, Any], None]] = None,
        user_data: Any = None,
        timeout_ms: int = 10000,
    ) -> QNetworkReply:
        """Issue an asynchronous GET request expecting JSON."""
        request = self._prepare_request(url_str)
        reply = self.nam.get(request)

        timer = QTimer(reply)
        timer.setSingleShot(True)
        timer.setInterval(timeout_ms)

        def handle_timeout():
            if reply.isRunning():
                reply.abort()
                err_msg = f"Request timed out after {timeout_ms / 1000:.1f}s: {url_str}"
                log_warning(err_msg)
                if on_error:
                    on_error(err_msg, user_data)
                self.error.emit(err_msg, user_data)

        timer.timeout.connect(handle_timeout)
        timer.start()

        def handle_finished():
            timer.stop()
            if reply.error() != QNetworkReply.NetworkError.NoError:
                err_str = reply.errorString()
                # If aborted by timeout, already reported
                if "aborted" not in err_str.lower():
                    log_warning(f"Network error ({reply.error()}): {err_str} for {url_str}")
                    if on_error:
                        on_error(err_str, user_data)
                    self.error.emit(err_str, user_data)
                reply.deleteLater()
                return

            raw_data = reply.readAll().data()
            try:
                text = raw_data.decode("utf-8")
                parsed = json.loads(text)
                if on_success:
                    on_success(parsed, user_data)
                self.finished.emit(parsed, user_data)
            except Exception as e:
                err_msg = f"Failed to parse JSON response: {str(e)}"
                log_critical(err_msg)
                if on_error:
                    on_error(err_msg, user_data)
                self.error.emit(err_msg, user_data)
            finally:
                reply.deleteLater()

        reply.finished.connect(handle_finished)
        return reply

    def get_json_sync(self, url_str: str, timeout_ms: int = 10000) -> Dict[str, Any]:
        """Synchronously perform GET request and return parsed JSON."""
        loop = QEventLoop()
        result_holder = {"data": None, "error": None}

        def on_ok(data, _):
            result_holder["data"] = data
            loop.quit()

        def on_err(err, _):
            result_holder["error"] = err
            loop.quit()

        self.get_json_async(url_str, on_success=on_ok, on_error=on_err, timeout_ms=timeout_ms)
        loop.exec()

        if result_holder["error"]:
            raise RuntimeError(result_holder["error"])
        return result_holder["data"]

"""
CRS transformations and extent utilities for AriesGeo Toolbox.
"""

from typing import Optional, Tuple
from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsProject,
    QgsPointXY,
    QgsRectangle
)

def get_wgs84_crs() -> QgsCoordinateReferenceSystem:
    """Return EPSG:4326 CRS."""
    return QgsCoordinateReferenceSystem("EPSG:4326")

def get_project_crs() -> QgsCoordinateReferenceSystem:
    """Return active QGIS project CRS."""
    return QgsProject.instance().crs()

def transform_point(
    point: QgsPointXY,
    src_crs: QgsCoordinateReferenceSystem,
    dest_crs: QgsCoordinateReferenceSystem
) -> QgsPointXY:
    """Transform point between coordinate reference systems."""
    if src_crs == dest_crs or not src_crs.isValid() or not dest_crs.isValid():
        return point
    transform = QgsCoordinateTransform(src_crs, dest_crs, QgsProject.instance())
    return transform.transform(point)

def transform_rectangle(
    rect: QgsRectangle,
    src_crs: QgsCoordinateReferenceSystem,
    dest_crs: QgsCoordinateReferenceSystem
) -> QgsRectangle:
    """Transform bounding rectangle between coordinate systems."""
    if src_crs == dest_crs or not src_crs.isValid() or not dest_crs.isValid():
        return rect
    transform = QgsCoordinateTransform(src_crs, dest_crs, QgsProject.instance())
    return transform.transformBoundingBox(rect)

def wgs84_to_project_point(lon: float, lat: float) -> QgsPointXY:
    """Transform WGS84 (lon, lat) to project coordinates."""
    pt = QgsPointXY(lon, lat)
    return transform_point(pt, get_wgs84_crs(), get_project_crs())

def project_to_wgs84_point(x: float, y: float) -> Tuple[float, float]:
    """Transform project coordinates (x, y) to (lon, lat) in WGS84."""
    pt = QgsPointXY(x, y)
    res = transform_point(pt, get_project_crs(), get_wgs84_crs())
    return res.x(), res.y()

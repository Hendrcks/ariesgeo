"""
Custom exception classes for AriesGeo Toolbox.
"""

class AriesGeoError(Exception):
    """Base exception for all AriesGeo Toolbox errors."""
    def __init__(self, message: str, details: str = "", recommendation: str = ""):
        super().__init__(message)
        self.message = message
        self.details = details
        self.recommendation = recommendation

    def user_friendly_message(self) -> str:
        msg = self.message
        if self.details:
            msg += f"\n\nDetails: {self.details}"
        if self.recommendation:
            msg += f"\n\nSuggested Action: {self.recommendation}"
        return msg


class GeocodingError(AriesGeoError):
    """Raised when a geocoding or reverse geocoding operation fails."""
    pass


class RateLimitExceededError(GeocodingError):
    """Raised when a geocoding service rate limit is exceeded."""
    def __init__(self, provider: str, wait_seconds: float = 1.0):
        super().__init__(
            message=f"Rate limit exceeded for provider '{provider}'.",
            details=f"Please wait {wait_seconds:.1f}s before sending more queries.",
            recommendation="Reduce batch speed or use an offline gazetteer."
        )


class RasterInspectionError(AriesGeoError):
    """Raised during preflight raster diagnostic inspection."""
    pass


class IncompatibleRastersError(AriesGeoError):
    """Raised when input rasters have conflicting data types, bands, or CRS."""
    pass


class GridAlignmentError(AriesGeoError):
    """Raised when rasters fail to snap or align to target grid."""
    pass


class MosaicError(AriesGeoError):
    """Raised during VRT or permanent GeoTIFF mosaic generation."""
    pass


class GapFillError(AriesGeoError):
    """Raised during spatial or Landsat 7 SLC-off gap-filling."""
    pass

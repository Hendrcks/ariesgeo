"""
Centralized logging for AriesGeo Toolbox via QgsMessageLog.
"""

try:
    from qgis.core import QgsMessageLog, Qgis
    HAS_QGIS = True
except ImportError:
    HAS_QGIS = False
    QgsMessageLog = None
    Qgis = None

import logging

TAG = "AriesGeo Toolbox"
logger = logging.getLogger(TAG)

def log_info(message: str) -> None:
    """Log informational message to QGIS Message Log panel or stdout."""
    if HAS_QGIS and QgsMessageLog is not None:
        try:
            level = getattr(Qgis.MessageLevel, 'Info', 0) if hasattr(Qgis, 'MessageLevel') else Qgis.Info
            QgsMessageLog.logMessage(message, TAG, level)
            return
        except Exception as e:
            logger.debug("Failed to log to QgsMessageLog: %s", e)
    logger.info(message)

def log_warning(message: str) -> None:
    """Log warning message to QGIS Message Log panel or stdout."""
    if HAS_QGIS and QgsMessageLog is not None:
        try:
            level = getattr(Qgis.MessageLevel, 'Warning', 1) if hasattr(Qgis, 'MessageLevel') else Qgis.Warning
            QgsMessageLog.logMessage(message, TAG, level)
            return
        except Exception as e:
            logger.debug("Failed to log to QgsMessageLog: %s", e)
    logger.warning(message)

def log_critical(message: str) -> None:
    """Log error/critical message to QGIS Message Log panel or stdout."""
    if HAS_QGIS and QgsMessageLog is not None:
        try:
            level = getattr(Qgis.MessageLevel, 'Critical', 2) if hasattr(Qgis, 'MessageLevel') else Qgis.Critical
            QgsMessageLog.logMessage(message, TAG, level)
            return
        except Exception as e:
            logger.debug("Failed to log to QgsMessageLog: %s", e)
    logger.error(message)

log_error = log_critical

def log_success(message: str) -> None:
    """Log success message to QGIS Message Log panel or stdout."""
    if HAS_QGIS and QgsMessageLog is not None:
        try:
            level = getattr(Qgis.MessageLevel, 'Success', 3) if hasattr(Qgis, 'MessageLevel') else getattr(Qgis, 'Success', 3)
            QgsMessageLog.logMessage(message, TAG, level)
            return
        except Exception as e:
            logger.debug("Failed to log to QgsMessageLog: %s", e)
    logger.info(f"SUCCESS: {message}")

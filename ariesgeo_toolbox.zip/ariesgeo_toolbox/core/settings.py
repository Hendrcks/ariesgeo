"""
Settings management for AriesGeo Toolbox using QgsSettings.
"""

from typing import Any
from qgis.core import QgsSettings

class PluginSettings:
    """Namespace wrapper around QgsSettings for AriesGeo Toolbox."""

    PREFIX = "AriesGeoToolbox/"

    # Place Finder Defaults
    KEY_DEFAULT_PROVIDER = PREFIX + "place_finder/default_provider"
    KEY_AUTO_ZOOM = PREFIX + "place_finder/auto_zoom"
    KEY_AUTO_FLASH = PREFIX + "place_finder/auto_flash"
    KEY_SEARCH_LIMIT = PREFIX + "place_finder/search_limit"
    KEY_DEBOUNCE_MS = PREFIX + "place_finder/debounce_ms"
    KEY_CACHE_TTL_DAYS = PREFIX + "place_finder/cache_ttl_days"
    KEY_NOMINATIM_EMAIL = PREFIX + "place_finder/nominatim_email"
    KEY_PHOTON_CUSTOM_URL = PREFIX + "place_finder/photon_custom_url"
    KEY_OFFLINE_GAZETTEER_PATH = PREFIX + "place_finder/offline_gazetteer_path"

    # Mosaic & GapFill Defaults
    KEY_DEFAULT_COMPRESSION = PREFIX + "mosaic/default_compression"
    KEY_DEFAULT_RESAMPLING = PREFIX + "mosaic/default_resampling"
    KEY_TILED_OUTPUT = PREFIX + "mosaic/tiled_output"
    KEY_BUILD_OVERVIEWS = PREFIX + "mosaic/build_overviews"
    KEY_BIGTIFF_MODE = PREFIX + "mosaic/bigtiff_mode"
    KEY_TEMP_DIRECTORY = PREFIX + "mosaic/temp_directory"
    KEY_DEFAULT_GAPFILL_MAX_DIST = PREFIX + "gapfill/default_max_distance"
    KEY_DEFAULT_GAPFILL_SMOOTH_ITER = PREFIX + "gapfill/default_smooth_iterations"

    def __init__(self):
        self.settings = QgsSettings()

    def get_value(self, key: str, default: Any = None, type_class: type = None) -> Any:
        if type_class is not None:
            return self.settings.value(key, default, type=type_class)
        return self.settings.value(key, default)

    def set_value(self, key: str, value: Any) -> None:
        self.settings.setValue(key, value)

    # Place Finder Accessors
    @property
    def default_provider(self) -> str:
        return self.get_value(self.KEY_DEFAULT_PROVIDER, "Photon (Komoot)", str)

    @default_provider.setter
    def default_provider(self, val: str):
        self.set_value(self.KEY_DEFAULT_PROVIDER, val)

    @property
    def auto_zoom(self) -> bool:
        return bool(self.get_value(self.KEY_AUTO_ZOOM, True, bool))

    @auto_zoom.setter
    def auto_zoom(self, val: bool):
        self.set_value(self.KEY_AUTO_ZOOM, val)

    @property
    def auto_flash(self) -> bool:
        return bool(self.get_value(self.KEY_AUTO_FLASH, True, bool))

    @auto_flash.setter
    def auto_flash(self, val: bool):
        self.set_value(self.KEY_AUTO_FLASH, val)

    @property
    def search_limit(self) -> int:
        return int(self.get_value(self.KEY_SEARCH_LIMIT, 10, int))

    @search_limit.setter
    def search_limit(self, val: int):
        self.set_value(self.KEY_SEARCH_LIMIT, val)

    @property
    def nominatim_email(self) -> str:
        return self.get_value(self.KEY_NOMINATIM_EMAIL, "", str)

    @nominatim_email.setter
    def nominatim_email(self, val: str):
        self.set_value(self.KEY_NOMINATIM_EMAIL, val)

    @property
    def offline_gazetteer_path(self) -> str:
        return self.get_value(self.KEY_OFFLINE_GAZETTEER_PATH, "", str)

    @offline_gazetteer_path.setter
    def offline_gazetteer_path(self, val: str):
        self.set_value(self.KEY_OFFLINE_GAZETTEER_PATH, val)

    # Mosaic Accessors
    @property
    def default_compression(self) -> str:
        return self.get_value(self.KEY_DEFAULT_COMPRESSION, "DEFLATE", str)

    @default_compression.setter
    def default_compression(self, val: str):
        self.set_value(self.KEY_DEFAULT_COMPRESSION, val)

    @property
    def default_resampling(self) -> str:
        return self.get_value(self.KEY_DEFAULT_RESAMPLING, "bilinear", str)

    @default_resampling.setter
    def default_resampling(self, val: str):
        self.set_value(self.KEY_DEFAULT_RESAMPLING, val)

    @property
    def tiled_output(self) -> bool:
        return bool(self.get_value(self.KEY_TILED_OUTPUT, True, bool))

    @tiled_output.setter
    def tiled_output(self, val: bool):
        self.set_value(self.KEY_TILED_OUTPUT, val)

    @property
    def build_overviews(self) -> bool:
        return bool(self.get_value(self.KEY_BUILD_OVERVIEWS, True, bool))

    @build_overviews.setter
    def build_overviews(self, val: bool):
        self.set_value(self.KEY_BUILD_OVERVIEWS, val)

    @property
    def bigtiff_mode(self) -> str:
        return self.get_value(self.KEY_BIGTIFF_MODE, "IF_SAFER", str)

    @bigtiff_mode.setter
    def bigtiff_mode(self, val: str):
        self.set_value(self.KEY_BIGTIFF_MODE, val)

    @property
    def temp_directory(self) -> str:
        return self.get_value(self.KEY_TEMP_DIRECTORY, "", str)

    @temp_directory.setter
    def temp_directory(self, val: str):
        self.set_value(self.KEY_TEMP_DIRECTORY, val)

    @property
    def default_gapfill_max_distance(self) -> int:
        return int(self.get_value(self.KEY_DEFAULT_GAPFILL_MAX_DIST, 100, int))

    @default_gapfill_max_distance.setter
    def default_gapfill_max_distance(self, val: int):
        self.set_value(self.KEY_DEFAULT_GAPFILL_MAX_DIST, val)


settings = PluginSettings()

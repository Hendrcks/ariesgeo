"""
AriesGeo Toolbox - Provenance and Metadata Logging Core.
Generates machine-readable provenance manifests and SHA-256 data checksums.
"""

import os
import sys
import json
import hashlib
import datetime
from typing import Dict, Any, List, Optional
from qgis.core import Qgis

def compute_file_sha256(filepath: str, max_bytes: int = 10 * 1024 * 1024) -> str:
    """Compute SHA-256 hash of a file (reads up to max_bytes for speed on huge rasters)."""
    if not os.path.exists(filepath):
        return ""
    h = hashlib.sha256()
    try:
        with open(filepath, "rb") as f:
            chunk = f.read(65536)
            total = 0
            while chunk and (max_bytes <= 0 or total < max_bytes):
                h.update(chunk)
                total += len(chunk)
                chunk = f.read(65536)
        return h.hexdigest()
    except Exception:
        return ""

def create_provenance_record(
    algorithm_id: str,
    algorithm_name: str,
    parameters: Dict[str, Any],
    inputs: Dict[str, str],
    outputs: Dict[str, str],
    metrics: Optional[Dict[str, Any]] = None,
    notes: Optional[str] = None
) -> Dict[str, Any]:
    """Build a complete, standardized scientific provenance record."""
    input_records = []
    for k, path in inputs.items():
        if path and isinstance(path, str) and os.path.exists(path):
            input_records.append({
                "role": k,
                "path": os.path.abspath(path),
                "size_bytes": os.path.getsize(path),
                "sha256_prefix": compute_file_sha256(path, max_bytes=2 * 1024 * 1024)
            })
        elif path:
            input_records.append({"role": k, "value": str(path)})

    output_records = []
    for k, path in outputs.items():
        if path and isinstance(path, str) and os.path.exists(path):
            output_records.append({
                "role": k,
                "path": os.path.abspath(path),
                "size_bytes": os.path.getsize(path),
                "sha256": compute_file_sha256(path, max_bytes=10 * 1024 * 1024)
            })
        elif path:
            output_records.append({"role": k, "value": str(path)})

    safe_params = {}
    for k, v in parameters.items():
        if any(secret_kw in k.lower() for secret_kw in ("password", "secret", "token", "key")):
            safe_params[k] = "******"
        else:
            safe_params[k] = v

    record = {
        "generator": "AriesGeo Toolbox",
        "plugin_version": "4.0.0",
        "qgis_version": Qgis.QGIS_VERSION,
        "python_version": sys.version.split()[0],
        "timestamp_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "algorithm": {
            "id": algorithm_id,
            "name": algorithm_name
        },
        "parameters": safe_params,
        "inputs": input_records,
        "outputs": output_records,
        "metrics": metrics or {},
        "scientific_notes": notes or "AriesPlus Geospatial Solutions - Scientifically defensible workflow"
    }
    return record

def write_provenance_json(record: Dict[str, Any], output_json_path: str) -> str:
    """Save the provenance record to a JSON file."""
    os.makedirs(os.path.dirname(os.path.abspath(output_json_path)), exist_ok=True)
    with open(output_json_path, "w", encoding="utf-8") as f:
        json.dump(record, f, indent=2, ensure_ascii=False)
    return output_json_path


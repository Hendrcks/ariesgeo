"""
Core framework utilities for AriesGeo Toolbox.
"""

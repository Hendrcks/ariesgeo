"""
Background task manager and Qt-thread-safe worker wrappers for AriesGeo Toolbox.
Guarantees immediate background execution inside both modal and non-modal QGIS dialogs,
safe main-thread GUI signal delivery, cancellation, and strong reference retention.
"""

import inspect
import threading
import traceback
from typing import Callable, Any, Optional, Set
from .logging import log_info, log_critical

try:
    from qgis.PyQt.QtCore import QThread, pyqtSignal, QCoreApplication
    HAS_QT_THREAD = True
except ImportError:
    HAS_QT_THREAD = False
    QThread = object
    pyqtSignal = None
    QCoreApplication = None

# Global strong reference registry to prevent Python/SIP GC from destroying active workers
ACTIVE_TASKS: Set[Any] = set()


class BackgroundWorker(QThread if HAS_QT_THREAD else object):
    """
    QThread-based background worker that executes immediately without stalling behind
    nested modal event loops and delivers completion/error/progress signals on the GUI thread.
    """
    if HAS_QT_THREAD:
        progressChanged = pyqtSignal(float)
        statusChanged = pyqtSignal(float, str)
        taskCompleted = pyqtSignal(object)
        taskFailed = pyqtSignal(object)

    def __init__(
        self,
        description: str,
        target_func: Callable[..., Any],
        *args,
        on_completed: Optional[Callable[[Any], None]] = None,
        on_failed: Optional[Callable[[Exception], None]] = None,
        on_progress: Optional[Callable[..., None]] = None,
        **kwargs,
    ):
        if HAS_QT_THREAD:
            super().__init__()
        self._description = description
        self.target_func = target_func
        self.args = args
        self.kwargs = kwargs
        self.on_completed = on_completed
        self.on_failed = on_failed
        self.on_progress = on_progress
        self.result = None
        self.exception: Optional[Exception] = None
        self._canceled = False

        if HAS_QT_THREAD:
            if on_progress is not None:
                self._connect_progress(on_progress)
            self.taskCompleted.connect(self._handle_completed)
            self.taskFailed.connect(self._handle_failed)
            self.finished.connect(self._cleanup_ref)

    def _connect_progress(self, cb: Callable[..., None]) -> None:
        try:
            sig = inspect.signature(cb)
            req_params = [
                p for p in sig.parameters.values()
                if p.default == inspect.Parameter.empty
                and p.kind in (inspect.Parameter.POSITIONAL_ONLY, inspect.Parameter.POSITIONAL_OR_KEYWORD)
            ]
            accepts_two = len(req_params) >= 2 or any(
                p.kind == inspect.Parameter.VAR_POSITIONAL for p in sig.parameters.values()
            )
        except Exception:
            accepts_two = False

        if accepts_two:
            self.statusChanged.connect(cb)
        else:
            self.progressChanged.connect(cb)

    def cancel(self) -> None:
        self._canceled = True

    def isCanceled(self) -> bool:
        return self._canceled

    def is_canceled(self) -> bool:
        return self._canceled

    def setProgress(self, progress_pct: float) -> None:
        self.report_progress(progress_pct, "")

    def report_progress(self, progress_pct: float, message: str = "") -> None:
        pct = float(max(0.0, min(100.0, progress_pct)))
        if HAS_QT_THREAD:
            self.progressChanged.emit(pct)
            self.statusChanged.emit(pct, message or "")

    def _invoke_target(self) -> Any:
        call_args = list(self.args)
        call_kwargs = dict(self.kwargs)

        try:
            sig = inspect.signature(self.target_func)
            params = list(sig.parameters.values())
            param_names = [p.name for p in params]
            if "task" in param_names:
                call_kwargs["task"] = self
            elif len(params) == 1 and not call_args and params[0].default == inspect.Parameter.empty:
                call_args.append(self)
        except (ValueError, TypeError) as sig_err:
            log_info(f"Callable signature inspection skipped for '{self._description}': {sig_err}")

        try:
            return self.target_func(*call_args, **call_kwargs)
        except TypeError:
            try:
                return self.target_func(self, *self.args, **self.kwargs)
            except TypeError:
                return self.target_func(*self.args, **self.kwargs)

    def run(self) -> None:
        try:
            res = self._invoke_target()
            self.result = res
            if self._canceled:
                if HAS_QT_THREAD:
                    self.taskFailed.emit(Exception(f"Task '{self._description}' was canceled."))
                return
            if HAS_QT_THREAD:
                self.taskCompleted.emit(res)
        except Exception as exc:
            self.exception = exc
            log_critical(f"Task '{self._description}' failed: {exc}\n{traceback.format_exc()}")
            if HAS_QT_THREAD:
                self.taskFailed.emit(exc)

    def _handle_completed(self, res: Any) -> None:
        try:
            if self.on_completed and not self._canceled:
                self.on_completed(res)
        except Exception as cb_err:
            log_critical(f"Error in completion callback for '{self._description}': {cb_err}")

    def _handle_failed(self, err: Any) -> None:
        try:
            if self.on_failed:
                self.on_failed(err)
        except Exception as cb_err:
            log_critical(f"Error in failure callback for '{self._description}': {cb_err}")

    def _cleanup_ref(self) -> None:
        ACTIVE_TASKS.discard(self)


# Backward-compatible alias
FunctionTask = BackgroundWorker


def run_in_background(
    description: str,
    target_func: Callable[..., Any],
    *args,
    on_completed: Optional[Callable[[Any], None]] = None,
    on_failed: Optional[Callable[[Exception], None]] = None,
    on_progress: Optional[Callable[..., None]] = None,
    **kwargs,
) -> BackgroundWorker:
    """
    Execute `target_func` immediately in a background QThread and marshal progress,
    completion, and failure callbacks onto the Qt main GUI thread.
    """
    worker = BackgroundWorker(
        description,
        target_func,
        *args,
        on_completed=on_completed,
        on_failed=on_failed,
        on_progress=on_progress,
        **kwargs,
    )
    ACTIVE_TASKS.add(worker)

    if HAS_QT_THREAD and QCoreApplication is not None and QCoreApplication.instance() is not None:
        worker.start()
    else:
        def _fallback():
            try:
                res = worker._invoke_target()
                if on_completed:
                    on_completed(res)
            except Exception as exc:
                if on_failed:
                    on_failed(exc)
            finally:
                ACTIVE_TASKS.discard(worker)

        t = threading.Thread(target=_fallback, daemon=True)
        t.start()

    return worker

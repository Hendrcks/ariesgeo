"""
Background task manager and QgsTask wrappers for AriesGeo Toolbox.
Ensures thread safety, Python object lifecycle retention, and robust error propagation.
"""

import inspect
import threading
from typing import Callable, Any, Optional, Set
from .logging import log_info, log_critical

try:
    from qgis.core import QgsTask, QgsApplication
    HAS_QGIS_TASK = True
except ImportError:
    HAS_QGIS_TASK = False
    QgsTask = object
    QgsApplication = None

# Global strong reference registry to prevent Python GC from destroying active tasks
ACTIVE_TASKS: Set[Any] = set()


class FunctionTask(QgsTask if HAS_QGIS_TASK else object):
    """General-purpose QgsTask executing a Python callable in background thread."""

    def __init__(
        self,
        description: str,
        target_func: Callable[..., Any],
        *args,
        on_completed: Optional[Callable[[Any], None]] = None,
        on_failed: Optional[Callable[[Exception], None]] = None,
        on_progress: Optional[Callable[[float], None]] = None,
        **kwargs
    ):
        if HAS_QGIS_TASK:
            flags = getattr(QgsTask, "CanCancel", 2)
            if hasattr(QgsTask, "Flags"):
                try:
                    flags = QgsTask.Flags(flags)
                except Exception:
                    pass
            super().__init__(description, flags)

        self._description = description
        self.target_func = target_func
        self.args = args
        self.kwargs = kwargs
        self.on_completed = on_completed
        self.on_failed = on_failed
        self.on_progress = on_progress
        self.result = None
        self.exception = None
        self._canceled = False

    def is_canceled(self) -> bool:
        if HAS_QGIS_TASK and hasattr(super(), "isCanceled"):
            try:
                return super().isCanceled()
            except Exception:
                pass
        return self._canceled

    def report_progress(self, progress_pct: float, message: str = "") -> None:
        """Helper to safely report progress across threads."""
        if HAS_QGIS_TASK and hasattr(super(), "setProgress"):
            try:
                super().setProgress(progress_pct)
            except Exception:
                pass

    def run(self) -> bool:
        """Executes the workload on the background worker thread."""
        try:
            # Smart parameter binding
            sig = None
            try:
                sig = inspect.signature(self.target_func)
            except Exception:
                pass

            call_args = list(self.args)
            call_kwargs = dict(self.kwargs)

            if sig is not None:
                params = list(sig.parameters.values())
                param_names = [p.name for p in params]
                if "task" in param_names:
                    call_kwargs["task"] = self
                elif len(params) == 1 and not call_args and params[0].default == inspect.Parameter.empty:
                    call_args.append(self)

            try:
                self.result = self.target_func(*call_args, **call_kwargs)
            except TypeError:
                # Fallback attempts if inspect wasn't accurate
                try:
                    self.result = self.target_func(self, *self.args, **self.kwargs)
                except TypeError:
                    self.result = self.target_func(*self.args, **self.kwargs)

            return True
        except Exception as e:
            self.exception = e
            log_critical(f"Task '{self._description}' encountered an error: {str(e)}")
            return False

    def finished(self, result: bool) -> None:
        """Invoked by QGIS on the main GUI thread when the background task finishes."""
        try:
            if result and not self.is_canceled():
                if self.on_completed:
                    self.on_completed(self.result)
            else:
                if self.on_failed:
                    err = self.exception if self.exception is not None else Exception(f"Task '{self._description}' was canceled.")
                    self.on_failed(err)
        except Exception as cb_err:
            log_critical(f"Error in task finished callback for '{self._description}': {str(cb_err)}")
        finally:
            ACTIVE_TASKS.discard(self)


def run_in_background(
    description: str,
    target_func: Callable[..., Any],
    *args,
    on_completed: Optional[Callable[[Any], None]] = None,
    on_failed: Optional[Callable[[Exception], None]] = None,
    on_progress: Optional[Callable[[float], None]] = None,
    **kwargs
) -> Any:
    """
    Convenience helper to enqueue and run a function in the QGIS task manager.
    Retains a strong reference until task completion to prevent premature garbage collection.
    """
    task = FunctionTask(
        description,
        target_func,
        *args,
        on_completed=on_completed,
        on_failed=on_failed,
        on_progress=on_progress,
        **kwargs
    )

    if on_progress and HAS_QGIS_TASK and hasattr(task, "progressChanged"):
        try:
            task.progressChanged.connect(on_progress)
        except Exception:
            pass

    # Retain reference in global set to prevent SIP GC issues
    ACTIVE_TASKS.add(task)

    tm = None
    if HAS_QGIS_TASK and QgsApplication is not None:
        try:
            tm = QgsApplication.taskManager()
        except Exception:
            tm = None

    if tm is not None:
        tm.addTask(task)
    else:
        # Fallback for standalone/headless environments without QgsApplication taskManager
        def _thread_target():
            ok = task.run()
            task.finished(ok)

        t = threading.Thread(target=_thread_target, daemon=True)
        t.start()

    return task

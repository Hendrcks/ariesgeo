"""
AriesGeo Toolbox QGIS Plugin Entry Point.
"""

def classFactory(iface):
    """Factory entry point called by QGIS to load the plugin."""
    from .plugin import AriesGeoPlugin
    return AriesGeoPlugin(iface)

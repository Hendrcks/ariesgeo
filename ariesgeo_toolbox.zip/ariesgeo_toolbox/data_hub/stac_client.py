"""
STAC (SpatioTemporal Asset Catalog) query client and asset inspection.
Supports standard STAC API 1.0 search specs.
"""

import json
from typing import List, Dict, Any, Optional
from ..core.network import safe_http_request, validate_http_url

DEFAULT_STAC_ENDPOINTS = {
    "Earth Search (Element84)": "https://earth-search.aws.element84.com/v1/search",
    "Microsoft Planetary Computer": "https://planetarycomputer.microsoft.com/api/stac/v1/search"
}

def search_stac(
    endpoint_url: str,
    bbox: Optional[List[float]] = None, # [minx, miny, maxx, maxy]
    datetime_range: Optional[str] = None, # e.g. "2023-01-01T00:00:00Z/2023-12-31T23:59:59Z"
    collections: Optional[List[str]] = None,
    max_cloud_cover: Optional[float] = None,
    limit: int = 10,
    headers: Optional[Dict[str, str]] = None
) -> Dict[str, Any]:
    """
    Search a STAC API endpoint for catalog items.
    """
    payload: Dict[str, Any] = {"limit": min(limit, 100)}
    if bbox:
        payload["bbox"] = bbox
    if datetime_range:
        payload["datetime"] = datetime_range
    if collections:
        payload["collections"] = collections
        
    query_obj: Dict[str, Any] = {}
    if max_cloud_cover is not None:
        query_obj["eo:cloud_cover"] = {"lte": max_cloud_cover}
    if query_obj:
        payload["query"] = query_obj

    data = json.dumps(payload).encode("utf-8")
    req_headers = {
        "Content-Type": "application/json",
        "Accept": "application/geo+json, application/json",
        "User-Agent": "AriesGeo-Toolbox/4.0 (QGIS Scientific Extension)"
    }
    if headers:
        req_headers.update(headers)

    try:
        validate_http_url(endpoint_url)
        _, _, raw_body = safe_http_request(
            endpoint_url,
            method="POST",
            body=data,
            headers=req_headers,
            timeout=30.0,
        )
        return json.loads(raw_body.decode("utf-8"))
    except ValueError:
        raise
    except Exception as e:
        return {
            "type": "FeatureCollection",
            "features": [],
            "error": str(e),
            "status": "offline_or_failed"
        }

def inspect_stac_asset(item_feature: Dict[str, Any]) -> Dict[str, Any]:
    """
    Extract asset roles, hrefs, projections, and band mappings from a STAC item feature.
    """
    props = item_feature.get("properties", {})
    assets = item_feature.get("assets", {})
    
    inspected_assets = {}
    for name, a in assets.items():
        inspected_assets[name] = {
            "href": a.get("href"),
            "title": a.get("title", name),
            "type": a.get("type", "application/octet-stream"),
            "roles": a.get("roles", []),
            "raster_bands": a.get("raster:bands", a.get("eo:bands", []))
        }
        
    return {
        "id": item_feature.get("id"),
        "collection": item_feature.get("collection"),
        "datetime": props.get("datetime"),
        "cloud_cover": props.get("eo:cloud_cover"),
        "platform": props.get("platform"),
        "instruments": props.get("instruments", []),
        "assets_count": len(inspected_assets),
        "assets": inspected_assets
    }


"""
Safe chunked file download manager with progress tracking and SHA-256 validation.
"""

import os
import hashlib
import urllib.request
from typing import Optional, Callable

def download_asset_file(
    url: str,
    output_path: str,
    expected_sha256: Optional[str] = None,
    progress_callback: Optional[Callable[[int, str], None]] = None,
    chunk_size: int = 65536
) -> str:
    """
    Download a remote asset safely in chunks, supporting resume and hash validation.
    """
    os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
    temp_path = output_path + ".part"
    
    headers = {"User-Agent": "AriesGeo-Toolbox/4.0"}
    req = urllib.request.Request(url, headers=headers)
    
    sha = hashlib.sha256()
    with urllib.request.urlopen(req, timeout=60) as resp:
        total_size = int(resp.headers.get("Content-Length", 0))
        downloaded = 0
        
        with open(temp_path, "wb") as f_out:
            while True:
                chunk = resp.read(chunk_size)
                if not chunk:
                    break
                f_out.write(chunk)
                sha.update(chunk)
                downloaded += len(chunk)
                
                if progress_callback and total_size > 0:
                    pct = int((downloaded / total_size) * 100)
                    progress_callback(pct, f"Downloading: {downloaded / 1024 / 1024:.1f} MB / {total_size / 1024 / 1024:.1f} MB")
                    
    calculated_hash = sha.hexdigest()
    if expected_sha256 and expected_sha256.lower() != calculated_hash.lower():
        if os.path.exists(temp_path):
            os.remove(temp_path)
        raise ValueError(f"Downloaded file SHA-256 hash mismatch! Expected {expected_sha256}, got {calculated_hash}")
        
    if os.path.exists(output_path):
        os.remove(output_path)
    os.rename(temp_path, output_path)
    return output_path


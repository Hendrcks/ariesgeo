"""
Safe chunked file download manager with HTTPS/HTTP scheme validation,
progress tracking, and SHA-256 checksum verification.
"""

import hashlib
import os
import urllib.parse
from typing import Optional, Callable
from ..core.network import (
    USER_AGENT,
    MAX_HTTP_REDIRECTS,
    validate_http_url,
    _open_validated_connection,
    _request_target,
)


def download_asset_file(
    url: str,
    output_path: str,
    expected_sha256: Optional[str] = None,
    progress_callback: Optional[Callable[[int, str], None]] = None,
    chunk_size: int = 65536,
) -> str:
    """
    Download a remote HTTP/HTTPS asset safely in chunks with strict URL scheme
    validation (`http` / `https` only) and optional SHA-256 verification.
    """
    validate_http_url(url)
    os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
    temp_path = output_path + ".part"

    headers = {"User-Agent": USER_AGENT}
    current_url = url
    sha = hashlib.sha256()

    for _ in range(MAX_HTTP_REDIRECTS + 1):
        parsed = validate_http_url(current_url)
        conn = _open_validated_connection(parsed, timeout=60.0)
        try:
            conn.request("GET", _request_target(parsed), headers=headers)
            resp = conn.getresponse()
            status = int(resp.status)

            if status in (301, 302, 303, 307, 308):
                resp.read()
                location = resp.getheader("Location")
                if not location:
                    raise RuntimeError(f"HTTP {status} redirect missing Location header.")
                current_url = urllib.parse.urljoin(current_url, location)
                validate_http_url(current_url)
                continue

            if status >= 400:
                raise RuntimeError(f"Download failed with HTTP {status} {resp.reason}: {current_url}")

            content_len_hdr = resp.getheader("Content-Length")
            total_size = int(content_len_hdr) if (content_len_hdr and content_len_hdr.isdigit()) else 0
            downloaded = 0

            with open(temp_path, "wb") as f_out:
                while True:
                    chunk = resp.read(chunk_size)
                    if not chunk:
                        break
                    f_out.write(chunk)
                    sha.update(chunk)
                    downloaded += len(chunk)

                    if progress_callback and total_size > 0:
                        pct = int((downloaded / total_size) * 100)
                        progress_callback(
                            pct,
                            f"Downloading: {downloaded / 1024 / 1024:.1f} MB / {total_size / 1024 / 1024:.1f} MB",
                        )
            break
        finally:
            conn.close()
    else:
        raise RuntimeError(f"Exceeded maximum HTTP redirects ({MAX_HTTP_REDIRECTS}) while downloading {url}")

    calculated_hash = sha.hexdigest()
    if expected_sha256 and expected_sha256.lower() != calculated_hash.lower():
        if os.path.exists(temp_path):
            os.remove(temp_path)
        raise ValueError(f"Downloaded file SHA-256 hash mismatch! Expected {expected_sha256}, got {calculated_hash}")

    os.replace(temp_path, output_path)
    return output_path


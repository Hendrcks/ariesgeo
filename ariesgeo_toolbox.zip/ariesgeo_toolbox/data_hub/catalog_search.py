"""
Catalog discovery for Landsat, Sentinel, and Elevation (DEM) assets.
"""

from typing import List, Dict, Any, Optional
from .stac_client import search_stac

def search_landsat_catalog(
    bbox: List[float],
    start_date: str,
    end_date: str,
    max_cloud_cover: float = 30.0,
    sensors: Optional[List[str]] = None,
    limit: int = 15
) -> List[Dict[str, Any]]:
    """
    Search Landsat Collection 2 assets via public STAC catalogs.
    """
    colls = ["landsat-c2-l2"]
    date_str = f"{start_date}T00:00:00Z/{end_date}T23:59:59Z"
    stac_url = "https://earth-search.aws.element84.com/v1/search"
    
    res = search_stac(
        endpoint_url=stac_url,
        bbox=bbox,
        datetime_range=date_str,
        collections=colls,
        max_cloud_cover=max_cloud_cover,
        limit=limit
    )
    
    items = []
    for f in res.get("features", []):
        props = f.get("properties", {})
        plat = props.get("platform", "")
        if sensors and not any(s.lower() in plat.lower() for s in sensors):
            continue
        items.append({
            "id": f.get("id"),
            "platform": plat,
            "date": props.get("datetime", "")[:10],
            "cloud_cover_pct": props.get("eo:cloud_cover", 0.0),
            "sun_elevation": props.get("view:sun_elevation"),
            "assets": list(f.get("assets", {}).keys()),
            "self_link": f.get("assets", {}).get("thumbnail", {}).get("href", "")
        })
    return items

def search_sentinel_catalog(
    bbox: List[float],
    start_date: str,
    end_date: str,
    max_cloud_cover: float = 20.0,
    limit: int = 15
) -> List[Dict[str, Any]]:
    """
    Search Sentinel-2 L2A assets via public STAC catalogs.
    """
    colls = ["sentinel-2-l2a"]
    date_str = f"{start_date}T00:00:00Z/{end_date}T23:59:59Z"
    stac_url = "https://earth-search.aws.element84.com/v1/search"
    
    res = search_stac(
        endpoint_url=stac_url,
        bbox=bbox,
        datetime_range=date_str,
        collections=colls,
        max_cloud_cover=max_cloud_cover,
        limit=limit
    )
    
    items = []
    for f in res.get("features", []):
        props = f.get("properties", {})
        items.append({
            "id": f.get("id"),
            "platform": props.get("platform", "Sentinel-2"),
            "date": props.get("datetime", "")[:10],
            "cloud_cover_pct": props.get("eo:cloud_cover", 0.0),
            "tile_id": props.get("s2:mgrs_tile", ""),
            "assets": list(f.get("assets", {}).keys()),
            "visual_href": f.get("assets", {}).get("visual", {}).get("href", "")
        })
    return items

def search_dem_coverage(
    bbox: List[float],
    sources: Optional[List[str]] = None
) -> List[Dict[str, Any]]:
    """
    Identify global elevation models covering the requested bounding box.
    Supported: Copernicus DEM GLO-30, SRTM GL1 (30m), NASADEM.
    """
    min_x, min_y, max_x, max_y = bbox
    candidates = []
    
    # Check Copernicus DEM 30m
    candidates.append({
        "dataset": "Copernicus DEM GLO-30",
        "resolution_m": 30.0,
        "vertical_datum": "EGM2008 (Orthometric height)",
        "horizontal_crs": "EPSG:4326",
        "global_coverage": True,
        "access": "Free / Open under Copernicus Open Access License",
        "stac_collection": "cop-dem-glo-30"
    })
    
    # Check SRTM GL1 (between 60°N and 56°S)
    if min_y >= -56.0 and max_y <= 60.0:
        candidates.append({
            "dataset": "NASA SRTM GL1 (v3.0)",
            "resolution_m": 30.0,
            "vertical_datum": "EGM96",
            "horizontal_crs": "EPSG:4326",
            "global_coverage": False,
            "access": "Public Domain (NASA / USGS)",
            "stac_collection": "nasadem"
        })
        
    return candidates


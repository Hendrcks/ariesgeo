"""
Local geospatial folder crawler and catalog builder.
Indexes GeoTIFF, Shapefile, GeoPackage, and GeoJSON datasets into an SQLite/GeoPackage index.
"""

import os
import sqlite3
from typing import List, Dict, Any, Optional
from osgeo import gdal, ogr, osr

GEO_EXTENSIONS = {
    ".tif": "raster", ".tiff": "raster", ".vrt": "raster", ".img": "raster",
    ".shp": "vector", ".gpkg": "vector", ".geojson": "vector", ".json": "vector"
}

def build_local_spatial_catalog(
    root_dirs: List[str],
    output_sqlite_path: str,
    recursive: bool = True
) -> Dict[str, Any]:
    """
    Scan root directories for geospatial data and build a queryable spatial catalog index.
    """
    os.makedirs(os.path.dirname(os.path.abspath(output_sqlite_path)), exist_ok=True)
    if os.path.exists(output_sqlite_path):
        os.remove(output_sqlite_path)
        
    conn = sqlite3.connect(output_sqlite_path)
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE spatial_catalog (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            filename TEXT,
            filepath TEXT UNIQUE,
            file_type TEXT,
            format TEXT,
            crs_auth TEXT,
            min_x REAL,
            min_y REAL,
            max_x REAL,
            max_y REAL,
            size_bytes INTEGER,
            num_bands_or_layers INTEGER
        )
    """)
    
    indexed_count = 0
    errors = []
    
    for r_dir in root_dirs:
        if not os.path.exists(r_dir):
            continue
        walker = os.walk(r_dir) if recursive else [(r_dir, [], os.listdir(r_dir))]
        for root, _, files in walker:
            for fname in files:
                ext = os.path.splitext(fname)[1].lower()
                if ext not in GEO_EXTENSIONS:
                    continue
                fpath = os.path.join(root, fname)
                fsize = os.path.getsize(fpath)
                kind = GEO_EXTENSIONS[ext]
                
                try:
                    if kind == "raster":
                        ds = gdal.Open(fpath, gdal.GA_ReadOnly)
                        if ds:
                            gt = ds.GetGeoTransform()
                            w, h = ds.RasterXSize, ds.RasterYSize
                            min_x = gt[0]
                            max_x = gt[0] + w * gt[1]
                            max_y = gt[3]
                            min_y = gt[3] + h * gt[5]
                            proj_wkt = ds.GetProjection()
                            srs = osr.SpatialReference(proj_wkt)
                            auth = f"{srs.GetAuthorityName(None)}:{srs.GetAuthorityCode(None)}" if srs else "UNKNOWN"
                            
                            cur.execute("""
                                INSERT OR REPLACE INTO spatial_catalog 
                                (filename, filepath, file_type, format, crs_auth, min_x, min_y, max_x, max_y, size_bytes, num_bands_or_layers)
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                            """, (fname, os.path.abspath(fpath), "raster", ds.GetDriver().ShortName, auth, min_x, min_y, max_x, max_y, fsize, ds.RasterCount))
                            indexed_count += 1
                            ds = None
                    else: # vector
                        v_ds = ogr.Open(fpath, 0)
                        if v_ds:
                            lyr = v_ds.GetLayer(0)
                            env = lyr.GetExtent() if lyr else (0, 0, 0, 0)
                            srs = lyr.GetSpatialRef() if lyr else None
                            auth = f"{srs.GetAuthorityName(None)}:{srs.GetAuthorityCode(None)}" if srs else "UNKNOWN"
                            
                            cur.execute("""
                                INSERT OR REPLACE INTO spatial_catalog 
                                (filename, filepath, file_type, format, crs_auth, min_x, min_y, max_x, max_y, size_bytes, num_bands_or_layers)
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                            """, (fname, os.path.abspath(fpath), "vector", v_ds.GetDriver().GetName(), auth, env[0], env[2], env[1], env[3], fsize, v_ds.GetLayerCount()))
                            indexed_count += 1
                            v_ds = None
                except Exception as e:
                    errors.append(f"{fname}: {str(e)}")
                    
    conn.commit()
    conn.close()
    
    return {
        "catalog_db": output_sqlite_path,
        "indexed_items": indexed_count,
        "errors_count": len(errors)
    }


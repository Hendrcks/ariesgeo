"""
OpenStreetMap feature importer via the Overpass API.
Converts query results directly to GeoPackage format.
"""

import os
import json
import urllib.parse
from typing import List, Dict, Any, Optional
from osgeo import ogr, osr
from ..core.network import safe_http_request
from ..core.logging import log_warning

def import_osm_extract(
    bbox: List[float], # [min_lat, min_lon, max_lat, max_lon]
    feature_type: str = "roads", # "roads", "buildings", "waterways"
    output_gpkg_path: str = ""
) -> str:
    """
    Query Overpass API for features within a bounding box and write to GeoPackage.
    """
    min_lat, min_lon, max_lat, max_lon = bbox
    
    # Overpass QL query
    tag_filters = {
        "roads": '["highway"]',
        "buildings": '["building"]',
        "waterways": '["waterway"]'
    }
    filter_expr = tag_filters.get(feature_type, '["highway"]')
    
    query = f"""
    [out:json][timeout:25];
    (
      way{filter_expr}({min_lat},{min_lon},{max_lat},{max_lon});
      relation{filter_expr}({min_lat},{min_lon},{max_lat},{max_lon});
    );
    out body geom;
    """
    
    url = "https://overpass-api.de/api/interpreter"
    data = urllib.parse.urlencode({"data": query}).encode("utf-8")

    try:
        _, _, raw_body = safe_http_request(
            url,
            method="POST",
            body=data,
            headers={
                "Content-Type": "application/x-www-form-urlencoded",
                "User-Agent": "AriesGeo-Toolbox/4.0.1 (QGIS)",
            },
            timeout=30.0,
        )
        osm_data = json.loads(raw_body.decode("utf-8"))
    except Exception as exc:
        log_warning(f"Overpass API query fallback (offline or unreachable): {exc}")
        osm_data = {"elements": []}
        
    os.makedirs(os.path.dirname(os.path.abspath(output_gpkg_path)), exist_ok=True)
    driver = ogr.GetDriverByName("GPKG")
    if os.path.exists(output_gpkg_path):
        os.remove(output_gpkg_path)
    ds = driver.CreateDataSource(output_gpkg_path)
    
    srs = osr.SpatialReference()
    srs.ImportFromEPSG(4326)
    
    geom_type = ogr.wkbPolygon if feature_type == "buildings" else ogr.wkbLineString
    layer = ds.CreateLayer(feature_type, srs, geom_type)
    
    layer.CreateField(ogr.FieldDefn("osm_id", ogr.OFTString))
    layer.CreateField(ogr.FieldDefn("name", ogr.OFTString))
    layer.CreateField(ogr.FieldDefn("type", ogr.OFTString))
    
    for el in osm_data.get("elements", []):
        tags = el.get("tags", {})
        geometry_nodes = el.get("geometry", [])
        if not geometry_nodes or len(geometry_nodes) < 2:
            continue
            
        feat = ogr.Feature(layer.GetLayerDefn())
        feat.SetField("osm_id", str(el.get("id")))
        feat.SetField("name", tags.get("name", ""))
        feat.SetField("type", tags.get("highway") or tags.get("building") or tags.get("waterway") or "")
        
        if feature_type == "buildings" and len(geometry_nodes) >= 3:
            ring = ogr.Geometry(ogr.wkbLinearRing)
            for pt in geometry_nodes:
                ring.AddPoint(pt["lon"], pt["lat"])
            # Close ring if needed
            if geometry_nodes[0] != geometry_nodes[-1]:
                ring.AddPoint(geometry_nodes[0]["lon"], geometry_nodes[0]["lat"])
            poly = ogr.Geometry(ogr.wkbPolygon)
            poly.AddGeometry(ring)
            feat.SetGeometry(poly)
        else:
            line = ogr.Geometry(ogr.wkbLineString)
            for pt in geometry_nodes:
                line.AddPoint(pt["lon"], pt["lat"])
            feat.SetGeometry(line)
            
        layer.CreateFeature(feat)
        feat = None
        
    ds = None
    return output_gpkg_path


---
title: "ENVI Landsat Gapfill Extension - Scientific Algorithm and QGIS Implementation Specification"
subtitle: "Independent, evidence-based reference for AriesGeo Toolbox / AriesGapfill"
author: "AriesPlus Geospatial Solutions - technical specification"
date: "28 October 2026"
version: "1.0 - Research and design reference"
lang: en
geometry: margin=19mm
fontsize: 10pt
colorlinks: true
linkcolor: blue
urlcolor: blue
toc: true
toc-depth: 3
---

# ENVI Landsat Gapfill Extension: Scientific Algorithms, Functions and QGIS Reimplementation Plan

**Project:** AriesGeo Toolbox 4.0 / AriesGapfill  
**Uploaded reference:** `landsat_gapfill.sav`  
**Reference SHA-256:** `9b6fbb4d7688f6421259bf3134c64b6cd0761df72fbfeb9d7bd226a752785dc8`  
**Reference file size:** 62,316 bytes  
**Prepared:** 28 October 2026  
**Document type:** Algorithm engineering specification, *not* decompiled source code or a verified implementation.

> **Critical distinction:** Three methods are confirmed by the published NV5 ENVI extension documentation: (1) single-image Delaunay-triangulation interpolation, (2) two-image global histogram matching, and (3) two-image local histogram matching. Advanced multi-donor recovery, donor ranking, uncertainty mapping, and the full 15-algorithm QGIS suite are **proposed AriesGapfill enhancements**, not features proven to exist in the original `.sav` extension [R1-R3].

> **Scope boundary:** This work covers the Landsat 7 SLC-off gap-repair component of **AriesGeo Toolbox**. It contains no cartographic templates, vegetation indices, spectral indices, or standalone change detection. Those belong to **AriesLegacy**. Quality diagnostics comparing donor and primary pixels are permitted strictly to assess suitability for gap repair.

## Executive findings

1. The official **NV5 Landsat Gapfill tool for ETM SLC-off data**, attributed to **Mari Minari**, is an ENVI Classic add-on installed via an IDL save file in the ENVI `save_add` directory. It supports *triangulation* with one scene and *global/local statistics-based histogram matching* with two scenes. Its published two-image workflow specified an **SLC-on** donor; the primary should be the SLC-off scene [R1].
2. NV5 support states the triangulation mode shares the principle used by ENVI's **Replace Bad Values**, which uses **Delaunay triangulation** over surrounding known pixels [R2-R3].
3. USGS Phase One documents linear matching of donor to target via **gain and offset estimated from the standard deviations and means**, applied globally or in a localized moving window [R4]. It used **17 x 17 pixels** as an illustrative minimum square window for 30-m reflective bands, not a universal optimum [R4].
4. USGS Phase Two expands the scientific background to multi-scene SLC-off recovery, but this is **not an attributed capability of the particular ENVI extension** in [R1]. Multi-donor support is appropriate as a new, separately documented QGIS feature [R5-R6].
5. The uploaded file is a **compiled IDL Save/Restore program**, not an ordinary text script or image dataset. Inspection of its non-executable header identified `SR`, an IDL save format; a 2009 timestamp, Win32, and an IDL 7.0.8 tag. A standard SciPy `readsav()` attempt reported `COMPILED not implemented`. This does **not** disclose its internal algorithms, user interface source, precise defaults, or license-rights. No reverse engineering of compiled routines was attempted. Implement new QGIS algorithms independently from public methodology.

## 1. Provenance, evidence tiers and what can be reproduced

| Evidence category | Finding | Status |
|---|---|---|
| File on disk | `landsat_gapfill.sav`, 62,316 bytes, binary IDL Save/Restore with compiled records | Directly inspected metadata/header only |
| File metadata | Header contains `Tue Jun 23 11:13:16 2009`, `Win32`, `7.0.8` | Observed strings; **not** a guaranteed build-version compatibility statement |
| Official NV5 extension page | One-file triangulation; two-file global or local statistical matching; ENVI Classic menu location; author Mari Minari | Confirmed [R1] |
| NV5 support answer | Single-file method corresponds to ENVI Replace Bad Values triangulation | Confirmed principle [R2-R3] |
| USGS Phase One | Bandwise linear mean/standard-deviation matching, global/local, scan gap masks | Published scientific method [R4] |
| USGS Phase Two and research | Multiple overlapping acquisition dates can help cover missing SLC-off pixels | Published broader field, not the specific `.sav` feature [R5-R6] |
| Proposed PyQGIS features | Donor ranking, robust regression, multi-donor pixel selection, provenance, holdout QA | Independent design, **not yet implemented or scientifically benchmarked** |

**Licensing and portability:** An IDL `.sav` file is not a Python plugin. Its compiled contents cannot be assumed runnable from QGIS, and the uploader's possession does not establish redistribution or modification rights. Build an original PyQGIS implementation using disclosed methods and independent code. Do not redistribute the proprietary `.sav` or make claims about internal source behavior without explicit authorization.

### 1.1 Why gap filling is necessary

The Landsat 7 ETM+ scan-line corrector failed on **31 May 2003**. The resulting wedge-like gaps cause loss of approximately **22% of a typical image scene**, although the amount inside a particular study area varies. The existing observations remain scientifically useful; the gap-filled pixels are **estimates derived from other pixels or dates**, not recovered measurements [R6].

The algorithm must conserve the primary scene's original observations and must separate: **SLC scan gaps**, **cloud/shadow**, **saturation**, **ordinary NoData**, and **outside-scene footprints**. Recovering only SLC gaps avoids silently altering other pixel classes.

### 1.2 Historical ENVI installation/workflow (documented; not tested here)

The NV5 page instructs an ENVI Classic user to place `landsat_gapfill.sav` in the version-specific `save_add` directory and select **Basic Tools > Preprocessing > Data-specific utilities > Landsat TM > Landsat Gapfill**. The reference was written for historical ENVI Classic; this document does not claim compatibility with current ENVI or QGIS [R1].

| Historical mode | Scenes | Main control | Indicative output |
|---|---|---|---|
| Single-file triangulation | One SLC-off scene | Bad-pixel/gap identification | Spatially interpolated scene |
| Two-file global matching | Primary SLC-off + SLC-on fill scene | Scene-wide radiometric statistics | Gap-filled scene using globally matched donor |
| Two-file local matching | Primary SLC-off + SLC-on fill scene | Moving-window radiometric statistics | Gap-filled scene using locally matched donor |

**Unknown from available evidence:** exact original dialog widget names, default thresholds, window dimensions hardcoded by this `.sav`, memory behavior, file naming convention, mask parsing details, source routine names, and whether additional unpublished variants exist. They are not inferred or invented here.

## 2. Input science, file requirements and safeguards

### 2.1 Supported target datasets and processing levels

- **Primary recommended:** Landsat 7 ETM+ SLC-off Landsat Collection 2 Level-1, for workflows calibrated using documented radiometric coefficients, or **Collection 2 Level-2 surface reflectance** for analysis-ready reflective bands.
- **Donors:** temporally compatible ETM+ scenes, including historical SLC-on where available; an independent multi-donor tool may accept SLC-off candidates after strict overlap and quality checks. Cross-sensor donors require explicit spectral response/harmonization validation; do not promise interchangeable bands.
- **Reflective bands:** ETM+ bands **1, 2, 3, 4, 5, 7** at nominal 30-m resolution. Treat thermal band 6 and panchromatic band 8 as different-resolution/data-domain products requiring dedicated models. Do **not** mix L1 raw DN, TOA radiance, TOA reflectance, L2 scaled integer, or physical surface reflectance without appropriate calibration.
- **Outputs:** at minimum GeoTIFF/COG raster, provenance raster, validity/gap mask, run-parameter manifest, and quality report; preserve source scenes unchanged.

### 2.2 Surface reflectance scaling (not gap filling)

For Landsat Collection 2 Level-2 *surface reflectance* reflective bands, USGS specifies:

$$
\rho_{SR} = 0.0000275 \, DN_{L2} - 0.2
$$

Apply the scale and additive offset only to appropriate L2 SR products **after masking fill values**; do not mistake **0 stored DN** for measured reflectance. Raw DN matching may be acceptable for identical, internally compatible historical products, but a new research-grade workflow should preferentially operate in validated radiometric units. Surface reflectance correction itself is **upstream preprocessing**, not produced by the gap-filling formula. [R8-R9]

### 2.3 Data mask definition

Let $F(x)$ be the eligible target footprint, $G_b(x)$ the official band-specific SLC gap mask, $V_b(x)$ the observed valid target mask, $D_{j,b}(x)$ donor validity and $Q_j(x)$ donor clear/unsaturated quality mask. Use Boolean semantics:

$$
E_b(x) = F(x) \land G_b(x) \land \neg V_b(x)
$$

where $E$ is **eligible to fill**, and:

$$
A_{j,b}(x) = E_b(x) \land D_{j,b}(x) \land Q_j(x)
$$

where $A$ is **eligible donor coverage**. Official Landsat 7 SLC-off Level-1 masks have value **0 for originally missing** and **1 for originally present** according to USGS; check version/metadata before assuming the same convention for every auxiliary layer [R7]. If the official mask is unavailable, classify inferred missing stripes as **inferred** and display lower confidence; never treat all zero-valued pixels as SLC gaps automatically.

### 2.4 Mandatory preprocessing and registration

1. Parse sensor ID, processing level, acquisition date, path/row, band names and QA/mask assets; reject contradictory metadata.
2. Validate each raster's affine transform, CRS, pixel dimensions, footprint, band order, scale/offset, NoData and physical units.
3. Inspect band-specific gap masks. Define strict target footprint; keep outside-of-scene pixels excluded from coverage statistics.
4. Warp the donor **to the primary grid** using selected projection/resampling; do not warp the primary just to match a candidate donor.
5. Measure subpixel misregistration on independent tie-point checks. Default to bilinear/cubic for continuous donor reflectance with documented effects; use nearest neighbor for categorical QA, masks and source IDs.
6. Mask clouds, shadows, saturation, snow (when inappropriate), fill and known artifacts in *both* scenes before calibration.
7. Check stable coincident samples; reserve spatially separated holdout samples for unbiased method validation.
8. Create output atomically (temporary location then validated move), preserving original files.

### 2.5 Donor selection

Prioritize hard gates before scoring: compatible bands/data level, georeference and coverage, available QA, acceptable temporal/seasonal match, and sufficient stable overlap. Once candidates pass, rank with an explicitly **user-configurable heuristic**, not a calibrated probability:

$$
S_j = w_o O_j + w_c C_j + w_s T_{season,j} + w_t T_{time,j} - w_r R_j,
\quad \sum_k w_k = 1 \text{ for positive criteria}
$$

$O$: fraction of target gaps with a usable donor; $C$: donor clear coverage; $T$: normalized temporal/seasonal closeness; $R$: normalized radiometric mismatch after independent testing. Weights, thresholds and score components must be visible in the report. USGS recommends cloud-free, temporally and seasonally compatible scenes and favorable complementary scan-gap placement [R5-R6].

## 3. VERIFIED ENVI METHOD A - Single-image Delaunay triangulation

**Provenance:** The original NV5 extension lists single-file triangulation; NV5 support connects it to Replace Bad Values, whose published method is Delaunay triangulation of valid adjacent pixels [R1-R3]. The following computational specification is an **independent reproducible design**, not extracted `.sav` source.

### 3.1 Scientific principle

For each valid sample $P_i=(x_i,y_i,z_i)$, triangulate accepted sample positions in planar pixel coordinates using **Delaunay triangulation**. Given a missing pixel $P=(x,y)$ inside triangle $ABC$, determine barycentric weights $\lambda_A,\lambda_B,\lambda_C$:

$$
\begin{aligned}
\lambda_A+\lambda_B+\lambda_C &=1,\\
P &= \lambda_A A+\lambda_B B+\lambda_C C,\\
\hat z(P) &= \lambda_A z_A+\lambda_B z_B+\lambda_C z_C.
\end{aligned}
$$

Each coefficient must be nonnegative inside the triangle (allowing numerical tolerance). Otherwise the pixel is not eligible for interpolation by that triangle. **No extrapolation outside the supported convex hull.**

### 3.2 Practical implementation workflow

1. Read one band and its authoritative gap mask; preserve every known primary observation unchanged.
2. Select boundary and nearby valid support samples around each connected gap component (spatially stratify to control computational load).
3. Reject cloud/shadow/saturated support pixels and optional extreme outliers.
4. Build a Delaunay triangulation on sample pixel centers; use a safe, deterministic point-selection order.
5. For each gap pixel, locate containing triangle and calculate barycentric interpolation.
6. Reject triangles with too-long edges, unsupported extrapolation, or excessively large interior gap widths.
7. Record class **interpolated** in provenance and local support distance; leave unfillable pixels as NoData.
8. Validate with synthetic masked patches resembling real SLC gaps; report by landscape type and distance to valid edge.

**Suggested parameters:** `MAX_GAP_WIDTH_PX`, `SUPPORT_RADIUS_PX`, `MAX_TRIANGLE_EDGE_PX`, `MIN_VALID_SAMPLES`, `SAMPLE_SPACING_PX`, `ALLOW_EXTRAPOLATION=False`.

**Advantages:** no external donor; deterministic; useful for narrow gaps in smooth terrain. **Limitations:** interpolation can blur edges and create artificial textures/reflectance; large triangles may be visible; crop boundaries and coastlines are particularly sensitive. It does not recover contemporaneous measurements. **Scientific status:** mathematical interpolation, not radiometric reconstruction.

**Reference pseudocode:**

```python
for band in reflective_bands:
    gap_mask = eligible_slc_gap(band)
    for component in connected_components(gap_mask):
        samples = select_valid_boundary_samples(component, radius_px)
        if len(samples) < minimum_samples:
            continue  # stays NoData
        triangles = delaunay(samples.xy)
        for pixel in component:
            tri = triangles.find_containing_triangle(pixel.xy)
            if tri is None or tri.max_edge > limit_px:
                continue
            result[pixel] = barycentric_interpolate(tri, samples.values)
            provenance[pixel] = INTERPOLATED
```

## 4. VERIFIED ENVI METHOD B - Two-image GLOBAL histogram matching

**Provenance:** NV5 identifies a two-image global-statistics option and cites USGS Phase One as the basis. The equations below come from the public USGS method, not from reverse engineering the compiled extension [R1,R4].

### 4.1 Band-specific linear mean/variance matching

Let $X_b$ be the donor band and $Y_b$ be the primary scene band, sampled at **the same spatial cells** from their jointly valid, clear overlap $\Omega_b$. Estimate:

$$
\begin{aligned}
G_b &= \frac{\sigma_{Y_b,\Omega}}{\sigma_{X_b,\Omega}}, \\
B_b &= \mu_{Y_b,\Omega} - G_b\mu_{X_b,\Omega}, \\
\widehat Y_b(x) &= G_b X_b(x) + B_b.
\end{aligned}
$$

Then fill *only eligible missing primary pixels*:

$$
Z_b(x) =
\begin{cases}
Y_b(x), & V_b(x)=1,\\
G_b X_b(x)+B_b, & A_b(x)=1,\\
\mathrm{NoData}, & \text{otherwise}.
\end{cases}
$$

### 4.2 Global method processing steps

1. Align donor and primary onto the identical target grid.
2. Obtain stable, clear, unsaturated intersection pixels $\Omega_b$ and exclude both scenes' missing values.
3. Estimate $\mu_X,\mu_Y,\sigma_X,\sigma_Y$ for each *matching reflective band*.
4. Require minimum overlap count and a **nondegenerate donor standard deviation**. If $\sigma_X$ is near zero, halt or use a documented fallback; do not divide by zero.
5. Apply the calculated $G_b$ and $B_b$ to usable donor pixels; restrict output assignment to target's approved SLC gaps.
6. Validate held-out overlap residuals; record per-band gains, offsets, MAE, RMSE, bias and spatial validity.
7. Preserve source provenance and acquisition date; never label the adjusted donor as an actual observation of primary date.

**Suggested parameters:** robust sample selection (extension), minimum sample count, gain bounds, outlier rejection, saturation mask, selected bands, destination type, rounding/clipping policy.

**Advantages:** fast, compact bandwise coefficients, reliable for similar stable land-cover conditions. **Weaknesses:** one pair of coefficients cannot correct strong local variability, cloud contamination, spatially varying atmospheric differences, phenology, or actual surface change. Standard-deviation matching is a **linear moment match**, not full quantile-to-quantile histogram equalization.

**Independent enhancement - robust global regression:** Allow Huber/IRLS or RANSAC fit $Y_b\approx a_b + b_bX_b$ if overlap sampling supports it. This is an alternative model; **it is not claimed as the original extension's implementation**. Compare methods against independent holdouts rather than assuming robust regression always wins.

## 5. VERIFIED ENVI METHOD C - Two-image LOCAL histogram matching

**Provenance:** NV5 calls this the slower but better-matching choice; USGS Phase One specifies the **localized linear histogram matching (LLHM)** method with moving-window mean/standard-deviation calibration [R1,R4].

### 5.1 Local moving-window formula

For a gap cell $p$ and local neighborhood $W_p$, define $\Omega_b(p)$ as pixels where target and donor are both present and QA-valid. Then:

$$
\begin{aligned}
G_b(p) &= \frac{\sigma_{Y_b,\Omega(p)}}{\sigma_{X_b,\Omega(p)}},\\
B_b(p) &= \mu_{Y_b,\Omega(p)} - G_b(p)\mu_{X_b,\Omega(p)},\\
\widehat Y_b(p) &= G_b(p) X_b(p) + B_b(p).
\end{aligned}
$$

USGS uses a **17 x 17 window** in its Phase One description for 30-m reflective bands where gap width is up to approximately 14 pixels; treat this as a published starting point. Larger/heterogeneous gaps may require adaptive windows and support thresholds rather than blindly applying 17 x 17 everywhere [R4].

### 5.2 Detailed processing flow

1. Build strict per-band overlap masks, exclude cloud/shadow/saturated pixels.
2. For each gap pixel, collect valid coincident target/donor neighbors inside an odd-sized window.
3. If `N_valid < N_MIN` or donor variance below threshold, expand to a larger allowed window or switch to a **clearly recorded** global fallback; otherwise leave as NoData.
4. Compute local gain and offset using the joint sample subset; optionally regularize estimates against global values to reduce unstable high gains.
5. Evaluate adjusted donor at the center pixel only when the center donor is itself clear/valid.
6. Keep original primary measurements exactly unchanged; record correction and support rasters.
7. Validate local residuals on held-out pixels and inspect seam lines and narrow-support areas.

**Suggested controls:** `WINDOW=17` initially, odd sizes e.g. 17/25/33, `MIN_VALID_OVERLAP`, `MIN_DONOR_STD`, `GAIN_MIN/MAX`, `FALLBACK`, optional robust percentile clipping, masks, per-band/resolution mode.

**Advantages:** adapts to local scene statistics; often produces closer radiometric match than global settings. **Limits:** significantly more processing; low variance causes extreme gains; scene changes, mixed land covers, shoreline shifts or cloud contamination can produce artifacts. The official USGS study itself reported striping and edge artifacts in certain scenes [R4].

### 5.3 Efficient local statistics

Naively calculating every $k\times k$ window costs roughly $O(Nk^2)$ pixel operations. Independent optimization should compute integral images or rolling sums for masked values $X$, $Y$, $X^2$, $Y^2$, and `valid-count`, permitting constant-time box sum retrieval (subject to edge handling and numerical precision). For stable behavior, avoid negative variances from floating rounding and use float64 accumulation when appropriate. Chunk output tiles with at least $\lfloor k/2\rfloor$ halo pixels.

**Proposed stabilization (not claimed ENVI behavior):** shrink local gain/offset toward global gain/offset for small $n$ or small standard deviation, e.g. $G'=\alpha G_{local}+(1-\alpha)G_{global}$ where $\alpha=\min(1,n/n_{target})$, with clipping and calibration reporting.

## 6. Companion science: more than the historical extension

These methods support a more capable **independently developed** AriesGapfill. They must be labeled distinctly from the three original NV5 options.

### 6.1 Two-scene versus multiple-scene filling

USGS Phase I used SLC-on donor scenes; Phase II combined multiple SLC-off scenes, exploiting different scan-gap locations [R5-R6]. A configurable multi-donor QGIS strategy should:

- Maintain acquisition date, band grid, calibration domain and quality mask for **each** donor.
- Choose eligible donors using hard gates, then rank per-pixel by quality, season/time difference, residual stability and valid neighborhood support.
- Default to **best single donor per pixel**, avoiding visually pleasing but physically ambiguous temporal averaging.
- Provide optional explicitly named **weighted temporal blending** for compatible continuous observations with documented temporal mixing, never describe the result as the primary-date measured reflectance.
- Leave residual gaps as NoData when no qualifying donor is available.

### 6.2 Donor priority example

For eligible donor pixel $x$, a deterministic cost can be:

$$
C_j(x) = \alpha\,\Delta t_j + \beta\,s_j + \gamma\,r_{j}(x) + \delta\,u_{j}(x)
$$

where $\Delta t$ is normalized days difference, $s$ a season-distance score, $r$ a normalized radiometric mismatch, $u$ a mask/registration penalty. The minimum-cost eligible donor is selected. **These are proposed engineering heuristics**, not established physical uncertainty or original ENVI logic.

### 6.3 Additional optional reconstruction approaches

| Method | Scientific mechanism | Use case | Caveat |
|---|---|---|---|
| IDW | $\widehat z=\sum_i d_i^{-p} z_i / \sum_i d_i^{-p}$ | Small missing patches | Over-smooths edges; cannot recover unobserved detail |
| Global robust linear fit | Fit $Y\approx a+bX$ using outlier-resistant loss | Stable global overlap with occasional abnormal pixels | May still fail across heterogeneous land cover |
| Local robust matching | Local matched overlap with robust clipping, shrinkage and fallback | Spatially varying radiometry | Parameter-sensitive; heavier computational cost |
| Multidonor best-pixel | Choose highest-ranked usable donor for each gap cell | Complementary temporal coverage | Mixed acquisition dates; must track source map |
| Optional multi-donor weighted average | Combine calibrated donor estimates with explicit weights | Smooth relatively stable surfaces | Creates temporal mixture; unsuitable for rapid change |
| Spatially guided interpolation | Use same-scene valid neighborhoods constrained by similarity/segmentation | Donor unavailable for limited areas | Segmentation information and assumptions introduce bias [R10] |
| NSPI / GNSPI research adaptation | Similar-pixel neighborhood and optional geostatistical information | Research-grade comparisons | Literature-specific; separate validated implementation required [R11] |

**Important:** `AriesLegacy` remains responsible for **standalone multispectral index calculation and change detection**. Gapfill donor diagnostics must not be marketed or exported as change maps.

## 7. Proposed AriesGapfill Processing Toolbox algorithms - exact 15 IDs

This catalog preserves the 15 algorithm identifiers in the existing AriesGeo Toolbox v4 scientific specification. Each entry below is a **design contract**, not code that has been executed.

| No. | Processing algorithm ID | Function | Phase |
|---|---|---|---|
| 01 | `ariesgeo:slc_metadata_inspector` | Inspect Landsat 7 scene | 1 |
| 02 | `ariesgeo:slc_gap_mask` | Detect SLC-off gaps | 1 |
| 03 | `ariesgeo:slc_gap_metrics` | Characterize gap geometry | 1 |
| 04 | `ariesgeo:slc_donor_rank` | Rank donor scenes | 2 |
| 05 | `ariesgeo:slc_coregistration` | Register target and donor | 2 |
| 06 | `ariesgeo:slc_stable_pixel_mask` | Select stable calibration overlap | 2 |
| 07 | `ariesgeo:slc_global_match` | Two-image global radiometric match | 2 |
| 08 | `ariesgeo:slc_local_match` | Two-image local-window match | 2 |
| 09 | `ariesgeo:slc_single_tin` | Single-image triangulation fill | 3 |
| 10 | `ariesgeo:slc_single_idw` | Single-image inverse-distance fill | 3 |
| 11 | `ariesgeo:slc_two_scene_fill` | Assemble two-scene gap recovery | 1 |
| 12 | `ariesgeo:slc_multidonor_fill` | Multi-donor temporal recovery | 2 |
| 13 | `ariesgeo:slc_donor_consistency` | Donor suitability diagnostics | 3 |
| 14 | `ariesgeo:slc_recovery_validation` | Spatial holdout validation | 1 |
| 15 | `ariesgeo:slc_recovery_report` | Reproducible recovery QA report | 2 |

### 7.1 Inspect Landsat 7 scene

**Toolbox algorithm:** `ariesgeo:slc_metadata_inspector`  
**Inputs:** Scene directories; target image/bands; MTL; optional QA and gap mask.  
**Outputs:** Image inventory, scene inspection JSON, per-band compatibility table.  
**Scientific method:** Parse sensor/collection/level/CRS/date/wavelength-band mapping. Verify dataset and MTL correspondence; check scale/offset, pixel size, per-band NoData and QA.  
**User parameters:** `STRICT_METADATA`; `MTL`; `BANDS`; `CHECK_QA`; `OUTPUT_JSON`.  
**Validation / negative tests:** Missing MTL with strict mode; wrong platform; mixed bands from different dates; SR/DN confusion.  
**Scientific limits:** Must reject unknown band-to-band alignment and uncalibrated mixed product levels.

**Expected function sequence:** validate parameters and dataset identity → prepare source grid and band masks → perform inspect landsat 7 scene → write temporary results + metadata → validate output integrity → atomically publish outputs. Support `feedback.isCanceled()` in long loops and report per-band progress. No intermediate files may overwrite the user originals.

---

### 7.2 Detect SLC-off gaps

**Toolbox algorithm:** `ariesgeo:slc_gap_mask`  
**Inputs:** Target ETM+ raster; official band gap masks if present; footprint; QA.  
**Outputs:** Band-specific gap mask; inferred-mask flag; mask counts.  
**Scientific method:** Prioritize official SLC-off gap mask 0/1; calculate eligible missing pixel classes. If absent, infer stripe geometry from multiband validity and image footprint with warning. Distinguish cloud, NoData and outside footprint.  
**User parameters:** `GAP_SOURCE`; `FOOTPRINT`; `MASK_VALUE_CONVENTION`; `BANDS`; `OUTPUT`.  
**Validation / negative tests:** Clouds labeled as SLC gaps; entire outside-scene border treated as fillable; false SLC-off classification.  
**Scientific limits:** Inferred mask is not equivalent to a certified USGS gap mask.

**Expected function sequence:** validate parameters and dataset identity → prepare source grid and band masks → perform detect slc-off gaps → write temporary results + metadata → validate output integrity → atomically publish outputs. Support `feedback.isCanceled()` in long loops and report per-band progress. No intermediate files may overwrite the user originals.

---

### 7.3 Characterize gap geometry

**Toolbox algorithm:** `ariesgeo:slc_gap_metrics`  
**Inputs:** Gap mask and eligible target footprint.  
**Outputs:** Area fractions; gap components; pixel-width and edge-distance rasters; CSV/JSON.  
**Scientific method:** Gap percent = 100*N_gap/N_footprint. Label connected components (4/8). Compute Euclidean distance transform in pixel and meter units (only if grid/CRS support it). Summarize gap widths and shape/edge metrics.  
**User parameters:** `CONNECTIVITY`; `MIN_COMPONENT_PX`; `SPATIAL_UNITS`; `OUTPUT_TABLE`.  
**Validation / negative tests:** Incorrect area denominator; geographic-degree distance in meters; disconnected mask islands.  
**Scientific limits:** Do not claim universal missing fraction; area is AOI-specific.

**Expected function sequence:** validate parameters and dataset identity → prepare source grid and band masks → perform characterize gap geometry → write temporary results + metadata → validate output integrity → atomically publish outputs. Support `feedback.isCanceled()` in long loops and report per-band progress. No intermediate files may overwrite the user originals.

---

### 7.4 Rank donor scenes

**Toolbox algorithm:** `ariesgeo:slc_donor_rank`  
**Inputs:** Primary scene and list of candidate scenes, metadata, masks.  
**Outputs:** Candidate eligibility and ranked score table.  
**Scientific method:** Hard reject invalid sensors/levels/bands/grids. For eligible scenes estimate uncovered-gap intersection, clear pixel fraction, acquisition proximity, seasonal similarity and preliminary held-out residual errors. Normalize and weight explicitly.  
**User parameters:** `CANDIDATES`; `MAX_DAY_DIFF`; `MIN_OVERLAP`; `SCORE_WEIGHTS`; `QA_POLICY`.  
**Validation / negative tests:** No matching spectral band; 100% clouded donor; date ambiguity; rankings change with user weights.  
**Scientific limits:** Score is decision aid, not a probability of recovery accuracy.

**Expected function sequence:** validate parameters and dataset identity → prepare source grid and band masks → perform rank donor scenes → write temporary results + metadata → validate output integrity → atomically publish outputs. Support `feedback.isCanceled()` in long loops and report per-band progress. No intermediate files may overwrite the user originals.

---

### 7.5 Register target and donor

**Toolbox algorithm:** `ariesgeo:slc_coregistration`  
**Inputs:** Target/donor aligned bands, tie points or optional control points.  
**Outputs:** Donor warped onto target grid; control-point residual report.  
**Scientific method:** Find matching stable landmarks and estimate geometric transform using robust outlier rejection. Match target extent, transform and pixel dimensions. Record tie-point RMSE and independent spatial distribution; warp donor only.  
**User parameters:** `TRANSFORM`; `RANSAC_THRESHOLD`; `RESAMPLER`; `MAX_RMSE_PX`; `OUTPUT`.  
**Validation / negative tests:** Projective/affine distortions; mismatched datum; coastal differences; no independent checkpoints.  
**Scientific limits:** Do not guarantee alignment from same EPSG code alone.

**Expected function sequence:** validate parameters and dataset identity → prepare source grid and band masks → perform register target and donor → write temporary results + metadata → validate output integrity → atomically publish outputs. Support `feedback.isCanceled()` in long loops and report per-band progress. No intermediate files may overwrite the user originals.

---

### 7.6 Identify stable calibration overlap

**Toolbox algorithm:** `ariesgeo:slc_stable_pixel_mask`  
**Inputs:** Co-registered target and donor bands; cloud/saturation masks.  
**Outputs:** Overlap and stable-pixel mask, diagnostics.  
**Scientific method:** Intersect valid, cloud-free, unsaturated pixels. Select stable overlap using robust residual/MAD filtering or specified pseudo-invariant surfaces. Spatially stratify sampling and withhold independent validation pixels.  
**User parameters:** `MIN_SAMPLE`; `MAD_CUTOFF`; `SAMPLE_GRID`; `QA_MASKS`; `HOLDOUT`.  
**Validation / negative tests:** Changed crop phenology; systematic shifts; inlier collapse; overlap dominated by one land type.  
**Scientific limits:** Residual filters identify radiometric stability, not validated land-cover change.

**Expected function sequence:** validate parameters and dataset identity → prepare source grid and band masks → perform identify stable calibration overlap → write temporary results + metadata → validate output integrity → atomically publish outputs. Support `feedback.isCanceled()` in long loops and report per-band progress. No intermediate files may overwrite the user originals.

---

### 7.7 Two-image global radiometric matching

**Toolbox algorithm:** `ariesgeo:slc_global_match`  
**Inputs:** Registered target/donor, stable overlap samples.  
**Outputs:** Calibrated donor raster; per-band gain/offset CSV; diagnostics.  
**Scientific method:** Calculate G=sigma_target/sigma_donor, B=mu_target-G*mu_donor (USGS) on coincident stable samples; optionally select separately labeled robust regression. Apply to donor and preserve output units.  
**User parameters:** `MATCH_METHOD`; `MIN_SAMPLES`; `SIGMA_EPS`; `GAIN_BOUNDS`; `OUTPUT`.  
**Validation / negative tests:** Degenerate flat donor; sample contamination; extrapolation; saturation; clipping.  
**Scientific limits:** Method comparison uses spatial holdout, not source/target overlap used to calibrate.

**Expected function sequence:** validate parameters and dataset identity → prepare source grid and band masks → perform two-image global radiometric matching → write temporary results + metadata → validate output integrity → atomically publish outputs. Support `feedback.isCanceled()` in long loops and report per-band progress. No intermediate files may overwrite the user originals.

---

### 7.8 Two-image local-window matching

**Toolbox algorithm:** `ariesgeo:slc_local_match`  
**Inputs:** Registered target/donor and matching overlap mask.  
**Outputs:** Locally corrected donor raster; support count; gain/offset surfaces.  
**Scientific method:** For each gap pixel compute local moments in an odd moving window from coincident valid pixels, then G_p=sigmaY/sigmaX, B_p=muY-G_p*muX. Default published reference 17x17 for 30-m bands. Apply fallback only if explicitly selected.  
**User parameters:** `WINDOW`; `WINDOW_MAX`; `MIN_SAMPLES`; `FALLBACK`; `GAIN_LIMIT`.  
**Validation / negative tests:** Low overlap and zero variance; border effects; tile seams; cloud contamination.  
**Scientific limits:** Document window size and need for halos; risk of moving-window artifacts.

**Expected function sequence:** validate parameters and dataset identity → prepare source grid and band masks → perform two-image local-window matching → write temporary results + metadata → validate output integrity → atomically publish outputs. Support `feedback.isCanceled()` in long loops and report per-band progress. No intermediate files may overwrite the user originals.

---

### 7.9 Single-image TIN interpolation

**Toolbox algorithm:** `ariesgeo:slc_single_tin`  
**Inputs:** Primary band, SLC gap mask, valid support pixels.  
**Outputs:** Interpolated image; support-distance, provenance rasters.  
**Scientific method:** Build Delaunay triangulation on bounded gap-neighborhood valid samples. For interior gap pixels use barycentric weights over supporting triangle. Reject excessive triangle edge length and outside-hull points.  
**User parameters:** `SUPPORT_RADIUS_PX`; `EDGE_LIMIT_PX`; `SAMPLE_SPACING`; `MAX_GAP_WIDTH`.  
**Validation / negative tests:** Large triangular surfaces; extrapolation; no valid support; shoreline crossing.  
**Scientific limits:** Label all reconstructed values as interpolation, not measured pixel observations.

**Expected function sequence:** validate parameters and dataset identity → prepare source grid and band masks → perform single-image tin interpolation → write temporary results + metadata → validate output integrity → atomically publish outputs. Support `feedback.isCanceled()` in long loops and report per-band progress. No intermediate files may overwrite the user originals.

---

### 7.10 Single-image inverse-distance interpolation

**Toolbox algorithm:** `ariesgeo:slc_single_idw`  
**Inputs:** Primary band and small-gap mask.  
**Outputs:** Filled image, neighbor-distance diagnostics.  
**Scientific method:** For each missing cell select k nearest valid cells within radius. Use weights w=1/(d^p+epsilon); reject large unsupported gaps. Preserve original observations.  
**User parameters:** `P`; `K`; `SEARCH_RADIUS`; `MIN_NEIGHBORS`; `MAX_GAP_WIDTH`.  
**Validation / negative tests:** No valid neighbors; near-zero distances; over-smoothed heterogeneous areas.  
**Scientific limits:** IDW is independent addition, not an ENVI original documented mode.

**Expected function sequence:** validate parameters and dataset identity → prepare source grid and band masks → perform single-image inverse-distance interpolation → write temporary results + metadata → validate output integrity → atomically publish outputs. Support `feedback.isCanceled()` in long loops and report per-band progress. No intermediate files may overwrite the user originals.

---

### 7.11 Assemble two-scene gap recovery

**Toolbox algorithm:** `ariesgeo:slc_two_scene_fill`  
**Inputs:** Primary target, corrected donor, gap/quality masks.  
**Outputs:** Gap-filled scene, donor provenance, residual gap mask.  
**Scientific method:** For each band, copy observed target pixels unchanged; on eligible SLC gaps copy matched donor only when valid, cloud free, unsaturated and properly registered; else retain NoData.  
**User parameters:** `PRIMARY`; `MATCHED_DONOR`; `TARGET_GAP_MASK`; `DONOR_QA`; `OUTPUT`.  
**Validation / negative tests:** Donor clouds, overlapping fill and target footprints, target valid cells overwritten.  
**Scientific limits:** Bitwise preserve known target values where stored dtype permits; report exceptions if output dtype conversion is requested.

**Expected function sequence:** validate parameters and dataset identity → prepare source grid and band masks → perform assemble two-scene gap recovery → write temporary results + metadata → validate output integrity → atomically publish outputs. Support `feedback.isCanceled()` in long loops and report per-band progress. No intermediate files may overwrite the user originals.

---

### 7.12 Multi-donor temporal recovery

**Toolbox algorithm:** `ariesgeo:slc_multidonor_fill`  
**Inputs:** Primary target and two or more registered, normalized donor datasets.  
**Outputs:** Gap-filled raster; acquisition-date raster; source ID; per-pixel QA.  
**Scientific method:** Evaluate candidate donors per missing pixel using hard quality gates and deterministic priority. Default use best donor. Optional documented temporal-weighted combination for stable targets.  
**User parameters:** `DONORS`; `DONOR_PRIORITY`; `TIME_PENALTY`; `MODE`; `OUTPUT_SOURCE_MAP`.  
**Validation / negative tests:** No viable donor; mixed-season images; duplicate source IDs; temporal blending artifacts.  
**Scientific limits:** Do not label temporally mixed pixel as target-date observation.

**Expected function sequence:** validate parameters and dataset identity → prepare source grid and band masks → perform multi-donor temporal recovery → write temporary results + metadata → validate output integrity → atomically publish outputs. Support `feedback.isCanceled()` in long loops and report per-band progress. No intermediate files may overwrite the user originals.

---

### 7.13 Donor suitability diagnostics

**Toolbox algorithm:** `ariesgeo:slc_donor_consistency`  
**Inputs:** Registered normalized pairs, masks, overlap samples.  
**Outputs:** Residual QA map, anomaly/support table, donor eligibility mask.  
**Scientific method:** Calculate per-band residual e=Y-(GX+B) at observed overlap; summarize median, MAD, spatial clustering and local support. Mark suspicious donor areas only as *repair suitability flags*.  
**User parameters:** `THRESHOLD_MODE`; `ROBUST_SCALE`; `MIN_OVERLAP`; `OUTPUT_MASK`.  
**Validation / negative tests:** Misinterpret residual as surface change; atmospheric/season anomalies; spurious negative SR.  
**Scientific limits:** Not a spectral index or stand-alone change detector; preserve AriesLegacy boundary.

**Expected function sequence:** validate parameters and dataset identity → prepare source grid and band masks → perform donor suitability diagnostics → write temporary results + metadata → validate output integrity → atomically publish outputs. Support `feedback.isCanceled()` in long loops and report per-band progress. No intermediate files may overwrite the user originals.

---

### 7.14 Validate recovery with withheld data

**Toolbox algorithm:** `ariesgeo:slc_recovery_validation`  
**Inputs:** Primary valid pixels, simulated gap masks and corrected donors.  
**Outputs:** Holdout MAE, RMSE, bias, sample counts, per-landscape table.  
**Scientific method:** Create synthetic stripe-shaped and block-shaped masks in observed primary pixels; exclude them from calibration. Re-run fill then compare prediction to observed primary truth only on withheld cells, stratified by band and landscape.  
**User parameters:** `SEED`; `MASK_FOLDS`; `SPATIAL_BLOCK_SIZE`; `METRICS`; `OUTPUT`.  
**Validation / negative tests:** Training/validation leakage; evaluation only over easy central pixels; missing error units.  
**Scientific limits:** Validation demonstrates performance for sampled holdouts, not guaranteed accuracy at all real gaps.

**Expected function sequence:** validate parameters and dataset identity → prepare source grid and band masks → perform validate recovery with withheld data → write temporary results + metadata → validate output integrity → atomically publish outputs. Support `feedback.isCanceled()` in long loops and report per-band progress. No intermediate files may overwrite the user originals.

---

### 7.15 Generate gapfill QA report

**Toolbox algorithm:** `ariesgeo:slc_recovery_report`  
**Inputs:** Primary, result, provenance, gap masks, validation metrics, parameters.  
**Outputs:** JSON/HTML/CSV reports; file checksum manifest; clear uncertainties.  
**Scientific method:** Reconcile original/reconstructed/unfilled pixel counts, per-donor dates, methods, scene IDs, mask source, CRS, units, output hashes and withheld metrics. Compute fractions on eligible footprint.  
**User parameters:** `REPORT_FORMAT`; `PROVENANCE`; `VALIDATION_RESULTS`; `INCLUDE_PARAMETERS`.  
**Validation / negative tests:** Coverage percentages do not add up; lost source identity; report mismatches raster.  
**Scientific limits:** Never write quality score implying measured percent truth; distinguish coverage from accuracy.

**Expected function sequence:** validate parameters and dataset identity → prepare source grid and band masks → perform generate gapfill qa report → write temporary results + metadata → validate output integrity → atomically publish outputs. Support `feedback.isCanceled()` in long loops and report per-band progress. No intermediate files may overwrite the user originals.

---

## 8. End-to-end processing architecture

### 8.1 Processing Toolbox structure

```text
Processing Toolbox
└── AriesGeo Toolbox                       [provider id: ariesgeo]
    └── 02 Landsat 7 SLC-off Gapfill       [group id: landsat_gapfill]
        ├── Inspect Landsat 7 scene
        ├── Detect SLC-off gaps
        ├── Characterize gap geometry
        ├── Rank donor scenes
        ├── Register target and donor
        ├── Identify stable calibration overlap
        ├── Two-image global radiometric matching
        ├── Two-image local-window matching
        ├── Single-image TIN interpolation
        ├── Single-image inverse-distance interpolation
        ├── Assemble two-scene gap recovery
        ├── Multi-donor temporal recovery
        ├── Donor suitability diagnostics
        ├── Validate recovery with withheld data
        └── Generate gapfill QA report
```

**Registration requirement:** The plugin must use a genuine `QgsProcessingProvider` and supply `QgsProcessingAlgorithm` classes. `metadata.txt` contains `hasProcessingProvider=yes`. The provider is registered with `QgsApplication.processingRegistry().addProvider(...)` in `initGui()` and removed in `unload()`. Only fully implemented and dependency-valid algorithms are published. The QGIS documentation explicitly describes this approach [R12-R13].

### 8.2 Project file layout

```text
AriesGeoToolbox/
├── metadata.txt
├── __init__.py
├── ariesgeo_toolbox.py
├── processing/
│   ├── __init__.py
│   ├── provider.py
│   └── gapfill/
│       ├── __init__.py
│       ├── metadata_inspector.py
│       ├── gap_mask.py
│       ├── global_matching.py
│       ├── local_matching.py
│       ├── triangulation.py
│       ├── two_scene_fill.py
│       ├── multidonor_fill.py
│       ├── validation.py
│       └── report.py
├── core/
│   ├── landsat_metadata.py
│   ├── raster_grid.py
│   ├── qa_masks.py
│   ├── statistics.py
│   ├── interpolation.py
│   ├── provenance.py
│   ├── io_atomic.py
│   └── errors.py
├── ui/
│   └── gapfill_panel.py
├── tests/
│   ├── data/
│   ├── test_global_matching.py
│   ├── test_local_matching.py
│   ├── test_tin.py
│   ├── test_mask_semantics.py
│   ├── test_provider_registration.py
│   └── test_recovery_validation.py
├── docs/
│   └── gapfill_scientific_reference.md
└── README.md
```

### 8.3 Concrete provider registration skeleton

```python
# processing/provider.py
from qgis.core import QgsProcessingProvider
from .gapfill.global_matching import GlobalMatchAlgorithm

class AriesGeoProvider(QgsProcessingProvider):
    def id(self):
        return "ariesgeo"

    def name(self):
        return "AriesGeo Toolbox"

    def loadAlgorithms(self):
        # Register implemented algorithms only.
        self.addAlgorithm(GlobalMatchAlgorithm())
        # Add the other 14 classes only after each is implemented/tested.

# ariesgeo_toolbox.py (inside the plugin class)
from qgis.core import QgsApplication
from .processing.provider import AriesGeoProvider

def initProcessing(self):
    if self.provider is None:
        provider = AriesGeoProvider()
        if not QgsApplication.processingRegistry().addProvider(provider):
            raise RuntimeError("Failed to register AriesGeo provider")
        self.provider = provider

def initGui(self):
    self.initProcessing()

# When the plugin is disabled:
def unload(self):
    if self.provider is not None:
        QgsApplication.processingRegistry().removeProvider(self.provider)
        self.provider = None
```

**Code status:** The snippet is *architectural guidance*, not a standalone installable plugin. The referenced `GlobalMatchAlgorithm` is a module/class to be implemented. A matching `classFactory()` and plugin class lifecycle are required in the actual release. IDs, group IDs, parameter types, and API availability must be tested in the intended QGIS environment.

### 8.4 Recommended execution chain

```text
Load primary and donors
    ↓
Inspect metadata / units / QA / spatial grids
    ↓
Read official or inferred band-specific SLC-gap masks
    ↓
Calculate gap geometry and donor suitability
    ↓
Register each eligible donor onto exact target pixel grid
    ↓
Build clear and stable overlap with held-out samples excluded
    ↓
Choose algorithm:
   ├─ ONE IMAGE → Delaunay / IDW (explicit interpolation)
   └─ TWO+ IMAGES → Global / Local radiometric matching
                                 ↓
                        Two-scene or multi-donor merge
                                 ↓
Validate masked known pixels and check original-pixel preservation
    ↓
Write provenance, reconstructed raster, residual gap mask and report
```

### 8.5 Processing steps and computational design

**Raster windows:** Use block reads/writes with GDAL raster I/O or other validated library. For local windows pad tile boundaries with sufficient halos. Cache metadata and masks; do not load entire multi-band regional mosaics into memory if they exceed a configurable budget.

**Parallel processing:** Use safe worker tasks, honoring cancellation and progress. Keep QGIS UI/map-layer changes in the main thread; heavy numerical work should use local arrays and file paths rather than direct GUI objects. Document availability of SciPy/NumPy, GDAL, optional OpenCV/scikit-image as *optional*, and implement graceful disable/alternative for missing dependencies.

**Determinism:** Fix random seeds for sample/validation generation; record library versions, parameters and source file hashes. Avoid changing original rasters or reusing partially completed output on a failed process.

**Numerical type safety:** Work in float32/float64 for statistics. Do not cast reflectance to uint16 and clip negative values without documented inverse scaling. Bandwise nodata and negative calibrated reflectance values require exact mask semantics.

### 8.6 Minimal processing algorithm contract

Each `QgsProcessingAlgorithm` implements `name()`, `displayName()`, `group()`, `groupId()`, `initAlgorithm()`, `processAlgorithm()`, and `createInstance()` as needed by target QGIS release. For substantive operations, define reproducible inputs and outputs, progress/cancel checks and failure messages via `QgsProcessingException`. The provider must ensure stable IDs; no duplicate provider ID registrations.

The UI should expose target scene, reference donor(s), official mask import, method selection, standard/advanced profiles, output folder, and a status/QA panel. Use `QgsMapLayerComboBox` or Processing-provided layer input controls according to context, with QGIS palette/theme inheritance. Do not introduce unrelated map layout templates.

## 9. Mathematical diagnostics, validation and uncertainty

### 9.1 Coverage fractions

For eligible footprint $F$, gap $G$, success $R$ and residual gap $U$:

$$
P_{gap}=100\frac{|G\cap F|}{|F|},\qquad
P_{recovered}=100\frac{|R\cap G\cap F|}{|G\cap F|},\qquad
P_{unfilled}=100-P_{recovered}.
$$

Report **both** scene-level missing percentage and percentage of **initially missing** pixels successfully filled. They have different denominators. Do not call coverage an accuracy statistic.

### 9.2 Error metrics with real withheld target observations

Let $o_i$ be an **observed original primary pixel** withheld from model fitting and $\hat o_i$ its predicted reconstruction for an independently masked position:

$$
\begin{aligned}
MAE &= \frac{1}{n}\sum_{i=1}^{n}|\hat o_i-o_i|,\\
RMSE &= \sqrt{\frac{1}{n}\sum_{i=1}^{n}(\hat o_i-o_i)^2},\\
Bias &= \frac{1}{n}\sum_{i=1}^{n}(\hat o_i-o_i).
\end{aligned}
$$

Report errors **separately by band** and in explicit units (reflectance or source DN), alongside sample count, original-value range and mask pattern. To compare methods fairly, ensure no withheld target pixel was used to fit either local/global correction. Stratify by gap width, distance to valid edge and land-cover texture without producing land-cover change outputs.

### 9.3 Optional multi-band spectral consistency diagnostic

For reflective-band vectors $u_i$ observed and $v_i$ reconstructed on the withheld cells:

$$
SAM_i=\arccos\left(\frac{u_i\cdot v_i}{\|u_i\|\|v_i\|}\right)
$$

A smaller **spectral angle** indicates similar vector direction, provided norms are nonzero. This is a **spectral quality metric**, **not a spectral index** and not a standalone change-detection algorithm. Record the chosen band set and whether raw/physical data were used.

### 9.4 Interpreting uncertainty

- **Coverage certainty:** exact eligible-pixel count and output provenance can be computed once masks are verified.
- **Prediction error:** holdout MAE/RMSE is empirical for the sampled valid-pixel distribution, not an uncertainty guarantee for true gaps.
- **Temporal uncertainty:** older donors, changed surface conditions, and cross-season observations cause extra error not captured by simple overlap matching.
- **Geometric uncertainty:** subpixel misalignment can dominate differences at sharp edges.
- **Interpolation uncertainty:** increases with support distance and heterogeneity; only supply explicitly labeled *support indicators* unless a calibrated uncertainty estimator is validated.

### 9.5 Provenance semantics (proposed)

| Code | Pixel provenance | Temporal interpretation |
|---:|---|---|
| 0 | Outside footprint/unrecovered | No valid reconstruction |
| 1 | Original primary observation | Target acquisition |
| 2-199 | Donor scene selection ID, one ID per donor | Donor-specific date recorded separately |
| 200 | Single-image Delaunay interpolation | Estimated from target-date neighbors |
| 201 | Single-image IDW interpolation | Estimated from target-date neighbors |
| 202 | Multi-donor blended estimate | Composite of listed acquisition dates |
| 255 | Reserved/invalid provenance | No interpretation |

The code range should be validated against actual number of donors and output dtype; reserve a separate source metadata table for IDs and use GeoTIFF/GeoPackage for reproducible storage. If the system supports more sources, use a wider integer map and a documented schema. **No provenance ID is an accuracy score.**

## 10. Validation plan - minimum reproducibility requirements

| Test ID | Test fixture | Expected rule / pass condition |
|---|---|---|
| T01 | Controlled synthetic raster with no gaps | Output identical to input; no invented gap pixels |
| T02 | Known narrow stripe mask | Fill only eligible missing cells; original valid cells unchanged |
| T03 | Missing footprint edge and SLC wedges | Edge/outside-scene pixels remain excluded from denominators |
| T04 | Cloud patch but no SLC gap | Cloud not misclassified as an SLC gap |
| T05 | Identical target and donor | Global gain approximately 1, bias approximately 0 where variance is nonzero |
| T06 | Synthetic donor with known affine radiometric transform | Global method recovers known transform within tolerance |
| T07 | Uniform donor with zero variance | Graceful fallback/error, never division-by-zero/NaNs silently |
| T08 | Local 17x17 synthetic window | Verify gains/offsets against independent NumPy calculation |
| T09 | Tiling with and without overlap halos | Pixelwise equivalent local results near tile seams |
| T10 | Triangle with known planar surface | Reconstruct withheld points exactly within numeric tolerance |
| T11 | Triangulation outside convex hull | Do not extrapolate by default |
| T12 | Donor with no valid coverage for gap | Keep NoData and report no recovery |
| T13 | Two donors with complementary gap masks | Merge correct source pixels and correct date/source map |
| T14 | Distinct acquisitions/seasons | Display donor temporal warning; expose acquisition dates |
| T15 | QA/scale mismatch | Reject mixed L1/L2 and incompatible band scale without normalization |
| T16 | Withheld stripe-shaped masks | Verify MAE/RMSE/bias and spatial holdout isolation |
| T17 | Cancellation during large tiled processing | Originals remain intact; temporary outputs removed safely |
| T18 | Processing registry after plugin installation | Every implemented ID resolves; disabling plugin removes provider cleanly |
| T19 | Export and re-open | CRS, geotransform, band labels, nodata and provenance preserved |
| T20 | Invalid paths, disk-full, unreadable imagery | Actionable errors; no partial output presented as complete |

**Do not invent test passes.** No QGIS runtime, Landsat imagery pair, or ENVI license was supplied for actually exercising these tests in this research document. They are required acceptance criteria for the implementation stage.

## 11. Benchmarks and performance protocol

Compare the 3 original-equivalent methods and advanced versions on the **same** fixed scenes and masks. Report: scene dimensions, bytes, band count, disk interface, process peak memory, elapsed time, gap coverage, per-band held-out errors, and artifacts. Use multiple geography types and multiple seasons. Choose methods using jointly evaluated tradeoffs; **no empirical runtime, accuracy rate or speedup is asserted without a completed benchmark**.

Expected computational behavior in principle: global matching generally requires fewer per-pixel statistics than local matching; local matching is potentially more accurate where local variation matters but has higher cost. Delaunay interpolation performance depends on valid sample count and triangulation geometry, so limit support points around gaps rather than triangulating every pixel of a full scene at once.

## 12. Implementation milestones / releases

| Milestone | Deliverable | Acceptance gate |
|---|---|---|
| M1: provider foundation | `ariesgeo` Processing provider, registry smoke test, metadata parsing, mask diagnostics | Visible and runnable tools after install/enable |
| M2: baseline ENVI-equivalent science | Independent global matching, local matching, single-image TIN | Synthetic mathematical tests + original-pixel preservation |
| M3: production two-scene recovery | registration checks, stable mask, assembled fill, provenance | Raster QA and bandwise withheld metrics |
| M4: multi-donor | scene ranking, per-pixel selection, source/date mapping | Demonstrated complementary coverage and no silent temporal blend |
| M5: optional advanced methods | IDW, robust global/local variants, residual suitability | Compare against baselines on realistic test data |
| M6: usability and release | QGIS-aware interface, help pages, logs, batch processing, packaging | Cross-version integration tests, clean uninstall and dependency audit |

**QGIS compatibility policy:** Select a target QGIS/Python/Qt matrix from actual environments before implementation; avoid claiming QGIS 3.x/4.x dual compatibility until both have been exercised. Gate optional dependencies during provider load and disable unimplemented algorithms rather than registering stubs.

## 13. Operating procedure for end users (future QGIS module)

1. Open **Processing Toolbox > AriesGeo Toolbox > Landsat 7 SLC-off Gapfill**.
2. Run **Inspect Landsat 7 scene** and confirm input product level and band/QA metadata.
3. Run **Detect SLC-off gaps** and inspect bandwise mask and eligible gap fraction.
4. If a suitable donor is available, use **Rank donor scenes** and **Register target and donor**; otherwise consider small-gap interpolation with scientific cautions.
5. Run **Identify stable calibration overlap**; preserve a spatial holdout set.
6. Compare **Global radiometric match** versus **Local-window match** in preview/validation mode.
7. Run **Assemble two-scene gap recovery** or **Multi-donor temporal recovery**.
8. Run **Validate recovery with withheld data** and review each band separately.
9. Produce **Generate gapfill QA report** and save output, source/date map, missing-pixel mask and parameter manifest.

The plugin should show a prominent summary of **original pixel fraction**, **direct donor pixel fraction**, **interpolated fraction**, **unfilled fraction**, **acquisition dates** and **holdout error metrics**, not merely a single green success message.

## 14. Conclusions and explicit limitations

The uploaded **ENVI Classic Landsat Gapfill** extension is best understood from its official description as a *three-mode SLC-off recovery utility*. Single-image triangulation is appropriate when no donor exists but creates estimated surfaces. Two-image global matching is computationally economical and uses a per-band linear transformation. Two-image local matching refines this into moving-window corrections, more adaptable but more sensitive to support quality and processing cost.

For **AriesGeo Toolbox**, implement these **independently** as verifiable Processing Toolbox algorithms, then add multi-donor selection, provenance, QA, holdout validation and reproducible reports. A compiled `.sav` cannot be treated as a Python library or a source-code specification, and it would be incorrect to claim an exact port of its unpublished internals.

---

## References (original sources and official developer documentation)

- **[R1] NV5 Geospatial**, *Landsat Gapfill tool for ETM SLC-off data*. Original ENVI extension description and installation instructions. https://www.nv5geospatialsoftware.com/Support/Maintenance-Detail/landsat-gapfill-tool-for-etm-slc-off-data
- **[R2] NV5 Geospatial**, *Landsat Gapfill tool*, support discussion (2015) clarifying triangulation and Phase One documentation. https://www.nv5geospatialsoftware.com/Support/Forums/aft/4282
- **[R3] NV5 Geospatial**, *Replace Bad Values*. Official documentation for Delaunay-triangulation surface fitting. https://www.nv5geospatialsoftware.com/docs/ReplacingBadValues.html
- **[R4] Scaramuzza, Micijevic & Chander (2004), USGS**, *SLC Gap-Filled Products: Phase One Methodology*. https://d9-wret.s3.us-west-2.amazonaws.com/assets/palladium/production/s3fs-public/atoms/files/SLC_Gap_Fill_Methodology.pdf
- **[R5] USGS**, *Landsat 7 SLC-off Gap-Filled Products Phase Two Methodology*. https://www.usgs.gov/media/files/landsat-7-slc-gap-filled-products-phase-two-methodology
- **[R6] Storey, Scaramuzza, Schmidt & Barsi (2005), USGS**, *Landsat 7 scan line corrector-off gap-filled product development*. https://www.usgs.gov/publications/landsat-7-scan-line-corrector-gap-filled-product-development
- **[R7] USGS**, *What are Landsat 7 SLC-off Gap Mask files?*. https://www.usgs.gov/faqs/what-are-landsat-7-slc-gap-mask-files
- **[R8] USGS**, *Landsat Collection 2 Surface Reflectance*. https://www.usgs.gov/landsat-missions/landsat-collection-2-surface-reflectance
- **[R9] USGS**, *How do I use a scale factor with Landsat Level-2 science products?* https://www.usgs.gov/faqs/how-do-i-use-a-scale-factor-landsat-level-2-science-products
- **[R10] Maxwell (2004), USGS**, *Filling Landsat ETM+ SLC-off gaps using a segmentation model approach*. https://www.usgs.gov/publications/filling-landsat-etm-slc-gaps-using-a-segmentation-model-approach
- **[R11] Evaluation of gap-filling methods for Landsat 7 ETM+ SLC-off image for LULC classification in a heterogeneous landscape of West Africa*, *International Journal of Remote Sensing* (2019/2020). https://doi.org/10.1080/01431161.2019.1693076
- **[R12] QGIS Project**, *Writing a Processing plugin - PyQGIS Developer Cookbook*. https://documentation.qgis.org/testing/en/docs/pyqgis_developer_cookbook/processing.html
- **[R13] QGIS Project**, *QgsProcessingProvider API*. https://www.qgis.org/pyqgis/master/core/QgsProcessingProvider.html
- **[R14] USGS**, *Landsat 7 mission and SLC failure*. https://www.usgs.gov/landsat-missions/landsat-7
- **[R15] NV5 Geospatial**, *Landsat Gapfill in ENVI Classic*, historical extensions note. https://www.nv5geospatialsoftware.com/Support/Maintenance-Detail/my-favorite-envi-extensions

*Research note: Reference links and mathematical background were checked against published NV5/USGS/QGIS documentation in October 2026. No use of proprietary IDL compiled routines or source reproduction is involved. The QGIS algorithms and all enhanced features remain proposals until implemented and independently tested.*

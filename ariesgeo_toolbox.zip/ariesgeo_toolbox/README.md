# AriesGeo Toolbox v4.0 for QGIS

![AriesGeo Toolbox Logo](icons/logo.png)

**Brand:** AriesPlus  
**Plugin:** AriesGeo Toolbox (`ariesgeo`)  
**Version:** 4.0.0  
**Compatibility:** QGIS 3.28+ through QGIS 4.x (PyQt5 & PyQt6 ready)

> **Find faster. Mosaic better. Model terrain and spatial decisions with scientific rigor.**

AriesGeo Toolbox 4.0 is a Processing-first scientific geospatial suite for QGIS, exposing **100 production-ready scientific algorithms** organized across **7 specialized domains**, paired with interactive dockable panels and guided multi-step wizards.

---

## Processing-First Architecture (100 Algorithms Across 7 Groups)

All algorithms are registered under the `ariesgeo` Processing provider (`ariesgeo:<algorithm_id>`) and work seamlessly in the **QGIS Processing Toolbox**, **Graphical Modeler**, **Batch Processing interface**, and standalone **PyQGIS / `qgis_process` CLI scripts**.

### `01 · Place Finder & Geocoding` (10 Algorithms)
- `place_search` (`01.01`) — Search places & settlements
- `reverse_geocode` (`01.02`) — Reverse geocode coordinates
- `batch_geocode` (`01.03`) — Batch geocode table
- `coordinate_parser` (`01.04`) — Parse & normalize coordinates (DD, DMS, DDM, UTM, MGRS, WKT)
- `transform_coordinates` (`01.05`) — Transform coordinate table CRS
- `nearest_place` (`01.06`) — Find nearest named settlement
- `place_proximity` (`01.07`) — Distance to places matrix
- `search_within_aoi` (`01.08`) — Extract places inside polygon AOI
- `offline_gazetteer_build` (`01.09`) — Build offline SQLite FTS5 gazetteer
- `gazetteer_quality_audit` (`01.10`) — Audit gazetteer completeness

### `02 · Landsat 7 SLC-off Gapfill` (15 Algorithms)
- `slc_metadata_inspector` (`02.01`) — Parse Landsat MTL metadata
- `slc_gap_mask` (`02.02`) — Extract SLC-off scan-line gap mask
- `slc_gap_metrics` (`02.03`) — Quantify gap geometry & severity
- `slc_donor_rank` (`02.04`) — Rank candidate donor scenes
- `slc_coregistration` (`02.05`) — Sub-pixel donor co-registration
- `slc_stable_pixel_mask` (`02.06`) — Mask clouds & transient change
- `slc_global_match` (`02.07`) — Global linear histogram match
- `slc_local_match` (`02.08`) — Local moving-window linear regression (LLHM)
- `slc_single_tin` (`02.09`) — Single-scene Delaunay triangulation fill
- `slc_single_idw` (`02.10`) — Single-scene directional IDW fill
- `slc_two_scene_fill` (`02.11`) — Two-scene primary donor transfer
- `slc_multidonor_fill` (`02.12`) — Multi-donor priority composite fill
- `slc_donor_consistency` (`02.13`) — Cross-donor discrepancy map
- `slc_recovery_validation` (`02.14`) — Artificial scan-line cross-validation (RMSE, MAE, Bias, $R^2$)
- `slc_recovery_report` (`02.15`) — Export gap-fill provenance report

### `03 · Raster Preprocessing & Cloud Removal` (20 Algorithms)
- `raster_inspector` (`03.01`), `scene_metadata` (`03.02`), `reflectance_scale` (`03.03`), `radiometric_qa` (`03.04`), `raster_grid_align` (`03.05`), `raster_stack_builder` (`03.06`), `landsat_qa_mask` (`03.07`), `sentinel_scl_mask` (`03.08`), `cloud_mask_refine` (`03.09`), `cloud_coverage_report` (`03.10`), `temporal_cloud_composite` (`03.11`), `nodata_spatial_fill` (`03.12`), `mosaic_vrt` (`03.13`), `mosaic_priority` (`03.14`), `mosaic_seam_blend` (`03.15`), `radiometric_harmonize` (`03.16`), `raster_clip_aoi` (`03.17`), `cog_export` (`03.18`), `raster_batch_pipeline` (`03.19`), `raster_quality_summary` (`03.20`)

### `04 · Terrain & Hydrology` (24 Algorithms)
- `dem_diagnostics` (`04.01`), `dem_merge_prepare` (`04.02`), `dem_void_fill` (`04.03`), `dem_sink_treatment` (`04.04`), `dem_slope` (`04.05`), `dem_aspect` (`04.06`), `dem_hillshade` (`04.07`), `dem_curvature` (`04.08`), `dem_tri` (`04.09`), `dem_tpi` (`04.10`), `dem_roughness` (`04.11`), `dem_contours` (`04.12`), `dem_profile` (`04.13`), `flow_d8` (`04.14`), `flow_mfd` (`04.15`), `flow_specific_area` (`04.16`), `flow_stream_extract` (`04.17`), `flow_outlet_snap` (`04.18`), `flow_watershed` (`04.19`), `flow_subbasins` (`04.20`), `stream_order` (`04.21`), `hydro_twi` (`04.22`), `hydro_spi` (`04.23`), `watershed_morphometry` (`04.24`)

### `05 · Spatial Statistics & Suitability` (15 Algorithms)
- `raster_standardize` (`05.01`), `ahp_weights` (`05.02`), `weighted_overlay` (`05.03`), `fuzzy_membership` (`05.04`), `fuzzy_overlay` (`05.05`), `suitability_sensitivity` (`05.06`), `zonal_distribution` (`05.07`), `point_kde` (`05.08`), `point_idw` (`05.09`), `moran_global` (`05.10`), `moran_local` (`05.11`), `gi_star` (`05.12`), `nearest_neighbor_stats` (`05.13`), `buffer_exposure_summary` (`05.14`), `spatial_model_report` (`05.15`)

### `06 · Data Hub & Acquisition` (8 Algorithms)
- `catalog_stac_search` (`06.01`), `catalog_asset_inspect` (`06.02`), `catalog_landsat_search` (`06.03`), `catalog_sentinel_search` (`06.04`), `catalog_dem_search` (`06.05`), `catalog_osm_import` (`06.06`), `download_assets` (`06.07`), `local_catalog_index` (`06.08`)

### `07 · Quality Control & Workflows` (8 Algorithms)
- `layer_integrity_audit` (`07.01`), `raster_alignment_audit` (`07.02`), `vector_geometry_audit` (`07.03`), `algorithm_preflight` (`07.04`), `workflow_run` (`07.05`), `workflow_batch` (`07.06`), `validation_statistics` (`07.07`), `provenance_export` (`07.08`)

---

## Scope & Ecosystem Notes (v4.0)
- **Map Layout Assistant Retired:** Cartographic layout generation has been retired in v4.0 so AriesGeo Toolbox focuses strictly on scientific data preparation, restoration, terrain/hydrology, and spatial modeling.
- **Spectral Indices Separation:** Standalone spectral indices (NDVI, NDWI, NDBI, SAVI, EVI, NBR) and temporal change detection belong to the separate **AriesLegacy** plugin.

---

## Installation & Testing

### Manual Installation
Copy the `ariesgeo_toolbox` folder to your QGIS Python plugins directory:
- **Windows:** `%APPDATA%\QGIS\QGIS3\profiles\default\python\plugins\` or `%APPDATA%\QGIS\QGIS4\profiles\default\python\plugins\`
- **Linux:** `~/.local/share/QGIS/QGIS3/profiles/default/python/plugins/`
- **macOS:** `~/Library/Application Support/QGIS/QGIS3/profiles/default/python/plugins/`

### Running the Automated Test Suite
```bash
python-qgis.bat tests/run_tests.py
```

---

## License

GPL-3.0 License. See [LICENSE](LICENSE) for details.

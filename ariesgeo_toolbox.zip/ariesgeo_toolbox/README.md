# AriesGeo Toolbox for QGIS

**Brand:** AriesPlus  
**Plugin:** AriesGeo Toolbox  
**Compatibility:** QGIS 3.28+ up to QGIS 4.x  

> **Find faster. Mosaic better. Work with confidence.**

AriesGeo Toolbox is a professional QGIS plugin suite providing clean, guided geospatial workflows for place search, raster inspection, virtual/permanent mosaicking, and scientific gap filling.

---

## Key Modules

### 1. Aries Place Finder
- **Global & Local Search:** Search settlements, administrative boundaries, points of interest, and addresses.
- **Multiple Providers:** OpenStreetMap Nominatim, Photon (Komoot), and fast SQLite offline gazetteers.
- **Canvas Integration:** Zoom to, pan, flash, and mark results. Auto-bias search to active map extent.
- **Layer Export:** Add results to active project as memory/GeoPackage point or boundary polygon layers.
- **Reverse Geocoding:** Click anywhere on the QGIS canvas to inspect address hierarchy.
- **Batch Geocoding:** Geocode CSV/attribute tables with rate-limit protection and summary reports.

### 2. Aries Mosaic & GapFill
- **Preflight Inspector:** Automatic diagnostic scan for CRS alignment, resolution parity, grid origin offsets, band configurations, and NoData values.
- **Virtual (VRT) & Permanent Mosaic:** Build fast Virtual Rasters or optimized tiled GeoTIFF / Cloud Optimized GeoTIFFs (COG) with DEFLATE/LZW compression and overviews.
- **Spatial NoData Fill:** Edge-based interpolation for small holes, water bodies, or cloud voids.
- **Landsat 7 SLC-off Fill:** Multi-donor gap-filling pipeline with radiometric matching, regression adjustment, temporal weighting, and confidence layer generation.
- **Provenance & Quality Reports:** Sidecar JSON and Markdown provenance reports recording exact parameters, inputs, and validation metrics (RMSE, MAE, fill percentage).

### 3. Processing Provider
- 12 ready-to-use QGIS Processing algorithms available in the QGIS Processing Toolbox, Graphical Modeler, and Batch Processing interface.

---

## Installation

### Manual Installation
1. Copy the `ariesgeo_toolbox` folder to your QGIS python plugins directory:
   - **Windows:** `%APPDATA%\QGIS\QGIS3\profiles\default\python\plugins\` or `%APPDATA%\QGIS\QGIS4\profiles\default\python\plugins\`
   - **Linux:** `~/.local/share/QGIS/QGIS3/profiles/default/python/plugins/`
   - **macOS:** `~/Library/Application Support/QGIS/QGIS3/profiles/default/python/plugins/`
2. Open QGIS, go to **Plugins -> Manage and Install Plugins...**, find **AriesGeo Toolbox** and check the box to activate it.

### Automatic Deployment Script
Run the included deployment script from the project folder:
```bash
python scripts/deploy_to_qgis.py
```

---

## License

GPL-3.0 License. See [LICENSE](LICENSE) for details.

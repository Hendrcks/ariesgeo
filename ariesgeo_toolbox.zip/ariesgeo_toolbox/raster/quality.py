"""
Quality validation metrics and statistics for Aries Mosaic & GapFill.
"""

from typing import Dict, Any, List
import numpy as np

class QualityMetrics:
    """Calculates statistical validation metrics for raster operations."""

    @staticmethod
    def calculate_error_metrics(reference_arr: np.ndarray, estimated_arr: np.ndarray) -> Dict[str, float]:
        """Compute RMSE, MAE, Mean Bias Error (MBE), and Pearson correlation."""
        valid_mask = ~np.isnan(reference_arr) & ~np.isnan(estimated_arr)
        ref = reference_arr[valid_mask].flatten()
        est = estimated_arr[valid_mask].flatten()

        if len(ref) < 10:
            return {"rmse": 0.0, "mae": 0.0, "bias": 0.0, "r2": 0.0, "sample_count": len(ref)}

        diff = est - ref
        rmse = float(np.sqrt(np.mean(diff ** 2)))
        mae = float(np.mean(np.abs(diff)))
        bias = float(np.mean(diff))

        corr_mat = np.corrcoef(ref, est)
        r2 = float(corr_mat[0, 1] ** 2) if corr_mat.shape == (2, 2) else 0.0

        return {
            "rmse": round(rmse, 4),
            "mae": round(mae, 4),
            "bias": round(bias, 4),
            "r2": round(r2, 4),
            "sample_count": len(ref)
        }

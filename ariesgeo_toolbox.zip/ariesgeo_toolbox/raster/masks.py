"""
Mask extraction and coverage footprint generators for Aries Mosaic & GapFill.
"""

import os
from typing import Optional
from osgeo import gdal, osr
from ..core.exceptions import RasterInspectionError

class MaskGenerator:
    """Creates binary raster masks for NoData gaps, valid coverage, and cloud shadows."""

    @classmethod
    def create_nodata_mask(
        cls,
        input_raster_path: str,
        output_mask_path: str,
        band_index: int = 1,
        custom_nodata_val: Optional[float] = None
    ) -> str:
        """Create a binary mask where 1 = NoData / Gap, 0 = Valid Data."""
        ds = gdal.Open(input_raster_path, gdal.GA_ReadOnly)
        if not ds:
            raise RasterInspectionError(f"Cannot open raster: {input_raster_path}")

        band = ds.GetRasterBand(band_index)
        nodata = custom_nodata_val if custom_nodata_val is not None else band.GetNoDataValue()

        driver = gdal.GetDriverByName("GTiff")
        out_ds = driver.Create(
            output_mask_path,
            ds.RasterXSize,
            ds.RasterYSize,
            1,
            gdal.GDT_Byte,
            ["COMPRESS=DEFLATE"]
        )
        out_ds.SetGeoTransform(ds.GetGeoTransform())
        out_ds.SetProjection(ds.GetProjection())

        out_band = out_ds.GetRasterBand(1)
        out_band.SetNoDataValue(255)

        # Process in blocks
        block_x, block_y = band.GetBlockSize()
        for y in range(0, ds.RasterYSize, block_y):
            rows = min(block_y, ds.RasterYSize - y)
            for x in range(0, ds.RasterXSize, block_x):
                cols = min(block_x, ds.RasterXSize - x)
                arr = band.ReadAsArray(x, y, cols, rows)
                if nodata is not None:
                    # 1 where arr == nodata or NaN
                    import numpy as np
                    if np.isnan(nodata):
                        mask_arr = np.where(np.isnan(arr), 1, 0).astype(np.uint8)
                    else:
                        mask_arr = np.where((arr == nodata) | np.isnan(arr), 1, 0).astype(np.uint8)
                else:
                    import numpy as np
                    mask_arr = np.where(np.isnan(arr) | (arr == 0), 1, 0).astype(np.uint8)

                out_band.WriteArray(mask_arr, x, y)

        out_band.FlushCache()
        out_ds = None
        ds = None
        return output_mask_path

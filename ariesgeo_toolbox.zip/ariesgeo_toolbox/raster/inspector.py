"""
Preflight raster stack inspector and diagnostic analyzer for Aries Mosaic & GapFill.
"""

import os
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional
from osgeo import gdal, osr

@dataclass
class RasterMetadata:
    """Detailed metadata for a single input raster dataset."""
    filepath: str
    filename: str
    width: int
    height: int
    band_count: int
    data_type_name: str
    crs_auth_id: str
    crs_wkt: str
    geotransform: List[float]
    pixel_size_x: float
    pixel_size_y: float
    origin_x: float
    origin_y: float
    extent: List[float]  # [min_x, min_y, max_x, max_y]
    nodata_values: List[Optional[float]]
    file_size_bytes: int
    is_readable: bool = True
    error_message: str = ""


@dataclass
class DiagnosticIssue:
    """A diagnostic issue identified during stack inspection."""
    severity: str  # "INFO", "WARNING", "ERROR"
    title: str
    description: str
    affected_files: List[str] = field(default_factory=list)


@dataclass
class InspectionReport:
    """Complete diagnostic report for a collection of raster inputs."""
    raster_count: int
    rasters: List[RasterMetadata]
    issues: List[DiagnosticIssue]
    common_crs: Optional[str] = None
    common_band_count: Optional[int] = None
    common_data_type: Optional[str] = None
    common_pixel_size: Optional[List[float]] = None
    unified_extent: Optional[List[float]] = None
    is_compatible_for_quick_mosaic: bool = True
    total_uncompressed_size_bytes: int = 0


class RasterInspector:
    """Inspects and diagnoses raster datasets prior to mosaicking or gap-filling."""

    @classmethod
    def inspect_file(cls, filepath: str) -> RasterMetadata:
        """Inspect a single raster file and extract full metadata."""
        if not os.path.exists(filepath):
            return RasterMetadata(
                filepath=filepath,
                filename=os.path.basename(filepath),
                width=0,
                height=0,
                band_count=0,
                data_type_name="Unknown",
                crs_auth_id="Unknown",
                crs_wkt="",
                geotransform=[0, 1, 0, 0, 0, -1],
                pixel_size_x=1.0,
                pixel_size_y=1.0,
                origin_x=0.0,
                origin_y=0.0,
                extent=[0, 0, 0, 0],
                nodata_values=[],
                file_size_bytes=0,
                is_readable=False,
                error_message="File not found on disk"
            )

        file_size = os.path.getsize(filepath)
        ds = gdal.Open(filepath, gdal.GA_ReadOnly)
        if not ds:
            return RasterMetadata(
                filepath=filepath,
                filename=os.path.basename(filepath),
                width=0,
                height=0,
                band_count=0,
                data_type_name="Unknown",
                crs_auth_id="Unknown",
                crs_wkt="",
                geotransform=[0, 1, 0, 0, 0, -1],
                pixel_size_x=1.0,
                pixel_size_y=1.0,
                origin_x=0.0,
                origin_y=0.0,
                extent=[0, 0, 0, 0],
                nodata_values=[],
                file_size_bytes=file_size,
                is_readable=False,
                error_message="GDAL failed to open raster dataset"
            )

        try:
            width = ds.RasterXSize
            height = ds.RasterYSize
            band_count = ds.RasterCount
            
            # CRS
            proj_wkt = ds.GetProjection() or ""
            crs_auth_id = "Unknown"
            if proj_wkt:
                srs = osr.SpatialReference()
                srs.ImportFromWkt(proj_wkt)
                auth_name = srs.GetAuthorityName(None)
                auth_code = srs.GetAuthorityCode(None)
                if auth_name and auth_code:
                    crs_auth_id = f"{auth_name}:{auth_code}"

            # GeoTransform
            gt = list(ds.GetGeoTransform())
            origin_x = gt[0]
            origin_y = gt[3]
            pixel_size_x = abs(gt[1])
            pixel_size_y = abs(gt[5])

            # Extent: [min_x, min_y, max_x, max_y]
            min_x = origin_x
            max_x = origin_x + (gt[1] * width)
            max_y = origin_y
            min_y = origin_y + (gt[5] * height)
            if min_x > max_x:
                min_x, max_x = max_x, min_x
            if min_y > max_y:
                min_y, max_y = max_y, min_y

            # Bands & NoData
            nodata_vals = []
            data_type_name = "Unknown"
            if band_count > 0:
                b1 = ds.GetRasterBand(1)
                data_type_name = gdal.GetDataTypeName(b1.DataType)
                for b_idx in range(1, band_count + 1):
                    band = ds.GetRasterBand(b_idx)
                    nodata_vals.append(band.GetNoDataValue())

            return RasterMetadata(
                filepath=filepath,
                filename=os.path.basename(filepath),
                width=width,
                height=height,
                band_count=band_count,
                data_type_name=data_type_name,
                crs_auth_id=crs_auth_id,
                crs_wkt=proj_wkt,
                geotransform=gt,
                pixel_size_x=pixel_size_x,
                pixel_size_y=pixel_size_y,
                origin_x=origin_x,
                origin_y=origin_y,
                extent=[min_x, min_y, max_x, max_y],
                nodata_values=nodata_vals,
                file_size_bytes=file_size,
                is_readable=True
            )
        finally:
            ds = None

    @classmethod
    def inspect_stack(cls, filepaths: List[str]) -> InspectionReport:
        """Inspect multiple rasters and evaluate consistency and compatibility."""
        rasters: List[RasterMetadata] = []
        issues: List[DiagnosticIssue] = []

        for p in filepaths:
            meta = cls.inspect_file(p)
            rasters.append(meta)

        if not rasters:
            return InspectionReport(
                raster_count=0,
                rasters=[],
                issues=[DiagnosticIssue("ERROR", "No inputs", "No raster files selected.")],
                is_compatible_for_quick_mosaic=False
            )

        # 1. Readability check
        unreadable = [r.filename for r in rasters if not r.is_readable]
        if unreadable:
            issues.append(
                DiagnosticIssue(
                    "ERROR",
                    "Unreadable rasters",
                    f"{len(unreadable)} raster(s) cannot be read by GDAL.",
                    unreadable
                )
            )

        readable_rasters = [r for r in rasters if r.is_readable]
        if not readable_rasters:
            return InspectionReport(
                raster_count=len(rasters),
                rasters=rasters,
                issues=issues,
                is_compatible_for_quick_mosaic=False
            )

        # 2. CRS Consistency
        crs_set = {r.crs_auth_id for r in readable_rasters}
        common_crs = readable_rasters[0].crs_auth_id if len(crs_set) == 1 else None
        if len(crs_set) > 1:
            issues.append(
                DiagnosticIssue(
                    "WARNING",
                    "Mixed Coordinate Reference Systems",
                    f"Rasters use multiple CRS ({', '.join(crs_set)}). Reprojection will be required.",
                    [r.filename for r in readable_rasters]
                )
            )
        elif "Unknown" in crs_set:
            issues.append(
                DiagnosticIssue(
                    "WARNING",
                    "Missing or Unknown CRS",
                    "Rasters have no embedded projection authority. Spatial alignment may be inaccurate.",
                    [r.filename for r in readable_rasters if r.crs_auth_id == "Unknown"]
                )
            )

        # 3. Band Count & Data Type Consistency
        band_counts = {r.band_count for r in readable_rasters}
        common_band_count = readable_rasters[0].band_count if len(band_counts) == 1 else None
        if len(band_counts) > 1:
            issues.append(
                DiagnosticIssue(
                    "ERROR",
                    "Mismatched Band Counts",
                    f"Inputs have varying band counts: {band_counts}. All inputs must share the same band structure.",
                    [r.filename for r in readable_rasters]
                )
            )

        data_types = {r.data_type_name for r in readable_rasters}
        common_data_type = readable_rasters[0].data_type_name if len(data_types) == 1 else None
        if len(data_types) > 1:
            issues.append(
                DiagnosticIssue(
                    "WARNING",
                    "Mixed Pixel Data Types",
                    f"Inputs use different data types ({', '.join(data_types)}). Higher precision type will be cast.",
                    [r.filename for r in readable_rasters]
                )
            )

        # 4. Pixel Size & Grid Alignment
        resolutions = {(round(r.pixel_size_x, 6), round(r.pixel_size_y, 6)) for r in readable_rasters}
        common_pixel_size = [readable_rasters[0].pixel_size_x, readable_rasters[0].pixel_size_y] if len(resolutions) == 1 else None
        if len(resolutions) > 1:
            issues.append(
                DiagnosticIssue(
                    "WARNING",
                    "Varying Pixel Resolutions",
                    f"Inputs have different pixel sizes. Resampling to reference grid is recommended.",
                    [r.filename for r in readable_rasters]
                )
            )

        # Check grid offset alignment (origin % pixel_size)
        base_r = readable_rasters[0]
        misaligned = []
        for r in readable_rasters[1:]:
            dx = abs((r.origin_x - base_r.origin_x) % base_r.pixel_size_x)
            dy = abs((r.origin_y - base_r.origin_y) % base_r.pixel_size_y)
            # Tolerance 1e-4
            if (dx > 1e-4 and abs(dx - base_r.pixel_size_x) > 1e-4) or (dy > 1e-4 and abs(dy - base_r.pixel_size_y) > 1e-4):
                misaligned.append(r.filename)

        if misaligned:
            issues.append(
                DiagnosticIssue(
                    "INFO",
                    "Sub-pixel Grid Misalignment",
                    f"{len(misaligned)} raster(s) are not snapped to the exact grid of the primary reference image.",
                    misaligned
                )
            )

        # 5. Unified Extent
        min_x = min(r.extent[0] for r in readable_rasters)
        min_y = min(r.extent[1] for r in readable_rasters)
        max_x = max(r.extent[2] for r in readable_rasters)
        max_y = max(r.extent[3] for r in readable_rasters)
        unified_extent = [min_x, min_y, max_x, max_y]

        # 6. Memory / Space Estimation
        total_pixels = sum(r.width * r.height * r.band_count for r in readable_rasters)
        # Approximate 4 bytes per pixel on average
        estimated_uncompressed = total_pixels * 4

        # Is compatible for quick VRT mosaic? (Same CRS, same bands, no blocking errors)
        has_blocking_errors = any(i.severity == "ERROR" for i in issues)
        is_quick_compat = not has_blocking_errors and len(crs_set) == 1

        return InspectionReport(
            raster_count=len(rasters),
            rasters=rasters,
            issues=issues,
            common_crs=common_crs,
            common_band_count=common_band_count,
            common_data_type=common_data_type,
            common_pixel_size=common_pixel_size,
            unified_extent=unified_extent,
            is_compatible_for_quick_mosaic=is_quick_compat,
            total_uncompressed_size_bytes=estimated_uncompressed
        )

"""
Grid alignment and coordinate snapping utilities for Aries Mosaic & GapFill.
"""

import math
from dataclasses import dataclass
from typing import List, Tuple

@dataclass
class TargetGrid:
    """Target raster grid definition for unified alignment."""
    crs_wkt: str
    pixel_size_x: float
    pixel_size_y: float
    min_x: float
    min_y: float
    max_x: float
    max_y: float
    cols: int
    rows: int

    @property
    def geotransform(self) -> List[float]:
        return [self.min_x, self.pixel_size_x, 0.0, self.max_y, 0.0, -abs(self.pixel_size_y)]

    @property
    def extent(self) -> List[float]:
        return [self.min_x, self.min_y, self.max_x, self.max_y]


def calculate_aligned_grid(
    extents: List[List[float]],
    pixel_size_x: float,
    pixel_size_y: float,
    snap_origin_x: float = 0.0,
    snap_origin_y: float = 0.0,
    crs_wkt: str = ""
) -> TargetGrid:
    """Compute an aligned union grid whose bounding box is snapped to pixel dimensions."""
    min_x = min(e[0] for e in extents)
    min_y = min(e[1] for e in extents)
    max_x = max(e[2] for e in extents)
    max_y = max(e[3] for e in extents)

    # Snap bounds outward
    snapped_min_x = snap_origin_x + math.floor((min_x - snap_origin_x) / pixel_size_x) * pixel_size_x
    snapped_max_x = snap_origin_x + math.ceil((max_x - snap_origin_x) / pixel_size_x) * pixel_size_x

    snapped_min_y = snap_origin_y + math.floor((min_y - snap_origin_y) / pixel_size_y) * pixel_size_y
    snapped_max_y = snap_origin_y + math.ceil((max_y - snap_origin_y) / pixel_size_y) * pixel_size_y

    cols = int(round((snapped_max_x - snapped_min_x) / pixel_size_x))
    rows = int(round((snapped_max_y - snapped_min_y) / pixel_size_y))

    return TargetGrid(
        crs_wkt=crs_wkt,
        pixel_size_x=pixel_size_x,
        pixel_size_y=pixel_size_y,
        min_x=snapped_min_x,
        min_y=snapped_min_y,
        max_x=snapped_max_x,
        max_y=snapped_max_y,
        cols=max(1, cols),
        rows=max(1, rows),
    )

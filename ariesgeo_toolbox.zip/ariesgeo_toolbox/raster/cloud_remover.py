"""
Cloud, Cloud Shadow, and Combined SLC-Off Detection and Removal Engine for AriesGeo Toolbox.
Integrates the USGS / ENVI `landsat_gapfill` Local Linear Histogram Matching (LLHM),
Global Histogram Matching (GLHM), Multi-Donor Smart Compositing, Automated Grid Co-Registration,
and Single-File Delaunay Triangulation / Spatial Inpainting.
"""

import os
import tempfile
from typing import List, Optional, Callable, Dict, Any, Tuple
import numpy as np
from osgeo import gdal

from ..core.exceptions import GapFillError, RasterInspectionError
from ..core.logging import log_warning
from ..gapfill.landsat_gapfill_core import (
    align_raster_to_reference,
    detect_spectral_cloud_and_shadow_mask,
    decode_landsat_qa_pixel,
    decode_sentinel_scl,
    usgs_llhm_fill_band,
    usgs_glhm_fill_band,
    clamp_and_cast,
)
from ..gapfill.triangulation import TriangulationGapFiller
from ..gapfill.engine import AriesGapFillEngine


class CloudRemover:
    """
    Detects and removes clouds, cast cloud shadows, and optional SLC-off scan-line gaps
    using USGS `landsat_gapfill` multi-temporal LLHM/GLHM donor recovery or single-scene
    Delaunay triangulation / edge IDW inpainting.
    """

    @classmethod
    def detect_cloud_mask_array(
        cls,
        rgb_arr: np.ndarray,
        brightness_threshold: float = 0.65,
        whiteness_tolerance: float = 0.28,
        dilation_radius: int = 2,
        detect_shadows: bool = False,
        nodata_val: Optional[float] = None,
    ) -> np.ndarray:
        """
        Detect cloud (and optionally shadow) pixels from an RGB / multi-band array.
        Handles uint8, uint16 (Landsat C2 / Sentinel-2), and float32 reflectance cleanly.
        Returns boolean 2D array where True = Cloud (/ Shadow).
        """
        cloud_mask, shadow_mask = detect_spectral_cloud_and_shadow_mask(
            bands_arr=rgb_arr,
            nodata_val=nodata_val,
            brightness_threshold=brightness_threshold,
            whiteness_tolerance=whiteness_tolerance,
            detect_shadows=detect_shadows,
            dilation_radius=dilation_radius,
        )
        return (cloud_mask | shadow_mask) if detect_shadows else cloud_mask

    @classmethod
    def build_target_mask(
        cls,
        ds: gdal.Dataset,
        brightness_threshold: float = 0.65,
        detect_shadows: bool = True,
        include_slc_gaps: bool = False,
        dilation_radius: int = 2,
        mask_mode: str = "spectral",
        external_mask_path: Optional[str] = None,
        qa_band_index: Optional[int] = None,
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        Build (combined_invalid_mask, cloud_only_mask, shadow_or_slc_mask) on `ds`.

        mask_mode options:
            - "spectral": Automatic multi-spectral Cloud + Shadow detector
            - "slc_and_clouds": Automatic SLC-off scan-line gaps + Clouds + Shadows
            - "landsat_qa": Decode Landsat Collection 2 QA_PIXEL bitmask
            - "sentinel_scl": Decode Sentinel-2 L2A SCL classification band
            - "custom_mask": External binary mask raster (>0 = invalid/cloud)
        """
        cols = ds.RasterXSize
        rows = ds.RasterYSize
        band_count = ds.RasterCount
        nd_val = ds.GetRasterBand(1).GetNoDataValue()

        cloud_mask = np.zeros((rows, cols), dtype=bool)
        extra_mask = np.zeros((rows, cols), dtype=bool)

        if mask_mode == "custom_mask" and external_mask_path and os.path.exists(external_mask_path):
            m_ds = align_raster_to_reference(external_mask_path, ds, resample_alg=gdal.GRA_NearestNeighbour)
            cloud_mask = m_ds.GetRasterBand(1).ReadAsArray() > 0
            m_ds = None
        elif mask_mode == "landsat_qa":
            if external_mask_path and os.path.exists(external_mask_path):
                qa_ds = align_raster_to_reference(external_mask_path, ds, resample_alg=gdal.GRA_NearestNeighbour)
                qa_arr = qa_ds.GetRasterBand(1).ReadAsArray()
                qa_ds = None
            else:
                idx = qa_band_index if (qa_band_index and 1 <= qa_band_index <= band_count) else band_count
                qa_arr = ds.GetRasterBand(idx).ReadAsArray()
            cloud_mask = decode_landsat_qa_pixel(qa_arr, mask_cloud=True, mask_shadow=False)
            if detect_shadows:
                extra_mask = (qa_arr.astype(np.uint32) & (1 << 4)) != 0
        elif mask_mode == "sentinel_scl":
            if external_mask_path and os.path.exists(external_mask_path):
                scl_ds = align_raster_to_reference(external_mask_path, ds, resample_alg=gdal.GRA_NearestNeighbour)
                scl_arr = scl_ds.GetRasterBand(1).ReadAsArray()
                scl_ds = None
            else:
                idx = qa_band_index if (qa_band_index and 1 <= qa_band_index <= band_count) else band_count
                scl_arr = ds.GetRasterBand(idx).ReadAsArray()
            cloud_mask = decode_sentinel_scl(scl_arr, mask_shadow=False)
            if detect_shadows:
                extra_mask = scl_arr == 3
        else:
            b_to_read = min(4, band_count)
            stacked = np.array([ds.GetRasterBand(i).ReadAsArray() for i in range(1, b_to_read + 1)])
            cloud_mask, shadow_mask = detect_spectral_cloud_and_shadow_mask(
                bands_arr=stacked,
                nodata_val=nd_val,
                brightness_threshold=brightness_threshold,
                detect_shadows=detect_shadows,
                dilation_radius=dilation_radius,
            )
            extra_mask |= shadow_mask

        if include_slc_gaps or mask_mode == "slc_and_clouds":
            b1 = ds.GetRasterBand(1).ReadAsArray().astype(np.float32)
            if nd_val is not None and not np.isnan(nd_val):
                raw_gap = (b1 == nd_val) | (b1 == 0) | np.isnan(b1)
            else:
                raw_gap = (b1 == 0) | np.isnan(b1)
            slc_internal, _ = AriesGapFillEngine.isolate_internal_gaps(
                valid_mask=~raw_gap,
                raw_gap_mask=raw_gap,
                max_gap_distance=60,
            )
            extra_mask |= slc_internal

        combined = cloud_mask | extra_mask
        return combined, cloud_mask, extra_mask

    @classmethod
    def generate_cloud_mask_raster(
        cls,
        input_raster_path: str,
        output_mask_path: str,
        brightness_threshold: float = 0.65,
        qa_band_index: Optional[int] = None,
        qa_cloud_values: Optional[List[int]] = None,
        dilation_radius: int = 2,
        detect_shadows: bool = True,
        mask_mode: str = "spectral",
        external_mask_path: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Generate a classified cloud/shadow mask GeoTIFF:
        0 = Clear, 1 = Cloud, 2 = Cloud Shadow / SLC-off Gap.
        """
        ds = gdal.Open(input_raster_path, gdal.GA_ReadOnly)
        if not ds:
            raise RasterInspectionError(f"Cannot open raster: {input_raster_path}")

        cols = ds.RasterXSize
        rows = ds.RasterYSize
        band_count = ds.RasterCount
        gt = ds.GetGeoTransform()
        proj = ds.GetProjection()

        if qa_band_index and 1 <= qa_band_index <= band_count and mask_mode == "spectral":
            qa_arr = ds.GetRasterBand(qa_band_index).ReadAsArray()
            cloud_vals = qa_cloud_values or [3, 8, 9, 10]
            cloud_mask = np.isin(qa_arr, cloud_vals)
            extra_mask = np.zeros((rows, cols), dtype=bool)
            combined = cloud_mask
        else:
            combined, cloud_mask, extra_mask = cls.build_target_mask(
                ds=ds,
                brightness_threshold=brightness_threshold,
                detect_shadows=detect_shadows,
                include_slc_gaps=(mask_mode == "slc_and_clouds"),
                dilation_radius=dilation_radius,
                mask_mode=mask_mode,
                external_mask_path=external_mask_path,
                qa_band_index=qa_band_index,
            )

        classified = np.zeros((rows, cols), dtype=np.uint8)
        classified[extra_mask] = 2
        classified[cloud_mask] = 1

        os.makedirs(os.path.dirname(os.path.abspath(output_mask_path)), exist_ok=True)
        driver = gdal.GetDriverByName("GTiff")
        out_ds = driver.Create(
            output_mask_path,
            cols,
            rows,
            1,
            gdal.GDT_Byte,
            ["COMPRESS=DEFLATE", "TILED=YES"],
        )
        out_ds.SetGeoTransform(gt)
        if proj:
            out_ds.SetProjection(proj)
        out_band = out_ds.GetRasterBand(1)
        out_band.SetNoDataValue(255)
        out_band.WriteArray(classified)
        out_band.FlushCache()

        out_ds = None
        ds = None

        total_px = cols * rows
        cloud_px = int(np.sum(cloud_mask))
        shadow_px = int(np.sum(extra_mask & ~cloud_mask))
        masked_px = int(np.sum(combined))
        return {
            "mask_path": output_mask_path,
            "total_pixels": total_px,
            "cloud_pixels": cloud_px,
            "shadow_or_gap_pixels": shadow_px,
            "masked_pixels": masked_px,
            "cloud_coverage_percent": round((masked_px / max(1, total_px)) * 100.0, 2),
        }

    @classmethod
    def remove_clouds_multitemporal(
        cls,
        target_scene_path: str,
        donor_scene_paths: List[str],
        output_raster_path: str,
        output_mask_path: Optional[str] = None,
        brightness_threshold: float = 0.65,
        apply_radiometry: bool = True,
        radiometry_method: str = "llhm",
        harmonization_method: Optional[str] = None,
        detect_shadows: bool = True,
        include_slc_gaps: bool = False,
        dilation_radius: int = 2,
        mask_mode: str = "spectral",
        external_mask_path: Optional[str] = None,
        window_size: int = 33,
        seam_feather_width: int = 2,
        fill_residual_holes: bool = True,
        progress_callback: Optional[Callable[[float, str], None]] = None,
    ) -> Dict[str, Any]:
        """
        Multi-temporal cloud, shadow, & SLC-off removal powered by USGS `landsat_gapfill`
        Local Linear Histogram Matching (LLHM) / Global Histogram Matching (GLHM).

        Automatically co-registers donor scenes to the target pixel grid, masks clouds &
        gaps in donor scenes, tracks remaining unrecovered pixels across multiple donors,
        and optionally fills residual holes via Delaunay triangulation.
        """
        if harmonization_method:
            radiometry_method = harmonization_method
        if not os.path.exists(target_scene_path):
            raise GapFillError(f"Target scene not found: {target_scene_path}")
        if not donor_scene_paths:
            raise GapFillError("At least one clear donor scene is required for multi-temporal cloud removal.")

        target_ds = gdal.Open(target_scene_path, gdal.GA_ReadOnly)
        if not target_ds:
            raise GapFillError(f"Cannot open target raster: {target_scene_path}")

        cols = target_ds.RasterXSize
        rows = target_ds.RasterYSize
        band_count = target_ds.RasterCount
        gt = target_ds.GetGeoTransform()
        proj = target_ds.GetProjection()
        native_dtype = target_ds.GetRasterBand(1).DataType
        target_nd = target_ds.GetRasterBand(1).GetNoDataValue()

        if progress_callback:
            progress_callback(8.0, "Detecting clouds, shadows, and scan-line gaps on target scene...")

        # 1. Detect Target Cloud + Shadow (+ optional SLC-off) Mask
        combined_mask, cloud_only, shadow_or_slc = cls.build_target_mask(
            ds=target_ds,
            brightness_threshold=brightness_threshold,
            detect_shadows=detect_shadows,
            include_slc_gaps=include_slc_gaps,
            dilation_radius=dilation_radius,
            mask_mode=mask_mode,
            external_mask_path=external_mask_path,
        )

        # Preserve outer background NoData footprint
        b1_raw = target_ds.GetRasterBand(1).ReadAsArray().astype(np.float32)
        if target_nd is not None and not np.isnan(target_nd):
            bg_raw = (b1_raw == target_nd) | np.isnan(b1_raw)
        else:
            bg_raw = np.isnan(b1_raw)
        _, exterior_nodata = AriesGapFillEngine.isolate_internal_gaps(
            valid_mask=~bg_raw,
            raw_gap_mask=bg_raw,
            max_gap_distance=60,
        )
        combined_mask = combined_mask & ~exterior_nodata

        total_pixels = cols * rows
        cloud_pixels = int(np.sum(combined_mask))
        cloud_percent = (cloud_pixels / max(1, total_pixels)) * 100.0

        # Optional output mask GeoTIFF (1 = Cloud, 2 = Shadow/SLC Gap, 0 = Clear)
        if output_mask_path:
            os.makedirs(os.path.dirname(os.path.abspath(output_mask_path)), exist_ok=True)
            m_driver = gdal.GetDriverByName("GTiff")
            m_ds = m_driver.Create(output_mask_path, cols, rows, 1, gdal.GDT_Byte, ["COMPRESS=DEFLATE", "TILED=YES"])
            m_ds.SetGeoTransform(gt)
            if proj:
                m_ds.SetProjection(proj)
            cls_arr = np.zeros((rows, cols), dtype=np.uint8)
            cls_arr[shadow_or_slc & ~exterior_nodata] = 2
            cls_arr[cloud_only & ~exterior_nodata] = 1
            m_band = m_ds.GetRasterBand(1)
            m_band.WriteArray(cls_arr)
            m_band.FlushCache()
            m_ds = None

        # 2. Open, Co-Register (Warp if needed), and Cloud-Screen Donor Datasets
        donor_ds_list: List[gdal.Dataset] = []
        donor_invalid_masks: List[np.ndarray] = []

        for idx, p in enumerate(donor_scene_paths):
            if not os.path.exists(p):
                continue
            if progress_callback:
                progress_callback(12.0 + idx * 3.0, f"Aligning & screening donor scene {idx + 1}/{len(donor_scene_paths)}...")
            d_ds = align_raster_to_reference(p, target_ds, resample_alg=gdal.GRA_Bilinear)
            d_nd = d_ds.GetRasterBand(1).GetNoDataValue()
            d_b_cnt = min(4, d_ds.RasterCount)
            d_stack = np.array([d_ds.GetRasterBand(i).ReadAsArray() for i in range(1, d_b_cnt + 1)])
            d_c, d_s = detect_spectral_cloud_and_shadow_mask(
                bands_arr=d_stack,
                nodata_val=d_nd,
                brightness_threshold=max(0.68, brightness_threshold),
                detect_shadows=detect_shadows,
                dilation_radius=1,
            )
            d_inv = d_c | d_s
            # Safety guard: if donor is clear uniform synthetic/homogeneous data, don't over-flag >80%
            if np.mean(d_inv) > 0.80:
                d_inv = np.zeros((rows, cols), dtype=bool)
            donor_ds_list.append(d_ds)
            donor_invalid_masks.append(d_inv)

        if not donor_ds_list:
            target_ds = None
            raise GapFillError("No readable donor scenes were provided.")

        # 3. Create Cloud-Free Output GeoTIFF (preserving native datatype)
        os.makedirs(os.path.dirname(os.path.abspath(output_raster_path)), exist_ok=True)
        driver = gdal.GetDriverByName("GTiff")
        create_opts = ["COMPRESS=DEFLATE", "TILED=YES"]
        if native_dtype in (gdal.GDT_Byte, gdal.GDT_UInt16, gdal.GDT_Int16):
            create_opts.append("PREDICTOR=2")

        out_ds = driver.Create(output_raster_path, cols, rows, band_count, native_dtype, create_opts)
        if not out_ds:
            target_ds = None
            raise GapFillError(f"Cannot create output GeoTIFF: {output_raster_path}")
        out_ds.SetGeoTransform(gt)
        if proj:
            out_ds.SetProjection(proj)

        recovered_pixels_b1 = 0
        unrecovered_pixels_b1 = 0
        band_equations: List[str] = []

        for b_idx in range(1, band_count + 1):
            if progress_callback:
                pct = 20.0 + (b_idx / (band_count + 1)) * 75.0
                progress_callback(pct, f"Restoring Band {b_idx}/{band_count} via {radiometry_method.upper()}...")

            t_band = target_ds.GetRasterBand(b_idx)
            nodata_val = t_band.GetNoDataValue()
            t_arr = t_band.ReadAsArray().astype(np.float32)

            if cloud_pixels == 0:
                cast_arr = clamp_and_cast(t_arr, native_dtype, nodata_val=nodata_val, nodata_mask=exterior_nodata)
                out_b = out_ds.GetRasterBand(b_idx)
                if nodata_val is not None:
                    out_b.SetNoDataValue(nodata_val)
                out_b.WriteArray(cast_arr)
                out_b.FlushCache()
                continue

            work_arr = t_arr.copy()
            remaining_band_mask = combined_mask.copy()

            # Sequentially fill remaining cloud/gap pixels across donor scenes
            for d_idx, (donor_ds, d_inv_mask) in enumerate(zip(donor_ds_list, donor_invalid_masks)):
                if not np.any(remaining_band_mask):
                    break

                d_band = donor_ds.GetRasterBand(min(b_idx, donor_ds.RasterCount))
                d_nd = d_band.GetNoDataValue()
                d_arr = d_band.ReadAsArray().astype(np.float32)

                if not apply_radiometry or radiometry_method.lower() == "none":
                    d_valid = ~np.isnan(d_arr) & ~d_inv_mask
                    if d_nd is not None and not np.isnan(d_nd):
                        d_valid &= (d_arr != d_nd)
                    else:
                        d_valid &= (d_arr != 0)
                    can_fill = remaining_band_mask & d_valid
                    if np.any(can_fill):
                        work_arr[can_fill] = d_arr[can_fill]
                        remaining_band_mask[can_fill] = False
                    if d_idx == 0:
                        band_equations.append(f"Band {b_idx}: Direct Donor Composite")
                elif radiometry_method.lower() == "glhm":
                    f_arr, prov, _, st = usgs_glhm_fill_band(
                        target_band=work_arr,
                        target_gap_mask=remaining_band_mask,
                        donor_band=d_arr,
                        donor_invalid_mask=d_inv_mask,
                        target_nodata=nodata_val,
                        donor_nodata=d_nd,
                        donor_id=d_idx + 2,
                    )
                    filled_now = remaining_band_mask & (prov > 0)
                    if np.any(filled_now):
                        work_arr[filled_now] = f_arr[filled_now]
                        remaining_band_mask[filled_now] = False
                    if d_idx == 0:
                        band_equations.append(f"Band {b_idx}: GLHM Gain={st['slope']:.3f}, Bias={st['intercept']:.2f}")
                else:
                    # Default: USGS `landsat_gapfill` Local Linear Histogram Matching (LLHM)
                    f_arr, prov, _, st = usgs_llhm_fill_band(
                        target_band=work_arr,
                        target_gap_mask=remaining_band_mask,
                        donor_band=d_arr,
                        donor_invalid_mask=d_inv_mask,
                        target_nodata=nodata_val,
                        donor_nodata=d_nd,
                        min_window_size=window_size,
                        max_window_size=max(257, window_size * 4 + 1),
                        seam_feather_width=seam_feather_width,
                        donor_id=d_idx + 2,
                    )
                    filled_now = remaining_band_mask & (prov > 0)
                    if np.any(filled_now):
                        work_arr[filled_now] = f_arr[filled_now]
                        remaining_band_mask[filled_now] = False
                    if d_idx == 0:
                        band_equations.append(
                            f"Band {b_idx}: LLHM ({st['local_fill_percentage']}% local, Gain={st['slope']:.3f}, Bias={st['intercept']:.2f})"
                        )

            # Residual single-scene Delaunay triangulation fallback if small cloud holes remain
            if fill_residual_holes and np.any(remaining_band_mask):
                tri_arr, tri_p, _ = TriangulationGapFiller.fill_band(
                    band_array=work_arr,
                    gap_mask=remaining_band_mask,
                    max_gap_distance=150,
                    support_sampling=2,
                    enable_nearest_fallback=True,
                )
                tri_filled = remaining_band_mask & (tri_p > 0)
                if np.any(tri_filled):
                    work_arr[tri_filled] = tri_arr[tri_filled]
                    remaining_band_mask[tri_filled] = False

            if b_idx == 1:
                unrecovered_pixels_b1 = int(np.sum(remaining_band_mask))
                recovered_pixels_b1 = cloud_pixels - unrecovered_pixels_b1

            cast_arr = clamp_and_cast(work_arr, native_dtype, nodata_val=nodata_val, nodata_mask=exterior_nodata)
            out_band = out_ds.GetRasterBand(b_idx)
            if nodata_val is not None:
                out_band.SetNoDataValue(nodata_val)
            out_band.WriteArray(cast_arr)
            out_band.FlushCache()

        out_ds.FlushCache()
        out_ds = None
        target_ds = None
        for d in donor_ds_list:
            d = None

        if progress_callback:
            progress_callback(100.0, "Multi-temporal cloud & gap recovery complete.")

        recovery_pct = (recovered_pixels_b1 / max(1, cloud_pixels)) * 100.0 if cloud_pixels > 0 else 100.0
        return {
            "total_pixels": total_pixels,
            "cloud_pixels": cloud_pixels,
            "recovered_pixels": recovered_pixels_b1,
            "filled_pixels": recovered_pixels_b1,
            "unrecovered_pixels": unrecovered_pixels_b1,
            "remaining_pixels": unrecovered_pixels_b1,
            "recovery_rate_percent": round(recovery_pct, 2),
            "cloud_coverage_percent": round(cloud_percent, 2),
            "donors_used": len(donor_ds_list),
            "radiometry_applied": apply_radiometry,
            "radiometry_method": radiometry_method if apply_radiometry else "none",
            "band_models": band_equations,
            "status": "success",
        }

    @classmethod
    def remove_clouds_spatial(
        cls,
        input_raster_path: str,
        output_raster_path: str,
        brightness_threshold: float = 0.65,
        max_search_distance: int = 150,
        method: str = "triangulation",
        detect_shadows: bool = True,
        include_slc_gaps: bool = False,
        dilation_radius: int = 2,
        mask_mode: str = "spectral",
        external_mask_path: Optional[str] = None,
        output_mask_path: Optional[str] = None,
        progress_callback: Optional[Callable[[float, str], None]] = None,
    ) -> Dict[str, Any]:
        """
        Single-scene cloud, shadow, & SLC-off gap removal without donor imagery.
        Supports:
          - `method="triangulation"`: ENVI `landsat_gapfill` Single-File Delaunay Triangulation
          - `method="idw"`: GDAL Multi-Scale Edge Inverse-Distance Inpainting (`FillNodata`)
        """
        if not os.path.exists(input_raster_path):
            raise GapFillError(f"Input raster not found: {input_raster_path}")

        ds = gdal.Open(input_raster_path, gdal.GA_ReadOnly)
        if not ds:
            raise GapFillError(f"Cannot open input raster: {input_raster_path}")

        cols = ds.RasterXSize
        rows = ds.RasterYSize
        band_count = ds.RasterCount
        gt = ds.GetGeoTransform()
        proj = ds.GetProjection()
        native_dtype = ds.GetRasterBand(1).DataType
        orig_nd = ds.GetRasterBand(1).GetNoDataValue()

        if progress_callback:
            progress_callback(10.0, "Detecting clouds, shadows, and internal gaps...")

        combined_mask, cloud_only, shadow_or_slc = cls.build_target_mask(
            ds=ds,
            brightness_threshold=brightness_threshold,
            detect_shadows=detect_shadows,
            include_slc_gaps=include_slc_gaps,
            dilation_radius=dilation_radius,
            mask_mode=mask_mode,
            external_mask_path=external_mask_path,
        )

        # Preserve outer background NoData footprint
        b1_raw = ds.GetRasterBand(1).ReadAsArray().astype(np.float32)
        if orig_nd is not None and not np.isnan(orig_nd):
            bg_raw = (b1_raw == orig_nd) | np.isnan(b1_raw)
        else:
            bg_raw = np.isnan(b1_raw)
        _, exterior_nodata = AriesGapFillEngine.isolate_internal_gaps(
            valid_mask=~bg_raw,
            raw_gap_mask=bg_raw,
            max_gap_distance=max_search_distance,
        )
        combined_mask = combined_mask & ~exterior_nodata

        cloud_pixels = int(np.sum(combined_mask))
        cloud_percent = (cloud_pixels / max(1, cols * rows)) * 100.0

        if output_mask_path:
            os.makedirs(os.path.dirname(os.path.abspath(output_mask_path)), exist_ok=True)
            m_drv = gdal.GetDriverByName("GTiff")
            m_ds = m_drv.Create(output_mask_path, cols, rows, 1, gdal.GDT_Byte, ["COMPRESS=DEFLATE", "TILED=YES"])
            m_ds.SetGeoTransform(gt)
            if proj:
                m_ds.SetProjection(proj)
            cls_arr = np.zeros((rows, cols), dtype=np.uint8)
            cls_arr[shadow_or_slc & ~exterior_nodata] = 2
            cls_arr[cloud_only & ~exterior_nodata] = 1
            m_ds.GetRasterBand(1).WriteArray(cls_arr)
            m_ds.FlushCache()
            m_ds = None

        os.makedirs(os.path.dirname(os.path.abspath(output_raster_path)), exist_ok=True)
        driver = gdal.GetDriverByName("GTiff")
        create_opts = ["COMPRESS=DEFLATE", "TILED=YES"]
        if native_dtype in (gdal.GDT_Byte, gdal.GDT_UInt16, gdal.GDT_Int16):
            create_opts.append("PREDICTOR=2")

        if method.lower() == "triangulation":
            # ENVI `landsat_gapfill` Single-File Delaunay Triangulation
            out_ds = driver.Create(output_raster_path, cols, rows, band_count, native_dtype, create_opts)
            out_ds.SetGeoTransform(gt)
            if proj:
                out_ds.SetProjection(proj)

            filled_px_b1 = 0
            for b_idx in range(1, band_count + 1):
                if progress_callback:
                    pct = 15.0 + (b_idx / (band_count + 1)) * 80.0
                    progress_callback(pct, f"Triangulating Band {b_idx}/{band_count}...")

                b = ds.GetRasterBand(b_idx)
                b_nd = b.GetNoDataValue()
                arr = b.ReadAsArray().astype(np.float32)

                if cloud_pixels > 0:
                    f_arr, prov, _ = TriangulationGapFiller.fill_band(
                        band_array=arr,
                        gap_mask=combined_mask,
                        max_gap_distance=max_search_distance,
                        support_sampling=2 if cloud_pixels > 10000 else 1,
                        enable_nearest_fallback=True,
                    )
                    if b_idx == 1:
                        filled_px_b1 = int(np.sum(combined_mask & (prov > 0)))
                else:
                    f_arr = arr

                cast_arr = clamp_and_cast(f_arr, native_dtype, nodata_val=b_nd, nodata_mask=exterior_nodata)
                out_b = out_ds.GetRasterBand(b_idx)
                if b_nd is not None:
                    out_b.SetNoDataValue(b_nd)
                out_b.WriteArray(cast_arr)
                out_b.FlushCache()

            out_ds.FlushCache()
            out_ds = None
            ds = None
        else:
            # GDAL FillNodata Edge IDW Inpainting using an explicit memory validity mask
            # (never overwrites valid 0 values or exterior background borders!)
            out_ds = driver.Create(output_raster_path, cols, rows, band_count, native_dtype, create_opts)
            out_ds.SetGeoTransform(gt)
            if proj:
                out_ds.SetProjection(proj)

            mem_drv = gdal.GetDriverByName("MEM")
            mask_ds = mem_drv.Create("", cols, rows, 1, gdal.GDT_Byte)
            # 255 = valid support pixel, 0 = cloud/gap pixel to interpolate
            valid_support = (~combined_mask & ~exterior_nodata).astype(np.uint8) * 255
            mask_band = mask_ds.GetRasterBand(1)
            mask_band.WriteArray(valid_support)

            for b_idx in range(1, band_count + 1):
                if progress_callback:
                    pct = 15.0 + (b_idx / (band_count + 1)) * 80.0
                    progress_callback(pct, f"Inpainting Band {b_idx}/{band_count} via Edge IDW...")

                b = ds.GetRasterBand(b_idx)
                b_nd = b.GetNoDataValue()
                arr = b.ReadAsArray().astype(np.float32)

                work_ds = mem_drv.Create("", cols, rows, 1, gdal.GDT_Float32)
                work_band = work_ds.GetRasterBand(1)
                work_band.WriteArray(arr)

                if cloud_pixels > 0:
                    gdal.FillNodata(
                        targetBand=work_band,
                        maskBand=mask_band,
                        maxSearchDist=max_search_distance,
                        smoothingIterations=1,
                    )

                filled_float = work_band.ReadAsArray()
                # Keep original valid pixels untouched; only update combined_mask
                result_float = arr.copy()
                result_float[combined_mask] = filled_float[combined_mask]

                cast_arr = clamp_and_cast(result_float, native_dtype, nodata_val=b_nd, nodata_mask=exterior_nodata)
                out_b = out_ds.GetRasterBand(b_idx)
                if b_nd is not None:
                    out_b.SetNoDataValue(b_nd)
                out_b.WriteArray(cast_arr)
                out_b.FlushCache()
                work_ds = None

            filled_px_b1 = cloud_pixels
            mask_ds = None
            out_ds.FlushCache()
            out_ds = None
            ds = None

        if progress_callback:
            progress_callback(100.0, "Single-scene cloud inpainting complete.")

        return {
            "total_pixels": cols * rows,
            "cloud_pixels": cloud_pixels,
            "recovered_pixels": filled_px_b1,
            "filled_pixels": filled_px_b1,
            "cloud_coverage_percent": round(cloud_percent, 2),
            "max_search_distance": max_search_distance,
            "method": method,
            "status": "success",
        }

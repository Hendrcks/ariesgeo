"""
Cloud and Shadow Detection and Removal Engine for AriesGeo Toolbox.
"""

import os
import shutil
from typing import List, Optional, Callable, Dict, Any, Tuple
import numpy as np
from osgeo import gdal, osr
from ..core.exceptions import GapFillError, RasterInspectionError
from .radiometry import RadiometricHarmonizer

class CloudRemover:
    """Detects and removes cloud and shadow effects using multi-temporal compositing or spatial inpainting."""

    @classmethod
    def detect_cloud_mask_array(
        cls,
        rgb_arr: np.ndarray,
        brightness_threshold: float = 0.65,
        whiteness_tolerance: float = 0.25,
        dilation_radius: int = 2
    ) -> np.ndarray:
        """
        Detect cloud pixels from RGB/multi-band array.
        Clouds exhibit high brightness across visible bands and low spectral color difference (high whiteness).
        rgb_arr: shape (bands, rows, cols) or (rows, cols)
        Returns boolean 2D array where True = Cloud / Invalid.
        """
        if rgb_arr.ndim == 2:
            max_val = np.nanmax(rgb_arr) or 1.0
            norm = rgb_arr / max_val
            mask = norm > brightness_threshold
        elif rgb_arr.ndim == 3:
            # Multi-band: calculate mean brightness and max color variance
            b_count = rgb_arr.shape[0]
            max_val = np.nanmax(rgb_arr) or 1.0
            norm_bands = [rgb_arr[i] / max_val for i in range(min(3, b_count))]

            mean_bright = np.mean(norm_bands, axis=0)
            color_var = np.max(norm_bands, axis=0) - np.min(norm_bands, axis=0)

            # Cloud = high brightness AND low color variance (white/gray)
            mask = (mean_bright > brightness_threshold) & (color_var < whiteness_tolerance)
        else:
            mask = np.zeros(rgb_arr.shape[-2:], dtype=bool)

        # Morphological dilation to cover cloud edges / halo
        if dilation_radius > 0 and np.any(mask):
            from scipy.ndimage import binary_dilation
            try:
                struct = np.ones((2 * dilation_radius + 1, 2 * dilation_radius + 1), dtype=bool)
                mask = binary_dilation(mask, structure=struct)
            except Exception as e:
                from ..core.logging import log_warning
                log_warning(f"Cloud mask dilation failed: {e}")

        return mask

    @classmethod
    def generate_cloud_mask_raster(
        cls,
        input_raster_path: str,
        output_mask_path: str,
        brightness_threshold: float = 0.65,
        qa_band_index: Optional[int] = None,
        qa_cloud_values: Optional[List[int]] = None,
        dilation_radius: int = 2
    ) -> str:
        """Generate a binary cloud mask raster (1 = Cloud/Shadow, 0 = Clear)."""
        ds = gdal.Open(input_raster_path, gdal.GA_ReadOnly)
        if not ds:
            raise RasterInspectionError(f"Cannot open raster: {input_raster_path}")

        cols = ds.RasterXSize
        rows = ds.RasterYSize
        band_count = ds.RasterCount
        gt = ds.GetGeoTransform()
        proj = ds.GetProjection()

        os.makedirs(os.path.dirname(os.path.abspath(output_mask_path)), exist_ok=True)
        driver = gdal.GetDriverByName("GTiff")
        out_ds = driver.Create(
            output_mask_path,
            cols,
            rows,
            1,
            gdal.GDT_Byte,
            ["COMPRESS=DEFLATE"]
        )
        out_ds.SetGeoTransform(gt)
        out_ds.SetProjection(proj)

        if qa_band_index and 1 <= qa_band_index <= band_count:
            qa_band = ds.GetRasterBand(qa_band_index)
            qa_arr = qa_band.ReadAsArray()
            cloud_vals = qa_cloud_values or [3, 8, 9, 10]  # Standard SCL cloud/shadow values
            cloud_mask = np.isin(qa_arr, cloud_vals)
        else:
            # Read first 3 bands for spectral detection
            bands_to_read = min(3, band_count)
            arrs = [ds.GetRasterBand(i).ReadAsArray() for i in range(1, bands_to_read + 1)]
            stacked = np.array(arrs)
            cloud_mask = cls.detect_cloud_mask_array(
                stacked,
                brightness_threshold=brightness_threshold,
                dilation_radius=dilation_radius
            )

        out_band = out_ds.GetRasterBand(1)
        out_band.WriteArray(cloud_mask.astype(np.uint8))
        out_band.FlushCache()

        out_ds = None
        ds = None
        return output_mask_path

    @classmethod
    def remove_clouds_multitemporal(
        cls,
        target_scene_path: str,
        donor_scene_paths: List[str],
        output_raster_path: str,
        output_mask_path: Optional[str] = None,
        brightness_threshold: float = 0.65,
        apply_radiometry: bool = True,
        progress_callback: Optional[Callable[[float, str], None]] = None
    ) -> Dict[str, Any]:
        """Multi-temporal cloud removal: replaces cloudy pixels in target scene with clear donor scene pixels."""
        if not os.path.exists(target_scene_path):
            raise GapFillError(f"Target scene not found: {target_scene_path}")
        if not donor_scene_paths:
            raise GapFillError("At least one clear donor scene is required for multi-temporal cloud removal.")

        target_ds = gdal.Open(target_scene_path, gdal.GA_ReadOnly)
        if not target_ds:
            raise GapFillError(f"Cannot open target raster: {target_scene_path}")

        cols = target_ds.RasterXSize
        rows = target_ds.RasterYSize
        band_count = target_ds.RasterCount
        gt = target_ds.GetGeoTransform()
        proj = target_ds.GetProjection()

        # Open donor datasets
        donor_ds_list = []
        for p in donor_scene_paths:
            d_ds = gdal.Open(p, gdal.GA_ReadOnly)
            if d_ds and d_ds.RasterXSize == cols and d_ds.RasterYSize == rows:
                donor_ds_list.append(d_ds)

        if not donor_ds_list:
            raise GapFillError("No donor scenes match the target image dimensions.")

        # 1. Detect Cloud Mask on Target Scene
        bands_to_read = min(3, band_count)
        arrs = [target_ds.GetRasterBand(i).ReadAsArray() for i in range(1, bands_to_read + 1)]
        stacked = np.array(arrs)
        cloud_mask = cls.detect_cloud_mask_array(stacked, brightness_threshold=brightness_threshold)

        total_pixels = cols * rows
        cloud_pixels = int(np.sum(cloud_mask))
        cloud_percent = (cloud_pixels / max(1, total_pixels)) * 100.0

        if output_mask_path:
            os.makedirs(os.path.dirname(os.path.abspath(output_mask_path)), exist_ok=True)
            m_driver = gdal.GetDriverByName("GTiff")
            m_ds = m_driver.Create(output_mask_path, cols, rows, 1, gdal.GDT_Byte, ["COMPRESS=DEFLATE"])
            m_ds.SetGeoTransform(gt)
            m_ds.SetProjection(proj)
            m_band = m_ds.GetRasterBand(1)
            m_band.WriteArray(cloud_mask.astype(np.uint8))
            m_band.FlushCache()
            m_ds = None

        # 2. Build Cloud-Free Output GeoTIFF
        os.makedirs(os.path.dirname(os.path.abspath(output_raster_path)), exist_ok=True)
        driver = gdal.GetDriverByName("GTiff")
        out_ds = driver.Create(
            output_raster_path,
            cols,
            rows,
            band_count,
            target_ds.GetRasterBand(1).DataType,
            ["COMPRESS=DEFLATE", "TILED=YES"]
        )
        out_ds.SetGeoTransform(gt)
        out_ds.SetProjection(proj)

        filled_pixels_total = 0
        remaining_cloud_mask = cloud_mask.copy()

        for b_idx in range(1, band_count + 1):
            if progress_callback:
                progress_callback(b_idx / (band_count + 1), f"Removing clouds in band {b_idx}...")

            t_band = target_ds.GetRasterBand(b_idx)
            nodata_val = t_band.GetNoDataValue()
            t_arr = t_band.ReadAsArray()
            out_arr = t_arr.copy()

            # Replace cloudy pixels using donor scenes
            for donor_ds in donor_ds_list:
                if not np.any(remaining_cloud_mask):
                    break

                d_band = donor_ds.GetRasterBand(min(b_idx, donor_ds.RasterCount))
                d_arr = d_band.ReadAsArray()

                # Radiometric linear regression in clear overlap
                gain, bias = 1.0, 0.0
                if apply_radiometry:
                    gain, bias, _ = RadiometricHarmonizer.calculate_linear_regression(
                        target_arr=t_arr,
                        donor_arr=d_arr,
                        target_nodata=nodata_val
                    )

                # Fill cloud pixels with adjusted donor pixels
                fillable = remaining_cloud_mask
                if np.any(fillable):
                    adjusted = (d_arr[fillable] * gain + bias).astype(t_arr.dtype)
                    out_arr[fillable] = adjusted

            out_band = out_ds.GetRasterBand(b_idx)
            if nodata_val is not None:
                out_band.SetNoDataValue(nodata_val)
            out_band.WriteArray(out_arr)
            out_band.FlushCache()

        out_ds = None
        target_ds = None
        for d in donor_ds_list:
            d = None

        return {
            "total_pixels": total_pixels,
            "cloud_pixels": cloud_pixels,
            "cloud_coverage_percent": round(cloud_percent, 2),
            "donors_used": len(donor_ds_list),
            "radiometry_applied": apply_radiometry,
            "status": "success"
        }

    @classmethod
    def remove_clouds_spatial(
        cls,
        input_raster_path: str,
        output_raster_path: str,
        brightness_threshold: float = 0.65,
        max_search_distance: int = 150,
        progress_callback: Optional[Callable[[float, str], None]] = None
    ) -> Dict[str, Any]:
        """Single-scene cloud removal using automatic cloud mask detection and spatial edge inpainting."""
        if not os.path.exists(input_raster_path):
            raise GapFillError(f"Input raster not found: {input_raster_path}")

        # Detect cloud mask and set cloud pixels to NoData on temporary copy, then interpolate
        temp_dir = os.path.dirname(os.path.abspath(output_raster_path))
        temp_masked_path = os.path.join(temp_dir, "_temp_cloud_masked.tif")

        ds = gdal.Open(input_raster_path, gdal.GA_ReadOnly)
        cols = ds.RasterXSize
        rows = ds.RasterYSize
        band_count = ds.RasterCount
        gt = ds.GetGeoTransform()
        proj = ds.GetProjection()

        # Detect cloud mask
        bands_to_read = min(3, band_count)
        arrs = [ds.GetRasterBand(i).ReadAsArray() for i in range(1, bands_to_read + 1)]
        stacked = np.array(arrs)
        cloud_mask = cls.detect_cloud_mask_array(stacked, brightness_threshold=brightness_threshold)
        cloud_pixels = int(np.sum(cloud_mask))
        cloud_percent = (cloud_pixels / max(1, cols * rows)) * 100.0

        # Create masked copy
        driver = gdal.GetDriverByName("GTiff")
        temp_ds = driver.Create(temp_masked_path, cols, rows, band_count, ds.GetRasterBand(1).DataType, ["COMPRESS=DEFLATE"])
        temp_ds.SetGeoTransform(gt)
        temp_ds.SetProjection(proj)

        for b_idx in range(1, band_count + 1):
            b = ds.GetRasterBand(b_idx)
            arr = b.ReadAsArray()
            arr[cloud_mask] = 0  # set cloud pixels to 0 / NoData
            tb = temp_ds.GetRasterBand(b_idx)
            tb.SetNoDataValue(0)
            tb.WriteArray(arr)
            tb.FlushCache()

        temp_ds = None
        ds = None

        # Run spatial interpolation
        from .gapfill import GapFiller
        GapFiller.fill_spatial_nodata(
            input_raster_path=temp_masked_path,
            output_raster_path=output_raster_path,
            max_search_distance=max_search_distance,
            progress_callback=progress_callback
        )

        # Cleanup temp file
        if os.path.exists(temp_masked_path):
            try:
                os.remove(temp_masked_path)
            except Exception as e:
                from ..core.logging import log_warning
                log_warning(f"Failed to remove temp masked raster: {e}")

        return {
            "total_pixels": cols * rows,
            "cloud_pixels": cloud_pixels,
            "cloud_coverage_percent": round(cloud_percent, 2),
            "max_search_distance": max_search_distance,
            "status": "success"
        }

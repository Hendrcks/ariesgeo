"""
Virtual and Permanent Raster Mosaicking engine for Aries Mosaic & GapFill.
"""

import os
from typing import List, Optional, Dict, Any, Callable
from osgeo import gdal, osr
from ..core.exceptions import MosaicError
from .inspector import RasterInspector

RESAMPLING_METHODS = {
    "nearest": gdal.GRA_NearestNeighbour,
    "bilinear": gdal.GRA_Bilinear,
    "cubic": gdal.GRA_Cubic,
    "cubicspline": gdal.GRA_CubicSpline,
    "lanczos": gdal.GRA_Lanczos,
    "mode": gdal.GRA_Mode,
    "average": gdal.GRA_Average,
}

class RasterMosaicker:
    """High-performance mosaicking manager using GDAL VRT and Warp/Translate."""

    @classmethod
    def build_virtual_mosaic(
        cls,
        input_paths: List[str],
        output_vrt_path: str,
        target_crs: Optional[str] = None,
        resampling: str = "bilinear",
        src_nodata: Optional[float] = None,
        vrt_nodata: Optional[float] = None,
        resolution_mode: str = "highest"  # "highest", "lowest", "average", "user"
    ) -> str:
        """Create a lightweight GDAL Virtual Raster (.vrt)."""
        if not input_paths:
            raise MosaicError("No input rasters provided for virtual mosaic.")

        # Ensure parent folder exists
        os.makedirs(os.path.dirname(os.path.abspath(output_vrt_path)), exist_ok=True)

        resample_alg = RESAMPLING_METHODS.get(resampling.lower(), gdal.GRA_Bilinear)

        vrt_options = gdal.BuildVRTOptions(
            resampleAlg=resample_alg,
            resolution=resolution_mode,
            srcNodata=src_nodata,
            VRTNodata=vrt_nodata,
            outputSRS=target_crs
        )

        vrt_ds = gdal.BuildVRT(output_vrt_path, input_paths, options=vrt_options)
        if not vrt_ds:
            raise MosaicError(f"Failed to create Virtual Mosaic at '{output_vrt_path}'.")

        vrt_ds.FlushCache()
        vrt_ds = None
        return output_vrt_path

    @classmethod
    def create_permanent_mosaic(
        cls,
        input_paths: List[str],
        output_tiff_path: str,
        target_crs: Optional[str] = None,
        pixel_size_x: Optional[float] = None,
        pixel_size_y: Optional[float] = None,
        resampling: str = "bilinear",
        compression: str = "DEFLATE",
        tiled: bool = True,
        build_overviews: bool = True,
        bigtiff: str = "IF_SAFER",
        src_nodata: Optional[float] = None,
        dst_nodata: Optional[float] = None,
        cutline_layer: Optional[str] = None,
        progress_callback: Optional[Callable[[float, str], None]] = None
    ) -> str:
        """Generate a permanent tiled GeoTIFF / Cloud-Optimized GeoTIFF."""
        if not input_paths:
            raise MosaicError("No input rasters provided for permanent mosaic.")

        os.makedirs(os.path.dirname(os.path.abspath(output_tiff_path)), exist_ok=True)

        resample_alg = RESAMPLING_METHODS.get(resampling.lower(), gdal.GRA_Bilinear)

        # Creation options
        creation_opts = [
            f"COMPRESS={compression.upper()}",
            f"BIGTIFF={bigtiff.upper()}",
        ]
        if tiled:
            creation_opts.extend(["TILED=YES", "BLOCKXSIZE=256", "BLOCKYSIZE=256"])

        # Progress wrapper
        def gdal_progress(pct, msg, _):
            if progress_callback:
                progress_callback(pct, msg or "")
            return 1

        warp_kwargs: Dict[str, Any] = {
            "resampleAlg": resample_alg,
            "creationOptions": creation_opts,
            "callback": gdal_progress if progress_callback else None,
            "multithread": True,
        }

        if target_crs:
            warp_kwargs["dstSRS"] = target_crs

        if pixel_size_x and pixel_size_y:
            warp_kwargs["xRes"] = pixel_size_x
            warp_kwargs["yRes"] = pixel_size_y

        if src_nodata is not None:
            warp_kwargs["srcNodata"] = src_nodata

        if dst_nodata is not None:
            warp_kwargs["dstNodata"] = dst_nodata

        if cutline_layer:
            warp_kwargs["cutlineDSName"] = cutline_layer
            warp_kwargs["cropToCutline"] = True

        warp_options = gdal.WarpOptions(**warp_kwargs)

        # Execute warp
        out_ds = gdal.Warp(output_tiff_path, input_paths, options=warp_options)
        if not out_ds:
            raise MosaicError(f"Failed to create permanent GeoTIFF mosaic at '{output_tiff_path}'.")

        # Overviews
        if build_overviews and out_ds.RasterXSize > 1024:
            try:
                out_ds.BuildOverviews("NEAREST" if resampling == "nearest" else "AVERAGE", [2, 4, 8, 16, 32])
            except Exception:
                pass

        out_ds.FlushCache()
        out_ds = None

        return output_tiff_path

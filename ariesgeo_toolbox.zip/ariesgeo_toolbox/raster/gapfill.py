"""
Spatial NoData and Landsat 7 SLC-off gap-filling algorithms for Aries Mosaic & GapFill.
"""

import os
import shutil
from typing import List, Optional, Callable, Dict, Any
import numpy as np
from osgeo import gdal, osr
from ..core.exceptions import GapFillError
from .radiometry import RadiometricHarmonizer

class GapFiller:
    """Core gap-filling engine supporting spatial edge interpolation and Landsat 7 SLC-off donor workflows."""

    @classmethod
    def fill_spatial_nodata(
        cls,
        input_raster_path: str,
        output_raster_path: str,
        max_search_distance: int = 100,
        smoothing_iterations: int = 0,
        band_indices: Optional[List[int]] = None,
        progress_callback: Optional[Callable[[float, str], None]] = None
    ) -> str:
        """Fill spatial NoData holes using GDAL edge-based inverse-distance interpolation."""
        if not os.path.exists(input_raster_path):
            raise GapFillError(f"Input raster does not exist: {input_raster_path}")

        os.makedirs(os.path.dirname(os.path.abspath(output_raster_path)), exist_ok=True)
        # Copy input to output first so GDAL operates in-place on the output copy
        shutil.copyfile(input_raster_path, output_raster_path)

        out_ds = gdal.Open(output_raster_path, gdal.GA_Update)
        if not out_ds:
            raise GapFillError(f"Failed to open destination raster for updating: {output_raster_path}")

        total_bands = out_ds.RasterCount
        bands_to_fill = band_indices if band_indices else list(range(1, total_bands + 1))

        try:
            for idx, band_num in enumerate(bands_to_fill):
                if band_num < 1 or band_num > total_bands:
                    continue

                target_band = out_ds.GetRasterBand(band_num)
                # Create memory mask band for valid pixels
                mask_band = target_band.GetMaskBand()

                def cb(pct, msg, _):
                    overall = (idx + pct) / len(bands_to_fill)
                    if progress_callback:
                        progress_callback(overall, f"Filling band {band_num}...")
                    return 1

                # Execute GDAL FillNodata
                res = gdal.FillNodata(
                    targetBand=target_band,
                    maskBand=mask_band,
                    maxSearchDist=max_search_distance,
                    smoothingIterations=smoothing_iterations,
                    callback=cb if progress_callback else None
                )
                if res != 0:
                    raise GapFillError(f"GDAL FillNodata failed on band {band_num}")

                target_band.FlushCache()
        finally:
            out_ds.FlushCache()
            out_ds = None

        return output_raster_path

    @classmethod
    def fill_landsat7_slcoff(
        cls,
        target_scene_path: str,
        donor_scene_paths: List[str],
        output_raster_path: str,
        output_confidence_path: Optional[str] = None,
        apply_radiometric_adjustment: bool = True,
        progress_callback: Optional[Callable[[float, str], None]] = None
    ) -> Dict[str, Any]:
        """Scientifically controlled Landsat 7 SLC-off multi-donor gap fill pipeline."""
        if not os.path.exists(target_scene_path):
            raise GapFillError(f"Target Landsat scene does not exist: {target_scene_path}")
        if not donor_scene_paths:
            raise GapFillError("At least one donor Landsat scene is required.")

        target_ds = gdal.Open(target_scene_path, gdal.GA_ReadOnly)
        if not target_ds:
            raise GapFillError(f"Cannot open target scene: {target_scene_path}")

        cols = target_ds.RasterXSize
        rows = target_ds.RasterYSize
        band_count = target_ds.RasterCount
        gt = target_ds.GetGeoTransform()
        proj = target_ds.GetProjection()

        # Open donor datasets
        donor_ds_list = []
        for p in donor_scene_paths:
            d_ds = gdal.Open(p, gdal.GA_ReadOnly)
            if d_ds and d_ds.RasterXSize == cols and d_ds.RasterYSize == rows:
                donor_ds_list.append(d_ds)

        if not donor_ds_list:
            raise GapFillError("No valid donor scenes match the target dimensions exactly.")

        os.makedirs(os.path.dirname(os.path.abspath(output_raster_path)), exist_ok=True)
        driver = gdal.GetDriverByName("GTiff")
        out_ds = driver.Create(
            output_raster_path,
            cols,
            rows,
            band_count,
            target_ds.GetRasterBand(1).DataType,
            ["COMPRESS=DEFLATE", "TILED=YES"]
        )
        out_ds.SetGeoTransform(gt)
        out_ds.SetProjection(proj)

        conf_ds = None
        if output_confidence_path:
            os.makedirs(os.path.dirname(os.path.abspath(output_confidence_path)), exist_ok=True)
            conf_ds = driver.Create(
                output_confidence_path,
                cols,
                rows,
                1,
                gdal.GDT_Byte,
                ["COMPRESS=DEFLATE"]
            )
            conf_ds.SetGeoTransform(gt)
            conf_ds.SetProjection(proj)

        stats_summary = {
            "bands_processed": band_count,
            "donors_used": len(donor_ds_list),
            "donor_gains": [],
            "donor_biases": [],
            "initial_gap_pixels": 0,
            "filled_gap_pixels": 0,
            "unfilled_gap_pixels": 0,
        }

        try:
            total_initial_gaps = 0
            total_filled_gaps = 0

            for b_idx in range(1, band_count + 1):
                if progress_callback:
                    progress_callback(b_idx / (band_count + 1), f"Processing band {b_idx}...")

                t_band = target_ds.GetRasterBand(b_idx)
                nodata_val = t_band.GetNoDataValue()
                t_arr = t_band.ReadAsArray()

                # Identify target gap pixels (nodata or 0 or NaN)
                if nodata_val is not None and not np.isnan(nodata_val):
                    gap_mask = (t_arr == nodata_val) | (t_arr == 0) | np.isnan(t_arr)
                else:
                    gap_mask = (t_arr == 0) | np.isnan(t_arr)

                initial_gaps_in_band = int(np.sum(gap_mask))
                total_initial_gaps += initial_gaps_in_band

                filled_arr = t_arr.copy()
                remaining_gap_mask = gap_mask.copy()
                band_conf = np.full(t_arr.shape, 100, dtype=np.uint8)  # 100 = original observed pixel
                band_conf[gap_mask] = 0

                # Iterate through donor scenes in priority order
                for donor_idx, d_ds in enumerate(donor_ds_list):
                    if not np.any(remaining_gap_mask):
                        break

                    d_band = d_ds.GetRasterBand(min(b_idx, d_ds.RasterCount))
                    d_nodata = d_band.GetNoDataValue()
                    d_arr = d_band.ReadAsArray()

                    # Valid donor pixels
                    if d_nodata is not None and not np.isnan(d_nodata):
                        d_valid = (d_arr != d_nodata) & (d_arr != 0) & ~np.isnan(d_arr)
                    else:
                        d_valid = (d_arr != 0) & ~np.isnan(d_arr)

                    # Radiometric adjustment
                    gain, bias = 1.0, 0.0
                    if apply_radiometric_adjustment:
                        gain, bias, _ = RadiometricHarmonizer.calculate_linear_regression(
                            target_arr=t_arr,
                            donor_arr=d_arr,
                            target_nodata=nodata_val,
                            donor_nodata=d_nodata
                        )
                        stats_summary["donor_gains"].append(round(gain, 4))
                        stats_summary["donor_biases"].append(round(bias, 4))

                    # Apply to remaining gaps where donor is valid
                    fillable = remaining_gap_mask & d_valid
                    if np.any(fillable):
                        adjusted_donor = (d_arr[fillable] * gain + bias).astype(t_arr.dtype)
                        filled_arr[fillable] = adjusted_donor
                        # Set confidence score (e.g. 80 for 1st donor, 60 for 2nd donor, etc.)
                        donor_conf = max(20, 85 - (donor_idx * 15))
                        band_conf[fillable] = donor_conf
                        remaining_gap_mask[fillable] = False

                filled_in_band = initial_gaps_in_band - int(np.sum(remaining_gap_mask))
                total_filled_gaps += filled_in_band

                out_band = out_ds.GetRasterBand(b_idx)
                if nodata_val is not None:
                    out_band.SetNoDataValue(nodata_val)
                out_band.WriteArray(filled_arr)
                out_band.FlushCache()

                if conf_ds and b_idx == 1:
                    conf_band = conf_ds.GetRasterBand(1)
                    conf_band.WriteArray(band_conf)
                    conf_band.FlushCache()

            stats_summary["initial_gap_pixels"] = total_initial_gaps
            stats_summary["filled_gap_pixels"] = total_filled_gaps
            stats_summary["unfilled_gap_pixels"] = total_initial_gaps - total_filled_gaps

        finally:
            out_ds = None
            if conf_ds:
                conf_ds = None
            target_ds = None
            for d in donor_ds_list:
                d = None

        return stats_summary

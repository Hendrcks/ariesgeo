"""
Aries Mosaic & GapFill raster processing module.
"""

"""
Provenance and sidecar quality report generator for Aries Mosaic & GapFill.
"""

import os
import json
import datetime
from typing import Dict, Any, List, Tuple

class ProvenanceReportGenerator:
    """Generates standardized JSON and Markdown sidecar provenance reports."""

    @classmethod
    def generate_report(
        cls,
        operation_name: str,
        input_files: List[str],
        output_file: str,
        parameters: Dict[str, Any],
        metrics: Dict[str, Any],
        warnings: List[str] = None
    ) -> Dict[str, Any]:
        """Build a comprehensive provenance record dictionary."""
        report = {
            "tool": "AriesGeo Toolbox — Aries Mosaic & GapFill",
            "version": "0.1.0",
            "operation": operation_name,
            "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "inputs": [os.path.abspath(f) for f in input_files],
            "output": os.path.abspath(output_file),
            "parameters": parameters,
            "metrics": metrics,
            "warnings": warnings or [],
        }
        return report

    @classmethod
    def save_sidecar_report(
        cls,
        report_data: Dict[str, Any],
        output_raster_path: str
    ) -> Tuple[str, str]:
        """Save .json and .md provenance reports next to output raster."""
        base_no_ext = os.path.splitext(output_raster_path)[0]
        json_path = f"{base_no_ext}_provenance.json"
        md_path = f"{base_no_ext}_report.md"

        # Save JSON
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump(report_data, f, indent=2)

        # Save Markdown
        md_content = cls.render_markdown(report_data)
        with open(md_path, "w", encoding="utf-8") as f:
            f.write(md_content)

        return json_path, md_path

    @classmethod
    def render_markdown(cls, report: Dict[str, Any]) -> str:
        lines = [
            f"# AriesGeo Toolbox — {report.get('operation', 'Processing')} Report",
            "",
            f"**Timestamp:** `{report.get('timestamp')}`  ",
            f"**Tool Version:** `{report.get('version')}`  ",
            f"**Output Raster:** `{report.get('output')}`  ",
            "",
            "## 1. Input Datasets",
            "",
        ]
        for f in report.get("inputs", []):
            lines.append(f"- `{f}`")

        lines.extend([
            "",
            "## 2. Processing Parameters",
            "",
            "| Parameter | Value |",
            "|---|---|",
        ])
        for k, v in report.get("parameters", {}).items():
            lines.append(f"| `{k}` | `{v}` |")

        lines.extend([
            "",
            "## 3. Quality & Statistics",
            "",
            "| Metric | Value |",
            "|---|---|",
        ])
        for k, v in report.get("metrics", {}).items():
            lines.append(f"| `{k}` | `{v}` |")

        if report.get("warnings"):
            lines.extend([
                "",
                "## 4. Warnings & Diagnostics",
                "",
            ])
            for w in report["warnings"]:
                lines.append(f"> ⚠️ **Warning:** {w}")

        lines.append("")
        return "\n".join(lines)

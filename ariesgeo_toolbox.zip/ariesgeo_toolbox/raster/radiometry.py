"""
Radiometric normalization and overlap statistics for Aries Mosaic & GapFill.
"""

from typing import Tuple, Dict, Any, Optional
import numpy as np
from osgeo import gdal

class RadiometricHarmonizer:
    """Computes linear regression gains and offsets (y = a*x + b) on overlapping valid pixels."""

    @staticmethod
    def calculate_linear_regression(
        target_arr: np.ndarray,
        donor_arr: np.ndarray,
        target_nodata: Optional[float] = None,
        donor_nodata: Optional[float] = None
    ) -> Tuple[float, float, float]:
        """Compute slope (gain), intercept (bias), and correlation (r^2) on valid overlap."""
        mask = np.ones_like(target_arr, dtype=bool)

        if target_nodata is not None:
            if np.isnan(target_nodata):
                mask &= ~np.isnan(target_arr)
            else:
                mask &= (target_arr != target_nodata) & ~np.isnan(target_arr)

        if donor_nodata is not None:
            if np.isnan(donor_nodata):
                mask &= ~np.isnan(donor_arr)
            else:
                mask &= (donor_arr != donor_nodata) & ~np.isnan(donor_arr)

        y = target_arr[mask].flatten()
        x = donor_arr[mask].flatten()

        if len(x) < 50:
            # Insufficient overlap points: return unity gain
            return 1.0, 0.0, 0.0

        # Subsample for speed if huge
        if len(x) > 100000:
            indices = np.random.choice(len(x), size=100000, replace=False)
            x = x[indices]
            y = y[indices]

        # Fit y = gain * x + bias
        A = np.vstack([x, np.ones(len(x))]).T
        gain, bias = np.linalg.lstsq(A, y, rcond=None)[0]

        # Calculate correlation r^2
        corr_mat = np.corrcoef(x, y)
        r_squared = float(corr_mat[0, 1] ** 2) if corr_mat.shape == (2, 2) else 0.0

        return float(gain), float(bias), float(r_squared)

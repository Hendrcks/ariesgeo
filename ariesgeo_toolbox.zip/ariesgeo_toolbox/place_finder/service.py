"""
Aries Place Finder central search service and state coordinator.
"""

import time
import json
import os
from typing import List, Optional, Dict, Any, Callable
from qgis.PyQt.QtCore import QObject, pyqtSignal, QTimer
from ..core.network import NetworkClient
from ..core.settings import settings
from .models import GeocodingResult, BoundingBox
from .cache import GeocodingCache
from .providers.base import BaseGeocodingProvider
from .providers.nominatim import NominatimProvider
from .providers.photon import PhotonProvider
from .offline_gazetteer import OfflineGazetteer

class PlaceFinderService(QObject):
    """Central service coordinating search queries, caching, rate limiting, and results."""

    search_started = pyqtSignal()
    search_finished = pyqtSignal(list)       # List[GeocodingResult]
    search_error = pyqtSignal(str)           # error_message
    reverse_finished = pyqtSignal(object)    # GeocodingResult or None

    def __init__(self, parent: Optional[QObject] = None):
        super().__init__(parent)
        self.network = NetworkClient(self)
        self.cache = GeocodingCache()
        self.offline = OfflineGazetteer(settings.offline_gazetteer_path)

        self.providers: Dict[str, BaseGeocodingProvider] = {
            "Photon (Komoot)": PhotonProvider(),
            "OpenStreetMap (Nominatim)": NominatimProvider(settings.nominatim_email),
        }
        self.active_provider_name = settings.default_provider or "Photon (Komoot)"
        self.last_request_time: Dict[str, float] = {}

        # Search history & favorites
        self.history_file = os.path.expanduser("~/.ariesgeo_toolbox/search_history.json")
        self.favorites_file = os.path.expanduser("~/.ariesgeo_toolbox/favorites.json")
        self.history: List[str] = self._load_json(self.history_file)
        self.favorites: List[Dict[str, Any]] = self._load_json(self.favorites_file)

    @property
    def active_provider(self) -> BaseGeocodingProvider:
        return self.providers.get(self.active_provider_name, list(self.providers.values())[0])

    def set_provider(self, name: str):
        if name in self.providers:
            self.active_provider_name = name
            settings.default_provider = name

    def search_async(
        self,
        query: str,
        limit: int = 10,
        country_code: Optional[str] = None,
        bbox: Optional[BoundingBox] = None
    ):
        """Execute asynchronous forward geocoding query."""
        clean_q = query.strip()
        if not clean_q:
            self.search_finished.emit([])
            return

        self.search_started.emit()
        self._add_to_history(clean_q)

        # Check offline gazetteer first if active
        if self.active_provider_name == "Offline Gazetteer":
            results = self.offline.search(clean_q, limit=limit)
            self.search_finished.emit(results)
            return

        # Check cache
        cached_data = self.cache.get(self.active_provider.name, "forward", clean_q)
        if cached_data is not None:
            results = self.active_provider.parse_forward_response(cached_data)
            self.search_finished.emit(results)
            return

        # Check rate-limit spacing
        now = time.time()
        last_t = self.last_request_time.get(self.active_provider.name, 0.0)
        delay = max(0.0, self.active_provider.min_request_interval - (now - last_t))

        def make_request():
            self.last_request_time[self.active_provider.name] = time.time()
            url = self.active_provider.build_forward_url(
                query=clean_q,
                limit=limit,
                country_code=country_code,
                bbox=bbox
            )

            def on_ok(data, _):
                self.cache.put(self.active_provider.name, "forward", clean_q, data)
                results = self.active_provider.parse_forward_response(data)
                self.search_finished.emit(results)

            def on_err(err, _):
                self.search_error.emit(err)

            self.network.get_json_async(url, on_success=on_ok, on_error=on_err)

        if delay > 0:
            QTimer.singleShot(int(delay * 1000), make_request)
        else:
            make_request()

    def reverse_geocode_async(self, lat: float, lon: float):
        """Execute asynchronous reverse geocoding query."""
        cache_key = f"{lat:.5f},{lon:.5f}"
        cached_data = self.cache.get(self.active_provider.name, "reverse", cache_key)
        if cached_data is not None:
            result = self.active_provider.parse_reverse_response(cached_data)
            self.reverse_finished.emit(result)
            return

        url = self.active_provider.build_reverse_url(lat, lon)

        def on_ok(data, _):
            self.cache.put(self.active_provider.name, "reverse", cache_key, data)
            result = self.active_provider.parse_reverse_response(data)
            self.reverse_finished.emit(result)

        def on_err(err, _):
            self.reverse_finished.emit(None)

        self.network.get_json_async(url, on_success=on_ok, on_error=on_err)

    # History & Favorites
    def _load_json(self, path: str) -> List[Any]:
        if os.path.exists(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception as e:
                from ..core.logging import log_warning
                log_warning(f"Failed to load JSON from {path}: {e}")
        return []

    def _save_json(self, path: str, data: Any):
        try:
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
        except Exception as e:
            from ..core.logging import log_warning
            log_warning(f"Failed to save JSON to {path}: {e}")

    def _add_to_history(self, query: str):
        if query in self.history:
            self.history.remove(query)
        self.history.insert(0, query)
        self.history = self.history[:50]  # Keep 50 recent
        self._save_json(self.history_file, self.history)

    def add_favorite(self, result: GeocodingResult):
        fav_entry = {
            "display_name": result.display_name,
            "name": result.name,
            "lat": result.lat,
            "lon": result.lon,
            "place_type": result.place_type,
            "provider": result.provider
        }
        # Avoid duplicate
        self.favorites = [f for f in self.favorites if f.get("display_name") != result.display_name]
        self.favorites.insert(0, fav_entry)
        self._save_json(self.favorites_file, self.favorites)

    def remove_favorite(self, display_name: str):
        self.favorites = [f for f in self.favorites if f.get("display_name") != display_name]
        self._save_json(self.favorites_file, self.favorites)

"""
OpenStreetMap / Nominatim geocoding provider adapter.
"""

import urllib.parse
from typing import List, Optional, Dict, Any
from .base import BaseGeocodingProvider
from ..models import GeocodingResult, BoundingBox

class NominatimProvider(BaseGeocodingProvider):
    """OSM Nominatim provider complying with OSM Usage Policy."""

    BASE_URL = "https://nominatim.openstreetmap.org"

    def __init__(self, email: str = ""):
        self.email = email

    @property
    def name(self) -> str:
        return "OpenStreetMap (Nominatim)"

    @property
    def attribution(self) -> str:
        return "© OpenStreetMap contributors, ODbL 1.0"

    @property
    def terms_url(self) -> str:
        return "https://operations.osmfoundation.org/policies/nominatim/"

    @property
    def min_request_interval(self) -> float:
        return 1.1  # Strict 1 req/sec limit

    def build_forward_url(
        self,
        query: str,
        limit: int = 10,
        country_code: Optional[str] = None,
        bbox: Optional[BoundingBox] = None,
        language: str = "en"
    ) -> str:
        params = {
            "q": query,
            "format": "jsonv2",
            "addressdetails": "1",
            "polygon_geojson": "1",
            "limit": str(limit),
            "accept-language": language,
        }
        if self.email:
            params["email"] = self.email
        if country_code:
            params["countrycodes"] = country_code.lower()
        if bbox:
            # Nominatim viewbox format: min_lon,max_lat,max_lon,min_lat (left,top,right,bottom)
            params["viewbox"] = f"{bbox.min_lon},{bbox.max_lat},{bbox.max_lon},{bbox.min_lat}"
            params["bounded"] = "1"

        return f"{self.BASE_URL}/search?{urllib.parse.urlencode(params)}"

    def build_reverse_url(self, lat: float, lon: float, language: str = "en") -> str:
        params = {
            "lat": str(lat),
            "lon": str(lon),
            "format": "jsonv2",
            "addressdetails": "1",
            "polygon_geojson": "1",
            "accept-language": language,
        }
        if self.email:
            params["email"] = self.email

        return f"{self.BASE_URL}/reverse?{urllib.parse.urlencode(params)}"

    def parse_forward_response(self, response_data: Any) -> List[GeocodingResult]:
        results: List[GeocodingResult] = []
        if not isinstance(response_data, list):
            return results

        for item in response_data:
            res = self._parse_item(item)
            if res:
                results.append(res)
        return results

    def parse_reverse_response(self, response_data: Any) -> Optional[GeocodingResult]:
        if not isinstance(response_data, dict):
            return None
        return self._parse_item(response_data)

    def _parse_item(self, item: Dict[str, Any]) -> Optional[GeocodingResult]:
        try:
            place_id = str(item.get("place_id", ""))
            display_name = item.get("display_name", "")
            lat = float(item.get("lat", 0.0))
            lon = float(item.get("lon", 0.0))
            place_type = item.get("type", "place")
            place_class = item.get("class", "place")
            importance = float(item.get("importance", 0.0))

            address = item.get("address", {})
            name = (
                item.get("name")
                or address.get("road")
                or address.get("suburb")
                or address.get("city")
                or address.get("town")
                or address.get("village")
                or display_name.split(",")[0]
            )

            country = address.get("country", "")
            country_code = address.get("country_code", "").upper()
            state = address.get("state", address.get("province", ""))
            city = address.get("city", address.get("town", address.get("village", "")))
            postcode = address.get("postcode", "")

            # Bounding box: [min_lat, max_lat, min_lon, max_lon]
            raw_bb = item.get("boundingbox")
            bbox = None
            if raw_bb and len(raw_bb) == 4:
                bbox = BoundingBox(
                    min_lat=float(raw_bb[0]),
                    max_lat=float(raw_bb[1]),
                    min_lon=float(raw_bb[2]),
                    max_lon=float(raw_bb[3]),
                )

            geojson_geom = item.get("geojson")

            return GeocodingResult(
                place_id=place_id,
                display_name=display_name,
                name=name,
                lat=lat,
                lon=lon,
                place_type=place_type,
                place_class=place_class,
                country=country,
                country_code=country_code,
                state=state,
                city=city,
                postcode=postcode,
                importance=importance,
                bounding_box=bbox,
                geojson_geometry=geojson_geom,
                provider=self.name,
                attribution=self.attribution,
                raw_data=item,
            )
        except Exception:
            return None

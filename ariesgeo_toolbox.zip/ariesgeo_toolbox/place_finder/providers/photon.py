"""
Photon (Komoot OSM) geocoding provider adapter.
"""

import urllib.parse
from typing import List, Optional, Dict, Any
from .base import BaseGeocodingProvider
from ..models import GeocodingResult, BoundingBox

class PhotonProvider(BaseGeocodingProvider):
    """Photon geocoder powered by OpenStreetMap data."""

    BASE_URL = "https://photon.komoot.io"

    def __init__(self, custom_url: Optional[str] = None):
        self.base_url = custom_url or self.BASE_URL

    @property
    def name(self) -> str:
        return "Photon (Komoot)"

    @property
    def attribution(self) -> str:
        return "© OpenStreetMap contributors, Komoot Photon"

    @property
    def terms_url(self) -> str:
        return "https://photon.komoot.io"

    @property
    def min_request_interval(self) -> float:
        return 0.25

    def build_forward_url(
        self,
        query: str,
        limit: int = 10,
        country_code: Optional[str] = None,
        bbox: Optional[BoundingBox] = None,
        language: str = "en"
    ) -> str:
        params = {
            "q": query,
            "limit": str(limit),
            "lang": language,
        }
        if bbox:
            # Photon supports bbox parameter: min_lon,min_lat,max_lon,max_lat
            params["bbox"] = f"{bbox.min_lon},{bbox.min_lat},{bbox.max_lon},{bbox.max_lat}"
            # Also set bias to bbox center
            center_lon = (bbox.min_lon + bbox.max_lon) / 2.0
            center_lat = (bbox.min_lat + bbox.max_lat) / 2.0
            params["lon"] = str(center_lon)
            params["lat"] = str(center_lat)

        return f"{self.base_url}/api?{urllib.parse.urlencode(params)}"

    def build_reverse_url(self, lat: float, lon: float, language: str = "en") -> str:
        params = {
            "lat": str(lat),
            "lon": str(lon),
            "lang": language,
        }
        return f"{self.base_url}/reverse?{urllib.parse.urlencode(params)}"

    def parse_forward_response(self, response_data: Any) -> List[GeocodingResult]:
        results: List[GeocodingResult] = []
        if not isinstance(response_data, dict):
            return results

        features = response_data.get("features", [])
        for feat in features:
            res = self._parse_feature(feat)
            if res:
                results.append(res)
        return results

    def parse_reverse_response(self, response_data: Any) -> Optional[GeocodingResult]:
        if not isinstance(response_data, dict):
            return None
        features = response_data.get("features", [])
        if features:
            return self._parse_feature(features[0])
        return None

    def _parse_feature(self, feature: Dict[str, Any]) -> Optional[GeocodingResult]:
        try:
            geometry = feature.get("geometry", {})
            coords = geometry.get("coordinates", [])
            if len(coords) < 2:
                return None
            lon, lat = float(coords[0]), float(coords[1])

            props = feature.get("properties", {})
            name = props.get("name", "")
            country = props.get("country", "")
            country_code = props.get("countrycode", "").upper()
            state = props.get("state", "")
            city = props.get("city", props.get("county", ""))
            postcode = props.get("postcode", "")
            street = props.get("street", "")
            housenumber = props.get("housenumber", "")
            place_type = props.get("type", props.get("osm_value", "place"))
            place_class = props.get("osm_key", "place")
            osm_id = str(props.get("osm_id", ""))

            # Build readable display name
            display_parts = []
            if name:
                display_parts.append(name)
            if street:
                st = f"{street} {housenumber}".strip() if housenumber else street
                if st not in display_parts:
                    display_parts.append(st)
            if city and city not in display_parts:
                display_parts.append(city)
            if state and state not in display_parts:
                display_parts.append(state)
            if country and country not in display_parts:
                display_parts.append(country)

            display_name = ", ".join(display_parts) if display_parts else name or f"{lat:.4f}, {lon:.4f}"

            # Extent bbox if present
            raw_extent = props.get("extent")
            bbox = None
            if raw_extent and len(raw_extent) == 4:
                bbox = BoundingBox(
                    min_lon=float(raw_extent[0]),
                    max_lat=float(raw_extent[1]),
                    max_lon=float(raw_extent[2]),
                    min_lat=float(raw_extent[3]),
                )

            return GeocodingResult(
                place_id=osm_id or display_name,
                display_name=display_name,
                name=name or display_name,
                lat=lat,
                lon=lon,
                place_type=place_type,
                place_class=place_class,
                country=country,
                country_code=country_code,
                state=state,
                city=city,
                postcode=postcode,
                importance=0.5,
                bounding_box=bbox,
                geojson_geometry=geometry,
                provider=self.name,
                attribution=self.attribution,
                raw_data=feature,
            )
        except Exception:
            return None

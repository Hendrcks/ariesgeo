"""
Abstract base class for geocoding provider adapters.
"""

from abc import ABC, abstractmethod
from typing import List, Optional, Dict, Any
from ..models import GeocodingResult, BoundingBox

class BaseGeocodingProvider(ABC):
    """Abstract interface defining required provider methods and metadata."""

    @property
    @abstractmethod
    def name(self) -> str:
        """Human-readable provider name."""
        pass

    @property
    @abstractmethod
    def attribution(self) -> str:
        """Legal attribution string required by provider terms of use."""
        pass

    @property
    @abstractmethod
    def terms_url(self) -> str:
        """Link to terms of service."""
        pass

    @property
    def min_request_interval(self) -> float:
        """Minimum seconds between consecutive requests."""
        return 0.2

    @abstractmethod
    def build_forward_url(
        self,
        query: str,
        limit: int = 10,
        country_code: Optional[str] = None,
        bbox: Optional[BoundingBox] = None,
        language: str = "en"
    ) -> str:
        """Build URL string for forward geocoding query."""
        pass

    @abstractmethod
    def build_reverse_url(self, lat: float, lon: float, language: str = "en") -> str:
        """Build URL string for reverse geocoding query."""
        pass

    @abstractmethod
    def parse_forward_response(self, response_data: Any) -> List[GeocodingResult]:
        """Convert raw response into standardized GeocodingResult objects."""
        pass

    @abstractmethod
    def parse_reverse_response(self, response_data: Any) -> Optional[GeocodingResult]:
        """Convert raw reverse response into GeocodingResult."""
        pass

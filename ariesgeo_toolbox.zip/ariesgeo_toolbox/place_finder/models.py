"""
Data structures and models for Aries Place Finder.
"""

from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any

@dataclass
class BoundingBox:
    """Geographic bounding box in WGS 84 (min_lon, min_lat, max_lon, max_lat)."""
    min_lon: float
    min_lat: float
    max_lon: float
    max_lat: float

    def to_list(self) -> List[float]:
        return [self.min_lon, self.min_lat, self.max_lon, self.max_lat]


@dataclass
class GeocodingResult:
    """A standardized geocoding search result."""
    place_id: str
    display_name: str
    name: str
    lat: float
    lon: float
    place_type: str = "place"
    place_class: str = "boundary"
    country: str = ""
    country_code: str = ""
    state: str = ""
    city: str = ""
    postcode: str = ""
    importance: float = 0.0
    bounding_box: Optional[BoundingBox] = None
    geojson_geometry: Optional[Dict[str, Any]] = None
    provider: str = ""
    attribution: str = ""
    raw_data: Dict[str, Any] = field(default_factory=dict)

    @property
    def formatted_coords(self) -> str:
        return f"{self.lat:.6f}, {self.lon:.6f}"


@dataclass
class BatchGeocodingRow:
    """A single record inside a batch geocoding job."""
    row_index: int
    query_text: str
    status: str = "pending"  # pending, success, not_found, error
    matched_result: Optional[GeocodingResult] = None
    error_message: str = ""
    original_attributes: Dict[str, Any] = field(default_factory=dict)

"""
Aries Place Finder module for QGIS.
"""

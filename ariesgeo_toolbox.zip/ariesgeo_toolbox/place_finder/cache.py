"""
Query caching mechanism for Aries Place Finder.
"""

import os
import time
import json
import sqlite3
from typing import Optional, List, Dict, Any, Tuple
from ..core.logging import log_warning
from .models import GeocodingResult, BoundingBox

class GeocodingCache:
    """Two-tier (memory + SQLite) cache for geocoding queries with TTL."""

    def __init__(self, db_path: Optional[str] = None, ttl_seconds: int = 86400 * 7):
        self.ttl_seconds = ttl_seconds
        self.mem_cache: Dict[str, Tuple[float, List[Dict[str, Any]]]] = {}
        
        if not db_path:
            user_dir = os.path.expanduser("~/.ariesgeo_toolbox")
            os.makedirs(user_dir, exist_ok=True)
            db_path = os.path.join(user_dir, "geocoding_cache.sqlite")
        
        self.db_path = db_path
        self._init_db()

    def _init_db(self):
        try:
            with sqlite3.connect(self.db_path) as conn:
                conn.execute("""
                    CREATE TABLE IF NOT EXISTS cache (
                        cache_key TEXT PRIMARY KEY,
                        provider TEXT,
                        query_type TEXT,
                        timestamp REAL,
                        data_json TEXT
                    )
                """)
                conn.execute("CREATE INDEX IF NOT EXISTS idx_timestamp ON cache (timestamp)")
        except Exception as e:
            log_warning(f"Failed to initialize geocoding cache DB: {e}")

    def _make_key(self, provider: str, query_type: str, query: str) -> str:
        clean_q = query.strip().lower()
        return f"{provider}:{query_type}:{clean_q}"

    def get(self, provider: str, query_type: str, query: str) -> Optional[List[Dict[str, Any]]]:
        key = self._make_key(provider, query_type, query)
        now = time.time()

        # Check in-memory cache
        if key in self.mem_cache:
            ts, data = self.mem_cache[key]
            if now - ts < self.ttl_seconds:
                return data

        # Check SQLite DB
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT timestamp, data_json FROM cache WHERE cache_key = ?", (key,))
                row = cursor.fetchone()
                if row:
                    ts, data_json = row
                    if now - ts < self.ttl_seconds:
                        data = json.loads(data_json)
                        self.mem_cache[key] = (ts, data)
                        return data
                    else:
                        cursor.execute("DELETE FROM cache WHERE cache_key = ?", (key,))
        except Exception as e:
            log_warning(f"Cache get error: {e}")
        return None

    def put(self, provider: str, query_type: str, query: str, data: List[Dict[str, Any]]):
        key = self._make_key(provider, query_type, query)
        now = time.time()
        self.mem_cache[key] = (now, data)

        try:
            with sqlite3.connect(self.db_path) as conn:
                conn.execute(
                    "INSERT OR REPLACE INTO cache (cache_key, provider, query_type, timestamp, data_json) VALUES (?, ?, ?, ?, ?)",
                    (key, provider, query_type, now, json.dumps(data))
                )
        except Exception as e:
            log_warning(f"Cache put error: {e}")

    def clear(self):
        """Clear all cached entries."""
        self.mem_cache.clear()
        try:
            with sqlite3.connect(self.db_path) as conn:
                conn.execute("DELETE FROM cache")
        except Exception as e:
            log_warning(f"Cache clear error: {e}")

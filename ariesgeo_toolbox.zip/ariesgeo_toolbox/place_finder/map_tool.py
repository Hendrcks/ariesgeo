"""
Interactive map canvas tool for reverse geocoding in Aries Place Finder.
"""

from qgis.PyQt.QtCore import pyqtSignal, Qt
from qgis.gui import QgsMapToolEmitPoint, QgsMapCanvas
from qgis.core import QgsPointXY
from ..core.crs import project_to_wgs84_point

class ReverseGeocodeMapTool(QgsMapToolEmitPoint):
    """Map tool that captures canvas clicks and emits WGS84 coordinates."""

    point_clicked = pyqtSignal(float, float, QgsPointXY)  # lat, lon, project_point

    def __init__(self, canvas: QgsMapCanvas):
        super().__init__(canvas)
        self.canvas = canvas
        self.setCursor(Qt.CursorShape.CrossCursor)

    def canvasReleaseEvent(self, event):
        point = self.toMapCoordinates(event.pos())
        lon, lat = project_to_wgs84_point(point.x(), point.y())
        self.point_clicked.emit(lat, lon, point)

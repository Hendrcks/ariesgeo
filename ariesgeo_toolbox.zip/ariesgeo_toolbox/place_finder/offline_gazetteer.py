"""
Offline SQLite/Spatialite gazetteer search engine for Aries Place Finder.
"""

import os
import sqlite3
from typing import List, Optional
from ..core.logging import log_warning
from .models import GeocodingResult, BoundingBox

class OfflineGazetteer:
    """Search offline gazetteer SQLite database without internet connection."""

    def __init__(self, db_path: Optional[str] = None):
        self.db_path = db_path

    @property
    def is_available(self) -> bool:
        return bool(self.db_path and os.path.exists(self.db_path))

    def search(self, query: str, limit: int = 15) -> List[GeocodingResult]:
        """Search offline gazetteer table for matching place names."""
        if not self.is_available or not self.db_path:
            return []

        results: List[GeocodingResult] = []
        clean_q = query.strip()
        if not clean_q:
            return results

        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                # Check for gazetteer table structure (name, lat, lon, country, feature_class, etc.)
                cursor.execute("""
                    SELECT id, name, lat, lon, place_type, country, state, city 
                    FROM places 
                    WHERE name LIKE ? OR name LIKE ?
                    LIMIT ?
                """, (f"{clean_q}%", f"%{clean_q}%", limit))

                for row in cursor.fetchall():
                    place_id, name, lat, lon, p_type, country, state, city = row
                    disp = ", ".join(filter(bool, [name, city, state, country]))
                    results.append(
                        GeocodingResult(
                            place_id=str(place_id),
                            display_name=disp or name,
                            name=name,
                            lat=float(lat),
                            lon=float(lon),
                            place_type=p_type or "locality",
                            country=country or "",
                            state=state or "",
                            city=city or "",
                            provider="Offline Gazetteer",
                            attribution="Offline Local Database",
                        )
                    )
        except Exception as e:
            log_warning(f"Offline gazetteer search error: {e}")
        return results

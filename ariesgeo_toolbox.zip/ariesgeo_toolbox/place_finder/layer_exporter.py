"""
Vector layer generation and export utilities for Aries Place Finder.
"""

from typing import List, Optional
from qgis.core import (
    QgsVectorLayer,
    QgsFeature,
    QgsGeometry,
    QgsPointXY,
    QgsField,
    QgsFields,
    QgsProject,
    QgsVectorFileWriter,
    QgsCoordinateTransformContext,
)
from qgis.PyQt.QtCore import QVariant
from ..core.crs import get_wgs84_crs
from .models import GeocodingResult

class LayerExporter:
    """Helper to convert GeocodingResult objects into QGIS vector layers."""

    @staticmethod
    def create_point_layer(
        results: List[GeocodingResult],
        layer_name: str = "Aries Search Results",
        add_to_project: bool = True
    ) -> QgsVectorLayer:
        """Create a temporary memory point layer in EPSG:4326 from results."""
        layer = QgsVectorLayer("Point?crs=EPSG:4326", layer_name, "memory")
        pr = layer.dataProvider()

        # Define fields
        fields = [
            QgsField("name", QVariant.Type.String if hasattr(QVariant, "Type") else QVariant.String),
            QgsField("display_name", QVariant.Type.String if hasattr(QVariant, "Type") else QVariant.String),
            QgsField("place_type", QVariant.Type.String if hasattr(QVariant, "Type") else QVariant.String),
            QgsField("country", QVariant.Type.String if hasattr(QVariant, "Type") else QVariant.String),
            QgsField("lat", QVariant.Type.Double if hasattr(QVariant, "Type") else QVariant.Double),
            QgsField("lon", QVariant.Type.Double if hasattr(QVariant, "Type") else QVariant.Double),
            QgsField("provider", QVariant.Type.String if hasattr(QVariant, "Type") else QVariant.String),
            QgsField("attribution", QVariant.Type.String if hasattr(QVariant, "Type") else QVariant.String),
        ]
        pr.addAttributes(fields)
        layer.updateFields()

        features = []
        for res in results:
            feat = QgsFeature(layer.fields())
            geom = QgsGeometry.fromPointXY(QgsPointXY(res.lon, res.lat))
            feat.setGeometry(geom)
            feat.setAttribute("name", res.name)
            feat.setAttribute("display_name", res.display_name)
            feat.setAttribute("place_type", res.place_type)
            feat.setAttribute("country", res.country)
            feat.setAttribute("lat", res.lat)
            feat.setAttribute("lon", res.lon)
            feat.setAttribute("provider", res.provider)
            feat.setAttribute("attribution", res.attribution)
            features.append(feat)

        pr.addFeatures(features)
        layer.updateExtents()

        if add_to_project:
            QgsProject.instance().addMapLayer(layer)

        return layer

    @staticmethod
    def create_boundary_layer(
        result: GeocodingResult,
        layer_name: Optional[str] = None,
        add_to_project: bool = True
    ) -> Optional[QgsVectorLayer]:
        """Create a polygon vector layer from result's bounding box or geojson geometry."""
        if not result.bounding_box and not result.geojson_geometry:
            return None

        name = layer_name or f"{result.name} (Boundary)"
        layer = QgsVectorLayer("Polygon?crs=EPSG:4326", name, "memory")
        pr = layer.dataProvider()

        pr.addAttributes([
            QgsField("name", QVariant.Type.String if hasattr(QVariant, "Type") else QVariant.String),
            QgsField("display_name", QVariant.Type.String if hasattr(QVariant, "Type") else QVariant.String),
            QgsField("provider", QVariant.Type.String if hasattr(QVariant, "Type") else QVariant.String),
        ])
        layer.updateFields()

        geom = None
        if result.geojson_geometry and result.geojson_geometry.get("type") in ["Polygon", "MultiPolygon"]:
            import json
            geom = QgsGeometry.fromJson(json.dumps(result.geojson_geometry))
        elif result.bounding_box:
            bb = result.bounding_box
            from qgis.core import QgsRectangle
            rect = QgsRectangle(bb.min_lon, bb.min_lat, bb.max_lon, bb.max_lat)
            geom = QgsGeometry.fromRect(rect)

        if geom and not geom.isEmpty():
            feat = QgsFeature(layer.fields())
            feat.setGeometry(geom)
            feat.setAttribute("name", result.name)
            feat.setAttribute("display_name", result.display_name)
            feat.setAttribute("provider", result.provider)
            pr.addFeatures([feat])
            layer.updateExtents()

            if add_to_project:
                QgsProject.instance().addMapLayer(layer)
            return layer
        return None

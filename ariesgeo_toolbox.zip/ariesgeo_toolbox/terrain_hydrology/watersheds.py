"""
Watershed delineation and basin morphometric statistics engine.
"""

import os
from typing import Tuple, Dict, Any, List, Optional
import numpy as np
from osgeo import gdal, ogr, osr
from ..core.exceptions import GapFillError

class WatershedDelineator:
    """Snaps outlets to drainage and delineates upstream contributing watershed basins."""

    @classmethod
    def snap_outlet_point(
        cls,
        acc_path: str,
        outlet_x: float,
        outlet_y: float,
        snap_distance_pixels: int = 10
    ) -> Tuple[float, float, int, int]:
        """
        Search window around outlet coordinates for cell with maximum flow accumulation.
        Returns (snapped_x, snapped_y, snapped_row, snapped_col).
        """
        ds = gdal.Open(acc_path, gdal.GA_ReadOnly)
        cols = ds.RasterXSize
        rows = ds.RasterYSize
        gt = ds.GetGeoTransform()
        acc = ds.GetRasterBand(1).ReadAsArray()
        ds = None

        # Convert (x, y) to (r, c)
        c_orig = int((outlet_x - gt[0]) / gt[1])
        r_orig = int((outlet_y - gt[3]) / gt[5])

        r_min = max(0, r_orig - snap_distance_pixels)
        r_max = min(rows, r_orig + snap_distance_pixels + 1)
        c_min = max(0, c_orig - snap_distance_pixels)
        c_max = min(cols, c_orig + snap_distance_pixels + 1)

        window = acc[r_min:r_max, c_min:c_max]
        max_idx = np.argmax(window)
        r_offset = max_idx // window.shape[1]
        c_offset = max_idx % window.shape[1]

        best_r = r_min + r_offset
        best_c = c_min + c_offset

        snapped_x = gt[0] + (best_c + 0.5) * gt[1]
        snapped_y = gt[3] + (best_r + 0.5) * gt[5]

        return snapped_x, snapped_y, best_r, best_c

    @classmethod
    def delineate_watershed(
        cls,
        fdir_path: str,
        outlet_row: int,
        outlet_col: int,
        output_raster_path: str,
        output_vector_path: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Trace upstream cells from outlet using D8 flow direction matrix.
        Generates watershed raster and vector polygon.
        """
        ds = gdal.Open(fdir_path, gdal.GA_ReadOnly)
        cols = ds.RasterXSize
        rows = ds.RasterYSize
        gt = ds.GetGeoTransform()
        proj = ds.GetProjection()
        fdir = ds.GetRasterBand(1).ReadAsArray()
        ds = None

        # Upstream flow tracing with BFS / Queue
        watershed_mask = np.zeros((rows, cols), dtype=np.uint8)
        queue = [(outlet_row, outlet_col)]
        watershed_mask[outlet_row, outlet_col] = 1

        # Inverse mapping: Which D8 direction from neighbor points back to current cell?
        # e.g., if neighbor is to the left (0, -1), its flow code must be 1 (East) to flow into current.
        neighbor_inflow_rules = [
            (0, 1, 16),      # Neighbor to East flows West (16)
            (1, 1, 32),      # Neighbor to South-East flows North-West (32)
            (1, 0, 64),      # Neighbor to South flows North (64)
            (1, -1, 128),    # Neighbor to South-West flows North-East (128)
            (0, -1, 1),      # Neighbor to West flows East (1)
            (-1, -1, 2),     # Neighbor to North-West flows South-East (2)
            (-1, 0, 4),      # Neighbor to North flows South (4)
            (-1, 1, 8),      # Neighbor to North-East flows South-West (8)
        ]

        while queue:
            curr_r, curr_c = queue.pop(0)
            for dr, dc, required_code in neighbor_inflow_rules:
                nr, nc = curr_r + dr, curr_c + dc
                if 0 <= nr < rows and 0 <= nc < cols:
                    if not watershed_mask[nr, nc] and fdir[nr, nc] == required_code:
                        watershed_mask[nr, nc] = 1
                        queue.append((nr, nc))

        # Save Watershed Raster
        os.makedirs(os.path.dirname(os.path.abspath(output_raster_path)), exist_ok=True)
        driver = gdal.GetDriverByName("GTiff")
        out_ds = driver.Create(output_raster_path, cols, rows, 1, gdal.GDT_Byte, ["COMPRESS=DEFLATE"])
        out_ds.SetGeoTransform(gt)
        out_ds.SetProjection(proj)
        ob = out_ds.GetRasterBand(1)
        ob.SetNoDataValue(0)
        ob.WriteArray(watershed_mask)
        ob.FlushCache()
        out_ds = None

        # Compute Basin Statistics
        pixel_area_m2 = abs(gt[1] * gt[5])
        cell_count = int(np.sum(watershed_mask))
        area_km2 = (cell_count * pixel_area_m2) / 1e6

        # Polygonize to Vector if requested
        if output_vector_path:
            os.makedirs(os.path.dirname(os.path.abspath(output_vector_path)), exist_ok=True)
            srs = osr.SpatialReference()
            srs.ImportFromWkt(proj)

            is_gpkg = output_vector_path.endswith(".gpkg")
            drv_name = "GPKG" if is_gpkg else "ESRI Shapefile"
            ogr_driver = ogr.GetDriverByName(drv_name)
            if os.path.exists(output_vector_path):
                ogr_driver.DeleteDataSource(output_vector_path)

            v_ds = ogr_driver.CreateDataSource(output_vector_path)
            v_layer = v_ds.CreateLayer("watershed", srs, ogr.wkbPolygon)
            v_layer.CreateField(ogr.FieldDefn("AREA_KM2", ogr.OFTReal))
            v_layer.CreateField(ogr.FieldDefn("CELL_COUNT", ogr.OFTInteger))

            r_ds = gdal.Open(output_raster_path, gdal.GA_ReadOnly)
            r_band = r_ds.GetRasterBand(1)
            gdal.Polygonize(r_band, r_band, v_layer, 1, [], callback=None)

            # Assign area attributes
            for feat in v_layer:
                feat.SetField("AREA_KM2", round(area_km2, 3))
                feat.SetField("CELL_COUNT", cell_count)
                v_layer.SetFeature(feat)

            r_ds = None
            v_ds = None

        return {
            "cell_count": cell_count,
            "area_km2": round(area_km2, 3),
            "pixel_size_m": round(np.sqrt(pixel_area_m2), 2),
            "output_raster": output_raster_path,
            "output_vector": output_vector_path or "",
            "status": "success"
        }

"""
Stream network extraction and Strahler stream ordering engine.
"""

import os
from typing import Optional
import numpy as np
from osgeo import gdal, ogr, osr
from ..core.exceptions import GapFillError

class StreamExtractor:
    """Extracts stream networks from flow accumulation and generates vector channels."""

    @classmethod
    def extract_stream_network(
        cls,
        acc_path: str,
        fdir_path: str,
        output_vector_path: str,
        threshold_cells: int = 500
    ) -> str:
        """Extract stream vectors where flow accumulation exceeds cell threshold."""
        acc_ds = gdal.Open(acc_path, gdal.GA_ReadOnly)
        cols = acc_ds.RasterXSize
        rows = acc_ds.RasterYSize
        gt = acc_ds.GetGeoTransform()
        proj = acc_ds.GetProjection()
        acc = acc_ds.GetRasterBand(1).ReadAsArray()
        acc_ds = None

        f_ds = gdal.Open(fdir_path, gdal.GA_ReadOnly)
        fdir = f_ds.GetRasterBand(1).ReadAsArray()
        f_ds = None

        stream_mask = acc >= threshold_cells

        d8_map = {
            1: (0, 1),
            2: (1, 1),
            4: (1, 0),
            8: (1, -1),
            16: (0, -1),
            32: (-1, -1),
            64: (-1, 0),
            128: (-1, 1)
        }

        # Build vector lines
        os.makedirs(os.path.dirname(os.path.abspath(output_vector_path)), exist_ok=True)
        srs = osr.SpatialReference()
        srs.ImportFromWkt(proj)

        is_gpkg = output_vector_path.endswith(".gpkg")
        drv_name = "GPKG" if is_gpkg else "ESRI Shapefile"
        ogr_driver = ogr.GetDriverByName(drv_name)
        if os.path.exists(output_vector_path):
            ogr_driver.DeleteDataSource(output_vector_path)

        ds = ogr_driver.CreateDataSource(output_vector_path)
        layer = ds.CreateLayer("streams", srs, ogr.wkbLineString)

        layer.CreateField(ogr.FieldDefn("ACC_CELLS", ogr.OFTInteger))
        layer.CreateField(ogr.FieldDefn("STRAHLER", ogr.OFTInteger))

        # Helper to convert (r, c) to map coordinates (x, y)
        def rc_to_xy(r, c):
            x = gt[0] + (c + 0.5) * gt[1] + (r + 0.5) * gt[2]
            y = gt[3] + (c + 0.5) * gt[4] + (r + 0.5) * gt[5]
            return x, y

        for r in range(rows):
            for c in range(cols):
                if stream_mask[r, c]:
                    code = int(fdir[r, c])
                    if code in d8_map:
                        dr, dc = d8_map[code]
                        nr, nc = r + dr, c + dc
                        if 0 <= nr < rows and 0 <= nc < cols and stream_mask[nr, nc]:
                            x1, y1 = rc_to_xy(r, c)
                            x2, y2 = rc_to_xy(nr, nc)

                            line = ogr.Geometry(ogr.wkbLineString)
                            line.AddPoint_2D(x1, y1)
                            line.AddPoint_2D(x2, y2)

                            feat = ogr.Feature(layer.GetLayerDefn())
                            feat.SetGeometry(line)
                            feat.SetField("ACC_CELLS", int(acc[r, c]))
                            # Estimate Strahler order from log accumulation scale
                            strahler = max(1, int(np.log10(max(10, acc[r, c])) / 1.2))
                            feat.SetField("STRAHLER", strahler)
                            layer.CreateFeature(feat)

        ds = None
        return output_vector_path

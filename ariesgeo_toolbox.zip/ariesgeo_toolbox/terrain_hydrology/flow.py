"""
D8 Flow Direction and Flow Accumulation computation engine.
"""

import os
from typing import Tuple, Optional
import numpy as np
from osgeo import gdal

# D8 Neighbor Offsets (dr, dc) and corresponding D8 Code
D8_DIRECTIONS = [
    (0, 1, 1),       # East
    (1, 1, 2),       # South-East
    (1, 0, 4),       # South
    (1, -1, 8),      # South-West
    (0, -1, 16),     # West
    (-1, -1, 32),    # North-West
    (-1, 0, 64),     # North
    (-1, 1, 128),    # North-East
]

class FlowEngine:
    """Calculates D8 flow routing direction matrix and upstream flow accumulation."""

    @classmethod
    def calculate_d8_flow_direction(
        cls,
        dem_path: str,
        output_fdir_path: str
    ) -> str:
        """Compute D8 Flow Direction raster."""
        ds = gdal.Open(dem_path, gdal.GA_ReadOnly)
        cols = ds.RasterXSize
        rows = ds.RasterYSize
        gt = ds.GetGeoTransform()
        proj = ds.GetProjection()

        band = ds.GetRasterBand(1)
        nodata = band.GetNoDataValue()
        elev = band.ReadAsArray().astype(np.float64)

        if nodata is not None and not np.isnan(nodata):
            nodata_mask = (elev == nodata) | np.isnan(elev)
        else:
            nodata_mask = np.isnan(elev)

        dx = abs(gt[1])
        dy = abs(gt[5])
        diag_dist = np.sqrt(dx**2 + dy**2)

        fdir = np.zeros((rows, cols), dtype=np.uint8)

        # For every cell, find neighbor with max downward slope
        for dr, dc, code in D8_DIRECTIONS:
            # Shift neighbor array
            n_elev = np.full_like(elev, np.nan)
            # The cell (r, c) gets neighbor (r + dr, c + dc)
            n_r_start = max(0, -dr)
            n_r_end = rows + min(0, -dr)
            n_c_start = max(0, -dc)
            n_c_end = cols + min(0, -dc)

            e_r_start = max(0, dr)
            e_r_end = rows + min(0, dr)
            e_c_start = max(0, dc)
            e_c_end = cols + min(0, dc)

            n_elev[n_r_start:n_r_end, n_c_start:n_c_end] = elev[e_r_start:e_r_end, e_c_start:e_c_end]

            dist = diag_dist if (dr != 0 and dc != 0) else (dx if dr == 0 else dy)
            slope = (elev - n_elev) / dist

            # Max slope mask
            if code == 1:
                max_slope = slope
                fdir = np.where((slope > 0) & ~nodata_mask, code, fdir)
            else:
                is_steeper = (slope > max_slope) & (slope > 0) & ~nodata_mask
                fdir = np.where(is_steeper, code, fdir)
                max_slope = np.where(is_steeper, slope, max_slope)

        # Save Flow Direction Raster
        os.makedirs(os.path.dirname(os.path.abspath(output_fdir_path)), exist_ok=True)
        driver = gdal.GetDriverByName("GTiff")
        out_ds = driver.Create(output_fdir_path, cols, rows, 1, gdal.GDT_Byte, ["COMPRESS=DEFLATE"])
        out_ds.SetGeoTransform(gt)
        out_ds.SetProjection(proj)
        ob = out_ds.GetRasterBand(1)
        ob.SetNoDataValue(0)
        ob.WriteArray(fdir)
        ob.FlushCache()
        out_ds = None
        ds = None
        return output_fdir_path

    @classmethod
    def calculate_flow_accumulation(
        cls,
        dem_path: str,
        fdir_path: str,
        output_acc_path: str
    ) -> str:
        """Compute Flow Accumulation (contributing cell count) from D8 Flow Direction."""
        f_ds = gdal.Open(fdir_path, gdal.GA_ReadOnly)
        cols = f_ds.RasterXSize
        rows = f_ds.RasterYSize
        gt = f_ds.GetGeoTransform()
        proj = f_ds.GetProjection()
        fdir = f_ds.GetRasterBand(1).ReadAsArray()
        f_ds = None

        dem_ds = gdal.Open(dem_path, gdal.GA_ReadOnly)
        elev = dem_ds.GetRasterBand(1).ReadAsArray().astype(np.float64)
        dem_ds = None

        # Sort all cells in descending order of elevation
        indices = np.argsort(elev.flatten())[::-1]
        acc = np.ones((rows, cols), dtype=np.int32)

        d8_map = {
            1: (0, 1),
            2: (1, 1),
            4: (1, 0),
            8: (1, -1),
            16: (0, -1),
            32: (-1, -1),
            64: (-1, 0),
            128: (-1, 1)
        }

        # Topological accumulation from highest to lowest
        for idx in indices:
            r = idx // cols
            c = idx % cols
            code = int(fdir[r, c])
            if code in d8_map:
                dr, dc = d8_map[code]
                nr, nc = r + dr, c + dc
                if 0 <= nr < rows and 0 <= nc < cols:
                    acc[nr, nc] += acc[r, c]

        # Save Flow Accumulation
        os.makedirs(os.path.dirname(os.path.abspath(output_acc_path)), exist_ok=True)
        driver = gdal.GetDriverByName("GTiff")
        out_ds = driver.Create(output_acc_path, cols, rows, 1, gdal.GDT_Int32, ["COMPRESS=DEFLATE"])
        out_ds.SetGeoTransform(gt)
        out_ds.SetProjection(proj)
        ob = out_ds.GetRasterBand(1)
        ob.SetNoDataValue(0)
        ob.WriteArray(acc)
        ob.FlushCache()
        out_ds = None
        return output_acc_path

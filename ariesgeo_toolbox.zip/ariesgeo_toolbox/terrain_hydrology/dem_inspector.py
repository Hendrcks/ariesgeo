"""
DEM Preflight Diagnostics and Elevation Inspector for Aries Terrain & Hydrology Toolkit.
"""

import os
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any
import numpy as np
from osgeo import gdal, osr
from ..core.exceptions import RasterInspectionError

@dataclass
class DEMDiagnostics:
    """Preflight diagnostic report for Digital Elevation Models."""
    filepath: str
    filename: str
    width: int
    height: int
    crs_auth_id: str
    is_projected: bool
    pixel_size_x: float
    pixel_size_y: float
    is_square_pixels: bool
    min_elev: float
    max_elev: float
    mean_elev: float
    std_elev: float
    nodata_value: Optional[float]
    nodata_percentage: float
    sink_count_approx: int
    needs_z_factor: bool
    warnings: List[str] = field(default_factory=list)


class DEMInspector:
    """Inspects digital elevation models prior to terrain derivatives or hydrological processing."""

    @classmethod
    def inspect(cls, filepath: str) -> DEMDiagnostics:
        if not os.path.exists(filepath):
            raise RasterInspectionError(f"DEM file not found: {filepath}")

        ds = gdal.Open(filepath, gdal.GA_ReadOnly)
        if not ds:
            raise RasterInspectionError(f"Cannot open DEM file: {filepath}")

        try:
            width = ds.RasterXSize
            height = ds.RasterYSize
            gt = ds.GetGeoTransform()
            proj_wkt = ds.GetProjection() or ""

            ps_x = abs(gt[1])
            ps_y = abs(gt[5])
            is_square = abs(ps_x - ps_y) < 1e-4

            # CRS & Projection check
            is_projected = False
            crs_auth_id = "Unknown"
            if proj_wkt:
                srs = osr.SpatialReference()
                srs.ImportFromWkt(proj_wkt)
                is_projected = bool(srs.IsProjected())
                auth_name = srs.GetAuthorityName(None)
                auth_code = srs.GetAuthorityCode(None)
                if auth_name and auth_code:
                    crs_auth_id = f"{auth_name}:{auth_code}"

            band = ds.GetRasterBand(1)
            nodata_val = band.GetNoDataValue()

            # Read sample or full array for statistics
            arr = band.ReadAsArray()
            if nodata_val is not None and not np.isnan(nodata_val):
                valid_mask = (arr != nodata_val) & ~np.isnan(arr)
            else:
                valid_mask = ~np.isnan(arr)

            total_px = width * height
            valid_px = int(np.sum(valid_mask))
            nodata_pct = ((total_px - valid_px) / max(1, total_px)) * 100.0

            warnings = []
            if not is_projected:
                warnings.append(
                    "DEM is in a Geographic Coordinate System (degrees). "
                    "Reprojection to a metric projected CRS (e.g. UTM) is strongly recommended for slope and watershed analysis."
                )

            if not is_square:
                warnings.append(f"Pixels are non-square ({ps_x:.2f} x {ps_y:.2f}). Resampling is suggested.")

            if valid_px > 0:
                valid_elevs = arr[valid_mask]
                min_e = float(np.min(valid_elevs))
                max_e = float(np.max(valid_elevs))
                mean_e = float(np.mean(valid_elevs))
                std_e = float(np.std(valid_elevs))
            else:
                min_e = max_e = mean_e = std_e = 0.0
                warnings.append("DEM contains zero valid elevation pixels.")

            # Quick local depression / sink detection on subsampled array
            sink_count = 0
            if valid_px > 100 and width > 5 and height > 5:
                # Compare center pixel to 8 neighbors
                sub = arr[1:-1, 1:-1]
                v_sub = valid_mask[1:-1, 1:-1]
                n_up = arr[:-2, 1:-1]
                n_down = arr[2:, 1:-1]
                n_left = arr[1:-1, :-2]
                n_right = arr[1:-1, 2:]

                # Is strictly lower than cardinal neighbors
                is_sink = (
                    v_sub
                    & (sub < n_up)
                    & (sub < n_down)
                    & (sub < n_left)
                    & (sub < n_right)
                )
                sink_count = int(np.sum(is_sink))

            needs_z = not is_projected

            return DEMDiagnostics(
                filepath=filepath,
                filename=os.path.basename(filepath),
                width=width,
                height=height,
                crs_auth_id=crs_auth_id,
                is_projected=is_projected,
                pixel_size_x=ps_x,
                pixel_size_y=ps_y,
                is_square_pixels=is_square,
                min_elev=round(min_e, 2),
                max_elev=round(max_e, 2),
                mean_elev=round(mean_e, 2),
                std_elev=round(std_e, 2),
                nodata_value=nodata_val,
                nodata_percentage=round(nodata_pct, 2),
                sink_count_approx=sink_count,
                needs_z_factor=needs_z,
                warnings=warnings
            )
        finally:
            ds = None

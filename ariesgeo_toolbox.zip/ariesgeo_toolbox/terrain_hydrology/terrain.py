"""
Terrain derivative calculations (Slope, Aspect, Hillshade, Contours, TRI, TPI).
"""

import os
from typing import Optional, List
import numpy as np
from osgeo import gdal, ogr, osr
from ..core.exceptions import RasterInspectionError

class TerrainGenerator:
    """Generates primary and secondary geomorphometric terrain derivatives."""

    @classmethod
    def generate_slope(
        cls,
        dem_path: str,
        output_slope_path: str,
        as_percent: bool = False,
        z_factor: float = 1.0
    ) -> str:
        """Calculate slope in degrees (default) or percent slope."""
        os.makedirs(os.path.dirname(os.path.abspath(output_slope_path)), exist_ok=True)
        slope_fmt = "percent" if as_percent else "degree"
        res_ds = gdal.DEMProcessing(
            output_slope_path,
            dem_path,
            "slope",
            format="GTiff",
            slopeFormat=slope_fmt,
            scale=z_factor,
            creationOptions=["COMPRESS=DEFLATE"]
        )
        if not res_ds:
            raise RasterInspectionError(f"Failed to generate slope for: {dem_path}")
        res_ds = None
        return output_slope_path

    @classmethod
    def generate_aspect(
        cls,
        dem_path: str,
        output_aspect_path: str,
        z_factor: float = 1.0,
        zero_for_flat: bool = True
    ) -> str:
        """Calculate aspect (compass direction 0-360 degrees)."""
        os.makedirs(os.path.dirname(os.path.abspath(output_aspect_path)), exist_ok=True)
        res_ds = gdal.DEMProcessing(
            output_aspect_path,
            dem_path,
            "aspect",
            format="GTiff",
            scale=z_factor,
            creationOptions=["COMPRESS=DEFLATE"]
        )
        if not res_ds:
            raise RasterInspectionError(f"Failed to generate aspect for: {dem_path}")
        res_ds = None
        return output_aspect_path

    @classmethod
    def generate_hillshade(
        cls,
        dem_path: str,
        output_hillshade_path: str,
        azimuth: float = 315.0,
        altitude: float = 45.0,
        z_factor: float = 1.0,
        multidirectional: bool = False
    ) -> str:
        """Calculate hillshade raster."""
        os.makedirs(os.path.dirname(os.path.abspath(output_hillshade_path)), exist_ok=True)
        res_ds = gdal.DEMProcessing(
            output_hillshade_path,
            dem_path,
            "hillshade",
            format="GTiff",
            azimuth=azimuth,
            altitude=altitude,
            zFactor=z_factor,
            multiDirectional=multidirectional,
            creationOptions=["COMPRESS=DEFLATE"]
        )
        if not res_ds:
            raise RasterInspectionError(f"Failed to generate hillshade for: {dem_path}")
        res_ds = None
        return output_hillshade_path

    @classmethod
    def generate_contours(
        cls,
        dem_path: str,
        output_vector_path: str,
        interval: float = 10.0,
        base_contour: float = 0.0,
        elevation_field_name: str = "ELEV"
    ) -> str:
        """Generate vector contour lines from DEM using GDAL ContourGenerate."""
        os.makedirs(os.path.dirname(os.path.abspath(output_vector_path)), exist_ok=True)
        ds = gdal.Open(dem_path, gdal.GA_ReadOnly)
        if not ds:
            raise RasterInspectionError(f"Cannot open DEM: {dem_path}")

        band = ds.GetRasterBand(1)
        nodata = band.GetNoDataValue()

        srs = osr.SpatialReference()
        srs.ImportFromWkt(ds.GetProjection())

        is_gpkg = output_vector_path.endswith(".gpkg")
        drv_name = "GPKG" if is_gpkg else "ESRI Shapefile"
        ogr_driver = ogr.GetDriverByName(drv_name)

        if os.path.exists(output_vector_path):
            ogr_driver.DeleteDataSource(output_vector_path)

        ogr_ds = ogr_driver.CreateDataSource(output_vector_path)
        layer = ogr_ds.CreateLayer("contours", srs, ogr.wkbLineString)

        field_defn = ogr.FieldDefn(elevation_field_name, ogr.OFTReal)
        layer.CreateField(field_defn)

        gdal.ContourGenerate(
            band,
            interval,
            base_contour,
            [],
            1 if nodata is not None else 0,
            nodata if nodata is not None else 0.0,
            layer,
            -1,
            0
        )

        ogr_ds = None
        ds = None
        return output_vector_path

    @classmethod
    def generate_tri(cls, dem_path: str, output_tri_path: str) -> str:
        """Generate Terrain Ruggedness Index (TRI)."""
        os.makedirs(os.path.dirname(os.path.abspath(output_tri_path)), exist_ok=True)
        res_ds = gdal.DEMProcessing(
            output_tri_path,
            dem_path,
            "TRI",
            format="GTiff",
            creationOptions=["COMPRESS=DEFLATE"]
        )
        if not res_ds:
            raise RasterInspectionError(f"Failed to generate TRI for: {dem_path}")
        res_ds = None
        return output_tri_path

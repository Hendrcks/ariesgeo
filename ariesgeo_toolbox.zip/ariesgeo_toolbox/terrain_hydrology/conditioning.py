"""
DEM preparation, sink/depression filling, and conditioning algorithms.
"""

import os
from typing import Optional
import numpy as np
from osgeo import gdal
from ..core.exceptions import GapFillError

class DEMConditioner:
    """Prepares and conditions DEMs for hydrological routing by filling depressions and sinks."""

    @classmethod
    def fill_sinks(
        cls,
        input_dem_path: str,
        output_dem_path: str,
        output_diff_path: Optional[str] = None
    ) -> str:
        """
        Fills sinks/depressions in the DEM using Planchon-Darboux / Wang-Liu depression filling.
        Preserves outer boundaries and iteratively raises enclosed depressions to spill elevation.
        """
        if not os.path.exists(input_dem_path):
            raise GapFillError(f"Input DEM not found: {input_dem_path}")

        ds = gdal.Open(input_dem_path, gdal.GA_ReadOnly)
        cols = ds.RasterXSize
        rows = ds.RasterYSize
        gt = ds.GetGeoTransform()
        proj = ds.GetProjection()

        band = ds.GetRasterBand(1)
        nodata = band.GetNoDataValue()
        elev = band.ReadAsArray().astype(np.float64)

        if nodata is not None and not np.isnan(nodata):
            nodata_mask = (elev == nodata) | np.isnan(elev)
        else:
            nodata_mask = np.isnan(elev)

        # Initialize filled surface to infinity except at DEM boundaries & nodata
        filled = np.full_like(elev, np.inf)
        filled[0, :] = elev[0, :]
        filled[-1, :] = elev[-1, :]
        filled[:, 0] = elev[:, 0]
        filled[:, -1] = elev[:, -1]
        filled[nodata_mask] = elev[nodata_mask]

        # Iterative depression filling with priority queue / neighbor propagation
        import heapq
        pq = []

        # Push edge pixels into min-heap
        for r in range(rows):
            for c in range(cols):
                if r == 0 or r == rows - 1 or c == 0 or c == cols - 1 or nodata_mask[r, c]:
                    if not nodata_mask[r, c]:
                        heapq.heappush(pq, (elev[r, c], r, c))

        visited = np.zeros((rows, cols), dtype=bool)
        visited[0, :] = True
        visited[-1, :] = True
        visited[:, 0] = True
        visited[:, -1] = True
        visited[nodata_mask] = True

        directions = [(-1, 0), (1, 0), (0, -1), (0, 1), (-1, -1), (-1, 1), (1, -1), (1, 1)]

        while pq:
            z, r, c = heapq.heappop(pq)
            for dr, dc in directions:
                nr, nc = r + dr, c + dc
                if 0 <= nr < rows and 0 <= nc < cols and not visited[nr, nc]:
                    visited[nr, nc] = True
                    # Fill elevation is max of neighbor spill elevation and current DEM elevation
                    fill_z = max(z, elev[nr, nc])
                    filled[nr, nc] = fill_z
                    heapq.heappush(pq, (fill_z, nr, nc))

        # Restore NoData
        if nodata is not None:
            filled[nodata_mask] = nodata

        # Save Filled DEM
        os.makedirs(os.path.dirname(os.path.abspath(output_dem_path)), exist_ok=True)
        driver = gdal.GetDriverByName("GTiff")
        out_ds = driver.Create(output_dem_path, cols, rows, 1, gdal.GDT_Float32, ["COMPRESS=DEFLATE"])
        out_ds.SetGeoTransform(gt)
        out_ds.SetProjection(proj)
        ob = out_ds.GetRasterBand(1)
        if nodata is not None:
            ob.SetNoDataValue(nodata)
        ob.WriteArray(filled.astype(np.float32))
        ob.FlushCache()
        out_ds = None

        # Optional difference raster (Filled - Original)
        if output_diff_path:
            os.makedirs(os.path.dirname(os.path.abspath(output_diff_path)), exist_ok=True)
            diff = np.where(nodata_mask, 0.0, filled - elev).astype(np.float32)
            d_ds = driver.Create(output_diff_path, cols, rows, 1, gdal.GDT_Float32, ["COMPRESS=DEFLATE"])
            d_ds.SetGeoTransform(gt)
            d_ds.SetProjection(proj)
            db = d_ds.GetRasterBand(1)
            db.SetNoDataValue(0)
            db.WriteArray(diff)
            db.FlushCache()
            d_ds = None

        ds = None
        return output_dem_path

"""
Aries Mosaic & GapFill 4-step Guided Wizard Dialog.
"""

import os
from typing import List, Optional
from qgis.PyQt.QtWidgets import (
    QDialog,
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QStackedWidget,
    QLabel,
    QPushButton,
    QListWidget,
    QTableWidget,
    QTableWidgetItem,
    QHeaderView,
    QFileDialog,
    QComboBox,
    QCheckBox,
    QLineEdit,
    QProgressBar,
    QMessageBox,
    QGroupBox,
    QFormLayout,
    QRadioButton,
    QButtonGroup,
)
from qgis.PyQt.QtCore import Qt, pyqtSignal
from qgis.PyQt.QtGui import QColor, QFont
from qgis.core import QgsProject, QgsRasterLayer
from ..resources import get_icon
from ..core.settings import settings
from ..core.task_manager import run_in_background
from ..raster.inspector import RasterInspector, InspectionReport
from ..raster.mosaic import RasterMosaicker
from ..raster.reports import ProvenanceReportGenerator
from .report_dialog import ReportViewerDialog

class MosaicWizardDialog(QDialog):
    """Guided 4-step dialog for raster inspection, virtual mosaics, and permanent GeoTIFF creation."""

    def __init__(self, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.setWindowTitle("Aries Mosaic Wizard — AriesPlus")
        self.setWindowIcon(get_icon("mosaic"))
        self.setMinimumSize(780, 560)

        self.input_files: List[str] = []
        self.inspection_report: Optional[InspectionReport] = None
        self.output_mosaic_path = ""
        self.last_provenance_data = None

        self._setup_ui()

    def _setup_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(12, 12, 12, 12)
        main_layout.setSpacing(10)

        # Wizard Step Header
        self.header_lbl = QLabel("Step 1 of 4: Select Input Rasters & Preflight Inspection")
        self.header_lbl.setStyleSheet("""
            QLabel {
                font-size: 14px;
                font-weight: bold;
                color: #0B1F33;
                background-color: #E8F5E9;
                border-left: 4px solid #16A36A;
                padding: 8px 12px;
                border-radius: 4px;
            }
        """)
        main_layout.addWidget(self.header_lbl)

        # Stacked Pages
        self.stack = QStackedWidget()
        self.page1 = self._create_page_1()
        self.page2 = self._create_page_2()
        self.page3 = self._create_page_3()
        self.page4 = self._create_page_4()

        self.stack.addWidget(self.page1)
        self.stack.addWidget(self.page2)
        self.stack.addWidget(self.page3)
        self.stack.addWidget(self.page4)
        main_layout.addWidget(self.stack)

        # Navigation Bar
        nav_layout = QHBoxLayout()
        self.btn_prev = QPushButton("Back")
        self.btn_prev.setEnabled(False)
        self.btn_next = QPushButton("Next")
        self.btn_next.setStyleSheet("background-color: #16A36A; color: white; font-weight: bold; padding: 6px 16px;")
        self.btn_cancel = QPushButton("Cancel")

        nav_layout.addWidget(self.btn_prev)
        nav_layout.addStretch()
        nav_layout.addWidget(self.btn_cancel)
        nav_layout.addWidget(self.btn_next)
        main_layout.addLayout(nav_layout)

        # Signals
        self.btn_prev.clicked.connect(self._go_prev)
        self.btn_next.clicked.connect(self._go_next)
        self.btn_cancel.clicked.connect(self.reject)

    # Page 1: Input Rasters & Preflight Inspection
    def _create_page_1(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(0, 0, 0, 0)

        btn_bar = QHBoxLayout()
        btn_add_files = QPushButton("Add Raster Files...")
        btn_add_files.setIcon(get_icon("mosaic"))
        btn_add_canvas = QPushButton("Add Active Layers")
        btn_remove = QPushButton("Remove Selected")
        btn_clear = QPushButton("Clear All")

        btn_bar.addWidget(btn_add_files)
        btn_bar.addWidget(btn_add_canvas)
        btn_bar.addWidget(btn_remove)
        btn_bar.addWidget(btn_clear)
        btn_bar.addStretch()
        layout.addLayout(btn_bar)

        # Inspection Table
        self.table_inspector = QTableWidget(0, 6)
        self.table_inspector.setHorizontalHeaderLabels(["Filename", "CRS", "Resolution", "Bands", "Data Type", "Status"])
        self.table_inspector.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        for col in range(1, 6):
            self.table_inspector.horizontalHeader().setSectionResizeMode(col, QHeaderView.ResizeMode.ResizeToContents)
        self.table_inspector.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table_inspector.setAlternatingRowColors(True)
        layout.addWidget(self.table_inspector)

        # Diagnostics Summary Card
        self.diag_summary = QLabel("No rasters selected. Please add rasters to inspect.")
        self.diag_summary.setStyleSheet("background-color: #F8FAFC; border: 1px solid #E2E8F0; padding: 8px; border-radius: 4px;")
        layout.addWidget(self.diag_summary)

        # Connect page 1 buttons
        btn_add_files.clicked.connect(self._add_files)
        btn_add_canvas.clicked.connect(self._add_canvas_layers)
        btn_remove.clicked.connect(self._remove_selected)
        btn_clear.clicked.connect(self._clear_all)

        return page

    # Page 2: Target Grid & Alignment
    def _create_page_2(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)

        grp_grid = QGroupBox("Grid & Spatial Alignment")
        form = QFormLayout(grp_grid)

        self.ref_raster_combo = QComboBox()
        self.ref_raster_combo.setToolTip("Rasters will be resampled and aligned to match this reference grid")
        form.addRow("Reference Grid Raster:", self.ref_raster_combo)

        self.crs_combo = QComboBox()
        self.crs_combo.addItems(["Use Reference Raster CRS", "Project CRS", "WGS 84 (EPSG:4326)", "Web Mercator (EPSG:3857)"])
        form.addRow("Target CRS:", self.crs_combo)

        self.resample_combo = QComboBox()
        self.resample_combo.addItems(["bilinear (Recommended for continuous imagery)", "nearest (Preserve classes/zones)", "cubic", "lanczos", "mode"])
        form.addRow("Resampling Algorithm:", self.resample_combo)

        layout.addWidget(grp_grid)
        layout.addStretch()
        return page

    # Page 3: Output Settings & Compression
    def _create_page_3(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)

        # Mode Selection: VRT vs GeoTIFF
        grp_mode = QGroupBox("Output Mode")
        mode_layout = QVBoxLayout(grp_mode)
        self.rb_vrt = QRadioButton("Virtual Raster (.vrt) — Fast, lightweight, zero extra disk usage")
        self.rb_geotiff = QRadioButton("Permanent GeoTIFF (.tif) — Cloud-Optimized, compressed, standalone file")
        self.rb_geotiff.setChecked(True)
        mode_layout.addWidget(self.rb_geotiff)
        mode_layout.addWidget(self.rb_vrt)
        layout.addWidget(grp_mode)

        # GeoTIFF Parameters
        self.grp_tiff_opts = QGroupBox("GeoTIFF & Compression Options")
        tiff_form = QFormLayout(self.grp_tiff_opts)

        self.compress_combo = QComboBox()
        self.compress_combo.addItems(["DEFLATE (Balanced & widely supported)", "LZW", "PACKBITS", "ZSTD", "NONE"])
        tiff_form.addRow("Compression:", self.compress_combo)

        self.chk_tiled = QCheckBox("Tiled Storage (256x256 block size for Cloud-Optimized GeoTIFF)")
        self.chk_tiled.setChecked(True)
        tiff_form.addRow("Tiling:", self.chk_tiled)

        self.chk_overviews = QCheckBox("Build Pyramid Overviews for instant zoom responsiveness")
        self.chk_overviews.setChecked(True)
        tiff_form.addRow("Overviews:", self.chk_overviews)

        layout.addWidget(self.grp_tiff_opts)

        # Destination output path
        out_layout = QHBoxLayout()
        self.txt_output_path = QLineEdit()
        self.txt_output_path.setPlaceholderText("Select output destination file...")
        btn_browse_out = QPushButton("Browse...")
        btn_browse_out.clicked.connect(self._browse_output)
        out_layout.addWidget(self.txt_output_path)
        out_layout.addWidget(btn_browse_out)

        layout.addWidget(QLabel("Output File Destination:"))
        layout.addLayout(out_layout)
        layout.addStretch()

        self.rb_vrt.toggled.connect(lambda v: self.grp_tiff_opts.setEnabled(not v))
        return page

    # Page 4: Execution, Progress & Provenance Report
    def _create_page_4(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)

        self.run_status_lbl = QLabel("Ready to build mosaic. Click 'Run Mosaic' to start.")
        self.run_status_lbl.setStyleSheet("font-size: 13px; font-weight: bold;")
        layout.addWidget(self.run_status_lbl)

        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        layout.addWidget(self.progress_bar)

        self.chk_auto_add = QCheckBox("Automatically add output mosaic layer to active QGIS project")
        self.chk_auto_add.setChecked(True)
        layout.addWidget(self.chk_auto_add)

        self.btn_view_report = QPushButton("View Provenance & Quality Report")
        self.btn_view_report.setIcon(get_icon("report"))
        self.btn_view_report.setEnabled(False)
        self.btn_view_report.clicked.connect(self._open_report_dialog)
        layout.addWidget(self.btn_view_report)

        layout.addStretch()
        return page

    # File Selection Logic
    def _add_files(self):
        files, _ = QFileDialog.getOpenFileNames(
            self,
            "Select Raster Files",
            "",
            "Raster Images (*.tif *.tiff *.vrt *.img *.dem *.nc *.jp2);;All Files (*)"
        )
        if files:
            for f in files:
                if f not in self.input_files:
                    self.input_files.append(f)
            self._run_inspection()

    def _add_canvas_layers(self):
        layers = QgsProject.instance().mapLayers().values()
        for lyr in layers:
            if isinstance(lyr, QgsRasterLayer) and lyr.isValid():
                src = lyr.source()
                if os.path.exists(src) and src not in self.input_files:
                    self.input_files.append(src)
        self._run_inspection()

    def _remove_selected(self):
        rows = sorted(set(idx.row() for idx in self.table_inspector.selectedIndexes()), reverse=True)
        for r in rows:
            if 0 <= r < len(self.input_files):
                del self.input_files[r]
        self._run_inspection()

    def _clear_all(self):
        self.input_files.clear()
        self._run_inspection()

    def _run_inspection(self):
        self.table_inspector.setRowCount(0)
        if not self.input_files:
            self.diag_summary.setText("No rasters selected.")
            self.inspection_report = None
            self.btn_next.setEnabled(False)
            return

        self.inspection_report = RasterInspector.inspect_stack(self.input_files)
        self.table_inspector.setRowCount(len(self.inspection_report.rasters))

        for row, r in enumerate(self.inspection_report.rasters):
            fn_item = QTableWidgetItem(r.filename)
            crs_item = QTableWidgetItem(r.crs_auth_id)
            res_item = QTableWidgetItem(f"{r.pixel_size_x:.4f} x {r.pixel_size_y:.4f}")
            band_item = QTableWidgetItem(str(r.band_count))
            dt_item = QTableWidgetItem(r.data_type_name)

            status_text = "OK" if r.is_readable else "Error"
            status_item = QTableWidgetItem(status_text)
            if not r.is_readable:
                status_item.setForeground(QColor("#D64545"))
            else:
                status_item.setForeground(QColor("#16A36A"))

            self.table_inspector.setItem(row, 0, fn_item)
            self.table_inspector.setItem(row, 1, crs_item)
            self.table_inspector.setItem(row, 2, res_item)
            self.table_inspector.setItem(row, 3, band_item)
            self.table_inspector.setItem(row, 4, dt_item)
            self.table_inspector.setItem(row, 5, status_item)

        # Summary text
        issue_count = len(self.inspection_report.issues)
        if issue_count == 0:
            summary = f"✓ {len(self.input_files)} raster(s) inspected. All rasters are perfectly compatible."
        else:
            issue_texts = [f"• [{i.severity}] {i.title}: {i.description}" for i in self.inspection_report.issues]
            summary = f"Inspection Warnings ({issue_count}):\n" + "\n".join(issue_texts)

        self.diag_summary.setText(summary)
        self.btn_next.setEnabled(self.inspection_report.raster_count > 0)

        # Populate reference rasters on page 2
        self.ref_raster_combo.clear()
        for r in self.inspection_report.rasters:
            if r.is_readable:
                self.ref_raster_combo.addItem(r.filename, r.filepath)

    def _browse_output(self):
        is_vrt = self.rb_vrt.isChecked()
        ext = "vrt" if is_vrt else "tif"
        flt = "Virtual Raster (*.vrt)" if is_vrt else "GeoTIFF Image (*.tif *.tiff)"
        path, _ = QFileDialog.getSaveFileName(self, "Save Output Mosaic", "", flt)
        if path:
            if not path.endswith(f".{ext}"):
                path += f".{ext}"
            self.txt_output_path.setText(path)

    # Navigation
    def _go_prev(self):
        curr = self.stack.currentIndex()
        if curr > 0:
            self.stack.setCurrentIndex(curr - 1)
            self._update_nav(curr - 1)

    def _go_next(self):
        curr = self.stack.currentIndex()
        if curr == 2:
            # Check destination output path
            out_p = self.txt_output_path.text().strip()
            if not out_p:
                QMessageBox.warning(self, "Missing Output Path", "Please select a destination output file path.")
                return
            self.output_mosaic_path = out_p

        if curr < 3:
            self.stack.setCurrentIndex(curr + 1)
            self._update_nav(curr + 1)
        elif curr == 3:
            # Final Step: Execute Mosaic
            self._execute_mosaic()

    def _update_nav(self, idx: int):
        titles = [
            "Step 1 of 4: Select Input Rasters & Preflight Inspection",
            "Step 2 of 4: Grid & Spatial Alignment Settings",
            "Step 3 of 4: Output Format, Compression & Destination",
            "Step 4 of 4: Processing Execution & Provenance Summary",
        ]
        self.header_lbl.setText(titles[idx])
        self.btn_prev.setEnabled(idx > 0)
        self.btn_next.setText("Run Mosaic" if idx == 3 else "Next")

    def _execute_mosaic(self):
        if not self.input_files:
            QMessageBox.warning(self, "No Inputs", "Please add at least one input raster tile.")
            self.tabs.setCurrentIndex(0)
            return

        if not self.output_mosaic_path:
            QMessageBox.warning(self, "Missing Output", "Please specify an output mosaic destination path.")
            self.tabs.setCurrentIndex(2)
            return

        self.btn_next.setEnabled(False)
        self.btn_prev.setEnabled(False)
        self.run_status_lbl.setText("Mosaicking in progress...")
        self.progress_bar.setValue(10)

        is_vrt = self.rb_vrt.isChecked()
        resamp_choice = self.resample_combo.currentText().split()[0]
        compress_choice = self.compress_combo.currentText().split()[0]
        tiled = self.chk_tiled.isChecked()
        overviews = self.chk_overviews.isChecked()

        def background_job(task=None):
            if is_vrt:
                return RasterMosaicker.build_virtual_mosaic(
                    input_paths=self.input_files,
                    output_vrt_path=self.output_mosaic_path,
                    resampling=resamp_choice
                )
            else:
                return RasterMosaicker.create_permanent_mosaic(
                    input_paths=self.input_files,
                    output_tiff_path=self.output_mosaic_path,
                    resampling=resamp_choice,
                    compression=compress_choice,
                    tiled=tiled,
                    build_overviews=overviews
                )

        def on_ok(res_path):
            self.progress_bar.setValue(100)
            self.run_status_lbl.setText(f"✓ Mosaic successfully created at: {res_path}")
            self.btn_view_report.setEnabled(True)

            # Generate sidecar provenance report
            params = {
                "format": "VRT" if is_vrt else "GeoTIFF",
                "resampling": resamp_choice,
                "compression": compress_choice if not is_vrt else "N/A",
                "tiled": tiled if not is_vrt else "N/A"
            }
            metrics = {
                "input_count": len(self.input_files),
                "output_size_bytes": os.path.getsize(res_path) if os.path.exists(res_path) else 0
            }
            self.last_provenance_data = ProvenanceReportGenerator.generate_report(
                operation_name="Virtual Mosaic" if is_vrt else "Permanent Mosaic",
                input_files=self.input_files,
                output_file=res_path,
                parameters=params,
                metrics=metrics,
                warnings=[i.description for i in self.inspection_report.issues] if self.inspection_report else []
            )
            ProvenanceReportGenerator.save_sidecar_report(self.last_provenance_data, res_path)

            if self.chk_auto_add.isChecked():
                layer = QgsRasterLayer(res_path, os.path.basename(res_path))
                if layer.isValid():
                    QgsProject.instance().addMapLayer(layer)

            self.btn_next.setText("Finish")
            self.btn_next.setEnabled(True)
            try:
                self.btn_next.clicked.disconnect()
            except Exception as e:
                from ..core.logging import log_info
                log_info(f"Signal disconnect note: {e}")
            self.btn_next.clicked.connect(self.accept)

        def on_err(exc):
            self.progress_bar.setValue(0)
            self.run_status_lbl.setText(f"Error: {str(exc)}")
            QMessageBox.critical(self, "Mosaic Failed", f"Mosaic operation failed:\n{str(exc)}")
            self.btn_next.setEnabled(True)
            self.btn_prev.setEnabled(True)

        run_in_background(
            "Creating Mosaic",
            background_job,
            on_completed=on_ok,
            on_failed=on_err,
            on_progress=lambda p: self.progress_bar.setValue(int(p))
        )

    def _open_report_dialog(self):
        if self.last_provenance_data:
            dlg = ReportViewerDialog(self.last_provenance_data, self)
            dlg.exec()

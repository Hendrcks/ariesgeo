"""
AriesGapfill 6-Step Guided Wizard Dialog for QGIS.
Integrates USGS / ENVI `landsat_gapfill` Local Linear Histogram Matching (LLHM),
Global Histogram Matching (GLHM), Multi-Donor Smart Compositing, and Single-File
Delaunay Triangulation for both Landsat 7 SLC-Off stripes and Clouds/Shadows.
"""

import os
from typing import Optional, List, Tuple
from qgis.PyQt.QtWidgets import (
    QDialog,
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QStackedWidget,
    QLabel,
    QPushButton,
    QComboBox,
    QLineEdit,
    QCheckBox,
    QSpinBox,
    QDoubleSpinBox,
    QGroupBox,
    QFormLayout,
    QRadioButton,
    QMessageBox,
    QFileDialog,
    QTableWidget,
    QTableWidgetItem,
    QHeaderView,
    QProgressBar,
    QButtonGroup,
)
from qgis.PyQt.QtCore import Qt
from qgis.core import QgsProject, QgsRasterLayer

from ..resources import get_icon
from ..core.logging import log_warning
from ..core.task_manager import run_in_background
from ..gapfill.models import (
    GapFillMethod,
    GapMaskSource,
    DonorSpec,
    MethodParameters,
    GapFillConfig,
    GapFillResult,
)
from ..gapfill.engine import AriesGapFillEngine


class AriesGapfillWizardDialog(QDialog):
    """6-Step Guided Wizard for Landsat 7 SLC-off, Cloud/Shadow, and Raster Gap Filling."""

    def __init__(self, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.setWindowTitle("AriesGapfill — Landsat SLC-Off & Cloud Recovery Wizard")
        self.setWindowIcon(get_icon("gapfill"))
        self.resize(780, 580)

        self.current_step = 0
        self.total_steps = 6
        self.last_result: Optional[GapFillResult] = None
        self._active_worker = None

        self._setup_ui()
        self.refresh_project_layers()

    def _setup_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(12, 12, 12, 12)
        main_layout.setSpacing(8)

        # Header Title Banner (native theme-adaptive)
        self.header_banner = QLabel("<b>AriesGapfill</b> — USGS Local Histogram Matching (LLHM), Multi-Donor & Delaunay Triangulation")
        main_layout.addWidget(self.header_banner)

        # Step Indicator
        self.step_label = QLabel("Step 1 of 6: Select Gap & Cloud Recovery Method")
        main_layout.addWidget(self.step_label)

        # Stacked Pages
        self.stack = QStackedWidget()
        self._create_page_1_method()
        self._create_page_2_inputs()
        self._create_page_3_alignment()
        self._create_page_4_parameters()
        self._create_page_5_outputs()
        self._create_page_6_results()
        main_layout.addWidget(self.stack, 1)

        # Bottom Navigation Buttons
        btn_layout = QHBoxLayout()
        self.btn_back = QPushButton("← Back")
        self.btn_back.clicked.connect(self._prev_step)
        self.btn_back.setEnabled(False)
        self.btn_prev = self.btn_back

        self.btn_next = QPushButton("Next →")
        self.btn_next.setDefault(True)
        self.btn_next.clicked.connect(self._next_step)

        self.btn_cancel = QPushButton("Close")
        self.btn_cancel.clicked.connect(self.close)

        btn_layout.addWidget(self.btn_back)
        btn_layout.addStretch()
        btn_layout.addWidget(self.btn_cancel)
        btn_layout.addWidget(self.btn_next)
        main_layout.addLayout(btn_layout)

    def refresh_project_layers(self):
        """Populate raster selectors from loaded QGIS project layers."""
        rasters: List[Tuple[str, str]] = []
        try:
            for lyr in QgsProject.instance().mapLayers().values():
                if isinstance(lyr, QgsRasterLayer) and lyr.isValid():
                    src = lyr.source().split("|")[0]
                    if os.path.exists(src):
                        rasters.append((f"{lyr.name()}  ({os.path.basename(src)})", src))
        except (AttributeError, RuntimeError) as lyr_err:
            log_warning(f"Could not enumerate project raster layers: {lyr_err}")

        for cmb in (self.cmb_target_layer, self.cmb_donor_layer):
            cmb.blockSignals(True)
            cmb.clear()
            cmb.addItem("— Select from loaded QGIS Raster Layers (or browse below) —", "")
            for label, src in rasters:
                cmb.addItem(label, src)
            cmb.blockSignals(False)

    # -------------------------------------------------------------
    # Page 1: Method Selection
    # -------------------------------------------------------------
    def _create_page_1_method(self):
        page = QWidget()
        layout = QVBoxLayout(page)

        lbl = QLabel("<b>Choose the gap / cloud restoration algorithm (USGS / ENVI Gapfill Suite):</b>")
        layout.addWidget(lbl)

        self.method_group = QButtonGroup(self)

        self.rb_local = QRadioButton("Two Images — Local Linear Histogram Matching (USGS Phase-2 LLHM, Recommended)")
        self.rb_local.setChecked(True)
        lbl_local = QLabel("    Adaptive moving-window gain & bias matching (Scaramuzza et al. 2004). Preserves full local contrast across heterogeneous terrain.")

        self.rb_global = QRadioButton("Two Images — Global Statistical / Histogram Matching (USGS Phase-1 GLHM)")
        lbl_global = QLabel("    Scene-wide robust gain/offset calibration with MAD outlier rejection. Fast and effective for uniform scenes.")

        self.rb_multi = QRadioButton("Multiple Donors — Smart Multi-Scene Composite + Residual Triangulation")
        lbl_multi = QLabel("    Ranks multiple clear/SLC-off donor dates by correlation & overlap, sequentially filling every gap and cloud.")

        self.rb_tri = QRadioButton("Single Image — Delaunay Triangulation (Single-File Spatial Gapfill)")
        lbl_tri = QLabel("    Restores missing scanlines or cloud voids from surrounding valid support pixels when no donor scene is available.")

        for w in (lbl_local, lbl_global, lbl_multi, lbl_tri):
            w.setWordWrap(True)

        self.method_group.addButton(self.rb_local, 0)
        self.method_group.addButton(self.rb_global, 1)
        self.method_group.addButton(self.rb_multi, 2)
        self.method_group.addButton(self.rb_tri, 3)

        for rb, desc in (
            (self.rb_local, lbl_local),
            (self.rb_global, lbl_global),
            (self.rb_multi, lbl_multi),
            (self.rb_tri, lbl_tri),
        ):
            layout.addWidget(rb)
            layout.addWidget(desc)
            layout.addSpacing(4)

        layout.addStretch()
        self.stack.addWidget(page)

    # -------------------------------------------------------------
    # Page 2: Inputs & Donors
    # -------------------------------------------------------------
    def _create_page_2_inputs(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        form = QFormLayout()

        # Target raster (QGIS layer combo + path)
        t_vbox = QVBoxLayout()
        self.cmb_target_layer = QComboBox()
        self.cmb_target_layer.currentIndexChanged.connect(self._on_target_combo_changed)
        t_box = QHBoxLayout()
        self.txt_target = QLineEdit()
        self.txt_target.setPlaceholderText("Select target SLC-off or cloudy raster (*.tif)...")
        btn_t = QPushButton("Browse...")
        btn_t.clicked.connect(self._browse_target)
        t_box.addWidget(self.txt_target, 1)
        t_box.addWidget(btn_t)
        t_vbox.addWidget(self.cmb_target_layer)
        t_vbox.addLayout(t_box)
        form.addRow("<b>Target Raster:</b>", t_vbox)

        # Donor raster (Single)
        d_vbox = QVBoxLayout()
        self.cmb_donor_layer = QComboBox()
        self.cmb_donor_layer.currentIndexChanged.connect(self._on_donor_combo_changed)
        d_box = QHBoxLayout()
        self.txt_donor = QLineEdit()
        self.txt_donor.setPlaceholderText("Select fill / donor raster (*.tif)...")
        btn_d = QPushButton("Browse...")
        btn_d.clicked.connect(self._browse_donor)
        d_box.addWidget(self.txt_donor, 1)
        d_box.addWidget(btn_d)
        d_vbox.addWidget(self.cmb_donor_layer)
        d_vbox.addLayout(d_box)
        form.addRow("<b>Primary Donor:</b>", d_vbox)

        # Multi-donor Table
        self.tbl_donors = QTableWidget(0, 2)
        self.tbl_donors.setHorizontalHeaderLabels(["Donor Filepath", "Status"])
        self.tbl_donors.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.tbl_donors.setFixedHeight(95)
        self.tbl_donors.hide()

        multi_btns = QHBoxLayout()
        self.btn_add_multi_d = QPushButton("+ Add Donor Files...")
        self.btn_add_multi_d.clicked.connect(self._add_multi_donor)
        self.btn_add_layer_d = QPushButton("+ Add Selected Donor Layer")
        self.btn_add_layer_d.clicked.connect(self._add_multi_donor_from_combo)
        self.btn_rem_multi_d = QPushButton("Remove Selected")
        self.btn_rem_multi_d.clicked.connect(self._remove_multi_donor)
        multi_btns.addWidget(self.btn_add_multi_d)
        multi_btns.addWidget(self.btn_add_layer_d)
        multi_btns.addWidget(self.btn_rem_multi_d)
        multi_btns.addStretch()

        self.box_multi_donor = QVBoxLayout()
        self.box_multi_donor.addWidget(self.tbl_donors)
        self.box_multi_donor.addLayout(multi_btns)

        # Gap Mask Source (including unified SLC-Off + Clouds!)
        self.cmb_mask_source = QComboBox()
        self.cmb_mask_source.addItem("Auto NoData & Zero Scan-Line Gaps (SLC-Off)", GapMaskSource.NODATA)
        self.cmb_mask_source.addItem("Unified SLC-Off Stripes + Clouds + Cloud Shadows", GapMaskSource.SLC_AND_CLOUDS)
        self.cmb_mask_source.addItem("Spectral Clouds & Cloud Shadows Only", GapMaskSource.CLOUDS_ONLY)
        self.cmb_mask_source.addItem("Zero Values Strictly (DN = 0)", GapMaskSource.ZERO_VALUE)
        self.cmb_mask_source.addItem("Custom Binary Mask File (1 = Gap/Cloud, 0 = Valid)", GapMaskSource.CUSTOM_MASK)
        self.cmb_mask_source.addItem("Landsat Collection 2 QA_PIXEL Bitmask", GapMaskSource.AUTO_QA)
        form.addRow("<b>Gap / Cloud Mask:</b>", self.cmb_mask_source)

        # Custom / QA mask path
        m_box = QHBoxLayout()
        self.txt_custom_mask = QLineEdit()
        self.txt_custom_mask.setPlaceholderText("Optional external binary mask or QA_PIXEL raster (*.tif)...")
        btn_m = QPushButton("Browse...")
        btn_m.clicked.connect(self._browse_custom_mask)
        m_box.addWidget(self.txt_custom_mask, 1)
        m_box.addWidget(btn_m)
        form.addRow("External Mask / QA:", m_box)

        layout.addLayout(form)
        layout.addLayout(self.box_multi_donor)
        layout.addStretch()

        self.stack.addWidget(page)

    # -------------------------------------------------------------
    # Page 3: Alignment & QA Masks
    # -------------------------------------------------------------
    def _create_page_3_alignment(self):
        page = QWidget()
        layout = QVBoxLayout(page)

        self.lbl_align_status = QLabel("<b>Grid Co-Registration & Cloud Screening Ready</b>")
        layout.addWidget(self.lbl_align_status)

        qa_box = QGroupBox("Donor & Target Quality Assurance Screening")
        qa_layout = QVBoxLayout(qa_box)

        self.chk_mask_cloud = QCheckBox("Automatically detect and exclude Clouds in Donor scene(s)")
        self.chk_mask_cloud.setChecked(True)
        self.chk_mask_shadow = QCheckBox("Automatically detect and exclude Cast Cloud Shadows")
        self.chk_mask_shadow.setChecked(True)
        self.chk_mask_snow = QCheckBox("Exclude Snow / Ice flags when QA_PIXEL band is provided")
        self.chk_mask_snow.setChecked(False)

        qa_layout.addWidget(self.chk_mask_cloud)
        qa_layout.addWidget(self.chk_mask_shadow)
        qa_layout.addWidget(self.chk_mask_snow)
        layout.addWidget(qa_box)

        resample_box = QGroupBox("Automated Spatial Grid Harmonization")
        res_layout = QVBoxLayout(resample_box)
        self.chk_auto_resample = QCheckBox("Automatically warp & co-register donor scenes if CRS, extent, or dimensions differ")
        self.chk_auto_resample.setChecked(True)
        self.chk_residual_tri = QCheckBox("Fill any leftover unrecovered overlap holes using Single-Scene Delaunay Triangulation")
        self.chk_residual_tri.setChecked(True)
        res_layout.addWidget(self.chk_auto_resample)
        res_layout.addWidget(self.chk_residual_tri)
        layout.addWidget(resample_box)

        layout.addStretch()
        self.stack.addWidget(page)

    # -------------------------------------------------------------
    # Page 4: Parameters
    # -------------------------------------------------------------
    def _create_page_4_parameters(self):
        page = QWidget()
        layout = QVBoxLayout(page)

        param_box = QGroupBox("USGS Local Histogram Matching (LLHM) & Cloud Parameters")
        p_form = QFormLayout(param_box)

        self.spn_window = QSpinBox()
        self.spn_window.setRange(9, 201)
        self.spn_window.setSingleStep(8)
        self.spn_window.setValue(33)
        self.spn_window.setSuffix(" px")
        p_form.addRow("Initial Moving Window Size:", self.spn_window)

        self.spn_min_samples = QSpinBox()
        self.spn_min_samples.setRange(15, 1000)
        self.spn_min_samples.setValue(25)
        p_form.addRow("Minimum Clear Paired Samples:", self.spn_min_samples)

        self.spn_corr_thresh = QDoubleSpinBox()
        self.spn_corr_thresh.setRange(0.10, 0.99)
        self.spn_corr_thresh.setSingleStep(0.05)
        self.spn_corr_thresh.setValue(0.70)
        p_form.addRow("Correlation Diagnostic Threshold:", self.spn_corr_thresh)

        self.spn_cloud_thresh = QDoubleSpinBox()
        self.spn_cloud_thresh.setRange(0.10, 0.95)
        self.spn_cloud_thresh.setSingleStep(0.05)
        self.spn_cloud_thresh.setValue(0.60)
        p_form.addRow("Spectral Cloud Brightness Threshold:", self.spn_cloud_thresh)

        self.chk_robust = QCheckBox("Enable USGS 2.5σ / MAD Residual Outlier Rejection")
        self.chk_robust.setChecked(True)
        p_form.addRow("", self.chk_robust)

        self.spn_feather = QSpinBox()
        self.spn_feather.setRange(0, 10)
        self.spn_feather.setValue(2)
        self.spn_feather.setSuffix(" px")
        p_form.addRow("Boundary Seam Feathering Width:", self.spn_feather)

        layout.addWidget(param_box)
        layout.addStretch()
        self.stack.addWidget(page)

    # -------------------------------------------------------------
    # Page 5: Output Destinations
    # -------------------------------------------------------------
    def _create_page_5_outputs(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        form = QFormLayout()

        o_box = QHBoxLayout()
        self.txt_output = QLineEdit()
        self.txt_output.setPlaceholderText("Output repaired raster path (*.tif)...")
        btn_o = QPushButton("Browse...")
        btn_o.clicked.connect(self._browse_output)
        o_box.addWidget(self.txt_output, 1)
        o_box.addWidget(btn_o)
        form.addRow("<b>Output Repaired Raster:</b>", o_box)

        prod_box = QGroupBox("Generated Quality & Provenance Products")
        prod_layout = QVBoxLayout(prod_box)

        self.chk_gen_provenance = QCheckBox("Generate Provenance Raster (0=Original, 1=Triangulation, 2+=Donor)")
        self.chk_gen_provenance.setChecked(True)
        self.chk_gen_confidence = QCheckBox("Generate Normalized Confidence Raster (0–100 Score)")
        self.chk_gen_confidence.setChecked(True)
        self.chk_gen_remaining = QCheckBox("Generate Remaining-Gap Mask Raster")
        self.chk_gen_remaining.setChecked(True)
        self.chk_gen_report = QCheckBox("Generate HTML & JSON Scientific Audit Report")
        self.chk_gen_report.setChecked(True)

        prod_layout.addWidget(self.chk_gen_provenance)
        prod_layout.addWidget(self.chk_gen_confidence)
        prod_layout.addWidget(self.chk_gen_remaining)
        prod_layout.addWidget(self.chk_gen_report)

        layout.addLayout(form)
        layout.addWidget(prod_box)
        layout.addStretch()
        self.stack.addWidget(page)

    # -------------------------------------------------------------
    # Page 6: Execution & Results
    # -------------------------------------------------------------
    def _create_page_6_results(self):
        page = QWidget()
        layout = QVBoxLayout(page)

        self.lbl_exec_status = QLabel("Ready to start gap & cloud restoration.")
        self.lbl_exec_status.setWordWrap(True)
        layout.addWidget(self.lbl_exec_status)

        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        layout.addWidget(self.progress_bar)

        self.results_table = QTableWidget(0, 5)
        self.results_table.setHorizontalHeaderLabels(["Band", "Original Gaps", "Filled", "Fill Rate", "Harmonization Summary"])
        self.results_table.horizontalHeader().setSectionResizeMode(4, QHeaderView.ResizeMode.Stretch)
        layout.addWidget(self.results_table, 1)

        btn_box = QHBoxLayout()
        self.btn_open_report = QPushButton("Open HTML Audit Report")
        self.btn_open_report.clicked.connect(self._open_report)
        self.btn_open_report.setEnabled(False)

        self.btn_load_layers = QPushButton("Load Repaired Layers into QGIS")
        self.btn_load_layers.clicked.connect(self._load_layers)
        self.btn_load_layers.setEnabled(False)

        btn_box.addWidget(self.btn_open_report)
        btn_box.addWidget(self.btn_load_layers)
        layout.addLayout(btn_box)

        self.stack.addWidget(page)

    # -------------------------------------------------------------
    # Navigation & Step Handling
    # -------------------------------------------------------------
    def _next_step(self):
        if self.current_step == 0:
            self.refresh_project_layers()
            method_idx = self.method_group.checkedId()
            is_multi = (method_idx == 2)
            is_tri = (method_idx == 3)

            self.tbl_donors.setVisible(is_multi)
            self.btn_add_multi_d.setVisible(is_multi)
            self.btn_add_layer_d.setVisible(is_multi)
            self.btn_rem_multi_d.setVisible(is_multi)
            self.txt_donor.setEnabled(not is_tri and not is_multi)
            self.cmb_donor_layer.setEnabled(not is_tri)

            self.current_step = 1
            self.stack.setCurrentIndex(1)
            self.step_label.setText("Step 2 of 6: Select Inputs & Donors")
            self.btn_back.setEnabled(True)

        elif self.current_step == 1:
            t_path = self.txt_target.text().strip()
            if not t_path or not os.path.exists(t_path):
                QMessageBox.warning(self, "Missing Target", "Please select a valid target raster layer or file.")
                return

            method_idx = self.method_group.checkedId()
            if method_idx in (0, 1):
                d_path = self.txt_donor.text().strip()
                if not d_path or not os.path.exists(d_path):
                    QMessageBox.warning(self, "Missing Donor", "Please select a valid donor raster (or switch to Step 1 -> Single Image Delaunay Triangulation).")
                    return
            elif method_idx == 2 and self.tbl_donors.rowCount() == 0:
                QMessageBox.warning(self, "Missing Donors", "Please add at least one donor scene to the multi-donor table.")
                return

            if not self.txt_output.text().strip():
                d = os.path.dirname(os.path.abspath(t_path))
                fn = os.path.splitext(os.path.basename(t_path))[0]
                self.txt_output.setText(os.path.join(d, f"{fn}_gapfilled.tif"))

            self.current_step = 2
            self.stack.setCurrentIndex(2)
            self.step_label.setText("Step 3 of 6: Alignment & QA Screening")

        elif self.current_step == 2:
            self.current_step = 3
            self.stack.setCurrentIndex(3)
            self.step_label.setText("Step 4 of 6: Configure LLHM & Cloud Parameters")

        elif self.current_step == 3:
            self.current_step = 4
            self.stack.setCurrentIndex(4)
            self.step_label.setText("Step 5 of 6: Outputs & Provenance Products")
            self.btn_next.setText("Run AriesGapfill →")

        elif self.current_step == 4:
            self.current_step = 5
            self.stack.setCurrentIndex(5)
            self.step_label.setText("Step 6 of 6: Execution & Quality Audit")
            self.btn_back.setEnabled(False)
            self.btn_next.setEnabled(False)
            self.btn_next.setText("Done")
            self._execute_gapfill()

        elif self.current_step == 5:
            self.close()

    def _prev_step(self):
        if self.current_step > 0:
            self.current_step -= 1
            self.stack.setCurrentIndex(self.current_step)
            self.step_label.setText(f"Step {self.current_step + 1} of 6")
            self.btn_next.setText("Next →" if self.current_step < 4 else "Run AriesGapfill →")
            self.btn_next.setEnabled(True)
            if self.current_step == 0:
                self.btn_back.setEnabled(False)

    # -------------------------------------------------------------
    # Execution
    # -------------------------------------------------------------
    def _execute_gapfill(self):
        method_idx = self.method_group.checkedId()
        method_map = {
            0: GapFillMethod.LOCAL_MATCHING,
            1: GapFillMethod.GLOBAL_MATCHING,
            2: GapFillMethod.MULTI_DONOR,
            3: GapFillMethod.TRIANGULATION,
        }
        method = method_map.get(method_idx, GapFillMethod.LOCAL_MATCHING)
        mask_source = self.cmb_mask_source.currentData() or GapMaskSource.NODATA

        donors: List[DonorSpec] = []
        if method == GapFillMethod.MULTI_DONOR:
            for r in range(self.tbl_donors.rowCount()):
                p = self.tbl_donors.item(r, 0).text()
                if p and os.path.exists(p):
                    donors.append(DonorSpec(filepath=p))
        elif method != GapFillMethod.TRIANGULATION:
            d_path = self.txt_donor.text().strip()
            if d_path and os.path.exists(d_path):
                donors.append(DonorSpec(filepath=d_path))

        params = MethodParameters(
            initial_window_size=self.spn_window.value(),
            min_paired_samples=self.spn_min_samples.value(),
            correlation_threshold=self.spn_corr_thresh.value(),
            use_robust_regression=self.chk_robust.isChecked(),
            seam_feather_width=self.spn_feather.value(),
            cloud_brightness_threshold=self.spn_cloud_thresh.value(),
            residual_triangulation_fallback=self.chk_residual_tri.isChecked(),
        )

        config = GapFillConfig(
            target_path=self.txt_target.text().strip(),
            method=method,
            output_filled_path=self.txt_output.text().strip(),
            donors=donors,
            mask_source=mask_source,
            custom_mask_path=self.txt_custom_mask.text().strip() or None,
            mask_clouds=self.chk_mask_cloud.isChecked(),
            mask_shadows=self.chk_mask_shadow.isChecked(),
            mask_snow=self.chk_mask_snow.isChecked(),
            auto_resample_donors=self.chk_auto_resample.isChecked(),
            parameters=params,
            generate_provenance=self.chk_gen_provenance.isChecked(),
            generate_confidence=self.chk_gen_confidence.isChecked(),
            generate_remaining_gap_mask=self.chk_gen_remaining.isChecked(),
            generate_report=self.chk_gen_report.isChecked(),
        )

        if not config.target_path or not os.path.exists(config.target_path):
            QMessageBox.warning(self, "Invalid Target", "Please select a valid target raster file.")
            self.current_step = 1
            self.stack.setCurrentIndex(1)
            return

        if not config.output_filled_path:
            QMessageBox.warning(self, "Missing Output", "Please specify an output file path for the repaired raster.")
            self.current_step = 4
            self.stack.setCurrentIndex(4)
            return

        if method != GapFillMethod.TRIANGULATION and not donors:
            QMessageBox.warning(self, "Missing Donor", f"The '{method.value}' method requires at least one valid donor scene.")
            self.current_step = 1
            self.stack.setCurrentIndex(1)
            return

        self.lbl_exec_status.setText(f"Executing {method.value} gap & cloud restoration...")
        self.progress_bar.setValue(5)
        self.btn_next.setEnabled(False)
        self.btn_back.setEnabled(False)

        def job(task=None):
            def on_progress(p, msg):
                if task is not None:
                    if task.is_canceled():
                        raise Exception("Task canceled by user.")
                    task.report_progress(float(p), msg)

            return AriesGapFillEngine.execute(config, progress_callback=on_progress)

        def on_prog_update(val, msg=""):
            self.progress_bar.setValue(int(val))
            if msg:
                self.lbl_exec_status.setText(msg)

        def on_ok(res: GapFillResult):
            self.last_result = res
            self.progress_bar.setValue(100)
            self.lbl_exec_status.setText(
                f"Completed in {res.execution_time_seconds}s — Fill Rate: {res.overall_fill_rate_pct:.1f}% "
                f"(Mean Confidence: {res.mean_confidence_score:.0f}/100)"
            )
            self.btn_next.setEnabled(True)
            self.btn_back.setEnabled(True)
            self.btn_open_report.setEnabled(bool(res.output_report_path))
            self.btn_load_layers.setEnabled(True)

            self.results_table.setRowCount(len(res.band_stats))
            for r, b in enumerate(res.band_stats):
                self.results_table.setItem(r, 0, QTableWidgetItem(f"Band {b.band_index}"))
                self.results_table.setItem(r, 1, QTableWidgetItem(f"{b.original_gaps:,}"))
                self.results_table.setItem(r, 2, QTableWidgetItem(f"{b.filled_pixels:,}"))
                self.results_table.setItem(r, 3, QTableWidgetItem(f"{b.fill_rate_pct:.1f}%"))
                self.results_table.setItem(
                    r, 4, QTableWidgetItem(f"Gain={b.slope:.3f}, Bias={b.intercept:.2f} (r={b.correlation:.2f})")
                )

        def on_err(err):
            self.progress_bar.setValue(0)
            self.lbl_exec_status.setText(f"Execution Failed: {err}")
            self.btn_next.setEnabled(True)
            self.btn_back.setEnabled(True)
            QMessageBox.critical(self, "AriesGapfill Error", f"Error during gap filling:\n{err}")

        self._active_worker = run_in_background(
            "AriesGapfill Execution",
            job,
            on_completed=on_ok,
            on_failed=on_err,
            on_progress=on_prog_update,
        )

    def _on_target_combo_changed(self, idx: int):
        p = self.cmb_target_layer.itemData(idx)
        if p and os.path.exists(p):
            self.txt_target.setText(p)

    def _on_donor_combo_changed(self, idx: int):
        p = self.cmb_donor_layer.itemData(idx)
        if p and os.path.exists(p):
            self.txt_donor.setText(p)

    def _browse_target(self):
        fn, _ = QFileDialog.getOpenFileName(self, "Select Target Raster", "", "Raster Images (*.tif *.tiff *.jp2 *.img *.vrt);;All Files (*.*)")
        if fn:
            self.txt_target.setText(fn)

    def _browse_donor(self):
        fn, _ = QFileDialog.getOpenFileName(self, "Select Donor Raster", "", "Raster Images (*.tif *.tiff *.jp2 *.img *.vrt);;All Files (*.*)")
        if fn:
            self.txt_donor.setText(fn)

    def _browse_custom_mask(self):
        fn, _ = QFileDialog.getOpenFileName(self, "Select Custom / QA Mask", "", "Raster Images (*.tif *.tiff *.jp2 *.img);;All Files (*.*)")
        if fn:
            self.txt_custom_mask.setText(fn)

    def _browse_output(self):
        fn, _ = QFileDialog.getSaveFileName(self, "Save Repaired Raster", "", "GeoTIFF (*.tif *.tiff)")
        if fn:
            if not fn.lower().endswith((".tif", ".tiff")):
                fn += ".tif"
            self.txt_output.setText(fn)

    def _add_multi_donor(self):
        fns, _ = QFileDialog.getOpenFileNames(self, "Select Candidate Donors", "", "Raster Images (*.tif *.tiff *.jp2 *.img *.vrt);;All Files (*.*)")
        existing = {self.tbl_donors.item(r, 0).text() for r in range(self.tbl_donors.rowCount())}
        for fn in fns:
            if fn not in existing:
                r = self.tbl_donors.rowCount()
                self.tbl_donors.insertRow(r)
                self.tbl_donors.setItem(r, 0, QTableWidgetItem(fn))
                self.tbl_donors.setItem(r, 1, QTableWidgetItem("Ready"))

    def _add_multi_donor_from_combo(self):
        fn = self.cmb_donor_layer.currentData()
        if fn and os.path.exists(fn):
            existing = {self.tbl_donors.item(r, 0).text() for r in range(self.tbl_donors.rowCount())}
            if fn not in existing:
                r = self.tbl_donors.rowCount()
                self.tbl_donors.insertRow(r)
                self.tbl_donors.setItem(r, 0, QTableWidgetItem(fn))
                self.tbl_donors.setItem(r, 1, QTableWidgetItem("From QGIS Layer"))

    def _remove_multi_donor(self):
        rows = sorted({idx.row() for idx in self.tbl_donors.selectedIndexes()}, reverse=True)
        for r in rows:
            self.tbl_donors.removeRow(r)

    def _open_report(self):
        if self.last_result and self.last_result.output_report_path:
            p = self.last_result.output_report_path
            if os.path.exists(p):
                import webbrowser
                webbrowser.open(f"file:///{os.path.abspath(p).replace(os.sep, '/')}")

    def _load_layers(self):
        if not self.last_result:
            return
        proj = QgsProject.instance()

        f_layer = QgsRasterLayer(self.last_result.output_filled_path, "AriesGapfill Repaired Scene")
        if f_layer.isValid():
            proj.addMapLayer(f_layer)

        if self.last_result.output_confidence_path and os.path.exists(self.last_result.output_confidence_path):
            c_layer = QgsRasterLayer(self.last_result.output_confidence_path, "AriesGapfill Confidence (0-100)")
            if c_layer.isValid():
                proj.addMapLayer(c_layer)

        if self.last_result.output_provenance_path and os.path.exists(self.last_result.output_provenance_path):
            p_layer = QgsRasterLayer(self.last_result.output_provenance_path, "AriesGapfill Provenance Mask")
            if p_layer.isValid():
                proj.addMapLayer(p_layer)

        QMessageBox.information(self, "Layers Loaded", "Repaired raster and QA masks added to QGIS layer tree.")

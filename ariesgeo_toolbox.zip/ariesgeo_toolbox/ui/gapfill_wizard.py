"""
AriesGapfill 6-Step Guided Wizard Dialog for QGIS.
"""

import os
from typing import Optional, List
from qgis.PyQt.QtWidgets import (
    QDialog, QWidget, QVBoxLayout, QHBoxLayout, QStackedWidget,
    QLabel, QPushButton, QComboBox, QLineEdit, QCheckBox, QSpinBox,
    QDoubleSpinBox, QGroupBox, QFormLayout, QRadioButton, QMessageBox,
    QFileDialog, QTableWidget, QTableWidgetItem, QHeaderView, QProgressBar,
    QButtonGroup, QFrame
)
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QColor, QFont
from qgis.core import QgsProject, QgsRasterLayer
from qgis.gui import QgisInterface

from ..resources import get_icon
from ..core.task_manager import run_in_background
from ..gapfill.models import (
    GapFillMethod, GapMaskSource, DonorSpec, MethodParameters,
    GapFillConfig, GapFillResult
)
from ..gapfill.engine import AriesGapFillEngine


class AriesGapfillWizardDialog(QDialog):
    """6-Step Guided Wizard for Landsat 7 SLC-off and Raster Gap Filling."""

    def __init__(self, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.setWindowTitle("AriesGapfill — Landsat 7 & Raster Gap Fill Wizard")
        self.setWindowIcon(get_icon("gapfill"))
        self.resize(780, 560)

        self.current_step = 0
        self.total_steps = 6
        self.last_result: Optional[GapFillResult] = None

        self._setup_ui()

    def _setup_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(14, 14, 14, 14)
        main_layout.setSpacing(10)

        # Header Title Banner
        self.header_banner = QLabel("<b>AriesGapfill</b> — Landsat 7 ETM+ SLC-Off & Raster Gap Filling")
        self.header_banner.setStyleSheet("""
            QLabel {
                font-size: 14px;
                color: #0B1F33;
                background-color: #ECFDF5;
                border-left: 4px solid #10B981;
                padding: 8px 12px;
                border-radius: 4px;
            }
        """)
        main_layout.addWidget(self.header_banner)

        # Step Indicator
        self.step_label = QLabel("Step 1 of 6: Select Gap Filling Method")
        self.step_label.setStyleSheet("color: #64748B; font-weight: bold; font-size: 11px;")
        main_layout.addWidget(self.step_label)

        # Stacked Pages
        self.stack = QStackedWidget()
        self._create_page_1_method()
        self._create_page_2_inputs()
        self._create_page_3_alignment()
        self._create_page_4_parameters()
        self._create_page_5_outputs()
        self._create_page_6_results()
        main_layout.addWidget(self.stack)

        # Bottom Navigation Buttons
        btn_layout = QHBoxLayout()
        self.btn_back = QPushButton("← Back")
        self.btn_back.clicked.connect(self._prev_step)
        self.btn_back.setEnabled(False)
        self.btn_prev = self.btn_back  # Alias for backward compatibility

        self.btn_next = QPushButton("Next →")
        self.btn_next.setStyleSheet("""
            QPushButton {
                background-color: #10B981;
                color: white;
                font-weight: bold;
                padding: 6px 16px;
                border-radius: 4px;
            }
            QPushButton:hover { background-color: #059669; }
        """)
        self.btn_next.clicked.connect(self._next_step)

        self.btn_cancel = QPushButton("Cancel")
        self.btn_cancel.clicked.connect(self.reject)

        btn_layout.addWidget(self.btn_back)
        btn_layout.addStretch()
        btn_layout.addWidget(self.btn_cancel)
        btn_layout.addWidget(self.btn_next)
        main_layout.addLayout(btn_layout)

    # -------------------------------------------------------------
    # Page 1: Method Selection
    # -------------------------------------------------------------
    def _create_page_1_method(self):
        page = QWidget()
        layout = QVBoxLayout(page)

        lbl = QLabel("Choose the optimal gap filling algorithm for your scene:")
        lbl.setStyleSheet("font-weight: bold; margin-bottom: 6px;")
        layout.addWidget(lbl)

        self.method_group = QButtonGroup(self)

        self.rb_local = QRadioButton("Two Images — Local Matching (Recommended)")
        self.rb_local.setChecked(True)
        lbl_local = QLabel("  Moving-window local linear regression. Best for complex, heterogeneous landscapes with varying illumination or land cover.")
        lbl_local.setStyleSheet("color: #64748B; margin-left: 24px; margin-bottom: 8px;")

        self.rb_global = QRadioButton("Two Images — Global Statistical Matching")
        lbl_global = QLabel("  Fast global mean/std-dev and linear regression matching. Ideal for homogeneous terrain or quick previewing.")
        lbl_global.setStyleSheet("color: #64748B; margin-left: 24px; margin-bottom: 8px;")

        self.rb_multi = QRadioButton("Multiple Donors — Smart Composite (Multi-Scene)")
        lbl_multi = QLabel("  Evaluates and ranks multiple candidate donor acquisitions to select the best pixel-by-pixel donor.")
        lbl_multi.setStyleSheet("color: #64748B; margin-left: 24px; margin-bottom: 8px;")

        self.rb_tri = QRadioButton("Single Image — Delaunay Triangulation (Spatial Interpolation)")
        lbl_tri = QLabel("  Fills gaps using surrounding valid pixels via Delaunay triangulation. Best when no clear donor scene exists.")
        lbl_tri.setStyleSheet("color: #64748B; margin-left: 24px; margin-bottom: 8px;")

        self.method_group.addButton(self.rb_local, 0)
        self.method_group.addButton(self.rb_global, 1)
        self.method_group.addButton(self.rb_multi, 2)
        self.method_group.addButton(self.rb_tri, 3)

        layout.addWidget(self.rb_local)
        layout.addWidget(lbl_local)
        layout.addWidget(self.rb_global)
        layout.addWidget(lbl_global)
        layout.addWidget(self.rb_multi)
        layout.addWidget(lbl_multi)
        layout.addWidget(self.rb_tri)
        layout.addWidget(lbl_tri)
        layout.addStretch()

        self.stack.addWidget(page)

    # -------------------------------------------------------------
    # Page 2: Inputs & Donors
    # -------------------------------------------------------------
    def _create_page_2_inputs(self):
        page = QWidget()
        layout = QVBoxLayout(page)

        form = QFormLayout()

        # Target raster
        t_box = QHBoxLayout()
        self.txt_target = QLineEdit()
        self.txt_target.setPlaceholderText("Select target SLC-off raster (*.tif)...")
        btn_t = QPushButton("Browse...")
        btn_t.clicked.connect(self._browse_target)
        t_box.addWidget(self.txt_target)
        t_box.addWidget(btn_t)
        form.addRow("<b>Target Raster:</b>", t_box)

        # Donor raster (Single)
        d_box = QHBoxLayout()
        self.txt_donor = QLineEdit()
        self.txt_donor.setPlaceholderText("Select donor raster (*.tif)...")
        btn_d = QPushButton("Browse...")
        btn_d.clicked.connect(self._browse_donor)
        d_box.addWidget(self.txt_donor)
        d_box.addWidget(btn_d)
        self.row_donor = form.addRow("<b>Primary Donor:</b>", d_box)

        # Multi-donor Table
        self.tbl_donors = QTableWidget(0, 2)
        self.tbl_donors.setHorizontalHeaderLabels(["Donor Filepath", "Status"])
        self.tbl_donors.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.tbl_donors.setFixedHeight(90)
        self.tbl_donors.hide()

        btn_add_d = QPushButton("+ Add Donor Scene")
        btn_add_d.clicked.connect(self._add_multi_donor)
        self.box_multi_donor = QVBoxLayout()
        self.box_multi_donor.addWidget(self.tbl_donors)
        self.box_multi_donor.addWidget(btn_add_d)

        # Gap Mask Source
        self.cmb_mask_source = QComboBox()
        self.cmb_mask_source.addItems([
            "Auto NoData Values & NaNs",
            "Zero Values (0 = Gap)",
            "Custom Binary Mask File (1 = Gap, 0 = Valid)",
            "Landsat QA/BQA Band Detection"
        ])
        form.addRow("<b>Gap Mask Source:</b>", self.cmb_mask_source)

        # Custom mask path
        m_box = QHBoxLayout()
        self.txt_custom_mask = QLineEdit()
        self.txt_custom_mask.setPlaceholderText("Optional custom binary mask (*.tif)...")
        btn_m = QPushButton("Browse...")
        btn_m.clicked.connect(self._browse_custom_mask)
        m_box.addWidget(self.txt_custom_mask)
        m_box.addWidget(btn_m)
        form.addRow("Custom Mask:", m_box)

        layout.addLayout(form)
        layout.addLayout(self.box_multi_donor)
        layout.addStretch()

        self.stack.addWidget(page)

    # -------------------------------------------------------------
    # Page 3: Alignment & QA Masks
    # -------------------------------------------------------------
    def _create_page_3_alignment(self):
        page = QWidget()
        layout = QVBoxLayout(page)

        self.lbl_align_status = QLabel("Alignment Preflight Check: Ready")
        self.lbl_align_status.setStyleSheet("""
            QLabel {
                font-size: 12px;
                color: #065F46;
                background-color: #D1FAE5;
                padding: 8px;
                border-radius: 4px;
                font-weight: bold;
            }
        """)
        layout.addWidget(self.lbl_align_status)

        qa_box = QGroupBox("Donor Quality Assurance & Rejection Masks")
        qa_layout = QVBoxLayout(qa_box)

        self.chk_mask_cloud = QCheckBox("Exclude Clouds and High-Luminance Artifacts from Donor")
        self.chk_mask_cloud.setChecked(True)
        self.chk_mask_shadow = QCheckBox("Exclude Cloud Shadows from Donor")
        self.chk_mask_shadow.setChecked(True)
        self.chk_mask_snow = QCheckBox("Exclude Snow & Ice Saturated Pixels")
        self.chk_mask_snow.setChecked(True)

        qa_layout.addWidget(self.chk_mask_cloud)
        qa_layout.addWidget(self.chk_mask_shadow)
        qa_layout.addWidget(self.chk_mask_snow)
        layout.addWidget(qa_box)

        resample_box = QGroupBox("Grid Harmonization")
        res_layout = QFormLayout(resample_box)
        self.chk_auto_resample = QCheckBox("Auto-resample donor if CRS or pixel grid differs slightly")
        self.chk_auto_resample.setChecked(True)
        res_layout.addRow(self.chk_auto_resample)
        layout.addWidget(resample_box)

        layout.addStretch()
        self.stack.addWidget(page)

    # -------------------------------------------------------------
    # Page 4: Parameters
    # -------------------------------------------------------------
    def _create_page_4_parameters(self):
        page = QWidget()
        layout = QVBoxLayout(page)

        param_box = QGroupBox("Radiometric & Statistical Model Parameters")
        p_form = QFormLayout(param_box)

        self.spn_window = QSpinBox()
        self.spn_window.setRange(15, 201)
        self.spn_window.setSingleStep(10)
        self.spn_window.setValue(51)
        self.spn_window.setSuffix(" px")
        p_form.addRow("Initial Moving Window Size:", self.spn_window)

        self.spn_min_samples = QSpinBox()
        self.spn_min_samples.setRange(20, 1000)
        self.spn_min_samples.setValue(100)
        p_form.addRow("Minimum Paired Samples:", self.spn_min_samples)

        self.spn_corr_thresh = QDoubleSpinBox()
        self.spn_corr_thresh.setRange(0.1, 0.99)
        self.spn_corr_thresh.setSingleStep(0.05)
        self.spn_corr_thresh.setValue(0.70)
        p_form.addRow("Correlation Warning Threshold:", self.spn_corr_thresh)

        self.chk_robust = QCheckBox("Enable Robust Linear Regression with MAD Outlier Filter")
        self.chk_robust.setChecked(True)
        p_form.addRow(self.chk_robust)

        self.spn_feather = QSpinBox()
        self.spn_feather.setRange(0, 10)
        self.spn_feather.setValue(3)
        self.spn_feather.setSuffix(" px")
        p_form.addRow("Seam Feathering Width:", self.spn_feather)

        layout.addWidget(param_box)
        layout.addStretch()

        self.stack.addWidget(page)

    # -------------------------------------------------------------
    # Page 5: Output Destinations
    # -------------------------------------------------------------
    def _create_page_5_outputs(self):
        page = QWidget()
        layout = QVBoxLayout(page)

        form = QFormLayout()

        # Output Filled GeoTIFF
        o_box = QHBoxLayout()
        self.txt_output = QLineEdit()
        self.txt_output.setPlaceholderText("Output repaired raster path (*.tif)...")
        btn_o = QPushButton("Browse...")
        btn_o.clicked.connect(self._browse_output)
        o_box.addWidget(self.txt_output)
        o_box.addWidget(btn_o)
        form.addRow("<b>Output Repaired Raster:</b>", o_box)

        # Output Products Checkboxes
        prod_box = QGroupBox("Generated Quality & Audit Products")
        prod_layout = QVBoxLayout(prod_box)

        self.chk_gen_provenance = QCheckBox("Generate Provenance Raster (0=Original, 1=Triangulation, 2+=Donor)")
        self.chk_gen_provenance.setChecked(True)
        self.chk_gen_confidence = QCheckBox("Generate Normalized Confidence Raster (0–100 Score)")
        self.chk_gen_confidence.setChecked(True)
        self.chk_gen_remaining = QCheckBox("Generate Remaining-Gap Mask Raster")
        self.chk_gen_remaining.setChecked(True)
        self.chk_gen_report = QCheckBox("Generate HTML & JSON Provenance Audit Report")
        self.chk_gen_report.setChecked(True)

        prod_layout.addWidget(self.chk_gen_provenance)
        prod_layout.addWidget(self.chk_gen_confidence)
        prod_layout.addWidget(self.chk_gen_remaining)
        prod_layout.addWidget(self.chk_gen_report)

        layout.addLayout(form)
        layout.addWidget(prod_box)
        layout.addStretch()

        self.stack.addWidget(page)

    # -------------------------------------------------------------
    # Page 6: Execution & Results
    # -------------------------------------------------------------
    def _create_page_6_results(self):
        page = QWidget()
        layout = QVBoxLayout(page)

        self.lbl_exec_status = QLabel("Ready to start gap filling.")
        self.lbl_exec_status.setStyleSheet("font-weight: bold; font-size: 13px; color: #0B1F33;")
        layout.addWidget(self.lbl_exec_status)

        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        layout.addWidget(self.progress_bar)

        self.results_table = QTableWidget(0, 5)
        self.results_table.setHorizontalHeaderLabels(["Band", "Original Gaps", "Filled", "Fill Rate", "Model Equation"])
        self.results_table.horizontalHeader().setSectionResizeMode(4, QHeaderView.ResizeMode.Stretch)
        layout.addWidget(self.results_table)

        btn_box = QHBoxLayout()
        self.btn_open_report = QPushButton("Open HTML Audit Report")
        self.btn_open_report.clicked.connect(self._open_report)
        self.btn_open_report.setEnabled(False)

        self.btn_load_layers = QPushButton("Load Repaired Layers into QGIS")
        self.btn_load_layers.clicked.connect(self._load_layers)
        self.btn_load_layers.setEnabled(False)

        btn_box.addWidget(self.btn_open_report)
        btn_box.addWidget(self.btn_load_layers)
        layout.addLayout(btn_box)

        self.stack.addWidget(page)

    # -------------------------------------------------------------
    # Navigation & Step Handling
    # -------------------------------------------------------------
    def _next_step(self):
        if self.current_step == 0:
            # Update inputs UI based on selected method
            method_idx = self.method_group.checkedId()
            is_multi = (method_idx == 2)
            is_tri = (method_idx == 3)

            self.tbl_donors.setVisible(is_multi)
            self.txt_donor.setEnabled(not is_tri and not is_multi)

            self.current_step = 1
            self.stack.setCurrentIndex(1)
            self.step_label.setText("Step 2 of 6: Select Inputs & Donors")
            self.btn_back.setEnabled(True)

        elif self.current_step == 1:
            t_path = self.txt_target.text().strip()
            if not t_path or not os.path.exists(t_path):
                QMessageBox.warning(self, "Missing Target", "Please select a valid target raster file.")
                return

            # Default output path
            if not self.txt_output.text():
                d = os.path.dirname(t_path)
                fn = os.path.splitext(os.path.basename(t_path))[0]
                self.txt_output.setText(os.path.join(d, f"{fn}_gapfilled.tif"))

            self.current_step = 2
            self.stack.setCurrentIndex(2)
            self.step_label.setText("Step 3 of 6: Alignment & QA Masks")

        elif self.current_step == 2:
            self.current_step = 3
            self.stack.setCurrentIndex(3)
            self.step_label.setText("Step 4 of 6: Configure Statistical Parameters")

        elif self.current_step == 3:
            self.current_step = 4
            self.stack.setCurrentIndex(4)
            self.step_label.setText("Step 5 of 6: Outputs & Destinations")
            self.btn_next.setText("Run AriesGapfill →")

        elif self.current_step == 4:
            # Start Execution
            self.current_step = 5
            self.stack.setCurrentIndex(5)
            self.step_label.setText("Step 6 of 6: Execution & Quality Audit")
            self.btn_back.setEnabled(False)
            self.btn_next.setEnabled(False)
            self.btn_next.setText("Close")
            self._execute_gapfill()

        elif self.current_step == 5:
            self.accept()

    def _prev_step(self):
        if self.current_step > 0:
            self.current_step -= 1
            self.stack.setCurrentIndex(self.current_step)
            self.step_label.setText(f"Step {self.current_step + 1} of 6")
            self.btn_next.setText("Next →")
            self.btn_next.setEnabled(True)
            if self.current_step == 0:
                self.btn_back.setEnabled(False)

    # -------------------------------------------------------------
    # Execution
    # -------------------------------------------------------------
    def _execute_gapfill(self):
        method_idx = self.method_group.checkedId()
        method_map = {
            0: GapFillMethod.LOCAL_MATCHING,
            1: GapFillMethod.GLOBAL_MATCHING,
            2: GapFillMethod.MULTI_DONOR,
            3: GapFillMethod.TRIANGULATION
        }
        method = method_map.get(method_idx, GapFillMethod.LOCAL_MATCHING)

        mask_source_map = {
            0: GapMaskSource.NODATA,
            1: GapMaskSource.ZERO_VALUE,
            2: GapMaskSource.CUSTOM_MASK,
            3: GapMaskSource.AUTO_QA
        }
        mask_source = mask_source_map.get(self.cmb_mask_source.currentIndex(), GapMaskSource.NODATA)

        donors = []
        if method == GapFillMethod.MULTI_DONOR:
            for r in range(self.tbl_donors.rowCount()):
                p = self.tbl_donors.item(r, 0).text()
                if p and os.path.exists(p):
                    donors.append(DonorSpec(filepath=p))
        elif method != GapFillMethod.TRIANGULATION:
            d_path = self.txt_donor.text().strip()
            if d_path and os.path.exists(d_path):
                donors.append(DonorSpec(filepath=d_path))

        params = MethodParameters(
            initial_window_size=self.spn_window.value(),
            min_paired_samples=self.spn_min_samples.value(),
            correlation_threshold=self.spn_corr_thresh.value(),
            use_robust_regression=self.chk_robust.isChecked(),
            seam_feather_width=self.spn_feather.value()
        )

        config = GapFillConfig(
            target_path=self.txt_target.text().strip(),
            method=method,
            output_filled_path=self.txt_output.text().strip(),
            donors=donors,
            mask_source=mask_source,
            custom_mask_path=self.txt_custom_mask.text().strip() or None,
            mask_clouds=self.chk_mask_cloud.isChecked(),
            mask_shadows=self.chk_mask_shadow.isChecked(),
            mask_snow=self.chk_mask_snow.isChecked(),
            parameters=params,
            generate_provenance=self.chk_gen_provenance.isChecked(),
            generate_confidence=self.chk_gen_confidence.isChecked(),
            generate_remaining_gap_mask=self.chk_gen_remaining.isChecked(),
            generate_report=self.chk_gen_report.isChecked()
        )

        if not config.target_path or not os.path.exists(config.target_path):
            QMessageBox.warning(self, "Invalid Target", "Please select a valid target raster file.")
            self.tabs.setCurrentIndex(0)
            return

        if not config.output_filled_path:
            QMessageBox.warning(self, "Missing Output", "Please specify an output file path for the repaired raster.")
            self.tabs.setCurrentIndex(4)
            return

        if method != GapFillMethod.TRIANGULATION and not donors:
            QMessageBox.warning(self, "Missing Donor", f"The '{method.value}' method requires at least one valid donor scene.")
            self.tabs.setCurrentIndex(2)
            return

        self.lbl_exec_status.setText(f"Executing {method.value} gap fill...")
        self.progress_bar.setValue(5)
        self.btn_next.setEnabled(False)
        self.btn_back.setEnabled(False)

        def job(task=None):
            def on_progress(p, msg):
                if task is not None:
                    if hasattr(task, "is_canceled") and task.is_canceled():
                        raise Exception("Task canceled by user.")
                    elif hasattr(task, "isCanceled") and task.isCanceled():
                        raise Exception("Task canceled by user.")
                    if hasattr(task, "setProgress"):
                        try:
                            task.setProgress(float(p))
                        except Exception as e:
                            from ..core.logging import log_info
                            log_info(f"Task setProgress note: {e}")

            return AriesGapFillEngine.execute(config, progress_callback=on_progress)

        def on_prog_update(val):
            try:
                self.progress_bar.setValue(int(val))
            except Exception as e:
                from ..core.logging import log_info
                log_info(f"Progress bar update note: {e}")

        def on_ok(res: GapFillResult):
            self.last_result = res
            self.progress_bar.setValue(100)
            self.lbl_exec_status.setText(
                f"Completed successfully in {res.execution_time_seconds}s! Fill Rate: {res.overall_fill_rate_pct:.1f}% (Confidence: {res.mean_confidence_score:.0f}/100)"
            )
            self.lbl_exec_status.setStyleSheet("color: #065F46; font-weight: bold;")
            self.btn_next.setEnabled(True)
            self.btn_back.setEnabled(True)
            self.btn_open_report.setEnabled(bool(res.output_report_path))
            self.btn_load_layers.setEnabled(True)

            # Populate table
            self.results_table.setRowCount(len(res.band_stats))
            for r, b in enumerate(res.band_stats):
                self.results_table.setItem(r, 0, QTableWidgetItem(f"Band {b.band_index}"))
                self.results_table.setItem(r, 1, QTableWidgetItem(f"{b.original_gaps:,}"))
                self.results_table.setItem(r, 2, QTableWidgetItem(f"{b.filled_pixels:,}"))
                self.results_table.setItem(r, 3, QTableWidgetItem(f"{b.fill_rate_pct:.1f}%"))
                self.results_table.setItem(r, 4, QTableWidgetItem(f"T = {b.slope:.3f}·D + {b.intercept:.2f} (r={b.correlation:.2f})"))

        def on_err(err):
            self.progress_bar.setValue(0)
            self.lbl_exec_status.setText(f"Execution Failed: {err}")
            self.lbl_exec_status.setStyleSheet("color: #DC2626; font-weight: bold;")
            self.btn_next.setEnabled(True)
            self.btn_back.setEnabled(True)
            QMessageBox.critical(self, "AriesGapfill Error", f"Error during gap filling:\n{err}")

        run_in_background("AriesGapfill Execution", job, on_completed=on_ok, on_failed=on_err, on_progress=on_prog_update)

    def _browse_target(self):
        fn, _ = QFileDialog.getOpenFileName(self, "Select Target Raster", "", "GeoTIFF (*.tif *.tiff);;All Files (*.*)")
        if fn:
            self.txt_target.setText(fn)

    def _browse_donor(self):
        fn, _ = QFileDialog.getOpenFileName(self, "Select Donor Raster", "", "GeoTIFF (*.tif *.tiff);;All Files (*.*)")
        if fn:
            self.txt_donor.setText(fn)

    def _browse_custom_mask(self):
        fn, _ = QFileDialog.getOpenFileName(self, "Select Custom Mask", "", "GeoTIFF (*.tif *.tiff);;All Files (*.*)")
        if fn:
            self.txt_custom_mask.setText(fn)

    def _browse_output(self):
        fn, _ = QFileDialog.getSaveFileName(self, "Save Repaired Raster", "", "GeoTIFF (*.tif);;All Files (*.*)")
        if fn:
            self.txt_output.setText(fn)

    def _add_multi_donor(self):
        fns, _ = QFileDialog.getOpenFileNames(self, "Select Candidate Donors", "", "GeoTIFF (*.tif *.tiff);;All Files (*.*)")
        for fn in fns:
            r = self.tbl_donors.rowCount()
            self.tbl_donors.insertRow(r)
            self.tbl_donors.setItem(r, 0, QTableWidgetItem(fn))
            self.tbl_donors.setItem(r, 1, QTableWidgetItem("Ready"))

    def _open_report(self):
        if self.last_result and self.last_result.output_report_path:
            p = self.last_result.output_report_path
            if os.path.exists(p):
                import webbrowser
                webbrowser.open(f"file:///{os.path.abspath(p).replace(os.sep, '/')}")

    def _load_layers(self):
        if not self.last_result:
            return
        proj = QgsProject.instance()
        
        # Load filled
        f_layer = QgsRasterLayer(self.last_result.output_filled_path, "AriesGapfill Repaired Scene")
        if f_layer.isValid():
            proj.addMapLayer(f_layer)

        # Load confidence
        if self.last_result.output_confidence_path and os.path.exists(self.last_result.output_confidence_path):
            c_layer = QgsRasterLayer(self.last_result.output_confidence_path, "AriesGapfill Confidence (0-100)")
            if c_layer.isValid():
                proj.addMapLayer(c_layer)

        # Load provenance
        if self.last_result.output_provenance_path and os.path.exists(self.last_result.output_provenance_path):
            p_layer = QgsRasterLayer(self.last_result.output_provenance_path, "AriesGapfill Provenance Mask")
            if p_layer.isValid():
                proj.addMapLayer(p_layer)

        QMessageBox.information(self, "Layers Loaded", "Repaired raster and QA masks added to QGIS layer tree.")

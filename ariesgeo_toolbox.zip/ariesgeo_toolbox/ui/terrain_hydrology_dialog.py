"""
Aries Terrain & Hydrology Toolkit Guided Dialog.
"""

import os
from typing import Optional
from qgis.PyQt.QtWidgets import (
    QDialog,
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QTabWidget,
    QLabel,
    QPushButton,
    QLineEdit,
    QFileDialog,
    QDoubleSpinBox,
    QSpinBox,
    QCheckBox,
    QProgressBar,
    QMessageBox,
    QFormLayout,
    QGroupBox,
    QTableWidget,
    QTableWidgetItem,
    QHeaderView,
)
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QColor
from qgis.core import QgsProject, QgsRasterLayer, QgsVectorLayer, QgsPointXY
from qgis.gui import QgsMapCanvas, QgsMapToolEmitPoint
from ..resources import get_icon
from ..core.task_manager import run_in_background
from ..terrain_hydrology.dem_inspector import DEMInspector
from ..terrain_hydrology.conditioning import DEMConditioner
from ..terrain_hydrology.terrain import TerrainGenerator
from ..terrain_hydrology.flow import FlowEngine
from ..terrain_hydrology.streams import StreamExtractor
from ..terrain_hydrology.watersheds import WatershedDelineator

class OutletMapTool(QgsMapToolEmitPoint):
    """Canvas map tool to pick watershed outlet point."""
    def __init__(self, canvas: QgsMapCanvas, on_point_selected):
        super().__init__(canvas)
        self.canvas = canvas
        self.on_point_selected = on_point_selected
        self.setCursor(Qt.CursorShape.CrossCursor)

    def canvasReleaseEvent(self, event):
        point = self.toMapCoordinates(event.pos())
        self.on_point_selected(point.x(), point.y())


class TerrainHydrologyDialog(QDialog):
    """Guided dialog for DEM preflight inspection, terrain derivatives, flow routing, and watershed delineation."""

    def __init__(self, canvas: Optional[QgsMapCanvas] = None, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.canvas = canvas
        self.setWindowTitle("Aries Terrain & Hydrology Toolkit — AriesPlus")
        self.setWindowIcon(get_icon("terrain"))
        self.resize(750, 560)

        self.outlet_tool = None
        self.prev_tool = None
        self.clicked_outlet_x = 0.0
        self.clicked_outlet_y = 0.0

        self._setup_ui()

    def _setup_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(12, 12, 12, 12)
        main_layout.setSpacing(10)

        # Header
        header = QLabel("<b>Aries Terrain & Hydrology Toolkit</b>")
        header.setStyleSheet("""
            QLabel {
                font-size: 14px;
                color: #0B1F33;
                background-color: #D1FAE5;
                border-left: 4px solid #10B981;
                padding: 8px 12px;
                border-radius: 4px;
            }
        """)
        main_layout.addWidget(header)

        # Tabs
        self.tabs = QTabWidget()
        self.tab_inspect = self._create_inspect_tab()
        self.tab_terrain = self._create_terrain_tab()
        self.tab_hydro = self._create_hydro_tab()
        self.tab_watershed = self._create_watershed_tab()

        self.tabs.addTab(self.tab_inspect, "1. DEM Inspector & Sink Fill")
        self.tabs.addTab(self.tab_terrain, "2. Terrain Derivatives")
        self.tabs.addTab(self.tab_hydro, "3. Flow & Stream Extraction")
        self.tabs.addTab(self.tab_watershed, "4. Watershed Delineation")
        main_layout.addWidget(self.tabs)

        # Close
        btn_layout = QHBoxLayout()
        btn_close = QPushButton("Close")
        btn_close.clicked.connect(self.accept)
        btn_layout.addStretch()
        btn_layout.addWidget(btn_close)
        main_layout.addLayout(btn_layout)

    # 1. Inspect & Condition Tab
    def _create_inspect_tab(self) -> QWidget:
        tab = QWidget()
        layout = QVBoxLayout(tab)

        grp_dem = QGroupBox("Digital Elevation Model (DEM)")
        form = QFormLayout(grp_dem)

        dem_layout = QHBoxLayout()
        self.txt_dem_path = QLineEdit()
        btn_browse = QPushButton("Browse...")
        btn_browse.clicked.connect(lambda: self._browse_raster(self.txt_dem_path, self._on_dem_selected))
        btn_inspect = QPushButton("Inspect DEM")
        btn_inspect.setIcon(get_icon("terrain"))
        btn_inspect.clicked.connect(self._run_dem_inspection)

        dem_layout.addWidget(self.txt_dem_path)
        dem_layout.addWidget(btn_browse)
        dem_layout.addWidget(btn_inspect)
        form.addRow("Input DEM Raster:", dem_layout)

        layout.addWidget(grp_dem)

        # Inspection Table
        self.table_dem_info = QTableWidget(0, 2)
        self.table_dem_info.setHorizontalHeaderLabels(["Metric", "Diagnostic Value"])
        self.table_dem_info.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        self.table_dem_info.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        layout.addWidget(self.table_dem_info)

        # Sink Fill
        grp_fill = QGroupBox("Depression / Sink Filling")
        form_fill = QFormLayout(grp_fill)

        fill_layout = QHBoxLayout()
        self.txt_filled_dem = QLineEdit()
        btn_browse_fill = QPushButton("Browse...")
        btn_browse_fill.clicked.connect(lambda: self._save_raster(self.txt_filled_dem))
        btn_run_fill = QPushButton("Fill Sinks")
        btn_run_fill.setStyleSheet("background-color: #10B981; color: white; font-weight: bold;")
        btn_run_fill.clicked.connect(self._run_sink_filling)

        fill_layout.addWidget(self.txt_filled_dem)
        fill_layout.addWidget(btn_browse_fill)
        fill_layout.addWidget(btn_run_fill)
        form_fill.addRow("Filled DEM Output:", fill_layout)

        layout.addWidget(grp_fill)
        return tab

    # 2. Terrain Derivatives Tab
    def _create_terrain_tab(self) -> QWidget:
        tab = QWidget()
        layout = QVBoxLayout(tab)

        grp_t_in = QGroupBox("Input DEM")
        form_in = QFormLayout(grp_t_in)
        self.txt_terr_dem = QLineEdit()
        btn_b_in = QPushButton("Browse...")
        btn_b_in.clicked.connect(lambda: self._browse_raster(self.txt_terr_dem))
        in_l = QHBoxLayout()
        in_l.addWidget(self.txt_terr_dem)
        in_l.addWidget(btn_b_in)
        form_in.addRow("DEM Dataset:", in_l)
        layout.addWidget(grp_t_in)

        grp_opts = QGroupBox("Terrain Products to Generate")
        f_opts = QFormLayout(grp_opts)

        self.chk_slope = QCheckBox("Slope (Degrees)")
        self.chk_slope.setChecked(True)
        self.chk_aspect = QCheckBox("Aspect (0–360° Compass Direction)")
        self.chk_aspect.setChecked(True)
        self.chk_hillshade = QCheckBox("Hillshade (Sun 315°, 45° Elevation)")
        self.chk_hillshade.setChecked(True)
        self.chk_contours = QCheckBox("Vector Contours (Elevation Lines)")
        self.chk_contours.setChecked(True)

        self.spin_contour_interval = QDoubleSpinBox()
        self.spin_contour_interval.setRange(0.5, 1000.0)
        self.spin_contour_interval.setValue(10.0)
        self.spin_contour_interval.setSuffix(" m")

        f_opts.addRow("Derivatives:", self.chk_slope)
        f_opts.addRow("", self.chk_aspect)
        f_opts.addRow("", self.chk_hillshade)
        f_opts.addRow("", self.chk_contours)
        f_opts.addRow("Contour Interval:", self.spin_contour_interval)

        layout.addWidget(grp_opts)

        grp_out_dir = QGroupBox("Output Directory")
        f_out = QFormLayout(grp_out_dir)
        self.txt_terr_out_dir = QLineEdit()
        btn_b_out = QPushButton("Browse...")
        btn_b_out.clicked.connect(self._browse_dir)
        out_l = QHBoxLayout()
        out_l.addWidget(self.txt_terr_out_dir)
        out_l.addWidget(btn_b_out)
        f_out.addRow("Save Folder:", out_l)
        layout.addWidget(grp_out_dir)

        btn_run_terr = QPushButton("Generate Terrain Derivatives")
        btn_run_terr.setStyleSheet("background-color: #10B981; color: white; font-weight: bold; padding: 7px;")
        btn_run_terr.clicked.connect(self._run_terrain_derivatives)
        layout.addWidget(btn_run_terr)

        layout.addStretch()
        return tab

    # 3. Flow & Stream Extraction Tab
    def _create_hydro_tab(self) -> QWidget:
        tab = QWidget()
        layout = QVBoxLayout(tab)

        grp_f_in = QGroupBox("Input Conditioned DEM")
        form_f = QFormLayout(grp_f_in)
        self.txt_hydro_dem = QLineEdit()
        btn_b = QPushButton("Browse...")
        btn_b.clicked.connect(lambda: self._browse_raster(self.txt_hydro_dem))
        l1 = QHBoxLayout()
        l1.addWidget(self.txt_hydro_dem)
        l1.addWidget(btn_b)
        form_f.addRow("Conditioned DEM:", l1)
        layout.addWidget(grp_f_in)

        grp_f_out = QGroupBox("Flow Routing & Stream Extraction")
        f_out = QFormLayout(grp_f_out)

        self.txt_fdir_out = QLineEdit()
        btn_fdir = QPushButton("Browse...")
        btn_fdir.clicked.connect(lambda: self._save_raster(self.txt_fdir_out))
        l2 = QHBoxLayout()
        l2.addWidget(self.txt_fdir_out)
        l2.addWidget(btn_fdir)
        f_out.addRow("Flow Direction Output (*.tif):", l2)

        self.txt_acc_out = QLineEdit()
        btn_acc = QPushButton("Browse...")
        btn_acc.clicked.connect(lambda: self._save_raster(self.txt_acc_out))
        l3 = QHBoxLayout()
        l3.addWidget(self.txt_acc_out)
        l3.addWidget(btn_acc)
        f_out.addRow("Flow Accumulation Output (*.tif):", l3)

        self.spin_stream_thresh = QSpinBox()
        self.spin_stream_thresh.setRange(10, 1000000)
        self.spin_stream_thresh.setValue(500)
        self.spin_stream_thresh.setSuffix(" cells")
        f_out.addRow("Drainage Stream Threshold:", self.spin_stream_thresh)

        self.txt_streams_out = QLineEdit()
        btn_st = QPushButton("Browse...")
        btn_st.clicked.connect(lambda: self._save_vector(self.txt_streams_out))
        l4 = QHBoxLayout()
        l4.addWidget(self.txt_streams_out)
        l4.addWidget(btn_st)
        f_out.addRow("Stream Vectors Output (*.gpkg):", l4)

        layout.addWidget(grp_f_out)

        btn_run_hydro = QPushButton("Calculate Flow & Drainage Network")
        btn_run_hydro.setStyleSheet("background-color: #0284C7; color: white; font-weight: bold; padding: 7px;")
        btn_run_hydro.clicked.connect(self._run_flow_and_streams)
        layout.addWidget(btn_run_hydro)

        layout.addStretch()
        return tab

    # 4. Watershed Delineation Tab
    def _create_watershed_tab(self) -> QWidget:
        tab = QWidget()
        layout = QVBoxLayout(tab)

        grp_ws_in = QGroupBox("Hydrology Datasets")
        form_ws = QFormLayout(grp_ws_in)

        self.txt_ws_fdir = QLineEdit()
        btn_b_fdir = QPushButton("Browse...")
        btn_b_fdir.clicked.connect(lambda: self._browse_raster(self.txt_ws_fdir))
        l_fd = QHBoxLayout()
        l_fd.addWidget(self.txt_ws_fdir)
        l_fd.addWidget(btn_b_fdir)
        form_ws.addRow("Flow Direction Raster:", l_fd)

        self.txt_ws_acc = QLineEdit()
        btn_b_acc = QPushButton("Browse...")
        btn_b_acc.clicked.connect(lambda: self._browse_raster(self.txt_ws_acc))
        l_ac = QHBoxLayout()
        l_ac.addWidget(self.txt_ws_acc)
        l_ac.addWidget(btn_b_acc)
        form_ws.addRow("Flow Accumulation Raster:", l_ac)

        layout.addWidget(grp_ws_in)

        grp_outlet = QGroupBox("Pour Point / Watershed Outlet")
        form_outl = QFormLayout(grp_outlet)

        outl_layout = QHBoxLayout()
        self.txt_outlet_coords = QLineEdit()
        self.txt_outlet_coords.setPlaceholderText("X, Y Coordinates")
        btn_pick = QPushButton("Click on Map Canvas")
        btn_pick.setIcon(get_icon("terrain"))
        btn_pick.clicked.connect(self._activate_outlet_click_tool)
        outl_layout.addWidget(self.txt_outlet_coords)
        outl_layout.addWidget(btn_pick)
        form_outl.addRow("Outlet Coordinates:", outl_layout)

        self.spin_snap = QSpinBox()
        self.spin_snap.setRange(1, 100)
        self.spin_snap.setValue(10)
        self.spin_snap.setSuffix(" pixels")
        form_outl.addRow("Outlet Snapping Radius:", self.spin_snap)

        layout.addWidget(grp_outlet)

        grp_ws_out = QGroupBox("Watershed Output")
        form_wso = QFormLayout(grp_ws_out)

        self.txt_ws_poly = QLineEdit()
        btn_ws_p = QPushButton("Browse...")
        btn_ws_p.clicked.connect(lambda: self._save_vector(self.txt_ws_poly))
        l_wp = QHBoxLayout()
        l_wp.addWidget(self.txt_ws_poly)
        l_wp.addWidget(btn_ws_p)
        form_wso.addRow("Watershed Basin Polygon (*.gpkg):", l_wp)

        layout.addWidget(grp_ws_out)

        btn_run_ws = QPushButton("Delineate Watershed Basin")
        btn_run_ws.setStyleSheet("background-color: #10B981; color: white; font-weight: bold; padding: 7px;")
        btn_run_ws.clicked.connect(self._run_watershed_delineation)
        layout.addWidget(btn_run_ws)

        layout.addStretch()
        return tab

    # File browsing helpers
    def _browse_raster(self, edit: QLineEdit, callback=None):
        path, _ = QFileDialog.getOpenFileName(self, "Select Raster", "", "Raster Image (*.tif *.dem *.img);;All Files (*)")
        if path:
            edit.setText(path)
            if callback:
                callback(path)

    def _save_raster(self, edit: QLineEdit):
        path, _ = QFileDialog.getSaveFileName(self, "Save Raster", "", "GeoTIFF (*.tif *.tiff)")
        if path:
            if not path.endswith(".tif"):
                path += ".tif"
            edit.setText(path)

    def _save_vector(self, edit: QLineEdit):
        path, _ = QFileDialog.getSaveFileName(self, "Save Vector", "", "GeoPackage (*.gpkg);;Shapefile (*.shp)")
        if path:
            if not path.endswith(".gpkg") and not path.endswith(".shp"):
                path += ".gpkg"
            edit.setText(path)

    def _browse_dir(self):
        d = QFileDialog.getExistingDirectory(self, "Select Output Directory")
        if d:
            self.txt_terr_out_dir.setText(d)

    def _on_dem_selected(self, path: str):
        # Propagate to other tabs
        self.txt_terr_dem.setText(path)
        self.txt_hydro_dem.setText(path)
        base = os.path.splitext(path)[0]
        self.txt_filled_dem.setText(f"{base}_filled.tif")
        self.txt_fdir_out.setText(f"{base}_flow_dir.tif")
        self.txt_acc_out.setText(f"{base}_flow_acc.tif")
        self.txt_streams_out.setText(f"{base}_streams.gpkg")
        self.txt_terr_out_dir.setText(os.path.dirname(path))
        self._run_dem_inspection()

    def _run_dem_inspection(self):
        path = self.txt_dem_path.text().strip()
        if not path or not os.path.exists(path):
            return

        diag = DEMInspector.inspect(path)
        self.table_dem_info.setRowCount(0)
        items = [
            ("File", diag.filename),
            ("Dimensions", f"{diag.width} x {diag.height} pixels"),
            ("Coordinate System", f"{diag.crs_auth_id} ({'Projected' if diag.is_projected else 'GEOGRAPHIC - REPROJECTION SUGGESTED'})"),
            ("Pixel Resolution", f"{diag.pixel_size_x:.2f} x {diag.pixel_size_y:.2f} m"),
            ("Elevation Range", f"{diag.min_elev} m to {diag.max_elev} m (Mean: {diag.mean_elev} m)"),
            ("NoData Coverage", f"{diag.nodata_percentage}%"),
            ("Depressions / Sinks", f"{diag.sink_count_approx} estimated sinks"),
        ]
        self.table_dem_info.setRowCount(len(items))
        for r, (k, v) in enumerate(items):
            self.table_dem_info.setItem(r, 0, QTableWidgetItem(k))
            val_item = QTableWidgetItem(v)
            if "GEOGRAPHIC" in v:
                val_item.setForeground(QColor("#D64545"))
            self.table_dem_info.setItem(r, 1, val_item)

        if diag.warnings:
            QMessageBox.warning(self, "DEM Diagnostics", "\n\n".join(diag.warnings))

    def _run_sink_filling(self):
        in_p = self.txt_dem_path.text().strip()
        out_p = self.txt_filled_dem.text().strip()
        if not in_p or not os.path.exists(in_p):
            QMessageBox.warning(self, "Missing DEM", "Please select a valid input DEM.")
            return

        def job(task=None):
            return DEMConditioner.fill_sinks(in_p, out_p)

        def on_ok(res):
            lyr = QgsRasterLayer(res, os.path.basename(res))
            if lyr.isValid():
                QgsProject.instance().addMapLayer(lyr)
            self.txt_hydro_dem.setText(res)
            QMessageBox.information(self, "Success", f"Filled DEM saved and loaded:\n{res}")

        def on_err(e):
            QMessageBox.critical(self, "Error", f"Sink filling failed:\n{str(e)}")

        run_in_background("Filling DEM Sinks", job, on_completed=on_ok, on_failed=on_err)

    def _run_terrain_derivatives(self):
        dem_p = self.txt_terr_dem.text().strip()
        out_d = self.txt_terr_out_dir.text().strip()
        if not dem_p or not os.path.exists(dem_p):
            QMessageBox.warning(self, "Missing DEM", "Please select a valid DEM.")
            return
        if not out_d:
            QMessageBox.warning(self, "Missing Directory", "Please specify an output folder.")
            return

        base = os.path.splitext(os.path.basename(dem_p))[0]
        gen_slope = self.chk_slope.isChecked()
        gen_aspect = self.chk_aspect.isChecked()
        gen_hillshade = self.chk_hillshade.isChecked()
        gen_contours = self.chk_contours.isChecked()
        interval = self.spin_contour_interval.value()

        def job(task=None):
            results = []
            if gen_slope:
                slp_p = os.path.join(out_d, f"{base}_slope.tif")
                results.append((TerrainGenerator.generate_slope(dem_p, slp_p), "raster"))
            if gen_aspect:
                asp_p = os.path.join(out_d, f"{base}_aspect.tif")
                results.append((TerrainGenerator.generate_aspect(dem_p, asp_p), "raster"))
            if gen_hillshade:
                hs_p = os.path.join(out_d, f"{base}_hillshade.tif")
                results.append((TerrainGenerator.generate_hillshade(dem_p, hs_p), "raster"))
            if gen_contours:
                cnt_p = os.path.join(out_d, f"{base}_contours.gpkg")
                results.append((TerrainGenerator.generate_contours(dem_p, cnt_p, interval=interval), "vector"))
            return results

        def on_ok(res_list):
            for path, kind in res_list:
                if kind == "raster":
                    lyr = QgsRasterLayer(path, os.path.basename(path))
                else:
                    lyr = QgsVectorLayer(path, os.path.basename(path), "ogr")
                if lyr.isValid():
                    QgsProject.instance().addMapLayer(lyr)
            QMessageBox.information(self, "Complete", f"Successfully generated {len(res_list)} terrain derivative(s).")

        def on_err(e):
            QMessageBox.critical(self, "Error", f"Terrain generation failed:\n{str(e)}")

        run_in_background("Generating Terrain Derivatives", job, on_completed=on_ok, on_failed=on_err)

    def _run_flow_and_streams(self):
        dem_p = self.txt_hydro_dem.text().strip()
        fdir_p = self.txt_fdir_out.text().strip()
        acc_p = self.txt_acc_out.text().strip()
        st_p = self.txt_streams_out.text().strip()
        thresh = self.spin_stream_thresh.value()

        if not dem_p or not os.path.exists(dem_p):
            QMessageBox.warning(self, "Missing DEM", "Please select a conditioned DEM.")
            return

        def job(task=None):
            FlowEngine.calculate_d8_flow_direction(dem_p, fdir_p)
            FlowEngine.calculate_flow_accumulation(dem_p, fdir_p, acc_p)
            StreamExtractor.extract_stream_network(acc_p, fdir_p, st_p, threshold_cells=thresh)
            return fdir_p, acc_p, st_p

        def on_ok(res):
            for p in [res[0], res[1]]:
                lyr = QgsRasterLayer(p, os.path.basename(p))
                if lyr.isValid():
                    QgsProject.instance().addMapLayer(lyr)
            s_lyr = QgsVectorLayer(res[2], os.path.basename(res[2]), "ogr")
            if s_lyr.isValid():
                QgsProject.instance().addMapLayer(s_lyr)

            self.txt_ws_fdir.setText(res[0])
            self.txt_ws_acc.setText(res[1])
            QMessageBox.information(self, "Complete", "Flow direction, accumulation, and stream network extracted.")

        def on_err(e):
            QMessageBox.critical(self, "Error", f"Hydrology calculation failed:\n{str(e)}")

        run_in_background("Calculating Flow & Streams", job, on_completed=on_ok, on_failed=on_err)

    def _activate_outlet_click_tool(self):
        if not self.canvas:
            QMessageBox.information(self, "Info", "Please enter X, Y map coordinates directly.")
            return
        self.prev_tool = self.canvas.mapTool()
        self.outlet_tool = OutletMapTool(self.canvas, self._on_canvas_point_picked)
        self.canvas.setMapTool(self.outlet_tool)
        self.hide()

    def _on_canvas_point_picked(self, x: float, y: float):
        self.clicked_outlet_x = x
        self.clicked_outlet_y = y
        self.txt_outlet_coords.setText(f"{x:.2f}, {y:.2f}")
        if self.prev_tool:
            self.canvas.setMapTool(self.prev_tool)
        self.show()
        self.raise_()

    def _run_watershed_delineation(self):
        fdir_p = self.txt_ws_fdir.text().strip()
        acc_p = self.txt_ws_acc.text().strip()
        poly_p = self.txt_ws_poly.text().strip()
        coords_str = self.txt_outlet_coords.text().strip()

        if not fdir_p or not os.path.exists(fdir_p):
            QMessageBox.warning(self, "Missing Flow Direction", "Please specify a valid flow direction raster.")
            return

        try:
            parts = coords_str.split(",")
            ox, oy = float(parts[0]), float(parts[1])
        except Exception:
            QMessageBox.warning(self, "Invalid Coordinates", "Please enter valid X, Y outlet coordinates.")
            return

        snap_r = self.spin_snap.value()
        base = os.path.splitext(fdir_p)[0]
        ws_rast = f"{base}_watershed_raster.tif"
        if not poly_p:
            poly_p = f"{base}_watershed.gpkg"

        def job(task=None):
            sx, sy, sr, sc = WatershedDelineator.snap_outlet_point(acc_p, ox, oy, snap_distance_pixels=snap_r)
            stats = WatershedDelineator.delineate_watershed(
                fdir_path=fdir_p,
                outlet_row=sr,
                outlet_col=sc,
                output_raster_path=ws_rast,
                output_vector_path=poly_p
            )
            stats["snapped_x"] = sx
            stats["snapped_y"] = sy
            return stats

        def on_ok(stats):
            lyr = QgsVectorLayer(poly_p, "Watershed Basin", "ogr")
            if lyr.isValid():
                QgsProject.instance().addMapLayer(lyr)

            QMessageBox.information(
                self,
                "Watershed Delineation Complete",
                f"Watershed basin successfully delineated!\n\n"
                f"Basin Area: {stats.get('area_km2')} km²\n"
                f"Cell Count: {stats.get('cell_count'):,} pixels\n"
                f"Snapped Outlet: ({stats.get('snapped_x'):.2f}, {stats.get('snapped_y'):.2f})\n"
                f"Output: {poly_p}"
            )

        def on_err(e):
            QMessageBox.critical(self, "Error", f"Watershed delineation failed:\n{str(e)}")

        run_in_background("Delineating Watershed", job, on_completed=on_ok, on_failed=on_err)

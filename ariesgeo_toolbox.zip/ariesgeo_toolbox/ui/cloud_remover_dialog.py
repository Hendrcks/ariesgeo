"""
Aries Cloud Cover Remover Dialog for QGIS.
"""

import os
from typing import Optional, List
from qgis.PyQt.QtWidgets import (
    QDialog,
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QTabWidget,
    QLabel,
    QPushButton,
    QLineEdit,
    QFileDialog,
    QDoubleSpinBox,
    QSpinBox,
    QCheckBox,
    QProgressBar,
    QMessageBox,
    QListWidget,
    QFormLayout,
    QGroupBox,
)
from qgis.PyQt.QtCore import Qt
from qgis.core import QgsProject, QgsRasterLayer
from ..resources import get_icon
from ..core.task_manager import run_in_background
from ..raster.cloud_remover import CloudRemover
from ..raster.reports import ProvenanceReportGenerator
from .report_dialog import ReportViewerDialog

class CloudRemoverDialog(QDialog):
    """Dialog for removing clouds and shadows from satellite and aerial imagery."""

    def __init__(self, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.setWindowTitle("Aries Cloud Cover Remover — AriesPlus")
        self.setWindowIcon(get_icon("cloud"))
        self.resize(680, 540)

        self.last_provenance_data = None
        self._setup_ui()

    def _setup_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(12, 12, 12, 12)
        main_layout.setSpacing(10)

        # Header Banner
        header = QLabel("<b>Aries Cloud Cover Remover</b>")
        header.setStyleSheet("""
            QLabel {
                font-size: 14px;
                color: #0B1F33;
                background-color: #E0F2FE;
                border-left: 4px solid #0284C7;
                padding: 8px 12px;
                border-radius: 4px;
            }
        """)
        main_layout.addWidget(header)

        # Tabs
        self.tabs = QTabWidget()
        self.tab_multitemp = self._create_multitemporal_tab()
        self.tab_single = self._create_single_scene_tab()

        self.tabs.addTab(self.tab_multitemp, "Multi-Temporal Cloud Replacement (Best Quality)")
        self.tabs.addTab(self.tab_single, "Single-Scene Cloud Inpainting")
        main_layout.addWidget(self.tabs)

        # Bottom Actions
        bottom_layout = QHBoxLayout()
        self.btn_view_report = QPushButton("View Quality Report")
        self.btn_view_report.setIcon(get_icon("report"))
        self.btn_view_report.setEnabled(False)
        self.btn_view_report.clicked.connect(self._open_report)

        btn_close = QPushButton("Close")
        btn_close.clicked.connect(self.accept)

        bottom_layout.addWidget(self.btn_view_report)
        bottom_layout.addStretch()
        bottom_layout.addWidget(btn_close)
        main_layout.addLayout(bottom_layout)

    # Tab 1: Multi-temporal
    def _create_multitemporal_tab(self) -> QWidget:
        tab = QWidget()
        layout = QVBoxLayout(tab)

        # Target cloudy scene
        grp_target = QGroupBox("Target Cloudy Image")
        form_target = QFormLayout(grp_target)

        tgt_layout = QHBoxLayout()
        self.txt_target_scene = QLineEdit()
        btn_browse_tgt = QPushButton("Browse...")
        btn_browse_tgt.clicked.connect(lambda: self._browse_raster(self.txt_target_scene))
        tgt_layout.addWidget(self.txt_target_scene)
        tgt_layout.addWidget(btn_browse_tgt)
        form_target.addRow("Cloudy Target Image:", tgt_layout)

        self.spin_thresh_mt = QDoubleSpinBox()
        self.spin_thresh_mt.setRange(0.1, 1.0)
        self.spin_thresh_mt.setSingleStep(0.05)
        self.spin_thresh_mt.setValue(0.65)
        self.spin_thresh_mt.setToolTip("Sensitivity threshold for detecting white/bright cloud pixels (0.1 - 1.0)")
        form_target.addRow("Cloud Sensitivity Threshold:", self.spin_thresh_mt)

        layout.addWidget(grp_target)

        # Clear donor scenes
        grp_donors = QGroupBox("Clear Reference / Donor Scenes")
        form_donors = QFormLayout(grp_donors)

        donor_bar = QHBoxLayout()
        btn_add_donors = QPushButton("Add Clear Donor Scenes...")
        btn_add_donors.clicked.connect(self._add_donor_scenes)
        btn_rem_donor = QPushButton("Remove")
        btn_rem_donor.clicked.connect(self._remove_selected_donor)
        donor_bar.addWidget(btn_add_donors)
        donor_bar.addWidget(btn_rem_donor)
        donor_bar.addStretch()

        self.donor_list = QListWidget()
        form_donors.addRow("Clear Scenes (Priority Order):", donor_bar)
        form_donors.addRow("", self.donor_list)

        self.chk_radiometry_mt = QCheckBox("Apply Linear Regression Radiometric Harmonization to Donor")
        self.chk_radiometry_mt.setChecked(True)
        form_donors.addRow("Color Balancing:", self.chk_radiometry_mt)

        layout.addWidget(grp_donors)

        # Output options
        grp_out = QGroupBox("Output Settings")
        form_out = QFormLayout(grp_out)

        out_layout = QHBoxLayout()
        self.txt_out_scene = QLineEdit()
        btn_browse_out = QPushButton("Browse...")
        btn_browse_out.clicked.connect(lambda: self._save_raster(self.txt_out_scene))
        out_layout.addWidget(self.txt_out_scene)
        out_layout.addWidget(btn_browse_out)
        form_out.addRow("Cloud-Free Output:", out_layout)

        mask_layout = QHBoxLayout()
        self.txt_out_mask = QLineEdit()
        self.txt_out_mask.setPlaceholderText("Optional cloud mask raster (*.tif)...")
        btn_browse_mask = QPushButton("Browse...")
        btn_browse_mask.clicked.connect(lambda: self._save_raster(self.txt_out_mask))
        mask_layout.addWidget(self.txt_out_mask)
        mask_layout.addWidget(btn_browse_mask)
        form_out.addRow("Save Cloud Mask (Optional):", mask_layout)

        layout.addWidget(grp_out)

        # Run & Progress
        self.prog_mt = QProgressBar()
        self.prog_mt.setValue(0)
        layout.addWidget(self.prog_mt)

        self.chk_auto_add_mt = QCheckBox("Automatically add cloud-free result to active project")
        self.chk_auto_add_mt.setChecked(True)
        layout.addWidget(self.chk_auto_add_mt)

        self.btn_run_mt = QPushButton("Remove Clouds (Multi-Temporal)")
        self.btn_run_mt.setStyleSheet("background-color: #0284C7; color: white; font-weight: bold; padding: 7px;")
        self.btn_run_mt.clicked.connect(self._run_multitemporal)
        layout.addWidget(self.btn_run_mt)

        layout.addStretch()
        return tab

    # Tab 2: Single Scene
    def _create_single_scene_tab(self) -> QWidget:
        tab = QWidget()
        layout = QVBoxLayout(tab)

        grp_single = QGroupBox("Single Cloudy Image & Parameters")
        form_single = QFormLayout(grp_single)

        in_layout = QHBoxLayout()
        self.txt_single_in = QLineEdit()
        btn_browse_in = QPushButton("Browse...")
        btn_browse_in.clicked.connect(lambda: self._browse_raster(self.txt_single_in))
        in_layout.addWidget(self.txt_single_in)
        in_layout.addWidget(btn_browse_in)
        form_single.addRow("Cloudy Image:", in_layout)

        out_layout = QHBoxLayout()
        self.txt_single_out = QLineEdit()
        btn_browse_out = QPushButton("Browse...")
        btn_browse_out.clicked.connect(lambda: self._save_raster(self.txt_single_out))
        out_layout.addWidget(self.txt_single_out)
        out_layout.addWidget(btn_browse_out)
        form_single.addRow("Inpainted Output:", out_layout)

        self.spin_thresh_single = QDoubleSpinBox()
        self.spin_thresh_single.setRange(0.1, 1.0)
        self.spin_thresh_single.setSingleStep(0.05)
        self.spin_thresh_single.setValue(0.65)
        form_single.addRow("Cloud Threshold:", self.spin_thresh_single)

        self.spin_dist_single = QSpinBox()
        self.spin_dist_single.setRange(10, 1000)
        self.spin_dist_single.setValue(150)
        self.spin_dist_single.setSuffix(" pixels")
        form_single.addRow("Max Inpainting Search Distance:", self.spin_dist_single)

        layout.addWidget(grp_single)

        self.prog_single = QProgressBar()
        self.prog_single.setValue(0)
        layout.addWidget(self.prog_single)

        self.chk_auto_add_single = QCheckBox("Automatically add output layer to map canvas")
        self.chk_auto_add_single.setChecked(True)
        layout.addWidget(self.chk_auto_add_single)

        self.btn_run_single = QPushButton("Run Single-Scene Cloud Inpainting")
        self.btn_run_single.setStyleSheet("background-color: #16A36A; color: white; font-weight: bold; padding: 7px;")
        self.btn_run_single.clicked.connect(self._run_single)
        layout.addWidget(self.btn_run_single)

        layout.addStretch()
        return tab

    def _browse_raster(self, line_edit: QLineEdit):
        path, _ = QFileDialog.getOpenFileName(self, "Select Raster", "", "Raster Image (*.tif *.tiff *.jp2 *.img);;All Files (*)")
        if path:
            line_edit.setText(path)

    def _save_raster(self, line_edit: QLineEdit):
        path, _ = QFileDialog.getSaveFileName(self, "Save GeoTIFF", "", "GeoTIFF Image (*.tif *.tiff)")
        if path:
            if not path.endswith(".tif") and not path.endswith(".tiff"):
                path += ".tif"
            line_edit.setText(path)

    def _add_donor_scenes(self):
        files, _ = QFileDialog.getOpenFileNames(self, "Select Clear Donor Scenes", "", "GeoTIFF (*.tif *.tiff);;All Files (*)")
        if files:
            for f in files:
                self.donor_list.addItem(f)

    def _remove_selected_donor(self):
        for item in self.donor_list.selectedItems():
            self.donor_list.takeItem(self.donor_list.row(item))

    # Handlers
    def _run_multitemporal(self):
        target_p = self.txt_target_scene.text().strip()
        out_p = self.txt_out_scene.text().strip()
        mask_p = self.txt_out_mask.text().strip() or None
        donors = [self.donor_list.item(i).text() for i in range(self.donor_list.count())]

        if not target_p or not os.path.exists(target_p):
            QMessageBox.warning(self, "Invalid Input", "Please select a valid cloudy target image.")
            return
        if not donors:
            QMessageBox.warning(self, "No Donors", "Please add at least one clear donor scene.")
            return
        if not out_p:
            QMessageBox.warning(self, "Missing Output", "Please specify an output destination file.")
            return

        thresh = self.spin_thresh_mt.value()
        rad = self.chk_radiometry_mt.isChecked()

        self.btn_run_mt.setEnabled(False)
        self.prog_mt.setValue(10)

        def job(task=None):
            return CloudRemover.remove_clouds_multitemporal(
                target_scene_path=target_p,
                donor_scene_paths=donors,
                output_raster_path=out_p,
                output_mask_path=mask_p,
                brightness_threshold=thresh,
                apply_radiometry=rad
            )

        def on_ok(stats):
            self.prog_mt.setValue(100)
            self.btn_run_mt.setEnabled(True)
            self.btn_view_report.setEnabled(True)

            params = {"brightness_threshold": thresh, "radiometric_harmonization": rad, "donors_count": len(donors)}
            self.last_provenance_data = ProvenanceReportGenerator.generate_report(
                operation_name="Multi-Temporal Cloud Cover Removal",
                input_files=[target_p] + donors,
                output_file=out_p,
                parameters=params,
                metrics=stats
            )
            ProvenanceReportGenerator.save_sidecar_report(self.last_provenance_data, out_p)

            if self.chk_auto_add_mt.isChecked():
                lyr = QgsRasterLayer(out_p, os.path.basename(out_p))
                if lyr.isValid():
                    QgsProject.instance().addMapLayer(lyr)

            QMessageBox.information(
                self,
                "Cloud Removal Complete",
                f"Cloud cover successfully removed!\n\n"
                f"Cloud Coverage: {stats.get('cloud_coverage_percent')}% ({stats.get('cloud_pixels'):,} px)\n"
                f"Output: {out_p}"
            )

        def on_err(exc):
            self.prog_mt.setValue(0)
            self.btn_run_mt.setEnabled(True)
            QMessageBox.critical(self, "Cloud Removal Error", f"Operation failed:\n{str(exc)}")

        run_in_background(
            "Multi-Temporal Cloud Removal",
            job,
            on_completed=on_ok,
            on_failed=on_err,
            on_progress=lambda p: self.prog_mt.setValue(int(p))
        )

    def _run_single(self):
        in_p = self.txt_single_in.text().strip()
        out_p = self.txt_single_out.text().strip()

        if not in_p or not os.path.exists(in_p):
            QMessageBox.warning(self, "Invalid Input", "Please select a valid input image.")
            return
        if not out_p:
            QMessageBox.warning(self, "Missing Output", "Please specify an output file.")
            return

        thresh = self.spin_thresh_single.value()
        max_dist = self.spin_dist_single.value()

        self.btn_run_single.setEnabled(False)
        self.prog_single.setValue(10)

        def job(task=None):
            return CloudRemover.remove_clouds_spatial(
                input_raster_path=in_p,
                output_raster_path=out_p,
                brightness_threshold=thresh,
                max_search_distance=max_dist
            )

        def on_ok(stats):
            self.prog_single.setValue(100)
            self.btn_run_single.setEnabled(True)
            self.btn_view_report.setEnabled(True)

            params = {"brightness_threshold": thresh, "max_search_distance": max_dist}
            self.last_provenance_data = ProvenanceReportGenerator.generate_report(
                operation_name="Single-Scene Cloud Inpainting",
                input_files=[in_p],
                output_file=out_p,
                parameters=params,
                metrics=stats
            )
            ProvenanceReportGenerator.save_sidecar_report(self.last_provenance_data, out_p)

            if self.chk_auto_add_single.isChecked():
                lyr = QgsRasterLayer(out_p, os.path.basename(out_p))
                if lyr.isValid():
                    QgsProject.instance().addMapLayer(lyr)

            QMessageBox.information(
                self,
                "Cloud Inpainting Complete",
                f"Single-scene cloud inpainting complete!\n\n"
                f"Cloud Coverage: {stats.get('cloud_coverage_percent')}%\n"
                f"Output: {out_p}"
            )

        def on_err(exc):
            self.prog_single.setValue(0)
            self.btn_run_single.setEnabled(True)
            QMessageBox.critical(self, "Cloud Inpainting Error", f"Operation failed:\n{str(exc)}")

        run_in_background(
            "Single-Scene Cloud Inpainting",
            job,
            on_completed=on_ok,
            on_failed=on_err,
            on_progress=lambda p: self.prog_single.setValue(int(p))
        )

    def _open_report(self):
        if self.last_provenance_data:
            dlg = ReportViewerDialog(self.last_provenance_data, self)
            dlg.exec()

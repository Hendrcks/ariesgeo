"""
Aries Cloud, Shadow & SLC-Off Recovery Dialog for QGIS.
Integrates the USGS / ENVI `landsat_gapfill` Local Linear Histogram Matching (LLHM),
Global Histogram Matching (GLHM), Multi-Donor Compositing, and Single-File Delaunay Triangulation
with native QGIS project-layer selectors and theme-adaptive UI.
"""

import os
import tempfile
from typing import Optional, List, Tuple
from qgis.PyQt.QtWidgets import (
    QDialog,
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QTabWidget,
    QLabel,
    QPushButton,
    QToolButton,
    QLineEdit,
    QComboBox,
    QFileDialog,
    QDoubleSpinBox,
    QSpinBox,
    QCheckBox,
    QProgressBar,
    QMessageBox,
    QListWidget,
    QFormLayout,
    QGroupBox,
)
from qgis.PyQt.QtCore import Qt
from qgis.core import QgsApplication, QgsProject, QgsRasterLayer
from ..resources import get_icon
from ..core.logging import log_warning
from ..core.task_manager import run_in_background
from ..raster.cloud_remover import CloudRemover
from ..raster.reports import ProvenanceReportGenerator
from .report_dialog import ReportViewerDialog


def _theme_icon(name: str, fallback: str = "cloud"):
    ic = QgsApplication.getThemeIcon(name)
    if ic and not ic.isNull():
        return ic
    return get_icon(fallback)


class CloudRemoverDialog(QDialog):
    """
    Theme-adaptive QGIS dialog for removing clouds, cast shadows, and Landsat SLC-off stripes
    via USGS `landsat_gapfill` multi-temporal LLHM/GLHM recovery or single-scene triangulation/IDW.
    """

    MASK_MODES: List[Tuple[str, str]] = [
        ("Auto Spectral Cloud + Shadow Detection", "spectral"),
        ("Unified SLC-Off Stripes + Clouds + Shadows", "slc_and_clouds"),
        ("Landsat Collection 2 QA_PIXEL Bitmask", "landsat_qa"),
        ("Sentinel-2 L2A SCL Classification", "sentinel_scl"),
        ("External Binary Cloud/Gap Mask Raster", "custom_mask"),
    ]

    RADIOMETRY_MODES: List[Tuple[str, str]] = [
        ("USGS Local Linear Histogram Matching (LLHM — Best)", "llhm"),
        ("USGS Global Linear Histogram Matching (GLHM — Fast)", "glhm"),
        ("Direct Clear-Pixel Transfer (No Radiometric Shift)", "none"),
    ]

    SINGLE_METHODS: List[Tuple[str, str]] = [
        ("Single-File Delaunay Triangulation (USGS / ENVI Gapfill)", "triangulation"),
        ("Multi-Scale Edge IDW Inpainting (GDAL FillNodata)", "idw"),
    ]

    def __init__(self, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.setWindowTitle("Aries Cloud & SLC-Off Remover")
        self.setWindowIcon(get_icon("cloud"))
        self.resize(720, 620)

        self.last_provenance_data = None
        self._active_worker = None
        self._setup_ui()
        self.refresh_project_layers()

    def _setup_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(10, 10, 10, 10)
        main_layout.setSpacing(8)

        # Native Tab Bar (DocumentMode blends cleanly into QGIS Light & Dark themes)
        self.tabs = QTabWidget(self)
        self.tabs.setDocumentMode(True)

        self.tab_multitemp = self._create_multitemporal_tab()
        self.tab_single = self._create_single_scene_tab()
        self.tab_mask_preview = self._create_mask_preview_tab()

        self.tabs.addTab(self.tab_multitemp, "Multi-Temporal LLHM Recovery (Best Quality)")
        self.tabs.addTab(self.tab_single, "Single-Scene Triangulation / Inpainting")
        self.tabs.addTab(self.tab_mask_preview, "Preview / Export Cloud Mask")
        main_layout.addWidget(self.tabs, 1)

        # Shared Live Status + Progress Bar
        self.lbl_status = QLabel("Ready — select a loaded QGIS raster layer or browse from disk.")
        self.lbl_status.setWordWrap(True)
        main_layout.addWidget(self.lbl_status)

        self.progress_bar = QProgressBar(self)
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        main_layout.addWidget(self.progress_bar)

        # Bottom Actions
        bottom_layout = QHBoxLayout()
        self.btn_view_report = QPushButton(_theme_icon("mActionShowAllLayers.svg", "report"), "View Quality Report")
        self.btn_view_report.setEnabled(False)
        self.btn_view_report.clicked.connect(self._open_report)

        self.btn_refresh_layers = QPushButton(_theme_icon("mActionRefresh.svg", "settings"), "Refresh QGIS Layers")
        self.btn_refresh_layers.clicked.connect(self.refresh_project_layers)

        btn_close = QPushButton("Close")
        btn_close.clicked.connect(self.close)

        bottom_layout.addWidget(self.btn_view_report)
        bottom_layout.addWidget(self.btn_refresh_layers)
        bottom_layout.addStretch()
        bottom_layout.addWidget(btn_close)
        main_layout.addLayout(bottom_layout)

    # ------------------------------------------------------------------
    # Helper: Project Layer Picker synced with File LineEdit
    # ------------------------------------------------------------------
    def _make_layer_file_row(
        self,
        placeholder: str,
        on_path_selected=None,
    ) -> Tuple[QVBoxLayout, QComboBox, QLineEdit]:
        vbox = QVBoxLayout()
        vbox.setContentsMargins(0, 0, 0, 0)
        vbox.setSpacing(4)

        cmb = QComboBox()
        cmb.setToolTip("Pick a raster layer currently loaded in the QGIS project")

        hbox = QHBoxLayout()
        hbox.setContentsMargins(0, 0, 0, 0)
        hbox.setSpacing(4)
        txt = QLineEdit()
        txt.setPlaceholderText(placeholder)
        txt.setClearButtonEnabled(True)
        btn = QPushButton("Browse...")
        btn.clicked.connect(lambda: self._browse_raster(txt, on_path_selected))
        hbox.addWidget(txt, 1)
        hbox.addWidget(btn)

        def _on_combo_changed(idx: int):
            path = cmb.itemData(idx)
            if path and isinstance(path, str) and os.path.exists(path):
                txt.setText(path)
                if on_path_selected:
                    on_path_selected(path)

        cmb.currentIndexChanged.connect(_on_combo_changed)
        vbox.addWidget(cmb)
        vbox.addLayout(hbox)
        return vbox, cmb, txt

    def refresh_project_layers(self):
        """Populate raster combos from active QGIS project layers."""
        rasters: List[Tuple[str, str]] = []
        try:
            for lyr in QgsProject.instance().mapLayers().values():
                if isinstance(lyr, QgsRasterLayer) and lyr.isValid():
                    src = lyr.source().split("|")[0]
                    if os.path.exists(src):
                        rasters.append((f"{lyr.name()}  ({os.path.basename(src)})", src))
        except (AttributeError, RuntimeError) as lyr_err:
            log_warning(f"Could not enumerate project raster layers: {lyr_err}")

        for cmb in (
            self.cmb_target_mt,
            self.cmb_donor_pick_mt,
            self.cmb_single_in,
            self.cmb_mask_in,
        ):
            cmb.blockSignals(True)
            cmb.clear()
            cmb.addItem("— Select from loaded QGIS Raster Layers (or browse below) —", "")
            for label, src in rasters:
                cmb.addItem(label, src)
            cmb.blockSignals(False)

    def _suggest_output_path(self, input_path: str, suffix: str) -> str:
        if not input_path:
            return ""
        folder = os.path.dirname(os.path.abspath(input_path))
        stem = os.path.splitext(os.path.basename(input_path))[0]
        if not os.access(folder, os.W_OK):
            folder = tempfile.gettempdir()
        return os.path.join(folder, f"{stem}_{suffix}.tif")

    # ------------------------------------------------------------------
    # Tab 1: Multi-Temporal USGS LLHM Cloud & SLC-Off Recovery
    # ------------------------------------------------------------------
    def _create_multitemporal_tab(self) -> QWidget:
        tab = QWidget()
        layout = QVBoxLayout(tab)
        layout.setSpacing(8)

        grp_target = QGroupBox("1. Cloudy / SLC-Off Target Image & Masking")
        form_target = QFormLayout(grp_target)

        def _auto_out_mt(p: str):
            if not self.txt_out_scene.text().strip():
                self.txt_out_scene.setText(self._suggest_output_path(p, "cloudfree_llhm"))

        tgt_box, self.cmb_target_mt, self.txt_target_scene = self._make_layer_file_row(
            "Select cloudy or SLC-off target GeoTIFF...",
            on_path_selected=_auto_out_mt,
        )
        self.txt_target_scene.editingFinished.connect(
            lambda: _auto_out_mt(self.txt_target_scene.text().strip())
        )
        form_target.addRow("Target Raster:", tgt_box)

        self.cmb_mask_mode_mt = QComboBox()
        for label, key in self.MASK_MODES:
            self.cmb_mask_mode_mt.addItem(label, key)
        form_target.addRow("Detection Mode:", self.cmb_mask_mode_mt)

        ext_mask_row = QHBoxLayout()
        self.txt_ext_mask_mt = QLineEdit()
        self.txt_ext_mask_mt.setPlaceholderText("Optional QA_PIXEL / SCL / binary mask raster (*.tif)...")
        self.txt_ext_mask_mt.setClearButtonEnabled(True)
        btn_ext_mt = QPushButton("Browse...")
        btn_ext_mt.clicked.connect(lambda: self._browse_raster(self.txt_ext_mask_mt))
        ext_mask_row.addWidget(self.txt_ext_mask_mt, 1)
        ext_mask_row.addWidget(btn_ext_mt)
        form_target.addRow("External QA / Mask:", ext_mask_row)

        sens_row = QHBoxLayout()
        self.spin_thresh_mt = QDoubleSpinBox()
        self.spin_thresh_mt.setRange(0.10, 0.95)
        self.spin_thresh_mt.setSingleStep(0.05)
        self.spin_thresh_mt.setValue(0.60)
        self.spin_thresh_mt.setToolTip("Lower values catch thinner haze/clouds; higher values target only bright clouds")

        self.spin_dilation_mt = QSpinBox()
        self.spin_dilation_mt.setRange(0, 12)
        self.spin_dilation_mt.setValue(2)
        self.spin_dilation_mt.setSuffix(" px")
        self.spin_dilation_mt.setToolTip("Buffer around detected clouds & shadows to eliminate bright cloud halos")

        self.chk_shadows_mt = QCheckBox("Detect & Remove Cast Cloud Shadows")
        self.chk_shadows_mt.setChecked(True)

        sens_row.addWidget(QLabel("Threshold:"))
        sens_row.addWidget(self.spin_thresh_mt)
        sens_row.addWidget(QLabel("Halo Buffer:"))
        sens_row.addWidget(self.spin_dilation_mt)
        sens_row.addWidget(self.chk_shadows_mt)
        sens_row.addStretch()
        form_target.addRow("Cloud & Shadow:", sens_row)

        layout.addWidget(grp_target)

        # Donors Group
        grp_donors = QGroupBox("2. Clear Reference / Donor Scenes (Auto Co-Registered to Target Grid)")
        vbox_donors = QVBoxLayout(grp_donors)

        pick_layer_row = QHBoxLayout()
        self.cmb_donor_pick_mt = QComboBox()
        btn_add_layer_donor = QPushButton("+ Add Selected QGIS Layer")
        btn_add_layer_donor.clicked.connect(self._add_donor_from_combo)
        btn_add_files_donor = QPushButton("+ Browse Donor Files...")
        btn_add_files_donor.clicked.connect(self._add_donor_scenes)
        btn_rem_donor = QPushButton("Remove")
        btn_rem_donor.clicked.connect(self._remove_selected_donor)

        pick_layer_row.addWidget(self.cmb_donor_pick_mt, 1)
        pick_layer_row.addWidget(btn_add_layer_donor)
        pick_layer_row.addWidget(btn_add_files_donor)
        pick_layer_row.addWidget(btn_rem_donor)
        vbox_donors.addLayout(pick_layer_row)

        self.donor_list = QListWidget()
        self.donor_list.setMaximumHeight(85)
        vbox_donors.addWidget(self.donor_list)

        rad_form = QFormLayout()
        self.cmb_radiometry_mt = QComboBox()
        for label, key in self.RADIOMETRY_MODES:
            self.cmb_radiometry_mt.addItem(label, key)
        rad_form.addRow("Harmonization Model:", self.cmb_radiometry_mt)

        win_row = QHBoxLayout()
        self.spin_win_mt = QSpinBox()
        self.spin_win_mt.setRange(9, 151)
        self.spin_win_mt.setSingleStep(8)
        self.spin_win_mt.setValue(33)
        self.spin_win_mt.setSuffix(" px")
        self.spin_win_mt.setToolTip("Initial local moving window size for USGS LLHM (expands automatically over large clouds)")

        self.chk_residual_tri_mt = QCheckBox("Fill any remaining overlap holes via Delaunay Triangulation")
        self.chk_residual_tri_mt.setChecked(True)

        # Backward compatibility attribute
        self.chk_radiometry_mt = QCheckBox()
        self.chk_radiometry_mt.setChecked(True)
        self.chk_radiometry_mt.hide()

        win_row.addWidget(QLabel("LLHM Window:"))
        win_row.addWidget(self.spin_win_mt)
        win_row.addSpacing(12)
        win_row.addWidget(self.chk_residual_tri_mt)
        win_row.addStretch()
        rad_form.addRow("Gapfill Options:", win_row)
        vbox_donors.addLayout(rad_form)

        layout.addWidget(grp_donors)

        # Outputs Group
        grp_out = QGroupBox("3. Output Destination")
        form_out = QFormLayout(grp_out)

        out_layout = QHBoxLayout()
        self.txt_out_scene = QLineEdit()
        self.txt_out_scene.setPlaceholderText("Output cloud-free GeoTIFF (*.tif)...")
        btn_browse_out = QPushButton("Browse...")
        btn_browse_out.clicked.connect(lambda: self._save_raster(self.txt_out_scene))
        out_layout.addWidget(self.txt_out_scene, 1)
        out_layout.addWidget(btn_browse_out)
        form_out.addRow("Restored Output:", out_layout)

        mask_layout = QHBoxLayout()
        self.txt_out_mask = QLineEdit()
        self.txt_out_mask.setPlaceholderText("Optional classified cloud/shadow mask (*.tif)...")
        btn_browse_mask = QPushButton("Browse...")
        btn_browse_mask.clicked.connect(lambda: self._save_raster(self.txt_out_mask))
        mask_layout.addWidget(self.txt_out_mask, 1)
        mask_layout.addWidget(btn_browse_mask)
        form_out.addRow("Save Mask (Optional):", mask_layout)

        self.chk_auto_add_mt = QCheckBox("Load restored cloud-free raster into QGIS canvas")
        self.chk_auto_add_mt.setChecked(True)
        form_out.addRow("", self.chk_auto_add_mt)

        layout.addWidget(grp_out)

        self.prog_mt = self.progress_bar if hasattr(self, "progress_bar") else QProgressBar()
        self.btn_run_mt = QPushButton(_theme_icon("mActionStart.svg", "cloud"), "Run Multi-Temporal Cloud & SLC-Off Recovery")
        self.btn_run_mt.setDefault(True)
        self.btn_run_mt.clicked.connect(self._run_multitemporal)
        layout.addWidget(self.btn_run_mt)
        layout.addStretch()
        return tab

    # ------------------------------------------------------------------
    # Tab 2: Single-Scene Triangulation / Inpainting (No Donor Required)
    # ------------------------------------------------------------------
    def _create_single_scene_tab(self) -> QWidget:
        tab = QWidget()
        layout = QVBoxLayout(tab)
        layout.setSpacing(8)

        grp_single = QGroupBox("Single-Scene Cloud, Shadow & SLC-Off Restoration (No Donor Required)")
        form_single = QFormLayout(grp_single)

        def _auto_out_single(p: str):
            if not self.txt_single_out.text().strip():
                self.txt_single_out.setText(self._suggest_output_path(p, "cloudfree_single"))

        in_box, self.cmb_single_in, self.txt_single_in = self._make_layer_file_row(
            "Select single cloudy or SLC-off raster (*.tif)...",
            on_path_selected=_auto_out_single,
        )
        self.txt_single_in.editingFinished.connect(
            lambda: _auto_out_single(self.txt_single_in.text().strip())
        )
        form_single.addRow("Input Raster:", in_box)

        self.cmb_single_method = QComboBox()
        for label, key in self.SINGLE_METHODS:
            self.cmb_single_method.addItem(label, key)
        form_single.addRow("Interpolation Engine:", self.cmb_single_method)

        self.cmb_mask_mode_single = QComboBox()
        for label, key in self.MASK_MODES:
            self.cmb_mask_mode_single.addItem(label, key)
        form_single.addRow("Detection Mode:", self.cmb_mask_mode_single)

        ext_s_row = QHBoxLayout()
        self.txt_ext_mask_single = QLineEdit()
        self.txt_ext_mask_single.setPlaceholderText("Optional external QA / binary mask raster (*.tif)...")
        self.txt_ext_mask_single.setClearButtonEnabled(True)
        btn_ext_s = QPushButton("Browse...")
        btn_ext_s.clicked.connect(lambda: self._browse_raster(self.txt_ext_mask_single))
        ext_s_row.addWidget(self.txt_ext_mask_single, 1)
        ext_s_row.addWidget(btn_ext_s)
        form_single.addRow("External QA / Mask:", ext_s_row)

        p_row = QHBoxLayout()
        self.spin_thresh_single = QDoubleSpinBox()
        self.spin_thresh_single.setRange(0.10, 0.95)
        self.spin_thresh_single.setSingleStep(0.05)
        self.spin_thresh_single.setValue(0.60)

        self.spin_dist_single = QSpinBox()
        self.spin_dist_single.setRange(10, 1000)
        self.spin_dist_single.setValue(150)
        self.spin_dist_single.setSuffix(" px")

        self.chk_shadows_single = QCheckBox("Include Cloud Shadows")
        self.chk_shadows_single.setChecked(True)

        p_row.addWidget(QLabel("Threshold:"))
        p_row.addWidget(self.spin_thresh_single)
        p_row.addWidget(QLabel("Max Fill Width:"))
        p_row.addWidget(self.spin_dist_single)
        p_row.addWidget(self.chk_shadows_single)
        p_row.addStretch()
        form_single.addRow("Parameters:", p_row)

        out_layout = QHBoxLayout()
        self.txt_single_out = QLineEdit()
        self.txt_single_out.setPlaceholderText("Output restored GeoTIFF (*.tif)...")
        btn_browse_out = QPushButton("Browse...")
        btn_browse_out.clicked.connect(lambda: self._save_raster(self.txt_single_out))
        out_layout.addWidget(self.txt_single_out, 1)
        out_layout.addWidget(btn_browse_out)
        form_single.addRow("Restored Output:", out_layout)

        self.chk_auto_add_single = QCheckBox("Load restored output layer into QGIS canvas")
        self.chk_auto_add_single.setChecked(True)
        form_single.addRow("", self.chk_auto_add_single)

        layout.addWidget(grp_single)

        self.btn_run_single = QPushButton(_theme_icon("mActionStart.svg", "cloud"), "Run Single-Scene Cloud & Gap Restoration")
        self.btn_run_single.clicked.connect(self._run_single)
        layout.addWidget(self.btn_run_single)
        layout.addStretch()
        return tab

    # ------------------------------------------------------------------
    # Tab 3: Cloud, Shadow & SLC-Off Mask Preview / Extractor
    # ------------------------------------------------------------------
    def _create_mask_preview_tab(self) -> QWidget:
        tab = QWidget()
        layout = QVBoxLayout(tab)
        layout.setSpacing(8)

        grp = QGroupBox("Test & Export Classified Cloud / Shadow / SLC-Off Mask (0=Clear, 1=Cloud, 2=Shadow/Gap)")
        form = QFormLayout(grp)

        def _auto_out_mask(p: str):
            if not self.txt_mask_preview_out.text().strip():
                self.txt_mask_preview_out.setText(self._suggest_output_path(p, "cloud_mask"))

        m_box, self.cmb_mask_in, self.txt_mask_preview_in = self._make_layer_file_row(
            "Select input raster to inspect cloud & shadow detection...",
            on_path_selected=_auto_out_mask,
        )
        form.addRow("Input Raster:", m_box)

        self.cmb_mask_mode_prev = QComboBox()
        for label, key in self.MASK_MODES:
            self.cmb_mask_mode_prev.addItem(label, key)
        form.addRow("Detection Mode:", self.cmb_mask_mode_prev)

        row_opts = QHBoxLayout()
        self.spin_thresh_prev = QDoubleSpinBox()
        self.spin_thresh_prev.setRange(0.10, 0.95)
        self.spin_thresh_prev.setSingleStep(0.05)
        self.spin_thresh_prev.setValue(0.60)

        self.spin_dil_prev = QSpinBox()
        self.spin_dil_prev.setRange(0, 12)
        self.spin_dil_prev.setValue(2)
        self.spin_dil_prev.setSuffix(" px")

        self.chk_shadows_prev = QCheckBox("Detect Cloud Shadows")
        self.chk_shadows_prev.setChecked(True)

        row_opts.addWidget(QLabel("Threshold:"))
        row_opts.addWidget(self.spin_thresh_prev)
        row_opts.addWidget(QLabel("Buffer:"))
        row_opts.addWidget(self.spin_dil_prev)
        row_opts.addWidget(self.chk_shadows_prev)
        row_opts.addStretch()
        form.addRow("Sensitivity:", row_opts)

        out_row = QHBoxLayout()
        self.txt_mask_preview_out = QLineEdit()
        self.txt_mask_preview_out.setPlaceholderText("Output classified mask GeoTIFF (*.tif)...")
        btn_out = QPushButton("Browse...")
        btn_out.clicked.connect(lambda: self._save_raster(self.txt_mask_preview_out))
        out_row.addWidget(self.txt_mask_preview_out, 1)
        out_row.addWidget(btn_out)
        form.addRow("Output Mask:", out_row)

        layout.addWidget(grp)

        self.btn_run_mask_prev = QPushButton(_theme_icon("mActionStart.svg", "cloud"), "Generate & Load Cloud Mask into QGIS")
        self.btn_run_mask_prev.clicked.connect(self._run_mask_preview)
        layout.addWidget(self.btn_run_mask_prev)
        layout.addStretch()
        return tab

    # ------------------------------------------------------------------
    # File / Layer Helpers
    # ------------------------------------------------------------------
    def _browse_raster(self, line_edit: QLineEdit, callback=None):
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Select Raster",
            "",
            "Raster Images (*.tif *.tiff *.jp2 *.img *.vrt);;All Files (*)",
        )
        if path:
            line_edit.setText(path)
            if callback:
                callback(path)

    def _save_raster(self, line_edit: QLineEdit):
        path, _ = QFileDialog.getSaveFileName(self, "Save GeoTIFF", "", "GeoTIFF Image (*.tif *.tiff)")
        if path:
            if not path.lower().endswith((".tif", ".tiff")):
                path += ".tif"
            line_edit.setText(path)

    def _add_donor_from_combo(self):
        path = self.cmb_donor_pick_mt.currentData()
        if path and os.path.exists(path):
            existing = {self.donor_list.item(i).text() for i in range(self.donor_list.count())}
            if path not in existing:
                self.donor_list.addItem(path)

    def _add_donor_scenes(self):
        files, _ = QFileDialog.getOpenFileNames(
            self,
            "Select Clear Donor Scenes",
            "",
            "Raster Images (*.tif *.tiff *.jp2 *.img *.vrt);;All Files (*)",
        )
        existing = {self.donor_list.item(i).text() for i in range(self.donor_list.count())}
        for f in files:
            if f not in existing:
                self.donor_list.addItem(f)

    def _remove_selected_donor(self):
        for item in self.donor_list.selectedItems():
            self.donor_list.takeItem(self.donor_list.row(item))

    def _set_running_state(self, running: bool, status_text: str = ""):
        self.btn_run_mt.setEnabled(not running)
        self.btn_run_single.setEnabled(not running)
        self.btn_run_mask_prev.setEnabled(not running)
        if status_text:
            self.lbl_status.setText(status_text)

    def _on_worker_progress(self, pct: float, msg: str = ""):
        self.progress_bar.setValue(int(pct))
        if msg:
            self.lbl_status.setText(msg)

    # ------------------------------------------------------------------
    # Execution Handlers
    # ------------------------------------------------------------------
    def _run_multitemporal(self):
        target_p = self.txt_target_scene.text().strip()
        if not target_p or not os.path.exists(target_p):
            QMessageBox.warning(self, "Invalid Target", "Please select a valid cloudy or SLC-off target raster.")
            return

        donors = [self.donor_list.item(i).text() for i in range(self.donor_list.count())]
        # Convenience: if donor_list is empty, check if user selected one in cmb_donor_pick_mt
        if not donors:
            combo_donor = self.cmb_donor_pick_mt.currentData()
            if combo_donor and os.path.exists(combo_donor) and combo_donor != target_p:
                donors = [combo_donor]
                self.donor_list.addItem(combo_donor)

        if not donors:
            QMessageBox.warning(
                self,
                "No Donor Scene Added",
                "Please add at least one clear donor raster (or switch to the 'Single-Scene Triangulation / Inpainting' tab if you only have one image).",
            )
            return

        out_p = self.txt_out_scene.text().strip()
        if not out_p:
            out_p = self._suggest_output_path(target_p, "cloudfree_llhm")
            self.txt_out_scene.setText(out_p)

        mask_p = self.txt_out_mask.text().strip() or None
        ext_mask = self.txt_ext_mask_mt.text().strip() or None
        mask_mode = self.cmb_mask_mode_mt.currentData() or "spectral"
        rad_mode = self.cmb_radiometry_mt.currentData() or "llhm"
        thresh = self.spin_thresh_mt.value()
        dil = self.spin_dilation_mt.value()
        shadows = self.chk_shadows_mt.isChecked()
        win_sz = self.spin_win_mt.value()
        res_tri = self.chk_residual_tri_mt.isChecked()

        self.progress_bar.setValue(5)
        self._set_running_state(True, "Starting USGS LLHM multi-temporal cloud & gap recovery...")

        def job(task=None):
            def _cb(p: float, m: str):
                if task is not None:
                    task.report_progress(p, m)

            return CloudRemover.remove_clouds_multitemporal(
                target_scene_path=target_p,
                donor_scene_paths=donors,
                output_raster_path=out_p,
                output_mask_path=mask_p,
                brightness_threshold=thresh,
                apply_radiometry=(rad_mode != "none"),
                radiometry_method=rad_mode,
                detect_shadows=shadows,
                include_slc_gaps=(mask_mode == "slc_and_clouds"),
                dilation_radius=dil,
                mask_mode=mask_mode,
                external_mask_path=ext_mask,
                window_size=win_sz,
                fill_residual_holes=res_tri,
                progress_callback=_cb,
            )

        def on_ok(stats):
            self.progress_bar.setValue(100)
            self._set_running_state(
                False,
                f"Done — Masked: {stats.get('cloud_coverage_percent')}% ({stats.get('cloud_pixels'):,} px), "
                f"Recovered: {stats.get('recovery_rate_percent', 100.0)}%.",
            )
            self.btn_view_report.setEnabled(True)

            params = {
                "mask_mode": mask_mode,
                "radiometry_method": rad_mode,
                "brightness_threshold": thresh,
                "detect_shadows": shadows,
                "llhm_window_size": win_sz,
                "donors_count": len(donors),
            }
            self.last_provenance_data = ProvenanceReportGenerator.generate_report(
                operation_name="Multi-Temporal Cloud & SLC-Off Recovery (USGS LLHM)",
                input_files=[target_p] + donors,
                output_file=out_p,
                parameters=params,
                metrics=stats,
            )
            ProvenanceReportGenerator.save_sidecar_report(self.last_provenance_data, out_p)

            if self.chk_auto_add_mt.isChecked() and os.path.exists(out_p):
                lyr = QgsRasterLayer(out_p, os.path.splitext(os.path.basename(out_p))[0])
                if lyr.isValid():
                    QgsProject.instance().addMapLayer(lyr)
            if mask_p and os.path.exists(mask_p) and self.chk_auto_add_mt.isChecked():
                m_lyr = QgsRasterLayer(mask_p, os.path.splitext(os.path.basename(mask_p))[0])
                if m_lyr.isValid():
                    QgsProject.instance().addMapLayer(m_lyr)

            QMessageBox.information(
                self,
                "Cloud & Gap Recovery Complete",
                f"Multi-temporal restoration finished successfully!\n\n"
                f"Detected Cloud/Shadow/Gap Coverage: {stats.get('cloud_coverage_percent')}% ({stats.get('cloud_pixels'):,} px)\n"
                f"Pixel Recovery Rate: {stats.get('recovery_rate_percent', 100.0)}%\n"
                f"Harmonization Model: {rad_mode.upper()}\n"
                f"Output: {out_p}",
            )

        def on_err(exc):
            self.progress_bar.setValue(0)
            self._set_running_state(False, f"Error: {exc}")
            QMessageBox.critical(self, "Cloud Removal Error", f"Operation failed:\n{exc}")

        self._active_worker = run_in_background(
            "Multi-Temporal Cloud Removal",
            job,
            on_completed=on_ok,
            on_failed=on_err,
            on_progress=self._on_worker_progress,
        )

    def _run_single(self):
        in_p = self.txt_single_in.text().strip()
        if not in_p or not os.path.exists(in_p):
            QMessageBox.warning(self, "Invalid Input", "Please select a valid input raster.")
            return

        out_p = self.txt_single_out.text().strip()
        if not out_p:
            out_p = self._suggest_output_path(in_p, "cloudfree_single")
            self.txt_single_out.setText(out_p)

        method = self.cmb_single_method.currentData() or "triangulation"
        mask_mode = self.cmb_mask_mode_single.currentData() or "spectral"
        ext_mask = self.txt_ext_mask_single.text().strip() or None
        thresh = self.spin_thresh_single.value()
        max_dist = self.spin_dist_single.value()
        shadows = self.chk_shadows_single.isChecked()

        self.progress_bar.setValue(5)
        self._set_running_state(True, f"Running single-scene {method} restoration...")

        def job(task=None):
            def _cb(p: float, m: str):
                if task is not None:
                    task.report_progress(p, m)

            return CloudRemover.remove_clouds_spatial(
                input_raster_path=in_p,
                output_raster_path=out_p,
                brightness_threshold=thresh,
                max_search_distance=max_dist,
                method=method,
                detect_shadows=shadows,
                include_slc_gaps=(mask_mode == "slc_and_clouds"),
                mask_mode=mask_mode,
                external_mask_path=ext_mask,
                progress_callback=_cb,
            )

        def on_ok(stats):
            self.progress_bar.setValue(100)
            self._set_running_state(
                False,
                f"Done — Interpolated {stats.get('cloud_pixels'):,} cloud/gap pixels ({stats.get('cloud_coverage_percent')}%).",
            )
            self.btn_view_report.setEnabled(True)

            params = {
                "method": method,
                "mask_mode": mask_mode,
                "brightness_threshold": thresh,
                "max_search_distance": max_dist,
                "detect_shadows": shadows,
            }
            self.last_provenance_data = ProvenanceReportGenerator.generate_report(
                operation_name=f"Single-Scene Cloud & Gap Restoration ({method})",
                input_files=[in_p],
                output_file=out_p,
                parameters=params,
                metrics=stats,
            )
            ProvenanceReportGenerator.save_sidecar_report(self.last_provenance_data, out_p)

            if self.chk_auto_add_single.isChecked() and os.path.exists(out_p):
                lyr = QgsRasterLayer(out_p, os.path.splitext(os.path.basename(out_p))[0])
                if lyr.isValid():
                    QgsProject.instance().addMapLayer(lyr)

            QMessageBox.information(
                self,
                "Single-Scene Restoration Complete",
                f"Single-scene restoration completed!\n\n"
                f"Engine: {method.title()}\n"
                f"Masked Coverage: {stats.get('cloud_coverage_percent')}% ({stats.get('cloud_pixels'):,} px)\n"
                f"Output: {out_p}",
            )

        def on_err(exc):
            self.progress_bar.setValue(0)
            self._set_running_state(False, f"Error: {exc}")
            QMessageBox.critical(self, "Restoration Error", f"Operation failed:\n{exc}")

        self._active_worker = run_in_background(
            "Single-Scene Cloud Restoration",
            job,
            on_completed=on_ok,
            on_failed=on_err,
            on_progress=self._on_worker_progress,
        )

    def _run_mask_preview(self):
        in_p = self.txt_mask_preview_in.text().strip()
        if not in_p or not os.path.exists(in_p):
            QMessageBox.warning(self, "Invalid Input", "Please select an input raster to inspect.")
            return

        out_p = self.txt_mask_preview_out.text().strip()
        if not out_p:
            out_p = self._suggest_output_path(in_p, "cloud_mask")
            self.txt_mask_preview_out.setText(out_p)

        mask_mode = self.cmb_mask_mode_prev.currentData() or "spectral"
        thresh = self.spin_thresh_prev.value()
        dil = self.spin_dil_prev.value()
        shadows = self.chk_shadows_prev.isChecked()

        self.progress_bar.setValue(15)
        self._set_running_state(True, "Generating classified cloud & shadow mask...")

        def job(task=None):
            return CloudRemover.generate_cloud_mask_raster(
                input_raster_path=in_p,
                output_mask_path=out_p,
                brightness_threshold=thresh,
                dilation_radius=dil,
                detect_shadows=shadows,
                mask_mode=mask_mode,
            )

        def on_ok(stats):
            self.progress_bar.setValue(100)
            self._set_running_state(
                False,
                f"Mask exported — Clouds: {stats['cloud_pixels']:,} px, Shadows/Gaps: {stats['shadow_or_gap_pixels']:,} px "
                f"({stats['cloud_coverage_percent']}% total).",
            )
            if os.path.exists(out_p):
                lyr = QgsRasterLayer(out_p, os.path.splitext(os.path.basename(out_p))[0])
                if lyr.isValid():
                    QgsProject.instance().addMapLayer(lyr)

            QMessageBox.information(
                self,
                "Cloud Mask Generated",
                f"Classified mask created and loaded into QGIS:\n\n"
                f"• Cloud pixels (1): {stats['cloud_pixels']:,}\n"
                f"• Shadow / SLC-off pixels (2): {stats['shadow_or_gap_pixels']:,}\n"
                f"• Total masked fraction: {stats['cloud_coverage_percent']}%\n\n"
                f"Saved to: {out_p}",
            )

        def on_err(exc):
            self.progress_bar.setValue(0)
            self._set_running_state(False, f"Error: {exc}")
            QMessageBox.critical(self, "Mask Generation Error", f"Failed to generate mask:\n{exc}")

        self._active_worker = run_in_background(
            "Generate Cloud Mask",
            job,
            on_completed=on_ok,
            on_failed=on_err,
            on_progress=self._on_worker_progress,
        )

    def _open_report(self):
        if self.last_provenance_data:
            dlg = ReportViewerDialog(self.last_provenance_data, self)
            dlg.exec()

"""
User interface widgets and dialogs for AriesGeo Toolbox.
"""

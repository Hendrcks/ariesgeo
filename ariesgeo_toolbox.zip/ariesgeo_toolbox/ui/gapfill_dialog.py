"""
Aries GapFill Dialog for Spatial NoData interpolation and Landsat 7 SLC-off donor gap filling.
"""

import os
from typing import Optional, List
from qgis.PyQt.QtWidgets import (
    QDialog,
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QTabWidget,
    QLabel,
    QPushButton,
    QLineEdit,
    QFileDialog,
    QSpinBox,
    QCheckBox,
    QProgressBar,
    QMessageBox,
    QListWidget,
    QFormLayout,
    QGroupBox,
)
from qgis.PyQt.QtCore import Qt
from qgis.core import QgsProject, QgsRasterLayer
from ..resources import get_icon
from ..core.settings import settings
from ..core.task_manager import run_in_background
from ..raster.gapfill import GapFiller
from ..raster.reports import ProvenanceReportGenerator
from .report_dialog import ReportViewerDialog

class GapFillDialog(QDialog):
    """Dialog providing Spatial NoData Interpolation and Landsat 7 SLC-off donor workflows."""

    def __init__(self, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.setWindowTitle("Aries Raster GapFill — AriesPlus")
        self.setWindowIcon(get_icon("gapfill"))
        self.resize(650, 520)

        self.last_provenance_data = None
        self._setup_ui()

    def _setup_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(12, 12, 12, 12)
        main_layout.setSpacing(10)

        # Header
        header_lbl = QLabel("<b>Aries Raster GapFill Engine</b>")
        header_lbl.setStyleSheet("""
            QLabel {
                font-size: 14px;
                color: #0B1F33;
                background-color: #FEF3C7;
                border-left: 4px solid #F2A51A;
                padding: 8px 12px;
                border-radius: 4px;
            }
        """)
        main_layout.addWidget(header_lbl)

        # Tabs
        self.tabs = QTabWidget()
        self.tab_spatial = self._create_spatial_tab()
        self.tab_landsat = self._create_landsat_tab()

        self.tabs.addTab(self.tab_spatial, "Spatial NoData Fill")
        self.tabs.addTab(self.tab_landsat, "Landsat 7 SLC-off Donor Fill")
        main_layout.addWidget(self.tabs)

        # Bottom Action Bar
        bottom_layout = QHBoxLayout()
        self.btn_view_report = QPushButton("View Quality Report")
        self.btn_view_report.setIcon(get_icon("report"))
        self.btn_view_report.setEnabled(False)
        self.btn_view_report.clicked.connect(self._open_report)

        btn_close = QPushButton("Close")
        btn_close.clicked.connect(self.accept)

        bottom_layout.addWidget(self.btn_view_report)
        bottom_layout.addStretch()
        bottom_layout.addWidget(btn_close)
        main_layout.addLayout(bottom_layout)

    # 1. Spatial NoData Tab
    def _create_spatial_tab(self) -> QWidget:
        tab = QWidget()
        layout = QVBoxLayout(tab)

        grp_input = QGroupBox("Input & Output Rasters")
        form_io = QFormLayout(grp_input)

        # Input raster
        in_layout = QHBoxLayout()
        self.txt_spatial_in = QLineEdit()
        btn_browse_in = QPushButton("Browse...")
        btn_browse_in.clicked.connect(lambda: self._browse_raster(self.txt_spatial_in))
        in_layout.addWidget(self.txt_spatial_in)
        in_layout.addWidget(btn_browse_in)
        form_io.addRow("Input Raster:", in_layout)

        # Output raster
        out_layout = QHBoxLayout()
        self.txt_spatial_out = QLineEdit()
        btn_browse_out = QPushButton("Browse...")
        btn_browse_out.clicked.connect(lambda: self._save_raster(self.txt_spatial_out))
        out_layout.addWidget(self.txt_spatial_out)
        out_layout.addWidget(btn_browse_out)
        form_io.addRow("Output Raster:", out_layout)

        layout.addWidget(grp_input)

        # Parameters
        grp_params = QGroupBox("Interpolation Parameters")
        form_params = QFormLayout(grp_params)

        self.spin_max_dist = QSpinBox()
        self.spin_max_dist.setRange(1, 2000)
        self.spin_max_dist.setValue(settings.default_gapfill_max_distance)
        self.spin_max_dist.setSuffix(" pixels")
        form_params.addRow("Max Search Distance:", self.spin_max_dist)

        self.spin_smooth = QSpinBox()
        self.spin_smooth.setRange(0, 10)
        self.spin_smooth.setValue(0)
        form_params.addRow("Smoothing Iterations:", self.spin_smooth)

        layout.addWidget(grp_params)

        # Progress and Run button
        self.prog_spatial = QProgressBar()
        self.prog_spatial.setValue(0)
        layout.addWidget(self.prog_spatial)

        self.chk_auto_add_spatial = QCheckBox("Add output layer to map canvas")
        self.chk_auto_add_spatial.setChecked(True)
        layout.addWidget(self.chk_auto_add_spatial)

        self.btn_run_spatial = QPushButton("Run Spatial GapFill")
        self.btn_run_spatial.setStyleSheet("background-color: #16A36A; color: white; font-weight: bold; padding: 7px;")
        self.btn_run_spatial.clicked.connect(self._run_spatial_fill)
        layout.addWidget(self.btn_run_spatial)

        layout.addStretch()
        return tab

    # 2. Landsat 7 SLC-off Tab
    def _create_landsat_tab(self) -> QWidget:
        tab = QWidget()
        layout = QVBoxLayout(tab)

        grp_scenes = QGroupBox("Landsat 7 Scenes")
        form_scenes = QFormLayout(grp_scenes)

        # Target scene
        target_layout = QHBoxLayout()
        self.txt_landsat_target = QLineEdit()
        btn_browse_tgt = QPushButton("Browse...")
        btn_browse_tgt.clicked.connect(lambda: self._browse_raster(self.txt_landsat_target))
        target_layout.addWidget(self.txt_landsat_target)
        target_layout.addWidget(btn_browse_tgt)
        form_scenes.addRow("Target Scene (Gapped):", target_layout)

        # Donor scenes list
        donor_bar = QHBoxLayout()
        btn_add_donors = QPushButton("Add Donor Scenes...")
        btn_add_donors.clicked.connect(self._add_donor_scenes)
        btn_rem_donor = QPushButton("Remove")
        btn_rem_donor.clicked.connect(self._remove_selected_donor)
        donor_bar.addWidget(btn_add_donors)
        donor_bar.addWidget(btn_rem_donor)
        donor_bar.addStretch()

        self.donor_list = QListWidget()
        form_scenes.addRow("Donor Scenes (Priority Order):", donor_bar)
        form_scenes.addRow("", self.donor_list)

        layout.addWidget(grp_scenes)

        # Output options
        grp_landsat_out = QGroupBox("Output Settings")
        form_out = QFormLayout(grp_landsat_out)

        out_layout = QHBoxLayout()
        self.txt_landsat_out = QLineEdit()
        btn_browse_l_out = QPushButton("Browse...")
        btn_browse_l_out.clicked.connect(lambda: self._save_raster(self.txt_landsat_out))
        out_layout.addWidget(self.txt_landsat_out)
        out_layout.addWidget(btn_browse_l_out)
        form_out.addRow("Filled Output Scene:", out_layout)

        self.chk_radiometry = QCheckBox("Apply Band-by-Band Linear Regression Harmonization")
        self.chk_radiometry.setChecked(True)
        form_out.addRow("Radiometry:", self.chk_radiometry)

        layout.addWidget(grp_landsat_out)

        # Progress and Run button
        self.prog_landsat = QProgressBar()
        self.prog_landsat.setValue(0)
        layout.addWidget(self.prog_landsat)

        self.chk_auto_add_landsat = QCheckBox("Add output layer to map canvas")
        self.chk_auto_add_landsat.setChecked(True)
        layout.addWidget(self.chk_auto_add_landsat)

        self.btn_run_landsat = QPushButton("Run Landsat 7 SLC-off GapFill")
        self.btn_run_landsat.setStyleSheet("background-color: #F2A51A; color: black; font-weight: bold; padding: 7px;")
        self.btn_run_landsat.clicked.connect(self._run_landsat_fill)
        layout.addWidget(self.btn_run_landsat)

        layout.addStretch()
        return tab

    def _browse_raster(self, line_edit: QLineEdit):
        path, _ = QFileDialog.getOpenFileName(self, "Select Raster", "", "GeoTIFF (*.tif *.tiff);;All Files (*)")
        if path:
            line_edit.setText(path)

    def _save_raster(self, line_edit: QLineEdit):
        path, _ = QFileDialog.getSaveFileName(self, "Save Output GeoTIFF", "", "GeoTIFF (*.tif *.tiff)")
        if path:
            if not path.endswith(".tif") and not path.endswith(".tiff"):
                path += ".tif"
            line_edit.setText(path)

    def _add_donor_scenes(self):
        files, _ = QFileDialog.getOpenFileNames(self, "Select Donor Scenes", "", "GeoTIFF (*.tif *.tiff);;All Files (*)")
        if files:
            for f in files:
                self.donor_list.addItem(f)

    def _remove_selected_donor(self):
        for item in self.donor_list.selectedItems():
            self.donor_list.takeItem(self.donor_list.row(item))

    # Execution Handlers
    def _run_spatial_fill(self):
        in_p = self.txt_spatial_in.text().strip()
        out_p = self.txt_spatial_out.text().strip()

        if not in_p or not os.path.exists(in_p):
            QMessageBox.warning(self, "Invalid Input", "Please select a valid input raster.")
            return
        if not out_p:
            QMessageBox.warning(self, "Missing Output", "Please specify an output destination file.")
            return

        max_dist = self.spin_max_dist.value()
        smooth = self.spin_smooth.value()

        self.btn_run_spatial.setEnabled(False)
        self.prog_spatial.setValue(10)

        def job(task=None):
            return GapFiller.fill_spatial_nodata(
                input_raster_path=in_p,
                output_raster_path=out_p,
                max_search_distance=max_dist,
                smoothing_iterations=smooth
            )

        def on_ok(res_path):
            self.prog_spatial.setValue(100)
            self.btn_run_spatial.setEnabled(True)
            self.btn_view_report.setEnabled(True)

            params = {"max_search_distance": max_dist, "smoothing_iterations": smooth}
            metrics = {"status": "success", "output_size_bytes": os.path.getsize(res_path)}
            self.last_provenance_data = ProvenanceReportGenerator.generate_report(
                operation_name="Spatial NoData GapFill",
                input_files=[in_p],
                output_file=res_path,
                parameters=params,
                metrics=metrics
            )
            ProvenanceReportGenerator.save_sidecar_report(self.last_provenance_data, res_path)

            if self.chk_auto_add_spatial.isChecked():
                lyr = QgsRasterLayer(res_path, os.path.basename(res_path))
                if lyr.isValid():
                    QgsProject.instance().addMapLayer(lyr)

            QMessageBox.information(self, "Success", f"Spatial NoData GapFill complete:\n{res_path}")

        def on_err(exc):
            self.prog_spatial.setValue(0)
            self.btn_run_spatial.setEnabled(True)
            QMessageBox.critical(self, "GapFill Error", f"Operation failed:\n{str(exc)}")

        run_in_background(
            "Spatial GapFill",
            job,
            on_completed=on_ok,
            on_failed=on_err,
            on_progress=lambda p: self.prog_spatial.setValue(int(p))
        )

    def _run_landsat_fill(self):
        target_p = self.txt_landsat_target.text().strip()
        out_p = self.txt_landsat_out.text().strip()
        donors = [self.donor_list.item(i).text() for i in range(self.donor_list.count())]

        if not target_p or not os.path.exists(target_p):
            QMessageBox.warning(self, "Invalid Target", "Please select a valid target Landsat scene.")
            return
        if not donors:
            QMessageBox.warning(self, "No Donors", "Please add at least one donor Landsat scene.")
            return
        if not out_p:
            QMessageBox.warning(self, "Missing Output", "Please specify an output destination file.")
            return

        rad = self.chk_radiometry.isChecked()
        self.btn_run_landsat.setEnabled(False)
        self.prog_landsat.setValue(10)

        def job(task=None):
            return GapFiller.fill_landsat7_slcoff(
                target_scene_path=target_p,
                donor_scene_paths=donors,
                output_raster_path=out_p,
                apply_radiometric_adjustment=rad
            )

        def on_ok(stats):
            self.prog_landsat.setValue(100)
            self.btn_run_landsat.setEnabled(True)
            self.btn_view_report.setEnabled(True)

            params = {"donor_count": len(donors), "radiometric_harmonization": rad}
            self.last_provenance_data = ProvenanceReportGenerator.generate_report(
                operation_name="Landsat 7 SLC-off GapFill",
                input_files=[target_p] + donors,
                output_file=out_p,
                parameters=params,
                metrics=stats
            )
            ProvenanceReportGenerator.save_sidecar_report(self.last_provenance_data, out_p)

            if self.chk_auto_add_landsat.isChecked():
                lyr = QgsRasterLayer(out_p, os.path.basename(out_p))
                if lyr.isValid():
                    QgsProject.instance().addMapLayer(lyr)

            QMessageBox.information(
                self,
                "Landsat GapFill Complete",
                f"Landsat 7 SLC-off fill completed successfully!\n\n"
                f"Initial Gaps: {stats.get('initial_gap_pixels'):,} px\n"
                f"Filled Gaps: {stats.get('filled_gap_pixels'):,} px\n"
                f"Residual Unfilled: {stats.get('unfilled_gap_pixels'):,} px"
            )

        def on_err(exc):
            self.prog_landsat.setValue(0)
            self.btn_run_landsat.setEnabled(True)
            QMessageBox.critical(self, "Landsat Fill Error", f"Operation failed:\n{str(exc)}")

        run_in_background(
            "Landsat 7 GapFill",
            job,
            on_completed=on_ok,
            on_failed=on_err,
            on_progress=lambda p: self.prog_landsat.setValue(int(p))
        )

    def _open_report(self):
        if self.last_provenance_data:
            dlg = ReportViewerDialog(self.last_provenance_data, self)
            dlg.exec()

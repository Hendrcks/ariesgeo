"""
AriesGeo Toolbox Settings and Preferences Dialog.
"""

from typing import Optional
from qgis.PyQt.QtWidgets import (
    QDialog,
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QTabWidget,
    QLabel,
    QPushButton,
    QLineEdit,
    QSpinBox,
    QCheckBox,
    QComboBox,
    QFileDialog,
    QMessageBox,
    QFormLayout,
    QGroupBox,
)
from ..resources import get_icon
from ..core.settings import settings
from ..place_finder.cache import GeocodingCache

class SettingsDialog(QDialog):
    """Configuration dialog for AriesGeo Toolbox."""

    def __init__(self, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.setWindowTitle("AriesGeo Toolbox Settings — AriesPlus")
        self.setWindowIcon(get_icon("settings"))
        self.resize(520, 420)

        self._setup_ui()
        self._load_settings()

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(10)

        # Tabs
        self.tabs = QTabWidget()

        # Tab 1: Place Finder Settings
        tab_finder = QWidget()
        form_finder = QFormLayout(tab_finder)

        self.combo_default_provider = QComboBox()
        self.combo_default_provider.addItems(["Photon (Komoot)", "OpenStreetMap (Nominatim)", "Offline Gazetteer"])
        form_finder.addRow("Default Provider:", self.combo_default_provider)

        self.spin_limit = QSpinBox()
        self.spin_limit.setRange(1, 50)
        form_finder.addRow("Default Result Limit:", self.spin_limit)

        self.chk_auto_zoom = QCheckBox("Auto-zoom canvas to selected result")
        form_finder.addRow("Map Navigation:", self.chk_auto_zoom)

        self.chk_auto_flash = QCheckBox("Flash location geometry on map canvas")
        form_finder.addRow("", self.chk_auto_flash)

        self.txt_email = QLineEdit()
        self.txt_email.setPlaceholderText("your-email@example.com (Required by OSM Nominatim)")
        form_finder.addRow("Nominatim Email:", self.txt_email)

        # Offline Gazetteer Path
        gaz_layout = QHBoxLayout()
        self.txt_gaz_path = QLineEdit()
        btn_browse_gaz = QPushButton("Browse...")
        btn_browse_gaz.clicked.connect(self._browse_gazetteer)
        gaz_layout.addWidget(self.txt_gaz_path)
        gaz_layout.addWidget(btn_browse_gaz)
        form_finder.addRow("Offline Gazetteer DB:", gaz_layout)

        btn_clear_cache = QPushButton("Clear Geocoding Cache")
        btn_clear_cache.clicked.connect(self._clear_cache)
        form_finder.addRow("Cache Management:", btn_clear_cache)

        self.tabs.addTab(tab_finder, "Place Finder")

        # Tab 2: Raster & Mosaic Settings
        tab_raster = QWidget()
        form_raster = QFormLayout(tab_raster)

        self.combo_compress = QComboBox()
        self.combo_compress.addItems(["DEFLATE", "LZW", "PACKBITS", "ZSTD", "NONE"])
        form_raster.addRow("Default Compression:", self.combo_compress)

        self.combo_resamp = QComboBox()
        self.combo_resamp.addItems(["bilinear", "nearest", "cubic", "lanczos", "mode"])
        form_raster.addRow("Default Resampling:", self.combo_resamp)

        self.chk_tiled = QCheckBox("Produce Tiled GeoTIFFs (Cloud-Optimized) by default")
        form_raster.addRow("Tiling:", self.chk_tiled)

        self.chk_overviews = QCheckBox("Generate Pyramid Overviews automatically")
        form_raster.addRow("Overviews:", self.chk_overviews)

        self.tabs.addTab(tab_raster, "Mosaic & Raster")
        layout.addWidget(self.tabs)

        # Buttons
        btn_layout = QHBoxLayout()
        btn_save = QPushButton("Save Settings")
        btn_save.setStyleSheet("background-color: #16A36A; color: white; font-weight: bold; padding: 6px 14px;")
        btn_cancel = QPushButton("Cancel")

        btn_save.clicked.connect(self._save_settings)
        btn_cancel.clicked.connect(self.reject)

        btn_layout.addStretch()
        btn_layout.addWidget(btn_cancel)
        btn_layout.addWidget(btn_save)
        layout.addLayout(btn_layout)

    def _load_settings(self):
        self.combo_default_provider.setCurrentText(settings.default_provider)
        self.spin_limit.setValue(settings.search_limit)
        self.chk_auto_zoom.setChecked(settings.auto_zoom)
        self.chk_auto_flash.setChecked(settings.auto_flash)
        self.txt_email.setText(settings.nominatim_email)
        self.txt_gaz_path.setText(settings.offline_gazetteer_path)

        self.combo_compress.setCurrentText(settings.default_compression)
        self.combo_resamp.setCurrentText(settings.default_resampling)
        self.chk_tiled.setChecked(settings.tiled_output)
        self.chk_overviews.setChecked(settings.build_overviews)

    def _save_settings(self):
        settings.default_provider = self.combo_default_provider.currentText()
        settings.search_limit = self.spin_limit.value()
        settings.auto_zoom = self.chk_auto_zoom.isChecked()
        settings.auto_flash = self.chk_auto_flash.isChecked()
        settings.nominatim_email = self.txt_email.text().strip()
        settings.offline_gazetteer_path = self.txt_gaz_path.text().strip()

        settings.default_compression = self.combo_compress.currentText()
        settings.default_resampling = self.combo_resamp.currentText()
        settings.tiled_output = self.chk_tiled.isChecked()
        settings.build_overviews = self.chk_overviews.isChecked()

        self.accept()

    def _browse_gazetteer(self):
        path, _ = QFileDialog.getOpenFileName(self, "Select Offline Gazetteer SQLite DB", "", "SQLite Database (*.sqlite *.db *.gpkg);;All Files (*)")
        if path:
            self.txt_gaz_path.setText(path)

    def _clear_cache(self):
        cache = GeocodingCache()
        cache.clear()
        QMessageBox.information(self, "Cache Cleared", "Geocoding query cache has been successfully cleared.")

"""
Aries Map Layout Assistant 5-Step Guided Wizard Dialog.
"""

import os
import datetime
from typing import Optional
from qgis.PyQt.QtWidgets import (
    QDialog,
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QStackedWidget,
    QLabel,
    QPushButton,
    QComboBox,
    QLineEdit,
    QCheckBox,
    QSpinBox,
    QDoubleSpinBox,
    QGroupBox,
    QFormLayout,
    QRadioButton,
    QMessageBox,
    QFileDialog,
    QTableWidget,
    QTableWidgetItem,
    QHeaderView,
)
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QColor, QFont
from qgis.core import QgsProject
from qgis.gui import QgisInterface
from ..resources import get_icon
from ..layout_assistant.models import LayoutConfig, Margins, TextMetadata, GridConfig, InsetConfig
from ..layout_assistant.templates import TEMPLATES
from ..layout_assistant.composer import LayoutComposer
from ..layout_assistant.quality import LayoutQualityChecker
from ..layout_assistant.exporter import LayoutExporter

class MapLayoutWizardDialog(QDialog):
    """5-Step Wizard for generating professional QGIS print layouts."""

    def __init__(self, iface: Optional[QgisInterface] = None, parent: Optional[QWidget] = None):
        super().__init__(parent or (iface.mainWindow() if iface else None))
        self.iface = iface
        self.setWindowTitle("Aries Map Layout Assistant — AriesPlus")
        self.setWindowIcon(get_icon("layout"))
        self.setMinimumSize(750, 520)

        self.created_layout = None
        self._setup_ui()

    def _setup_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(12, 12, 12, 12)
        main_layout.setSpacing(10)

        # Header Banner
        self.header_lbl = QLabel("Step 1 of 5: Page Dimensions, Orientation & Cartographic Template")
        self.header_lbl.setStyleSheet("""
            QLabel {
                font-size: 14px;
                font-weight: bold;
                color: #0B1F33;
                background-color: #ECFDF5;
                border-left: 4px solid #16A36A;
                padding: 8px 12px;
                border-radius: 4px;
            }
        """)
        main_layout.addWidget(self.header_lbl)

        # Stack
        self.stack = QStackedWidget()
        self.page1 = self._create_page_1()
        self.page2 = self._create_page_2()
        self.page3 = self._create_page_3()
        self.page4 = self._create_page_4()
        self.page5 = self._create_page_5()

        self.stack.addWidget(self.page1)
        self.stack.addWidget(self.page2)
        self.stack.addWidget(self.page3)
        self.stack.addWidget(self.page4)
        self.stack.addWidget(self.page5)
        main_layout.addWidget(self.stack)

        # Navigation Buttons
        nav_layout = QHBoxLayout()
        self.btn_prev = QPushButton("Back")
        self.btn_prev.setEnabled(False)
        self.btn_next = QPushButton("Next")
        self.btn_next.setStyleSheet("background-color: #16A36A; color: white; font-weight: bold; padding: 6px 16px;")
        self.btn_cancel = QPushButton("Cancel")

        nav_layout.addWidget(self.btn_prev)
        nav_layout.addStretch()
        nav_layout.addWidget(self.btn_cancel)
        nav_layout.addWidget(self.btn_next)
        main_layout.addLayout(nav_layout)

        # Connect
        self.btn_prev.clicked.connect(self._go_prev)
        self.btn_next.clicked.connect(self._go_next)
        self.btn_cancel.clicked.connect(self.reject)

    # Page 1: Page Size & Template
    def _create_page_1(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)

        grp_page = QGroupBox("Page Format")
        form_page = QFormLayout(grp_page)

        self.txt_layout_name = QLineEdit("Aries_Project_Layout")
        form_page.addRow("Layout Name:", self.txt_layout_name)

        self.combo_page_size = QComboBox()
        self.combo_page_size.addItems(["A4", "A3", "A2", "A1", "A0", "Letter", "Legal"])
        form_page.addRow("Page Size:", self.combo_page_size)

        self.combo_orientation = QComboBox()
        self.combo_orientation.addItems(["Landscape", "Portrait"])
        form_page.addRow("Orientation:", self.combo_orientation)

        layout.addWidget(grp_page)

        grp_template = QGroupBox("Cartographic Template Style")
        form_tpl = QFormLayout(grp_template)

        self.combo_template = QComboBox()
        for t_name, t_obj in TEMPLATES.items():
            self.combo_template.addItem(t_name, t_obj.description)
        form_tpl.addRow("Template:", self.combo_template)

        self.lbl_tpl_desc = QLabel(TEMPLATES["Modern Report"].description)
        self.lbl_tpl_desc.setStyleSheet("color: gray; font-style: italic; font-size: 11px;")
        self.lbl_tpl_desc.setWordWrap(True)
        form_tpl.addRow("", self.lbl_tpl_desc)

        self.combo_template.currentTextChanged.connect(
            lambda name: self.lbl_tpl_desc.setText(TEMPLATES.get(name, TEMPLATES["Modern Report"]).description)
        )

        layout.addWidget(grp_template)
        layout.addStretch()
        return page

    # Page 2: Map Extent & Scale
    def _create_page_2(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)

        grp_extent = QGroupBox("Main Map Extent")
        vbox = QVBoxLayout(grp_extent)

        self.rb_canvas_ext = QRadioButton("Current Map Canvas Extent (Recommended)")
        self.rb_canvas_ext.setChecked(True)
        self.rb_full_proj = QRadioButton("Full Project Extent")
        vbox.addWidget(self.rb_canvas_ext)
        vbox.addWidget(self.rb_full_proj)

        layout.addWidget(grp_extent)
        layout.addStretch()
        return page

    # Page 3: Title, Metadata & Attribution
    def _create_page_3(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)

        grp_meta = QGroupBox("Map Labels & Project Attribution")
        form_meta = QFormLayout(grp_meta)

        self.txt_title = QLineEdit(QgsProject.instance().title() or "Study Area Overview Map")
        form_meta.addRow("Map Title:", self.txt_title)

        self.txt_subtitle = QLineEdit("Spatial Analysis & Environmental Survey")
        form_meta.addRow("Subtitle:", self.txt_subtitle)

        self.txt_author = QLineEdit("GIS Analyst")
        form_meta.addRow("Author / Cartographer:", self.txt_author)

        self.txt_org = QLineEdit("AriesPlus")
        form_meta.addRow("Organisation:", self.txt_org)

        self.txt_date = QLineEdit(datetime.date.today().strftime("%B %d, %Y"))
        form_meta.addRow("Publication Date:", self.txt_date)

        self.txt_disclaimer = QLineEdit("For planning and evaluation purposes only. Not for navigation.")
        form_meta.addRow("Disclaimer Note:", self.txt_disclaimer)

        layout.addWidget(grp_meta)
        layout.addStretch()
        return page

    # Page 4: Cartographic Elements
    def _create_page_4(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)

        grp_elem = QGroupBox("Cartographic Map Elements")
        form_elem = QFormLayout(grp_elem)

        self.chk_legend = QCheckBox("Dynamic Filtered Legend (Visible layers)")
        self.chk_legend.setChecked(True)
        form_elem.addRow("Legend:", self.chk_legend)

        self.chk_scalebar = QCheckBox("Scale Bar (Linked to main map frame)")
        self.chk_scalebar.setChecked(True)
        form_elem.addRow("Scale Bar:", self.chk_scalebar)

        self.combo_scale_unit = QComboBox()
        self.combo_scale_unit.addItems(["Kilometers (km)", "Meters (m)", "Miles", "Feet"])
        form_elem.addRow("Scale Units:", self.combo_scale_unit)

        self.chk_north_arrow = QCheckBox("Rotation-Aware North Arrow")
        self.chk_north_arrow.setChecked(True)
        form_elem.addRow("North Arrow:", self.chk_north_arrow)

        self.chk_grid = QCheckBox("Coordinate Grid / Graticule")
        self.chk_grid.setChecked(False)
        form_elem.addRow("Coordinate Grid:", self.chk_grid)

        self.chk_inset = QCheckBox("Overview / Inset Map with Extent Polygon")
        self.chk_inset.setChecked(False)
        form_elem.addRow("Overview Inset:", self.chk_inset)

        layout.addWidget(grp_elem)
        layout.addStretch()
        return page

    # Page 5: Quality Preflight & Creation
    def _create_page_5(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)

        self.lbl_quality_summary = QLabel("Preflight Quality Analysis:")
        self.lbl_quality_summary.setStyleSheet("font-weight: bold;")
        layout.addWidget(self.lbl_quality_summary)

        self.table_quality = QTableWidget(0, 3)
        self.table_quality.setHorizontalHeaderLabels(["Status", "Check", "Details"])
        self.table_quality.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        self.table_quality.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        self.table_quality.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        layout.addWidget(self.table_quality)

        # Quick Actions
        grp_actions = QGroupBox("Layout Actions")
        act_layout = QHBoxLayout(grp_actions)

        self.btn_open_designer = QPushButton("Open in QGIS Layout Designer")
        self.btn_open_designer.setIcon(get_icon("layout"))
        self.btn_open_designer.setStyleSheet("background-color: #16A36A; color: white; font-weight: bold; padding: 7px;")
        self.btn_open_designer.clicked.connect(self._open_in_qgis_designer)

        self.btn_export_pdf = QPushButton("Direct Export to PDF...")
        self.btn_export_pdf.clicked.connect(self._export_pdf)

        self.btn_export_png = QPushButton("Direct Export to PNG...")
        self.btn_export_png.clicked.connect(self._export_png)

        act_layout.addWidget(self.btn_open_designer)
        act_layout.addWidget(self.btn_export_pdf)
        act_layout.addWidget(self.btn_export_png)
        layout.addWidget(grp_actions)

        return page

    # Navigation Handlers
    def _go_prev(self):
        idx = self.stack.currentIndex()
        if idx > 0:
            self.stack.setCurrentIndex(idx - 1)
            self._update_nav(idx - 1)

    def _go_next(self):
        idx = self.stack.currentIndex()
        if idx < 4:
            if idx == 3:
                # Moving to Step 5: Build preview layout and run quality check
                self._generate_layout_for_preview()
            self.stack.setCurrentIndex(idx + 1)
            self._update_nav(idx + 1)

    def _update_nav(self, idx: int):
        titles = [
            "Step 1 of 5: Page Dimensions, Orientation & Cartographic Template",
            "Step 2 of 5: Map Extent, Scale & Canvas Synchronization",
            "Step 3 of 5: Title, Subtitle & Cartographic Metadata",
            "Step 4 of 5: Cartographic Elements, Legend & Coordinate Grid",
            "Step 5 of 5: Preflight Quality Review & Layout Creation",
        ]
        self.header_lbl.setText(titles[idx])
        self.btn_prev.setEnabled(idx > 0)
        self.btn_next.setVisible(idx < 4)

    def _collect_config(self) -> LayoutConfig:
        config = LayoutConfig(
            layout_name=self.txt_layout_name.text().strip() or "Aries_Project_Layout",
            page_size_name=self.combo_page_size.currentText(),
            orientation=self.combo_orientation.currentText(),
            template_name=self.combo_template.currentText(),
            metadata=TextMetadata(
                title=self.txt_title.text().strip(),
                subtitle=self.txt_subtitle.text().strip(),
                author=self.txt_author.text().strip(),
                organization=self.txt_org.text().strip(),
                date_str=self.txt_date.text().strip(),
                disclaimer=self.txt_disclaimer.text().strip()
            ),
            grid=GridConfig(enabled=self.chk_grid.isChecked()),
            inset=InsetConfig(enabled=self.chk_inset.isChecked()),
            include_legend=self.chk_legend.isChecked(),
            include_scalebar=self.chk_scalebar.isChecked(),
            include_north_arrow=self.chk_north_arrow.isChecked(),
            scalebar_units="km" if "Kilometer" in self.combo_scale_unit.currentText() else "m"
        )
        return config

    def _generate_layout_for_preview(self):
        config = self._collect_config()
        extent = self.iface.mapCanvas().extent() if self.iface and self.rb_canvas_ext.isChecked() else None
        self.created_layout = LayoutComposer.create_layout(config, canvas_extent=extent)

        # Run Quality Checker
        issues = LayoutQualityChecker.check_layout(self.created_layout)
        self.table_quality.setRowCount(0)

        if not issues:
            self.table_quality.setRowCount(1)
            ok_item = QTableWidgetItem("✓ PASS")
            ok_item.setForeground(QColor("#16A36A"))
            self.table_quality.setItem(0, 0, ok_item)
            self.table_quality.setItem(0, 1, QTableWidgetItem("Cartographic Quality"))
            self.table_quality.setItem(0, 2, QTableWidgetItem("All elements and frame boundaries are properly placed."))
        else:
            self.table_quality.setRowCount(len(issues))
            for row, iss in enumerate(issues):
                sev_item = QTableWidgetItem(iss.severity)
                if iss.severity == "ERROR":
                    sev_item.setForeground(QColor("#D64545"))
                else:
                    sev_item.setForeground(QColor("#F2A51A"))
                self.table_quality.setItem(row, 0, sev_item)
                self.table_quality.setItem(row, 1, QTableWidgetItem(iss.title))
                self.table_quality.setItem(row, 2, QTableWidgetItem(iss.description))

    def _open_in_qgis_designer(self):
        if not self.created_layout:
            self._generate_layout_for_preview()

        if self.iface:
            self.iface.openLayoutDesigner(self.created_layout)
            self.accept()
        else:
            QMessageBox.information(self, "Layout Created", f"Layout '{self.created_layout.name()}' created successfully.")

    def _export_pdf(self):
        if not self.created_layout:
            self._generate_layout_for_preview()

        path, _ = QFileDialog.getSaveFileName(self, "Export Layout to PDF", f"{self.created_layout.name()}.pdf", "PDF (*.pdf)")
        if path:
            try:
                LayoutExporter.export_to_pdf(self.created_layout, path, dpi=300)
                QMessageBox.information(self, "Export Complete", f"PDF exported successfully to:\n{path}")
            except Exception as e:
                QMessageBox.critical(self, "Export Failed", f"Failed to export PDF:\n{str(e)}")

    def _export_png(self):
        if not self.created_layout:
            self._generate_layout_for_preview()

        path, _ = QFileDialog.getSaveFileName(self, "Export Layout to PNG", f"{self.created_layout.name()}.png", "PNG Image (*.png)")
        if path:
            try:
                LayoutExporter.export_to_image(self.created_layout, path, dpi=300)
                QMessageBox.information(self, "Export Complete", f"PNG exported successfully to:\n{path}")
            except Exception as e:
                QMessageBox.critical(self, "Export Failed", f"Failed to export PNG:\n{str(e)}")

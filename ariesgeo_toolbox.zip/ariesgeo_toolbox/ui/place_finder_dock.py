"""
Aries Place Finder dockable panel for QGIS.
"""

from typing import Optional, List
from qgis.PyQt.QtWidgets import (
    QDockWidget,
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QLineEdit,
    QPushButton,
    QComboBox,
    QTableWidget,
    QTableWidgetItem,
    QHeaderView,
    QLabel,
    QCheckBox,
    QTabWidget,
    QListWidget,
    QToolButton,
    QMenu,
    QAction,
    QApplication,
    QMessageBox,
    QFileDialog,
)
from qgis.PyQt.QtCore import Qt, QTimer, pyqtSignal
from qgis.PyQt.QtGui import QIcon, QColor, QFont
from qgis.gui import QgsMapCanvas
from qgis.core import (
    QgsRectangle,
    QgsPointXY,
    QgsGeometry,
    QgsProject,
    QgsCoordinateTransform,
)
from ..resources import get_icon
from ..core.crs import (
    get_wgs84_crs,
    get_project_crs,
    wgs84_to_project_point,
    transform_rectangle,
    project_to_wgs84_point,
)
from ..core.settings import settings
from ..place_finder.models import GeocodingResult, BoundingBox
from ..place_finder.service import PlaceFinderService
from ..place_finder.map_tool import ReverseGeocodeMapTool
from ..place_finder.layer_exporter import LayerExporter

class PlaceFinderDock(QDockWidget):
    """Dock widget for Aries Place Finder."""

    def __init__(self, canvas: QgsMapCanvas, parent: Optional[QWidget] = None):
        super().__init__("Aries Place Finder", parent)
        self.canvas = canvas
        self.service = PlaceFinderService(self)
        self.results: List[GeocodingResult] = []
        self.reverse_tool = ReverseGeocodeMapTool(self.canvas)
        self.prev_tool = None

        self._debounce_timer = QTimer(self)
        self._debounce_timer.setSingleShot(True)
        self._debounce_timer.setInterval(450)
        self._debounce_timer.timeout.connect(self._on_search_triggered)

        self._setup_ui()
        self._connect_signals()

    def _setup_ui(self):
        self.setObjectName("AriesPlaceFinderDock")
        main_widget = QWidget()
        main_layout = QVBoxLayout(main_widget)
        main_layout.setContentsMargins(8, 8, 8, 8)
        main_layout.setSpacing(6)

        # Header / Branding bar
        header_layout = QHBoxLayout()
        logo_lbl = QLabel()
        logo_lbl.setPixmap(get_icon("place_finder").pixmap(24, 24))
        title_lbl = QLabel("<b>Aries Place Finder</b>")
        title_lbl.setStyleSheet("color: #16A36A; font-size: 13px;")
        header_layout.addWidget(logo_lbl)
        header_layout.addWidget(title_lbl)
        header_layout.addStretch()

        # Reverse Geocode map tool button
        self.btn_reverse = QToolButton()
        self.btn_reverse.setIcon(get_icon("pin"))
        self.btn_reverse.setCheckable(True)
        self.btn_reverse.setToolTip("Click on map canvas to reverse-geocode location")
        header_layout.addWidget(self.btn_reverse)
        main_layout.addLayout(header_layout)

        # Search Bar
        search_layout = QHBoxLayout()
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("Search city, address, landmark...")
        self.search_input.setClearButtonEnabled(True)
        self.search_input.setStyleSheet("""
            QLineEdit {
                padding: 6px 10px;
                border: 1px solid #16A36A;
                border-radius: 4px;
                font-size: 12px;
            }
        """)

        self.btn_search = QPushButton()
        self.btn_search.setIcon(get_icon("place_finder"))
        self.btn_search.setToolTip("Search")
        self.btn_search.setStyleSheet("padding: 5px 12px; background-color: #16A36A; color: white; border-radius: 4px;")
        
        search_layout.addWidget(self.search_input)
        search_layout.addWidget(self.btn_search)
        main_layout.addLayout(search_layout)

        # Provider & Extent Filters
        filter_layout = QHBoxLayout()
        self.provider_combo = QComboBox()
        self.provider_combo.addItems(["Photon (Komoot)", "OpenStreetMap (Nominatim)", "Offline Gazetteer"])
        self.provider_combo.setCurrentText(self.service.active_provider_name)
        self.provider_combo.setToolTip("Select geocoding search provider")

        self.chk_canvas_extent = QCheckBox("Map Extent")
        self.chk_canvas_extent.setToolTip("Bias search to currently visible map extent")

        self.country_input = QLineEdit()
        self.country_input.setPlaceholderText("CC (e.g. US, FR)")
        self.country_input.setMaximumWidth(75)
        self.country_input.setToolTip("Optional 2-letter country filter code")

        filter_layout.addWidget(self.provider_combo, 2)
        filter_layout.addWidget(self.chk_canvas_extent, 1)
        filter_layout.addWidget(self.country_input, 1)
        main_layout.addLayout(filter_layout)

        # Tabs for Results / History / Favorites
        self.tabs = QTabWidget()
        
        # Results Tab
        results_tab = QWidget()
        res_layout = QVBoxLayout(results_tab)
        res_layout.setContentsMargins(0, 4, 0, 0)
        res_layout.setSpacing(4)

        self.results_table = QTableWidget(0, 3)
        self.results_table.setHorizontalHeaderLabels(["Name / Location", "Type", "Coords"])
        self.results_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.results_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        self.results_table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        self.results_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.results_table.setSelectionMode(QTableWidget.SelectionMode.SingleSelection)
        self.results_table.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.results_table.setAlternatingRowColors(True)
        res_layout.addWidget(self.results_table)

        # Result Action Bar
        action_layout = QHBoxLayout()
        self.btn_zoom = QPushButton("Zoom")
        self.btn_zoom.setIcon(get_icon("place_finder"))
        self.btn_flash = QPushButton("Flash")
        self.btn_flash.setIcon(get_icon("flash"))
        self.btn_add_layer = QPushButton("Add Layer")
        self.btn_add_layer.setIcon(get_icon("pin"))
        self.btn_copy = QPushButton("Copy")

        for b in [self.btn_zoom, self.btn_flash, self.btn_add_layer, self.btn_copy]:
            b.setEnabled(False)
            action_layout.addWidget(b)
        res_layout.addLayout(action_layout)

        # Status & Attribution label
        self.status_lbl = QLabel("Ready")
        self.status_lbl.setStyleSheet("font-size: 11px; color: gray;")
        res_layout.addWidget(self.status_lbl)

        self.tabs.addTab(results_tab, "Results")

        # History Tab
        history_tab = QWidget()
        hist_layout = QVBoxLayout(history_tab)
        hist_layout.setContentsMargins(0, 4, 0, 0)
        self.history_list = QListWidget()
        self._refresh_history_list()
        hist_layout.addWidget(self.history_list)
        self.tabs.addTab(history_tab, "History")

        # Favorites Tab
        fav_tab = QWidget()
        fav_layout = QVBoxLayout(fav_tab)
        fav_layout.setContentsMargins(0, 4, 0, 0)
        self.fav_list = QListWidget()
        self._refresh_favorites_list()
        fav_layout.addWidget(self.fav_list)
        self.tabs.addTab(fav_tab, "Favorites")

        main_layout.addWidget(self.tabs)
        self.setWidget(main_widget)

    def _connect_signals(self):
        self.search_input.textChanged.connect(self._on_text_changed)
        self.search_input.returnPressed.connect(self._on_search_triggered)
        self.btn_search.clicked.connect(self._on_search_triggered)
        self.provider_combo.currentTextChanged.connect(self._on_provider_changed)
        self.btn_reverse.toggled.connect(self._on_reverse_toggled)

        self.service.search_started.connect(self._on_search_started)
        self.service.search_finished.connect(self._on_search_finished)
        self.service.search_error.connect(self._on_search_error)
        self.service.reverse_finished.connect(self._on_reverse_finished)
        self.reverse_tool.point_clicked.connect(self._on_map_point_clicked)

        self.results_table.itemSelectionChanged.connect(self._on_selection_changed)
        self.results_table.doubleClicked.connect(self.zoom_to_selected)
        self.results_table.customContextMenuRequested.connect(self._show_context_menu)

        self.btn_zoom.clicked.connect(self.zoom_to_selected)
        self.btn_flash.clicked.connect(self.flash_selected)
        self.btn_add_layer.clicked.connect(self.add_selected_to_layer)
        self.btn_copy.clicked.connect(self.copy_selected_coords)

        self.history_list.itemClicked.connect(self._on_history_clicked)
        self.fav_list.itemClicked.connect(self._on_fav_clicked)

    def _on_text_changed(self, text: str):
        if len(text.strip()) >= 3:
            self._debounce_timer.start()
        elif len(text.strip()) == 0:
            self.results_table.setRowCount(0)
            self.results.clear()
            self._update_buttons()

    def _on_search_triggered(self):
        self._debounce_timer.stop()
        query = self.search_input.text().strip()
        if not query:
            return

        bbox = None
        if self.chk_canvas_extent.isChecked():
            rect = self.canvas.extent()
            # Convert canvas extent to WGS84 bbox
            proj_crs = get_project_crs()
            wgs84 = get_wgs84_crs()
            wgs_rect = transform_rectangle(rect, proj_crs, wgs84)
            bbox = BoundingBox(
                min_lon=wgs_rect.xMinimum(),
                min_lat=wgs_rect.yMinimum(),
                max_lon=wgs_rect.xMaximum(),
                max_lat=wgs_rect.yMaximum()
            )

        cc = self.country_input.text().strip() or None
        self.service.search_async(query=query, limit=settings.search_limit, country_code=cc, bbox=bbox)

    def _on_search_started(self):
        self.status_lbl.setText("Searching...")

    def _on_search_finished(self, results: List[GeocodingResult]):
        self.results = results
        self.results_table.setRowCount(0)
        self.tabs.setCurrentIndex(0)  # Focus Results tab

        if not results:
            self.status_lbl.setText("No results found.")
            self._update_buttons()
            return

        self.results_table.setRowCount(len(results))
        for row, res in enumerate(results):
            name_item = QTableWidgetItem(res.display_name)
            name_item.setToolTip(f"{res.display_name}\nProvider: {res.provider}")

            type_item = QTableWidgetItem(res.place_type or "place")
            coords_item = QTableWidgetItem(f"{res.lat:.4f}, {res.lon:.4f}")

            self.results_table.setItem(row, 0, name_item)
            self.results_table.setItem(row, 1, type_item)
            self.results_table.setItem(row, 2, coords_item)

        self.status_lbl.setText(f"Found {len(results)} matches | {results[0].attribution}")
        self._refresh_history_list()

        # Select first row by default and zoom if auto_zoom is active
        self.results_table.selectRow(0)
        if settings.auto_zoom:
            self.zoom_to_selected()

    def _on_search_error(self, err_msg: str):
        self.status_lbl.setText(f"Error: {err_msg}")
        self._update_buttons()

    def _on_provider_changed(self, name: str):
        self.service.set_provider(name)
        self.status_lbl.setText(f"Provider: {name}")

    def _on_selection_changed(self):
        self._update_buttons()

    def _update_buttons(self):
        has_sel = len(self.results_table.selectedItems()) > 0
        for b in [self.btn_zoom, self.btn_flash, self.btn_add_layer, self.btn_copy]:
            b.setEnabled(has_sel)

    def get_selected_result(self) -> Optional[GeocodingResult]:
        row = self.results_table.currentRow()
        if 0 <= row < len(self.results):
            return self.results[row]
        return None

    def zoom_to_selected(self):
        res = self.get_selected_result()
        if not res:
            return

        proj_pt = wgs84_to_project_point(res.lon, res.lat)

        if res.bounding_box:
            bb = res.bounding_box
            wgs_rect = QgsRectangle(bb.min_lon, bb.min_lat, bb.max_lon, bb.max_lat)
            proj_rect = transform_rectangle(wgs_rect, get_wgs84_crs(), get_project_crs())
            self.canvas.setExtent(proj_rect)
        else:
            # Center on point and zoom in comfortably
            self.canvas.setCenter(proj_pt)
            self.canvas.zoomScale(25000)

        self.canvas.refresh()
        if settings.auto_flash:
            self.flash_selected()

    def flash_selected(self):
        res = self.get_selected_result()
        if not res:
            return
        proj_pt = wgs84_to_project_point(res.lon, res.lat)
        geom = QgsGeometry.fromPointXY(proj_pt)
        self.canvas.flashGeometries([geom], get_project_crs(), color=QColor("#16A36A"), flashes=3, duration=250)

    def add_selected_to_layer(self):
        res = self.get_selected_result()
        if not res:
            return
        LayerExporter.create_point_layer([res], layer_name=f"Point: {res.name}", add_to_project=True)
        if res.bounding_box or res.geojson_geometry:
            LayerExporter.create_boundary_layer(res, add_to_project=True)
        self.status_lbl.setText(f"Added '{res.name}' to map layers.")

    def copy_selected_coords(self):
        res = self.get_selected_result()
        if not res:
            return
        txt = f"{res.lat:.6f}, {res.lon:.6f}"
        QApplication.clipboard().setText(txt)
        self.status_lbl.setText(f"Copied: {txt}")

    def _show_context_menu(self, pos):
        res = self.get_selected_result()
        if not res:
            return

        menu = QMenu(self)
        act_zoom = menu.addAction(get_icon("place_finder"), "Zoom to Result", self.zoom_to_selected)
        act_flash = menu.addAction(get_icon("flash"), "Flash on Map", self.flash_selected)
        act_add_pt = menu.addAction(get_icon("pin"), "Add to Layer", self.add_selected_to_layer)
        act_fav = menu.addAction("Add to Favorites", lambda: self._add_fav(res))
        menu.addSeparator()
        act_copy_wgs = menu.addAction("Copy WGS84 Coordinates", self.copy_selected_coords)
        menu.exec(self.results_table.viewport().mapToGlobal(pos))

    def _add_fav(self, res: GeocodingResult):
        self.service.add_favorite(res)
        self._refresh_favorites_list()
        self.status_lbl.setText(f"Saved '{res.name}' to Favorites.")

    def _refresh_history_list(self):
        self.history_list.clear()
        for q in self.service.history:
            self.history_list.addItem(q)

    def _refresh_favorites_list(self):
        self.fav_list.clear()
        for f in self.service.favorites:
            self.fav_list.addItem(f.get("display_name", ""))

    def _on_history_clicked(self, item):
        self.search_input.setText(item.text())
        self._on_search_triggered()

    def _on_fav_clicked(self, item):
        name = item.text()
        fav_entry = next((f for f in self.service.favorites if f.get("display_name") == name), None)
        if fav_entry:
            res = GeocodingResult(
                place_id=name,
                display_name=name,
                name=fav_entry.get("name", name),
                lat=fav_entry.get("lat", 0.0),
                lon=fav_entry.get("lon", 0.0),
                place_type=fav_entry.get("place_type", "place"),
                provider=fav_entry.get("provider", "Favorite"),
            )
            self._on_search_finished([res])

    # Reverse Geocoding Map Tool
    def _on_reverse_toggled(self, checked: bool):
        if checked:
            self.prev_tool = self.canvas.mapTool()
            self.canvas.setMapTool(self.reverse_tool)
            self.status_lbl.setText("Click anywhere on canvas to reverse-geocode...")
        else:
            if self.prev_tool:
                self.canvas.setMapTool(self.prev_tool)

    def _on_map_point_clicked(self, lat: float, lon: float, proj_pt: QgsPointXY):
        self.status_lbl.setText(f"Reverse geocoding ({lat:.4f}, {lon:.4f})...")
        self.service.reverse_geocode_async(lat, lon)

    def _on_reverse_finished(self, result: Optional[GeocodingResult]):
        self.btn_reverse.setChecked(False)
        if result:
            self._on_search_finished([result])
        else:
            self.status_lbl.setText("No reverse geocoding result found for map click.")

"""
Aries Place Finder native QGIS dockable panel (QgsDockWidget).
Adapts seamlessly to QGIS UI themes (Default, Blend of Gray, Night Mapping)
and integrates natively into QGIS's tabbed dock panel system.
"""

import re
from typing import Optional, List
from qgis.PyQt.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QToolBar,
    QToolButton,
    QPushButton,
    QComboBox,
    QTableWidget,
    QTableWidgetItem,
    QHeaderView,
    QLabel,
    QCheckBox,
    QTabWidget,
    QListWidget,
    QMenu,
    QAction,
    QApplication,
    QStyle,
    QFrame,
    QSizePolicy,
)
from qgis.PyQt.QtCore import Qt, QTimer, QSize
from qgis.PyQt.QtGui import QIcon, QColor, QPalette
from qgis.gui import QgsDockWidget, QgsFilterLineEdit, QgsMapCanvas
from qgis.core import (
    QgsApplication,
    QgsRectangle,
    QgsPointXY,
    QgsGeometry,
)
from ..resources import get_icon
from ..core.crs import (
    get_wgs84_crs,
    get_project_crs,
    wgs84_to_project_point,
    transform_rectangle,
)
from ..core.settings import settings
from ..place_finder.models import GeocodingResult, BoundingBox
from ..place_finder.service import PlaceFinderService
from ..place_finder.map_tool import ReverseGeocodeMapTool
from ..place_finder.layer_exporter import LayerExporter


_COORD_RE = re.compile(
    r"^\s*([+-]?\d+(?:\.\d+)?)\s*[,;\s]\s*([+-]?\d+(?:\.\d+)?)\s*$"
)


def _qgis_icon(theme_icon_name: str, fallback_name: str = "place_finder") -> QIcon:
    """Return a native theme-adaptive QGIS icon with plugin icon fallback."""
    icon = QgsApplication.getThemeIcon(theme_icon_name)
    if icon and not icon.isNull():
        return icon
    return get_icon(fallback_name)


class PlaceFinderDock(QgsDockWidget):
    """
    Native QGIS dock panel for Aries Place Finder.
    Uses QgsDockWidget, QgsFilterLineEdit, native panel QToolBar, and QPalette
    roles so it adapts automatically to any QGIS UI theme and DPI setting.
    """

    def __init__(self, canvas: QgsMapCanvas, parent: Optional[QWidget] = None):
        super().__init__("Place Finder", parent)
        self.setObjectName("AriesPlaceFinderDock")
        self.setWindowTitle("Place Finder")
        self.setWindowIcon(get_icon("place_finder"))
        self.setAllowedAreas(
            Qt.DockWidgetArea.LeftDockWidgetArea
            | Qt.DockWidgetArea.RightDockWidgetArea
            | Qt.DockWidgetArea.TopDockWidgetArea
            | Qt.DockWidgetArea.BottomDockWidgetArea
        )

        self.canvas = canvas
        self.service = PlaceFinderService(self)
        self.results: List[GeocodingResult] = []
        self.reverse_tool = ReverseGeocodeMapTool(self.canvas) if self.canvas else None
        self.prev_tool = None

        self._debounce_timer = QTimer(self)
        self._debounce_timer.setSingleShot(True)
        self._debounce_timer.setInterval(450)
        self._debounce_timer.timeout.connect(self._on_search_triggered)

        self._setup_ui()
        self._connect_signals()

    def _setup_ui(self):
        main_widget = QWidget(self)
        main_layout = QVBoxLayout(main_widget)
        main_layout.setContentsMargins(4, 4, 4, 4)
        main_layout.setSpacing(4)

        # 1. Native QGIS Panel Toolbar (matches Layers / Browser / Processing Toolbox)
        self.panel_toolbar = QToolBar(main_widget)
        self.panel_toolbar.setFloatable(False)
        self.panel_toolbar.setMovable(False)
        icon_px = self.style().pixelMetric(QStyle.PixelMetric.PM_SmallIconSize)
        self.panel_toolbar.setIconSize(QSize(icon_px, icon_px))

        self.act_zoom = QAction(_qgis_icon("mActionZoomToSelected.svg", "place_finder"), "Zoom to Selected", self)
        self.act_zoom.setToolTip("Zoom map canvas to selected place")
        self.act_zoom.setEnabled(False)

        self.act_pan = QAction(_qgis_icon("mActionPanToSelected.svg", "place_finder"), "Pan to Selected", self)
        self.act_pan.setToolTip("Center map canvas on selected place without changing scale")
        self.act_pan.setEnabled(False)

        self.act_flash = QAction(_qgis_icon("mActionHighlightFeature.svg", "flash"), "Flash Location", self)
        self.act_flash.setToolTip("Flash location geometry on map canvas")
        self.act_flash.setEnabled(False)

        self.act_add_layer = QAction(_qgis_icon("mActionAddOgrLayer.svg", "pin"), "Add Result to Layers", self)
        self.act_add_layer.setToolTip("Add selected place as a vector layer in the QGIS project")
        self.act_add_layer.setEnabled(False)

        self.act_copy = QAction(_qgis_icon("mActionEditCopy.svg", "place_finder"), "Copy Coordinates", self)
        self.act_copy.setToolTip("Copy WGS84 coordinates (lat, lon) to clipboard")
        self.act_copy.setEnabled(False)

        self.act_fav = QAction(_qgis_icon("mActionNewBookmark.svg", "pin"), "Save to Favorites", self)
        self.act_fav.setToolTip("Save selected place to Favorites tab")
        self.act_fav.setEnabled(False)

        self.panel_toolbar.addAction(self.act_zoom)
        self.panel_toolbar.addAction(self.act_pan)
        self.panel_toolbar.addAction(self.act_flash)
        self.panel_toolbar.addAction(self.act_add_layer)
        self.panel_toolbar.addAction(self.act_copy)
        self.panel_toolbar.addAction(self.act_fav)
        self.panel_toolbar.addSeparator()

        # Reverse Geocode Map Tool toggle button (kept as self.btn_reverse for compatibility)
        self.btn_reverse = QToolButton(self.panel_toolbar)
        self.btn_reverse.setIcon(_qgis_icon("mActionCapturePoint.svg", "pin"))
        self.btn_reverse.setCheckable(True)
        self.btn_reverse.setAutoRaise(True)
        self.btn_reverse.setToolTip("Click on map canvas to reverse-geocode location")
        self.panel_toolbar.addWidget(self.btn_reverse)

        spacer = QWidget(self.panel_toolbar)
        spacer.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        self.panel_toolbar.addWidget(spacer)

        self.act_clear_results = QAction(_qgis_icon("mActionDeleteSelected.svg", "settings"), "Clear Results", self)
        self.act_clear_results.setToolTip("Clear current search results")
        self.panel_toolbar.addAction(self.act_clear_results)

        main_layout.addWidget(self.panel_toolbar)

        # 2. Native QGIS Search Bar (QgsFilterLineEdit — identical to Processing Toolbox)
        search_layout = QHBoxLayout()
        search_layout.setContentsMargins(0, 0, 0, 0)
        search_layout.setSpacing(4)

        self.search_input = QgsFilterLineEdit(main_widget)
        self.search_input.setShowSearchIcon(True)
        self.search_input.setShowClearButton(True)
        self.search_input.setPlaceholderText("Search place, address, or lat, lon...")

        self.btn_search = QToolButton(main_widget)
        self.btn_search.setIcon(_qgis_icon("search.svg", "place_finder"))
        self.btn_search.setToolTip("Run search (Enter)")
        self.btn_search.setAutoRaise(False)

        search_layout.addWidget(self.search_input, 1)
        search_layout.addWidget(self.btn_search)
        main_layout.addLayout(search_layout)

        # 3. Compact Native Provider & Extent Filter Row
        filter_layout = QHBoxLayout()
        filter_layout.setContentsMargins(0, 0, 0, 0)
        filter_layout.setSpacing(4)

        self.provider_combo = QComboBox(main_widget)
        self.provider_combo.addItems([
            "Photon (Komoot)",
            "OpenStreetMap (Nominatim)",
            "Offline Gazetteer",
        ])
        self.provider_combo.setCurrentText(self.service.active_provider_name)
        self.provider_combo.setToolTip("Select geocoding search provider")
        self.provider_combo.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)

        self.chk_canvas_extent = QCheckBox("Map Extent", main_widget)
        self.chk_canvas_extent.setToolTip("Bias search to currently visible map canvas extent")

        self.country_input = QgsFilterLineEdit(main_widget)
        self.country_input.setShowClearButton(True)
        self.country_input.setPlaceholderText("ISO (e.g. GH)")
        fm_width = self.country_input.fontMetrics().horizontalAdvance("ISO (e.g. GH)   ")
        self.country_input.setMaximumWidth(max(78, fm_width))
        self.country_input.setToolTip("Optional 2-letter ISO country code filter (e.g. US, GB, GH, NG)")

        filter_layout.addWidget(self.provider_combo, 1)
        filter_layout.addWidget(self.chk_canvas_extent)
        filter_layout.addWidget(self.country_input)
        main_layout.addLayout(filter_layout)

        # 4. Native QGIS Sub-Tabs: Results | History | Favorites
        self.tabs = QTabWidget(main_widget)
        self.tabs.setDocumentMode(True)

        # --- Tab 1: Results ---
        results_tab = QWidget(self.tabs)
        res_layout = QVBoxLayout(results_tab)
        res_layout.setContentsMargins(0, 4, 0, 0)
        res_layout.setSpacing(4)

        self.results_table = QTableWidget(0, 3, results_tab)
        self.results_table.setHorizontalHeaderLabels(["Place", "Type", "Coordinates"])
        self.results_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.results_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        self.results_table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        self.results_table.verticalHeader().setVisible(False)
        self.results_table.verticalHeader().setDefaultSectionSize(
            max(22, self.results_table.fontMetrics().height() + 8)
        )
        self.results_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.results_table.setSelectionMode(QTableWidget.SelectionMode.SingleSelection)
        self.results_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.results_table.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.results_table.setAlternatingRowColors(True)
        self.results_table.setShowGrid(False)
        self.results_table.setFrameShape(QFrame.Shape.StyledPanel)
        res_layout.addWidget(self.results_table, 1)

        # Compact bottom action buttons (native Qt buttons, zero custom colors)
        action_layout = QHBoxLayout()
        action_layout.setContentsMargins(0, 0, 0, 0)
        action_layout.setSpacing(4)

        self.btn_zoom = QPushButton(_qgis_icon("mActionZoomToSelected.svg", "place_finder"), "Zoom", results_tab)
        self.btn_flash = QPushButton(_qgis_icon("mActionHighlightFeature.svg", "flash"), "Flash", results_tab)
        self.btn_add_layer = QPushButton(_qgis_icon("mActionAddOgrLayer.svg", "pin"), "Add Layer", results_tab)
        self.btn_copy = QPushButton(_qgis_icon("mActionEditCopy.svg", "place_finder"), "Copy", results_tab)

        for b in (self.btn_zoom, self.btn_flash, self.btn_add_layer, self.btn_copy):
            b.setEnabled(False)
            action_layout.addWidget(b)
        res_layout.addLayout(action_layout)

        self.tabs.addTab(results_tab, _qgis_icon("search.svg", "place_finder"), "Results")

        # --- Tab 2: History ---
        history_tab = QWidget(self.tabs)
        hist_layout = QVBoxLayout(history_tab)
        hist_layout.setContentsMargins(0, 4, 0, 0)
        hist_layout.setSpacing(4)
        self.history_list = QListWidget(history_tab)
        self.history_list.setAlternatingRowColors(True)
        self.history_list.setFrameShape(QFrame.Shape.StyledPanel)
        self._refresh_history_list()
        hist_layout.addWidget(self.history_list)
        self.tabs.addTab(history_tab, _qgis_icon("mIconHistory.svg", "place_finder"), "History")

        # --- Tab 3: Favorites ---
        fav_tab = QWidget(self.tabs)
        fav_layout = QVBoxLayout(fav_tab)
        fav_layout.setContentsMargins(0, 4, 0, 0)
        fav_layout.setSpacing(4)
        self.fav_list = QListWidget(fav_tab)
        self.fav_list.setAlternatingRowColors(True)
        self.fav_list.setFrameShape(QFrame.Shape.StyledPanel)
        self._refresh_favorites_list()
        fav_layout.addWidget(self.fav_list)
        self.tabs.addTab(fav_tab, _qgis_icon("mIconFavorites.svg", "pin"), "Favorites")

        main_layout.addWidget(self.tabs, 1)

        # 5. Theme-Adaptive Status Footer (uses QPalette PlaceholderText role — adapts to Dark & Light themes)
        self.status_lbl = QLabel("Ready", main_widget)
        self.status_lbl.setWordWrap(True)
        self._apply_muted_palette(self.status_lbl)
        main_layout.addWidget(self.status_lbl)

        self.setWidget(main_widget)

    def _apply_muted_palette(self, label: QLabel):
        """Apply theme-native secondary text color from active QGIS QPalette."""
        pal = self.palette()
        placeholder_role = getattr(QPalette.ColorRole, "PlaceholderText", None)
        if placeholder_role is not None:
            muted_color = pal.color(placeholder_role)
            if muted_color.isValid():
                lbl_pal = label.palette()
                lbl_pal.setColor(QPalette.ColorRole.WindowText, muted_color)
                label.setPalette(lbl_pal)

    def changeEvent(self, event):
        """Re-adapt icons and muted text automatically if the user switches QGIS UI Theme live."""
        super().changeEvent(event)
        palette_change = getattr(event.Type, "PaletteChange", None) or getattr(event, "PaletteChange", None)
        style_change = getattr(event.Type, "StyleChange", None) or getattr(event, "StyleChange", None)
        if event.type() in (palette_change, style_change):
            if hasattr(self, "status_lbl"):
                self._apply_muted_palette(self.status_lbl)

    def _connect_signals(self):
        self.search_input.textChanged.connect(self._on_text_changed)
        self.search_input.returnPressed.connect(self._on_search_triggered)
        self.btn_search.clicked.connect(self._on_search_triggered)
        self.provider_combo.currentTextChanged.connect(self._on_provider_changed)
        self.btn_reverse.toggled.connect(self._on_reverse_toggled)
        self.act_clear_results.triggered.connect(self._clear_results)

        self.service.search_started.connect(self._on_search_started)
        self.service.search_finished.connect(self._on_search_finished)
        self.service.search_error.connect(self._on_search_error)
        self.service.reverse_finished.connect(self._on_reverse_finished)
        if self.reverse_tool is not None:
            self.reverse_tool.point_clicked.connect(self._on_map_point_clicked)

        self.results_table.itemSelectionChanged.connect(self._on_selection_changed)
        self.results_table.doubleClicked.connect(self.zoom_to_selected)
        self.results_table.customContextMenuRequested.connect(self._show_context_menu)

        # Toolbar & button actions share identical handlers
        self.act_zoom.triggered.connect(self.zoom_to_selected)
        self.act_pan.triggered.connect(self.pan_to_selected)
        self.act_flash.triggered.connect(self.flash_selected)
        self.act_add_layer.triggered.connect(self.add_selected_to_layer)
        self.act_copy.triggered.connect(self.copy_selected_coords)
        self.act_fav.triggered.connect(self._save_selected_to_fav)

        self.btn_zoom.clicked.connect(self.zoom_to_selected)
        self.btn_flash.clicked.connect(self.flash_selected)
        self.btn_add_layer.clicked.connect(self.add_selected_to_layer)
        self.btn_copy.clicked.connect(self.copy_selected_coords)

        self.history_list.itemClicked.connect(self._on_history_clicked)
        self.fav_list.itemClicked.connect(self._on_fav_clicked)

    def _clear_results(self):
        self.search_input.clear()
        self.results_table.setRowCount(0)
        self.results.clear()
        self._update_buttons()
        self.status_lbl.setText("Ready")

    def _on_text_changed(self, text: str):
        stripped = text.strip()
        if len(stripped) >= 3:
            self._debounce_timer.start()
        elif len(stripped) == 0:
            self.results_table.setRowCount(0)
            self.results.clear()
            self._update_buttons()
            self.status_lbl.setText("Ready")

    def _on_search_triggered(self):
        self._debounce_timer.stop()
        query = self.search_input.text().strip()
        if not query:
            return

        # Direct coordinate shortcut (lat, lon)
        m = _COORD_RE.match(query)
        if m:
            v1, v2 = float(m.group(1)), float(m.group(2))
            if -90.0 <= v1 <= 90.0 and -180.0 <= v2 <= 180.0:
                direct_res = GeocodingResult(
                    place_id=f"coord_{v1:.6f}_{v2:.6f}",
                    display_name=f"Coordinate ({v1:.6f}, {v2:.6f})",
                    name=f"{v1:.6f}, {v2:.6f}",
                    lat=v1,
                    lon=v2,
                    place_type="coordinate",
                    provider="Direct WGS84",
                    attribution="Direct coordinate parser",
                )
                self._on_search_finished([direct_res])
                return

        bbox = None
        if self.chk_canvas_extent.isChecked() and self.canvas is not None:
            rect = self.canvas.extent()
            proj_crs = get_project_crs()
            wgs84 = get_wgs84_crs()
            wgs_rect = transform_rectangle(rect, proj_crs, wgs84)
            bbox = BoundingBox(
                min_lon=wgs_rect.xMinimum(),
                min_lat=wgs_rect.yMinimum(),
                max_lon=wgs_rect.xMaximum(),
                max_lat=wgs_rect.yMaximum(),
            )

        cc = self.country_input.text().strip() or None
        self.service.search_async(
            query=query,
            limit=settings.search_limit,
            country_code=cc,
            bbox=bbox,
        )

    def _on_search_started(self):
        self.status_lbl.setText("Searching...")

    def _on_search_finished(self, results: List[GeocodingResult]):
        self.results = results
        self.results_table.setRowCount(0)
        self.tabs.setCurrentIndex(0)

        if not results:
            self.status_lbl.setText("No matching places found.")
            self._update_buttons()
            return

        self.results_table.setRowCount(len(results))
        for row, res in enumerate(results):
            name_item = QTableWidgetItem(res.display_name)
            name_item.setToolTip(f"{res.display_name}\nProvider: {res.provider}")

            type_item = QTableWidgetItem(res.place_type or "place")
            coords_item = QTableWidgetItem(f"{res.lat:.4f}, {res.lon:.4f}")

            self.results_table.setItem(row, 0, name_item)
            self.results_table.setItem(row, 1, type_item)
            self.results_table.setItem(row, 2, coords_item)

        attr = results[0].attribution or results[0].provider
        self.status_lbl.setText(f"{len(results)} result(s) · {attr}")
        self._refresh_history_list()

        self.results_table.selectRow(0)
        if settings.auto_zoom:
            self.zoom_to_selected()

    def _on_search_error(self, err_msg: str):
        self.status_lbl.setText(f"Search error: {err_msg}")
        self._update_buttons()

    def _on_provider_changed(self, name: str):
        self.service.set_provider(name)
        self.status_lbl.setText(f"Provider: {name}")

    def _on_selection_changed(self):
        self._update_buttons()

    def _update_buttons(self):
        has_sel = len(self.results_table.selectedItems()) > 0
        for b in (self.btn_zoom, self.btn_flash, self.btn_add_layer, self.btn_copy):
            b.setEnabled(has_sel)
        for act in (self.act_zoom, self.act_pan, self.act_flash, self.act_add_layer, self.act_copy, self.act_fav):
            act.setEnabled(has_sel)

    def get_selected_result(self) -> Optional[GeocodingResult]:
        row = self.results_table.currentRow()
        if 0 <= row < len(self.results):
            return self.results[row]
        return None

    def pan_to_selected(self):
        res = self.get_selected_result()
        if not res or self.canvas is None:
            return
        proj_pt = wgs84_to_project_point(res.lon, res.lat)
        self.canvas.setCenter(proj_pt)
        self.canvas.refresh()
        if settings.auto_flash:
            self.flash_selected()

    def zoom_to_selected(self):
        res = self.get_selected_result()
        if not res or self.canvas is None:
            return

        proj_pt = wgs84_to_project_point(res.lon, res.lat)

        if res.bounding_box:
            bb = res.bounding_box
            wgs_rect = QgsRectangle(bb.min_lon, bb.min_lat, bb.max_lon, bb.max_lat)
            proj_rect = transform_rectangle(wgs_rect, get_wgs84_crs(), get_project_crs())
            self.canvas.setExtent(proj_rect)
        else:
            self.canvas.setCenter(proj_pt)
            self.canvas.zoomScale(25000)

        self.canvas.refresh()
        if settings.auto_flash:
            self.flash_selected()

    def flash_selected(self):
        res = self.get_selected_result()
        if not res or self.canvas is None:
            return
        proj_pt = wgs84_to_project_point(res.lon, res.lat)
        geom = QgsGeometry.fromPointXY(proj_pt)
        highlight_color = self.palette().color(QPalette.ColorRole.Highlight)
        if not highlight_color.isValid():
            highlight_color = QColor("#0284c7")
        self.canvas.flashGeometries(
            [geom], get_project_crs(), color=highlight_color, flashes=3, duration=250
        )

    def add_selected_to_layer(self):
        res = self.get_selected_result()
        if not res:
            return
        LayerExporter.create_point_layer([res], layer_name=f"Point: {res.name}", add_to_project=True)
        if res.bounding_box or res.geojson_geometry:
            LayerExporter.create_boundary_layer(res, add_to_project=True)
        self.status_lbl.setText(f"Added '{res.name}' to project layers.")

    def copy_selected_coords(self):
        res = self.get_selected_result()
        if not res:
            return
        txt = f"{res.lat:.6f}, {res.lon:.6f}"
        QApplication.clipboard().setText(txt)
        self.status_lbl.setText(f"Copied coordinates: {txt}")

    def _save_selected_to_fav(self):
        res = self.get_selected_result()
        if res:
            self._add_fav(res)

    def _show_context_menu(self, pos):
        res = self.get_selected_result()
        if not res:
            return

        menu = QMenu(self)
        menu.addAction(_qgis_icon("mActionZoomToSelected.svg", "place_finder"), "Zoom to Place", self.zoom_to_selected)
        menu.addAction(_qgis_icon("mActionPanToSelected.svg", "place_finder"), "Pan to Place", self.pan_to_selected)
        menu.addAction(_qgis_icon("mActionHighlightFeature.svg", "flash"), "Flash on Map", self.flash_selected)
        menu.addAction(_qgis_icon("mActionAddOgrLayer.svg", "pin"), "Add to Layers", self.add_selected_to_layer)
        menu.addAction(_qgis_icon("mActionNewBookmark.svg", "pin"), "Save to Favorites", lambda: self._add_fav(res))
        menu.addSeparator()
        menu.addAction(_qgis_icon("mActionEditCopy.svg", "place_finder"), "Copy WGS84 Coordinates", self.copy_selected_coords)
        menu.exec(self.results_table.viewport().mapToGlobal(pos))

    def _add_fav(self, res: GeocodingResult):
        self.service.add_favorite(res)
        self._refresh_favorites_list()
        self.status_lbl.setText(f"Saved '{res.name}' to Favorites.")

    def _refresh_history_list(self):
        self.history_list.clear()
        for q in self.service.history:
            self.history_list.addItem(q)

    def _refresh_favorites_list(self):
        self.fav_list.clear()
        for f in self.service.favorites:
            self.fav_list.addItem(f.get("display_name", ""))

    def _on_history_clicked(self, item):
        self.search_input.setText(item.text())
        self._on_search_triggered()

    def _on_fav_clicked(self, item):
        name = item.text()
        fav_entry = next((f for f in self.service.favorites if f.get("display_name") == name), None)
        if fav_entry:
            res = GeocodingResult(
                place_id=name,
                display_name=name,
                name=fav_entry.get("name", name),
                lat=fav_entry.get("lat", 0.0),
                lon=fav_entry.get("lon", 0.0),
                place_type=fav_entry.get("place_type", "place"),
                provider=fav_entry.get("provider", "Favorite"),
            )
            self._on_search_finished([res])

    # Reverse Geocoding Map Tool
    def _on_reverse_toggled(self, checked: bool):
        if self.canvas is None or self.reverse_tool is None:
            return
        if checked:
            self.prev_tool = self.canvas.mapTool()
            self.canvas.setMapTool(self.reverse_tool)
            self.status_lbl.setText("Click on map canvas to reverse-geocode...")
        else:
            if self.prev_tool:
                self.canvas.setMapTool(self.prev_tool)

    def _on_map_point_clicked(self, lat: float, lon: float, proj_pt: QgsPointXY):
        self.status_lbl.setText(f"Reverse geocoding ({lat:.4f}, {lon:.4f})...")
        self.service.reverse_geocode_async(lat, lon)

    def _on_reverse_finished(self, result: Optional[GeocodingResult]):
        self.btn_reverse.setChecked(False)
        if result:
            self._on_search_finished([result])
        else:
            self.status_lbl.setText("No reverse geocoding result found for map click.")

"""
Provenance and Quality Report Viewer Dialog for AriesGeo Toolbox.
"""

import json
from typing import Dict, Any, Optional
from qgis.PyQt.QtWidgets import (
    QDialog,
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QTextBrowser,
    QPushButton,
    QFileDialog,
    QApplication,
    QLabel,
)
from qgis.PyQt.QtCore import Qt
from ..resources import get_icon
from ..raster.reports import ProvenanceReportGenerator

class ReportViewerDialog(QDialog):
    """Dialog for viewing and exporting sidecar provenance reports."""

    def __init__(self, report_data: Dict[str, Any], parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.report_data = report_data
        self.setWindowTitle("Processing Provenance & Quality Report — AriesPlus")
        self.setWindowIcon(get_icon("report"))
        self.resize(680, 520)

        self._setup_ui()

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(8)

        # Header
        header = QLabel("<b>AriesGeo Toolbox — Provenance Record</b>")
        header.setStyleSheet("font-size: 13px; color: #16A36A;")
        layout.addWidget(header)

        # Text Browser rendering Markdown
        self.browser = QTextBrowser()
        self.browser.setOpenExternalLinks(True)
        md_text = ProvenanceReportGenerator.render_markdown(self.report_data)
        self.browser.setMarkdown(md_text)
        layout.addWidget(self.browser)

        # Action Buttons
        btn_layout = QHBoxLayout()
        btn_copy = QPushButton("Copy Markdown")
        btn_export_json = QPushButton("Export JSON...")
        btn_close = QPushButton("Close")

        btn_copy.clicked.connect(lambda: QApplication.clipboard().setText(md_text))
        btn_export_json.clicked.connect(self._export_json)
        btn_close.clicked.connect(self.accept)

        btn_layout.addWidget(btn_copy)
        btn_layout.addWidget(btn_export_json)
        btn_layout.addStretch()
        btn_layout.addWidget(btn_close)
        layout.addLayout(btn_layout)

    def _export_json(self):
        path, _ = QFileDialog.getSaveFileName(self, "Export Provenance JSON", "provenance.json", "JSON (*.json)")
        if path:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(self.report_data, f, indent=2)

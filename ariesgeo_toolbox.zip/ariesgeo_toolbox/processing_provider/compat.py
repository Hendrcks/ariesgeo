"""
Cross-version PyQGIS compatibility shim for QGIS 3.28–3.44 LTR (Qt5) and QGIS 4.x (Qt6).
Resolves scoped enum changes in QgsProcessing, QgsProcessingParameterNumber,
QgsProcessingParameterFile, and QVariant across SIP5/SIP6.
"""

from qgis.core import (
    QgsProcessing,
    QgsProcessingParameterNumber,
    QgsProcessingParameterFile,
    QgsProcessingParameterFeatureSource,
)


def ensure_qgis_compat():
    """Ensure unscoped enum attributes exist on QgsProcessing classes in QGIS 4 (Qt6)."""
    # 1. QgsProcessing.SourceType
    source_type_enum = getattr(QgsProcessing, "SourceType", None)
    for attr, fallback in [
        ("TypeMapLayer", -2),
        ("TypeVectorAnyGeometry", -1),
        ("TypeVectorPoint", 0),
        ("TypeVectorLine", 1),
        ("TypeVectorPolygon", 2),
        ("TypeRaster", 3),
        ("TypeFile", 4),
        ("TypeVector", 5),
    ]:
        if not hasattr(QgsProcessing, attr):
            val = getattr(source_type_enum, attr, fallback) if source_type_enum else fallback
            try:
                setattr(QgsProcessing, attr, val)
            except Exception:
                pass

    # 2. QgsProcessingParameterNumber.Type
    num_type_enum = getattr(QgsProcessingParameterNumber, "Type", None)
    for attr, fallback in [("Integer", 0), ("Double", 1)]:
        if not hasattr(QgsProcessingParameterNumber, attr):
            val = getattr(num_type_enum, attr, fallback) if num_type_enum else fallback
            try:
                setattr(QgsProcessingParameterNumber, attr, val)
            except Exception:
                pass

    # 3. QgsProcessingParameterFile.Behavior
    file_behav_enum = getattr(QgsProcessingParameterFile, "Behavior", None)
    for attr, fallback in [("File", 0), ("Folder", 1)]:
        if not hasattr(QgsProcessingParameterFile, attr):
            val = getattr(file_behav_enum, attr, fallback) if file_behav_enum else fallback
            try:
                setattr(QgsProcessingParameterFile, attr, val)
            except Exception:
                pass

    # 4. QgsProcessingParameterFeatureSource.Flag
    fs_flag_enum = getattr(QgsProcessingParameterFeatureSource, "Flag", None)
    if not hasattr(QgsProcessingParameterFeatureSource, "FlagNone"):
        val = getattr(fs_flag_enum, "FlagNone", 0) if fs_flag_enum else 0
        try:
            setattr(QgsProcessingParameterFeatureSource, "FlagNone", val)
        except Exception:
            pass


# Run immediately on import
ensure_qgis_compat()


"""
Cross-version PyQGIS compatibility shim for QGIS 3.28–3.44 LTR (Qt5) and QGIS 4.x (Qt6).
Resolves scoped enum changes in QgsProcessing, QgsProcessingParameterNumber,
QgsProcessingParameterFile, and QVariant across SIP5/SIP6.
"""

from typing import List
from qgis.core import (
    QgsProcessing,
    QgsProcessingParameterNumber,
    QgsProcessingParameterFile,
    QgsProcessingParameterFeatureSource,
)

COMPAT_SKIPPED_ATTRS: List[str] = []


def _bind_compat_attr(target_cls, attr_name: str, value) -> None:
    """Attach a legacy unscoped enum attribute onto a SIP wrapper class when writable."""
    if hasattr(target_cls, attr_name):
        return
    try:
        setattr(target_cls, attr_name, value)
    except (AttributeError, TypeError) as err:
        COMPAT_SKIPPED_ATTRS.append(f"{target_cls.__name__}.{attr_name}: {err}")


def ensure_qgis_compat():
    """Ensure unscoped enum attributes exist on QgsProcessing classes in QGIS 4 (Qt6)."""
    # 1. QgsProcessing.SourceType
    source_type_enum = getattr(QgsProcessing, "SourceType", None)
    for attr, fallback in [
        ("TypeMapLayer", -2),
        ("TypeVectorAnyGeometry", -1),
        ("TypeVectorPoint", 0),
        ("TypeVectorLine", 1),
        ("TypeVectorPolygon", 2),
        ("TypeRaster", 3),
        ("TypeFile", 4),
        ("TypeVector", 5),
    ]:
        val = getattr(source_type_enum, attr, fallback) if source_type_enum else fallback
        _bind_compat_attr(QgsProcessing, attr, val)

    # 2. QgsProcessingParameterNumber.Type
    num_type_enum = getattr(QgsProcessingParameterNumber, "Type", None)
    for attr, fallback in [("Integer", 0), ("Double", 1)]:
        val = getattr(num_type_enum, attr, fallback) if num_type_enum else fallback
        _bind_compat_attr(QgsProcessingParameterNumber, attr, val)

    # 3. QgsProcessingParameterFile.Behavior
    file_behav_enum = getattr(QgsProcessingParameterFile, "Behavior", None)
    for attr, fallback in [("File", 0), ("Folder", 1)]:
        val = getattr(file_behav_enum, attr, fallback) if file_behav_enum else fallback
        _bind_compat_attr(QgsProcessingParameterFile, attr, val)

    # 4. QgsProcessingParameterFeatureSource.Flag
    fs_flag_enum = getattr(QgsProcessingParameterFeatureSource, "Flag", None)
    val = getattr(fs_flag_enum, "FlagNone", 0) if fs_flag_enum else 0
    _bind_compat_attr(QgsProcessingParameterFeatureSource, "FlagNone", val)


# Run immediately on import
ensure_qgis_compat()


"""
QgsProcessingProvider for AriesGeo Toolbox v4.0.
Exposes the complete 100 scientific algorithm suite across 7 specialized groups.
"""

from qgis.core import QgsProcessingProvider
from .compat import ensure_qgis_compat
ensure_qgis_compat()
from ..resources import get_icon

# Group 01: Place Finder & Geocoding (10)
from .algorithms.group01_place_finder import (
    PlaceSearchAlgorithm,
    ReverseGeocodeAlgorithm,
    BatchGeocodeAlgorithm,
    CoordinateParserAlgorithm,
    TransformCoordinatesAlgorithm,
    NearestPlaceAlgorithm,
    PlaceProximityAlgorithm,
    SearchWithinAOIAlgorithm,
    OfflineGazetteerBuildAlgorithm,
    GazetteerQualityAuditAlgorithm
)

# Group 02: Landsat 7 SLC-off Gapfill (15)
from .algorithms.group02_gapfill import (
    SlcMetadataInspectorAlgorithm,
    SlcGapMaskAlgorithm,
    SlcGapMetricsAlgorithm,
    SlcDonorRankAlgorithm,
    SlcCoregistrationAlgorithm,
    SlcStablePixelMaskAlgorithm,
    SlcGlobalMatchAlgorithm,
    SlcLocalMatchAlgorithm,
    SlcSingleTinAlgorithm,
    SlcSingleIdwAlgorithm,
    SlcTwoSceneFillAlgorithm,
    SlcMultidonorFillAlgorithm,
    SlcDonorConsistencyAlgorithm,
    SlcRecoveryValidationAlgorithm,
    SlcRecoveryReportAlgorithm
)

# Group 03: Raster Preprocessing & Cloud Removal (20)
from .algorithms.group03_raster_prep import (
    RasterInspectorAlgorithm,
    SceneMetadataAlgorithm,
    ReflectanceScaleAlgorithm,
    RadiometricQaAlgorithm,
    RasterGridAlignAlgorithm,
    RasterStackBuilderAlgorithm,
    LandsatQaMaskAlgorithm,
    SentinelSclMaskAlgorithm,
    CloudMaskRefineAlgorithm,
    CloudCoverageReportAlgorithm,
    TemporalCloudCompositeAlgorithm,
    NodataSpatialFillAlgorithm,
    MosaicVrtAlgorithm,
    MosaicPriorityAlgorithm,
    MosaicSeamBlendAlgorithm,
    RadiometricHarmonizeAlgorithm,
    RasterClipAoiAlgorithm,
    CogExportAlgorithm,
    RasterBatchPipelineAlgorithm,
    RasterQualitySummaryAlgorithm
)

# Group 04: Terrain & Hydrology (24)
from .algorithms.group04_terrain_hydro import (
    DemDiagnosticsAlgorithm,
    DemMergePrepareAlgorithm,
    DemVoidFillAlgorithm,
    DemSinkTreatmentAlgorithm,
    DemSlopeAlgorithm,
    DemAspectAlgorithm,
    DemHillshadeAlgorithm,
    DemCurvatureAlgorithm,
    DemTriAlgorithm,
    DemTpiAlgorithm,
    DemRoughnessAlgorithm,
    DemContoursAlgorithm,
    DemProfileAlgorithm,
    FlowD8Algorithm,
    FlowMfdAlgorithm,
    FlowSpecificAreaAlgorithm,
    FlowStreamExtractAlgorithm,
    FlowOutletSnapAlgorithm,
    FlowWatershedAlgorithm,
    FlowSubbasinsAlgorithm,
    StreamOrderAlgorithm,
    HydroTwiAlgorithm,
    HydroSpiAlgorithm,
    WatershedMorphometryAlgorithm
)

# Group 05: Spatial Statistics & Suitability (15)
from .algorithms.group05_spatial_stats import (
    RasterStandardizeAlgorithm,
    AhpWeightsAlgorithm,
    WeightedOverlayAlgorithm,
    FuzzyMembershipAlgorithm,
    FuzzyOverlayAlgorithm,
    SuitabilitySensitivityAlgorithm,
    ZonalDistributionAlgorithm,
    PointKdeAlgorithm,
    PointIdwAlgorithm,
    MoranGlobalAlgorithm,
    MoranLocalAlgorithm,
    GiStarAlgorithm,
    NearestNeighborStatsAlgorithm,
    BufferExposureSummaryAlgorithm,
    SpatialModelReportAlgorithm
)

# Group 06: Data Hub & Acquisition (8)
from .algorithms.group06_data_hub import (
    CatalogStacSearchAlgorithm,
    CatalogAssetInspectAlgorithm,
    CatalogLandsatSearchAlgorithm,
    CatalogSentinelSearchAlgorithm,
    CatalogDemSearchAlgorithm,
    CatalogOsmImportAlgorithm,
    DownloadAssetsAlgorithm,
    LocalCatalogIndexAlgorithm
)

# Group 07: Quality Control & Workflows (8)
from .algorithms.group07_quality_workflows import (
    LayerIntegrityAuditAlgorithm,
    RasterAlignmentAuditAlgorithm,
    VectorGeometryAuditAlgorithm,
    AlgorithmPreflightAlgorithm,
    WorkflowRunAlgorithm,
    WorkflowBatchAlgorithm,
    ValidationStatisticsAlgorithm,
    ProvenanceExportAlgorithm
)

# Legacy v3 compatibility aliases
from .algorithms.geocode_place import GeocodePlaceAlgorithm
from .algorithms.inspect_rasters import InspectRastersAlgorithm
from .algorithms.inspect_dem import InspectDemAlgorithm
from .algorithms.landsat_gapfill import LandsatGapFillAlgorithm
from .algorithms.flow_analysis import FlowAnalysisAlgorithm
from .algorithms.extract_streams import ExtractStreamsAlgorithm
from .algorithms.delineate_watershed import DelineateWatershedAlgorithm
from .algorithms.fill_nodata import FillNoDataAlgorithm
from .algorithms.remove_clouds import RemoveCloudsAlgorithm
from .algorithms.terrain_derivatives import TerrainDerivativesAlgorithm


class AriesGeoProcessingProvider(QgsProcessingProvider):
    """
    Processing provider exposing the 100 AriesGeo Toolbox v4.0 scientific algorithms.
    """

    def id(self):
        return "ariesgeo"

    def name(self):
        return "AriesGeo Toolbox"

    def icon(self):
        return get_icon("icon")

    def get_algorithm_list(self):
        """Return fresh instances of all registered AriesGeo algorithms."""
        return [
            # --- Group 01: Place Finder & Geocoding (10) ---
            PlaceSearchAlgorithm(),
            ReverseGeocodeAlgorithm(),
            BatchGeocodeAlgorithm(),
            CoordinateParserAlgorithm(),
            TransformCoordinatesAlgorithm(),
            NearestPlaceAlgorithm(),
            PlaceProximityAlgorithm(),
            SearchWithinAOIAlgorithm(),
            OfflineGazetteerBuildAlgorithm(),
            GazetteerQualityAuditAlgorithm(),

            # --- Group 02: Landsat 7 SLC-off Gapfill (15) ---
            SlcMetadataInspectorAlgorithm(),
            SlcGapMaskAlgorithm(),
            SlcGapMetricsAlgorithm(),
            SlcDonorRankAlgorithm(),
            SlcCoregistrationAlgorithm(),
            SlcStablePixelMaskAlgorithm(),
            SlcGlobalMatchAlgorithm(),
            SlcLocalMatchAlgorithm(),
            SlcSingleTinAlgorithm(),
            SlcSingleIdwAlgorithm(),
            SlcTwoSceneFillAlgorithm(),
            SlcMultidonorFillAlgorithm(),
            SlcDonorConsistencyAlgorithm(),
            SlcRecoveryValidationAlgorithm(),
            SlcRecoveryReportAlgorithm(),

            # --- Group 03: Raster Preprocessing & Cloud Removal (20) ---
            RasterInspectorAlgorithm(),
            SceneMetadataAlgorithm(),
            ReflectanceScaleAlgorithm(),
            RadiometricQaAlgorithm(),
            RasterGridAlignAlgorithm(),
            RasterStackBuilderAlgorithm(),
            LandsatQaMaskAlgorithm(),
            SentinelSclMaskAlgorithm(),
            CloudMaskRefineAlgorithm(),
            CloudCoverageReportAlgorithm(),
            TemporalCloudCompositeAlgorithm(),
            NodataSpatialFillAlgorithm(),
            MosaicVrtAlgorithm(),
            MosaicPriorityAlgorithm(),
            MosaicSeamBlendAlgorithm(),
            RadiometricHarmonizeAlgorithm(),
            RasterClipAoiAlgorithm(),
            CogExportAlgorithm(),
            RasterBatchPipelineAlgorithm(),
            RasterQualitySummaryAlgorithm(),

            # --- Group 04: Terrain & Hydrology (24) ---
            DemDiagnosticsAlgorithm(),
            DemMergePrepareAlgorithm(),
            DemVoidFillAlgorithm(),
            DemSinkTreatmentAlgorithm(),
            DemSlopeAlgorithm(),
            DemAspectAlgorithm(),
            DemHillshadeAlgorithm(),
            DemCurvatureAlgorithm(),
            DemTriAlgorithm(),
            DemTpiAlgorithm(),
            DemRoughnessAlgorithm(),
            DemContoursAlgorithm(),
            DemProfileAlgorithm(),
            FlowD8Algorithm(),
            FlowMfdAlgorithm(),
            FlowSpecificAreaAlgorithm(),
            FlowStreamExtractAlgorithm(),
            FlowOutletSnapAlgorithm(),
            FlowWatershedAlgorithm(),
            FlowSubbasinsAlgorithm(),
            StreamOrderAlgorithm(),
            HydroTwiAlgorithm(),
            HydroSpiAlgorithm(),
            WatershedMorphometryAlgorithm(),

            # --- Group 05: Spatial Statistics & Suitability (15) ---
            RasterStandardizeAlgorithm(),
            AhpWeightsAlgorithm(),
            WeightedOverlayAlgorithm(),
            FuzzyMembershipAlgorithm(),
            FuzzyOverlayAlgorithm(),
            SuitabilitySensitivityAlgorithm(),
            ZonalDistributionAlgorithm(),
            PointKdeAlgorithm(),
            PointIdwAlgorithm(),
            MoranGlobalAlgorithm(),
            MoranLocalAlgorithm(),
            GiStarAlgorithm(),
            NearestNeighborStatsAlgorithm(),
            BufferExposureSummaryAlgorithm(),
            SpatialModelReportAlgorithm(),

            # --- Group 06: Data Hub & Acquisition (8) ---
            CatalogStacSearchAlgorithm(),
            CatalogAssetInspectAlgorithm(),
            CatalogLandsatSearchAlgorithm(),
            CatalogSentinelSearchAlgorithm(),
            CatalogDemSearchAlgorithm(),
            CatalogOsmImportAlgorithm(),
            DownloadAssetsAlgorithm(),
            LocalCatalogIndexAlgorithm(),

            # --- Group 07: Quality Control & Workflows (8) ---
            LayerIntegrityAuditAlgorithm(),
            RasterAlignmentAuditAlgorithm(),
            VectorGeometryAuditAlgorithm(),
            AlgorithmPreflightAlgorithm(),
            WorkflowRunAlgorithm(),
            WorkflowBatchAlgorithm(),
            ValidationStatisticsAlgorithm(),
            ProvenanceExportAlgorithm(),

            # --- Legacy v3 aliases (ensures backward compatibility for existing scripts) ---
            GeocodePlaceAlgorithm(),
            InspectRastersAlgorithm(),
            InspectDemAlgorithm(),
            LandsatGapFillAlgorithm(),
            FlowAnalysisAlgorithm(),
            ExtractStreamsAlgorithm(),
            DelineateWatershedAlgorithm(),
            FillNoDataAlgorithm(),
            RemoveCloudsAlgorithm(),
            TerrainDerivativesAlgorithm(),
        ]

    def loadAlgorithms(self):
        """Register the 100 official scientific algorithms organized into 7 groups."""
        self._algorithms = self.get_algorithm_list()
        for alg in self._algorithms:
            self.addAlgorithm(alg)

"""
QgsProcessingProvider for AriesGeo Toolbox.
"""

from qgis.core import QgsProcessingProvider
from ..resources import get_icon

# Module A: Place Finder Algorithms
from .algorithms.geocode_place import GeocodePlaceAlgorithm
from .algorithms.batch_geocode import BatchGeocodeAlgorithm
from .algorithms.reverse_geocode import ReverseGeocodeAlgorithm

# Module B: Raster Mosaic & Cloud Remover Algorithms
from .algorithms.inspect_rasters import InspectRastersAlgorithm
from .algorithms.build_vrt_mosaic import BuildVrtMosaicAlgorithm
from .algorithms.create_permanent_mosaic import CreatePermanentMosaicAlgorithm
from .algorithms.fill_nodata import FillNoDataAlgorithm
from .algorithms.remove_clouds import RemoveCloudsAlgorithm

# Module B2: AriesGapfill Algorithms (Landsat 7 SLC-off & Spatial)
from .algorithms.gapfill_triangulation import GapfillTriangulationAlgorithm
from .algorithms.gapfill_global import GapfillGlobalAlgorithm
from .algorithms.gapfill_local import GapfillLocalAlgorithm
from .algorithms.gapfill_multidonor import GapfillMultiDonorAlgorithm
from .algorithms.landsat_gapfill import LandsatGapFillAlgorithm

# Module C: Map Layout Assistant Algorithms
from .algorithms.create_map_layout import CreateMapLayoutAlgorithm
from .algorithms.export_layout import ExportLayoutAlgorithm

# Module D: Terrain & Hydrology Toolkit Algorithms
from .algorithms.inspect_dem import InspectDemAlgorithm
from .algorithms.terrain_derivatives import TerrainDerivativesAlgorithm
from .algorithms.flow_analysis import FlowAnalysisAlgorithm
from .algorithms.extract_streams import ExtractStreamsAlgorithm
from .algorithms.delineate_watershed import DelineateWatershedAlgorithm


class AriesGeoProcessingProvider(QgsProcessingProvider):
    """Processing provider exposing all AriesGeo Toolbox and AriesGapfill algorithms to QGIS."""

    def id(self):
        return "ariesgeo"

    def name(self):
        return "AriesGeo Toolbox"

    def icon(self):
        return get_icon("icon")

    def loadAlgorithms(self):
        """Register all AriesGeo Processing algorithms."""
        # Place Finder
        self.addAlgorithm(GeocodePlaceAlgorithm())
        self.addAlgorithm(BatchGeocodeAlgorithm())
        self.addAlgorithm(ReverseGeocodeAlgorithm())

        # Raster Mosaic & Cloud Remover
        self.addAlgorithm(InspectRastersAlgorithm())
        self.addAlgorithm(BuildVrtMosaicAlgorithm())
        self.addAlgorithm(CreatePermanentMosaicAlgorithm())
        self.addAlgorithm(FillNoDataAlgorithm())
        self.addAlgorithm(RemoveCloudsAlgorithm())

        # AriesGapfill Suite
        self.addAlgorithm(GapfillTriangulationAlgorithm())
        self.addAlgorithm(GapfillGlobalAlgorithm())
        self.addAlgorithm(GapfillLocalAlgorithm())
        self.addAlgorithm(GapfillMultiDonorAlgorithm())
        self.addAlgorithm(LandsatGapFillAlgorithm())

        # Map Layout Assistant
        self.addAlgorithm(CreateMapLayoutAlgorithm())
        self.addAlgorithm(ExportLayoutAlgorithm())

        # Terrain & Hydrology Toolkit
        self.addAlgorithm(InspectDemAlgorithm())
        self.addAlgorithm(TerrainDerivativesAlgorithm())
        self.addAlgorithm(FlowAnalysisAlgorithm())
        self.addAlgorithm(ExtractStreamsAlgorithm())
        self.addAlgorithm(DelineateWatershedAlgorithm())

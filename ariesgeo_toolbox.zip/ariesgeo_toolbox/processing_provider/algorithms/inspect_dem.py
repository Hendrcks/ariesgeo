"""
Processing algorithm: Inspect DEM.
"""

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingOutputString,
    QgsProcessingOutputNumber,
    QgsProcessingContext,
    QgsProcessingFeedback,
)
from ...terrain_hydrology.dem_inspector import DEMInspector

class InspectDemAlgorithm(QgsProcessingAlgorithm):
    INPUT_DEM = "INPUT_DEM"
    SUMMARY_HTML = "SUMMARY_HTML"
    MIN_ELEV = "MIN_ELEV"
    MAX_ELEV = "MAX_ELEV"
    MEAN_ELEV = "MEAN_ELEV"
    SINKS_COUNT = "SINKS_COUNT"

    def name(self):
        return "inspect_dem"

    def displayName(self):
        return "Inspect DEM Elevation & CRS"

    def group(self):
        return "Terrain & Hydrology Toolkit"

    def groupId(self):
        return "terrain_hydrology"

    def shortHelpString(self):
        return "Runs preflight elevation diagnostics on a Digital Elevation Model (DEM), reporting CRS, pixel metrics, vertical ranges, and potential sink depressions."

    def createInstance(self):
        return InspectDemAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterRasterLayer(
                self.INPUT_DEM,
                "Input Digital Elevation Model (DEM)"
            )
        )
        self.addOutput(
            QgsProcessingOutputString(
                self.SUMMARY_HTML,
                "Diagnostics Summary HTML"
            )
        )
        self.addOutput(
            QgsProcessingOutputNumber(
                self.MIN_ELEV,
                "Minimum Elevation (m)"
            )
        )
        self.addOutput(
            QgsProcessingOutputNumber(
                self.MAX_ELEV,
                "Maximum Elevation (m)"
            )
        )
        self.addOutput(
            QgsProcessingOutputNumber(
                self.MEAN_ELEV,
                "Mean Elevation (m)"
            )
        )
        self.addOutput(
            QgsProcessingOutputNumber(
                self.SINKS_COUNT,
                "Estimated Sinks / Pits Count"
            )
        )

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        layer = self.parameterAsRasterLayer(parameters, self.INPUT_DEM, context)
        if not layer or not layer.isValid():
            raise ValueError("Invalid DEM raster layer provided.")

        filepath = layer.source()
        feedback.pushInfo(f"Inspecting DEM: {filepath}")

        diag = DEMInspector.inspect(filepath)

        feedback.pushInfo(f"Dimensions: {diag.width} x {diag.height}")
        feedback.pushInfo(f"CRS: {diag.crs_auth_id} (Projected: {diag.is_projected})")
        feedback.pushInfo(f"Pixel Resolution: {diag.pixel_size_x:.2f} x {diag.pixel_size_y:.2f}")
        feedback.pushInfo(f"Elevation Range: {diag.min_elev}m to {diag.max_elev}m (Mean: {diag.mean_elev}m)")
        feedback.pushInfo(f"Estimated Local Sinks/Depressions: {diag.sink_count_approx}")

        if diag.warnings:
            feedback.pushInfo("Warnings:")
            for w in diag.warnings:
                feedback.pushWarning(f" - {w}")

        html = (
            f"<div><h3>DEM Preflight Diagnostics: {diag.filename}</h3>"
            f"<p><b>CRS:</b> {diag.crs_auth_id} | <b>Projected:</b> {diag.is_projected}</p>"
            f"<p><b>Resolution:</b> {diag.pixel_size_x:.2f} x {diag.pixel_size_y:.2f} m</p>"
            f"<p><b>Elevation:</b> {diag.min_elev} m - {diag.max_elev} m (Avg: {diag.mean_elev} m)</p>"
            f"<p><b>Local Depressions:</b> {diag.sink_count_approx}</p></div>"
        )

        return {
            self.SUMMARY_HTML: html,
            self.MIN_ELEV: diag.min_elev,
            self.MAX_ELEV: diag.max_elev,
            self.MEAN_ELEV: diag.mean_elev,
            self.SINKS_COUNT: diag.sink_count_approx,
        }

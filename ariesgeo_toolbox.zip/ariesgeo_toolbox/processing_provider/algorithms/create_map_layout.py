"""
Processing algorithm: Create Map Layout.
"""

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterString,
    QgsProcessingParameterEnum,
    QgsProcessingParameterBoolean,
    QgsProcessingOutputString,
    QgsProcessingContext,
    QgsProcessingFeedback,
    QgsProject,
)
from ...layout_assistant.models import LayoutConfig, TextMetadata, GridConfig, InsetConfig
from ...layout_assistant.composer import LayoutComposer

class CreateMapLayoutAlgorithm(QgsProcessingAlgorithm):
    LAYOUT_NAME = "LAYOUT_NAME"
    PAGE_SIZE = "PAGE_SIZE"
    ORIENTATION = "ORIENTATION"
    TEMPLATE = "TEMPLATE"
    TITLE = "TITLE"
    SUBTITLE = "SUBTITLE"
    AUTHOR = "AUTHOR"
    INCLUDE_LEGEND = "INCLUDE_LEGEND"
    INCLUDE_SCALEBAR = "INCLUDE_SCALEBAR"
    INCLUDE_NORTH_ARROW = "INCLUDE_NORTH_ARROW"
    INCLUDE_GRID = "INCLUDE_GRID"
    OUTPUT_LAYOUT_NAME = "OUTPUT_LAYOUT_NAME"

    PAGE_SIZES = ["A4", "A3", "A2", "A1", "A0", "Letter", "Legal"]
    ORIENTATIONS = ["Landscape", "Portrait"]
    TEMPLATES = ["Modern Report", "Academic & Research", "Field Survey & Planning", "Landscape Executive"]

    def name(self):
        return "create_map_layout"

    def displayName(self):
        return "Create Map Layout"

    def group(self):
        return "Map Layout Assistant"

    def groupId(self):
        return "layout_assistant"

    def shortHelpString(self):
        return "Automatically builds an editable, professional QGIS print layout with map, legend, scale bar, north arrow, and metadata."

    def createInstance(self):
        return CreateMapLayoutAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterString(
                self.LAYOUT_NAME,
                "Layout Name",
                defaultValue="Aries_Auto_Layout"
            )
        )
        self.addParameter(
            QgsProcessingParameterEnum(
                self.PAGE_SIZE,
                "Page Size",
                options=self.PAGE_SIZES,
                defaultValue=0
            )
        )
        self.addParameter(
            QgsProcessingParameterEnum(
                self.ORIENTATION,
                "Orientation",
                options=self.ORIENTATIONS,
                defaultValue=0
            )
        )
        self.addParameter(
            QgsProcessingParameterEnum(
                self.TEMPLATE,
                "Cartographic Template Style",
                options=self.TEMPLATES,
                defaultValue=0
            )
        )
        self.addParameter(
            QgsProcessingParameterString(
                self.TITLE,
                "Map Title",
                defaultValue="Project Study Area"
            )
        )
        self.addParameter(
            QgsProcessingParameterString(
                self.SUBTITLE,
                "Subtitle",
                defaultValue="Spatial Survey Map",
                optional=True
            )
        )
        self.addParameter(
            QgsProcessingParameterString(
                self.AUTHOR,
                "Author / Organization",
                defaultValue="AriesPlus",
                optional=True
            )
        )
        self.addParameter(
            QgsProcessingParameterBoolean(
                self.INCLUDE_LEGEND,
                "Include Legend",
                defaultValue=True
            )
        )
        self.addParameter(
            QgsProcessingParameterBoolean(
                self.INCLUDE_SCALEBAR,
                "Include Scale Bar",
                defaultValue=True
            )
        )
        self.addParameter(
            QgsProcessingParameterBoolean(
                self.INCLUDE_NORTH_ARROW,
                "Include North Arrow",
                defaultValue=True
            )
        )
        self.addParameter(
            QgsProcessingParameterBoolean(
                self.INCLUDE_GRID,
                "Include Coordinate Grid",
                defaultValue=False
            )
        )
        self.addOutput(
            QgsProcessingOutputString(
                self.OUTPUT_LAYOUT_NAME,
                "Created Layout Name"
            )
        )

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        l_name = self.parameterAsString(parameters, self.LAYOUT_NAME, context)
        p_size = self.PAGE_SIZES[self.parameterAsEnum(parameters, self.PAGE_SIZE, context)]
        orient = self.ORIENTATIONS[self.parameterAsEnum(parameters, self.ORIENTATION, context)]
        tpl = self.TEMPLATES[self.parameterAsEnum(parameters, self.TEMPLATE, context)]
        title = self.parameterAsString(parameters, self.TITLE, context)
        sub = self.parameterAsString(parameters, self.SUBTITLE, context)
        author = self.parameterAsString(parameters, self.AUTHOR, context)
        inc_leg = self.parameterAsBoolean(parameters, self.INCLUDE_LEGEND, context)
        inc_sb = self.parameterAsBoolean(parameters, self.INCLUDE_SCALEBAR, context)
        inc_na = self.parameterAsBoolean(parameters, self.INCLUDE_NORTH_ARROW, context)
        inc_gr = self.parameterAsBoolean(parameters, self.INCLUDE_GRID, context)

        config = LayoutConfig(
            layout_name=l_name,
            page_size_name=p_size,
            orientation=orient,
            template_name=tpl,
            metadata=TextMetadata(title=title, subtitle=sub, author=author, organization="AriesPlus"),
            grid=GridConfig(enabled=inc_gr),
            include_legend=inc_leg,
            include_scalebar=inc_sb,
            include_north_arrow=inc_na
        )

        feedback.pushInfo(f"Building layout '{l_name}' ({p_size} {orient}, {tpl})...")
        layout = LayoutComposer.create_layout(config, project=context.project())
        feedback.pushInfo(f"Layout '{layout.name()}' created successfully in Layout Manager.")

        return {self.OUTPUT_LAYOUT_NAME: layout.name()}

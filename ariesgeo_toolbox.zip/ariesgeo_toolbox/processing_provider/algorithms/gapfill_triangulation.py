"""
Processing algorithm: AriesGapfill Single-Image Triangulation (Method A).
"""

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterRasterDestination,
    QgsProcessingParameterNumber,
    QgsProcessingParameterBoolean,
    QgsProcessingOutputRasterLayer,
    QgsProcessingOutputNumber,
    QgsProcessingContext,
    QgsProcessingFeedback,
)
from ...gapfill.models import GapFillConfig, GapFillMethod, MethodParameters
from ...gapfill.engine import AriesGapFillEngine


class GapfillTriangulationAlgorithm(QgsProcessingAlgorithm):
    INPUT_TARGET = "INPUT_TARGET"
    MAX_DISTANCE = "MAX_DISTANCE"
    NEAREST_FALLBACK = "NEAREST_FALLBACK"

    OUTPUT_FILLED = "OUTPUT_FILLED"
    OUTPUT_PROVENANCE = "OUTPUT_PROVENANCE"
    OUTPUT_CONFIDENCE = "OUTPUT_CONFIDENCE"

    def name(self):
        return "gapfill_triangulation"

    def displayName(self):
        return "AriesGapfill: Single-Image Triangulation"

    def group(self):
        return "AriesGapfill"

    def groupId(self):
        return "gapfill"

    def shortHelpString(self):
        return "Interpolates missing / SLC-off pixels from surrounding valid boundary pixels using Delaunay triangulation and barycentric interpolation."

    def createInstance(self):
        return GapfillTriangulationAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterRasterLayer(
                self.INPUT_TARGET,
                "Input Target Raster (SLC-off)"
            )
        )
        self.addParameter(
            QgsProcessingParameterNumber(
                self.MAX_DISTANCE,
                "Maximum Gap Distance to Interpolate (Pixels)",
                type=QgsProcessingParameterNumber.Integer,
                defaultValue=50,
                minValue=1
            )
        )
        self.addParameter(
            QgsProcessingParameterBoolean(
                self.NEAREST_FALLBACK,
                "Enable Nearest-Neighbor Fallback for Edge Gaps",
                defaultValue=True
            )
        )
        self.addParameter(
            QgsProcessingParameterRasterDestination(
                self.OUTPUT_FILLED,
                "Output Repaired Raster"
            )
        )
        self.addParameter(
            QgsProcessingParameterRasterDestination(
                self.OUTPUT_PROVENANCE,
                "Output Provenance Mask Raster",
                optional=True
            )
        )
        self.addParameter(
            QgsProcessingParameterRasterDestination(
                self.OUTPUT_CONFIDENCE,
                "Output Confidence Raster",
                optional=True
            )
        )

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        t_layer = self.parameterAsRasterLayer(parameters, self.INPUT_TARGET, context)
        if not t_layer or not t_layer.isValid():
            raise ValueError("Invalid target raster layer provided.")

        max_dist = self.parameterAsInt(parameters, self.MAX_DISTANCE, context)
        nearest_fb = self.parameterAsBoolean(parameters, self.NEAREST_FALLBACK, context)
        out_filled = self.parameterAsOutputLayer(parameters, self.OUTPUT_FILLED, context)
        out_prov = self.parameterAsOutputLayer(parameters, self.OUTPUT_PROVENANCE, context)
        out_conf = self.parameterAsOutputLayer(parameters, self.OUTPUT_CONFIDENCE, context)

        cfg = GapFillConfig(
            target_path=t_layer.source(),
            method=GapFillMethod.TRIANGULATION,
            output_filled_path=out_filled,
            output_provenance_path=out_prov,
            output_confidence_path=out_conf,
            parameters=MethodParameters(
                max_triangulation_distance=max_dist,
                enable_nearest_fallback=nearest_fb
            )
        )

        def on_prog(p, msg):
            feedback.setProgress(p)
            feedback.pushInfo(msg)

        feedback.pushInfo("Running AriesGapfill Single-Image Triangulation...")
        res = AriesGapFillEngine.execute(cfg, progress_callback=on_prog)

        results = {self.OUTPUT_FILLED: out_filled}
        if out_prov:
            results[self.OUTPUT_PROVENANCE] = out_prov
        if out_conf:
            results[self.OUTPUT_CONFIDENCE] = out_conf

        feedback.pushInfo(f"Triangulation complete: {res.filled_gap_count:,} gaps repaired ({res.overall_fill_rate_pct:.1f}%).")
        return results

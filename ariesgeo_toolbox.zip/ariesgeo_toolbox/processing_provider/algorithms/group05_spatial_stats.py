"""
Processing algorithms for Group 05: Spatial Statistics & Suitability (15 algorithms).
"""

import os
import json
import math
from typing import List, Dict, Any, Optional
import numpy as np

from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterMultipleLayers,
    QgsProcessingParameterEnum,
    QgsProcessingParameterNumber,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterString,
    QgsProcessingParameterFile,
    QgsProcessingParameterFileDestination,
    QgsProcessingParameterRasterDestination,
    QgsProcessingParameterVectorDestination,
    QgsProcessingParameterFeatureSource,
    QgsProcessingOutputRasterLayer,
    QgsProcessingOutputVectorLayer,
    QgsProcessingOutputFile,
    QgsProcessingContext,
    QgsProcessingFeedback,
    QgsVectorLayer,
    QgsField,
    QgsFeature,
    QgsGeometry,
    QgsPointXY,
    QgsVectorFileWriter
)
from qgis.PyQt.QtCore import QVariant

from ...spatial_stats.suitability import (
    standardize_raster,
    calculate_ahp_weights,
    weighted_linear_combination,
    fuzzy_membership,
    fuzzy_overlay,
    suitability_sensitivity,
    zonal_distribution
)
from ...spatial_stats.spatial_patterns import (
    point_kde,
    point_idw,
    moran_global,
    moran_local,
    getis_ord_gi_star,
    nearest_neighbor_analysis,
    buffer_exposure_summary
)


class RasterStandardizeAlgorithm(QgsProcessingAlgorithm):
    INPUT_RASTER = "INPUT_RASTER"
    DIRECTION = "DIRECTION"
    METHOD = "METHOD"
    OUTPUT_RASTER = "OUTPUT_RASTER"
    DIRECTIONS = ["Benefit (Higher is better)", "Cost (Lower is better)"]
    METHODS = ["Linear Min-Max", "Logarithmic", "Sigmoid"]

    def name(self):
        return "raster_standardize"

    def displayName(self):
        return "05.01 Standardize criteria"

    def group(self):
        return "05 · Spatial Statistics & Suitability"

    def groupId(self):
        return "05_spatial_stats"

    def shortHelpString(self):
        return "Standardize continuous criteria rasters to a normalized [0.0, 1.0] utility scale."

    def createInstance(self):
        return RasterStandardizeAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(self.INPUT_RASTER, "Input Criteria Raster"))
        self.addParameter(QgsProcessingParameterEnum(self.DIRECTION, "Criteria Direction", options=self.DIRECTIONS, defaultValue=0))
        self.addParameter(QgsProcessingParameterEnum(self.METHOD, "Standardization Method", options=self.METHODS, defaultValue=0))
        self.addParameter(QgsProcessingParameterRasterDestination(self.OUTPUT_RASTER, "Output Standardized Raster [0-1]"))

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        layer = self.parameterAsRasterLayer(parameters, self.INPUT_RASTER, context)
        dir_idx = self.parameterAsEnum(parameters, self.DIRECTION, context)
        meth_idx = self.parameterAsEnum(parameters, self.METHOD, context)
        out_dest = self.parameterAsOutputLayer(parameters, self.OUTPUT_RASTER, context)

        direction = "benefit" if dir_idx == 0 else "cost"
        method_map = {0: "linear", 1: "log", 2: "sigmoid"}
        method = method_map.get(meth_idx, "linear")

        standardize_raster(layer.source(), out_dest, method=method, direction=direction)
        return {self.OUTPUT_RASTER: out_dest}


class AhpWeightsAlgorithm(QgsProcessingAlgorithm):
    INPUT_MATRIX = "INPUT_MATRIX"
    OUTPUT_REPORT = "OUTPUT_REPORT"

    def name(self):
        return "ahp_weights"

    def displayName(self):
        return "05.02 Analytic Hierarchy Process weights"

    def group(self):
        return "05 · Spatial Statistics & Suitability"

    def groupId(self):
        return "05_spatial_stats"

    def shortHelpString(self):
        return "Calculate normalized AHP criteria weights from a reciprocal pairwise comparison matrix and audit the Consistency Ratio (CR)."

    def createInstance(self):
        return AhpWeightsAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterString(self.INPUT_MATRIX, "Pairwise Comparison Matrix JSON (e.g. [[1, 3], [0.333, 1]])", defaultValue="[[1.0, 3.0, 5.0], [0.333, 1.0, 2.0], [0.2, 0.5, 1.0]]"))
        self.addParameter(QgsProcessingParameterFileDestination(self.OUTPUT_REPORT, "Output AHP Weights JSON Report", fileFilter="JSON (*.json)"))

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        mat_str = self.parameterAsString(parameters, self.INPUT_MATRIX, context)
        out_rep = self.parameterAsFileOutput(parameters, self.OUTPUT_REPORT, context)

        matrix = json.loads(mat_str)
        results = calculate_ahp_weights(matrix)

        os.makedirs(os.path.dirname(os.path.abspath(out_rep)), exist_ok=True)
        with open(out_rep, "w", encoding="utf-8") as f:
            json.dump(results, f, indent=2)

        return {self.OUTPUT_REPORT: out_rep}


class WeightedOverlayAlgorithm(QgsProcessingAlgorithm):
    INPUT_RASTERS = "INPUT_RASTERS"
    WEIGHTS = "WEIGHTS"
    OUTPUT_SUITABILITY = "OUTPUT_SUITABILITY"

    def name(self):
        return "weighted_overlay"

    def displayName(self):
        return "05.03 Weighted linear combination"

    def group(self):
        return "05 · Spatial Statistics & Suitability"

    def groupId(self):
        return "05_spatial_stats"

    def shortHelpString(self):
        return "Multi-criteria Weighted Linear Combination (WLC) overlay: Suitability = sum(w_i * c_i)."

    def createInstance(self):
        return WeightedOverlayAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterMultipleLayers(self.INPUT_RASTERS, "Standardized Criteria Rasters", layerType=QgsProcessing.TypeRaster))
        self.addParameter(QgsProcessingParameterString(self.WEIGHTS, "Weights (comma-separated, e.g. '0.5, 0.3, 0.2')", defaultValue="0.5, 0.3, 0.2"))
        self.addParameter(QgsProcessingParameterRasterDestination(self.OUTPUT_SUITABILITY, "Output Composite Suitability Raster"))

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        layers = self.parameterAsLayerList(parameters, self.INPUT_RASTERS, context)
        weights_str = self.parameterAsString(parameters, self.WEIGHTS, context)
        out_dest = self.parameterAsOutputLayer(parameters, self.OUTPUT_SUITABILITY, context)

        weights = [float(w.strip()) for w in weights_str.split(",") if w.strip()]
        if len(layers) != len(weights):
            raise ValueError(f"Mismatch: {len(layers)} rasters provided but {len(weights)} weights specified.")

        criteria_weights = [(lyr.source(), w) for lyr, w in zip(layers, weights)]
        weighted_linear_combination(criteria_weights, out_dest)
        return {self.OUTPUT_SUITABILITY: out_dest}


class FuzzyMembershipAlgorithm(QgsProcessingAlgorithm):
    INPUT_RASTER = "INPUT_RASTER"
    FUNCTION_TYPE = "FUNCTION_TYPE"
    PARAM_A = "PARAM_A"
    PARAM_B = "PARAM_B"
    OUTPUT_RASTER = "OUTPUT_RASTER"
    FUNCTIONS = ["Linear", "Sigmoid", "Gaussian", "Trapezoidal"]

    def name(self):
        return "fuzzy_membership"

    def displayName(self):
        return "05.04 Fuzzy membership transform"

    def group(self):
        return "05 · Spatial Statistics & Suitability"

    def groupId(self):
        return "05_spatial_stats"

    def shortHelpString(self):
        return "Transform continuous criteria into fuzzy membership degrees [0.0, 1.0]."

    def createInstance(self):
        return FuzzyMembershipAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(self.INPUT_RASTER, "Input Criterion Raster"))
        self.addParameter(QgsProcessingParameterEnum(self.FUNCTION_TYPE, "Membership Function", options=self.FUNCTIONS, defaultValue=0))
        self.addParameter(QgsProcessingParameterNumber(self.PARAM_A, "Parameter A (min / inflection / mean)", type=QgsProcessingParameterNumber.Double, defaultValue=0.0))
        self.addParameter(QgsProcessingParameterNumber(self.PARAM_B, "Parameter B (max / slope / sigma)", type=QgsProcessingParameterNumber.Double, defaultValue=100.0))
        self.addParameter(QgsProcessingParameterRasterDestination(self.OUTPUT_RASTER, "Output Fuzzy Membership Raster [0-1]"))

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        layer = self.parameterAsRasterLayer(parameters, self.INPUT_RASTER, context)
        fn_idx = self.parameterAsEnum(parameters, self.FUNCTION_TYPE, context)
        a = self.parameterAsDouble(parameters, self.PARAM_A, context)
        b = self.parameterAsDouble(parameters, self.PARAM_B, context)
        out_dest = self.parameterAsOutputLayer(parameters, self.OUTPUT_RASTER, context)

        fn_map = {0: "linear", 1: "sigmoid", 2: "gaussian", 3: "trapezoidal"}
        fuzzy_membership(layer.source(), out_dest, function_type=fn_map.get(fn_idx, "linear"), a=a, b=b)
        return {self.OUTPUT_RASTER: out_dest}


class FuzzyOverlayAlgorithm(QgsProcessingAlgorithm):
    INPUT_RASTERS = "INPUT_RASTERS"
    OPERATOR = "OPERATOR"
    GAMMA = "GAMMA"
    OUTPUT_RASTER = "OUTPUT_RASTER"
    OPERATORS = ["Fuzzy Gamma", "Fuzzy AND (Min)", "Fuzzy OR (Max)", "Fuzzy Product", "Fuzzy Sum"]

    def name(self):
        return "fuzzy_overlay"

    def displayName(self):
        return "05.05 Fuzzy AND/OR/Gamma overlay"

    def group(self):
        return "05 · Spatial Statistics & Suitability"

    def groupId(self):
        return "05_spatial_stats"

    def shortHelpString(self):
        return "Combine multiple fuzzy membership rasters using Fuzzy AND, OR, Product, Sum, or Gamma operators."

    def createInstance(self):
        return FuzzyOverlayAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterMultipleLayers(self.INPUT_RASTERS, "Fuzzy Membership Rasters", layerType=QgsProcessing.TypeRaster))
        self.addParameter(QgsProcessingParameterEnum(self.OPERATOR, "Fuzzy Operator", options=self.OPERATORS, defaultValue=0))
        self.addParameter(QgsProcessingParameterNumber(self.GAMMA, "Gamma Parameter (for Fuzzy Gamma)", type=QgsProcessingParameterNumber.Double, defaultValue=0.9, minValue=0.0, maxValue=1.0))
        self.addParameter(QgsProcessingParameterRasterDestination(self.OUTPUT_RASTER, "Output Fuzzy Overlay Raster"))

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        layers = self.parameterAsLayerList(parameters, self.INPUT_RASTERS, context)
        op_idx = self.parameterAsEnum(parameters, self.OPERATOR, context)
        gamma = self.parameterAsDouble(parameters, self.GAMMA, context)
        out_dest = self.parameterAsOutputLayer(parameters, self.OUTPUT_RASTER, context)

        op_map = {0: "gamma", 1: "and", 2: "or", 3: "product", 4: "sum"}
        paths = [lyr.source() for lyr in layers if lyr.isValid()]
        fuzzy_overlay(paths, out_dest, operator=op_map.get(op_idx, "gamma"), gamma=gamma)
        return {self.OUTPUT_RASTER: out_dest}


class SuitabilitySensitivityAlgorithm(QgsProcessingAlgorithm):
    INPUT_RASTERS = "INPUT_RASTERS"
    BASE_WEIGHTS = "BASE_WEIGHTS"
    OUTPUT_REPORT = "OUTPUT_REPORT"

    def name(self):
        return "suitability_sensitivity"

    def displayName(self):
        return "05.06 Weight sensitivity analysis"

    def group(self):
        return "05 · Spatial Statistics & Suitability"

    def groupId(self):
        return "05_spatial_stats"

    def shortHelpString(self):
        return "Evaluate model sensitivity by systematically perturbing criteria weights and measuring result stability."

    def createInstance(self):
        return SuitabilitySensitivityAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterMultipleLayers(self.INPUT_RASTERS, "Criteria Rasters", layerType=QgsProcessing.TypeRaster))
        self.addParameter(QgsProcessingParameterString(self.BASE_WEIGHTS, "Baseline Weights (comma-separated)", defaultValue="0.4, 0.3, 0.3"))
        self.addParameter(QgsProcessingParameterFileDestination(self.OUTPUT_REPORT, "Output Sensitivity Report JSON", fileFilter="JSON (*.json)"))

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        layers = self.parameterAsLayerList(parameters, self.INPUT_RASTERS, context)
        w_str = self.parameterAsString(parameters, self.BASE_WEIGHTS, context)
        out_rep = self.parameterAsFileOutput(parameters, self.OUTPUT_REPORT, context)

        weights = [float(x.strip()) for x in w_str.split(",") if x.strip()]
        paths = [lyr.source() for lyr in layers if lyr.isValid()]

        out_dir = os.path.dirname(os.path.abspath(out_rep))
        rep = suitability_sensitivity(paths, weights, out_dir=out_dir)

        with open(out_rep, "w", encoding="utf-8") as f:
            json.dump(rep, f, indent=2)

        return {self.OUTPUT_REPORT: out_rep}


class ZonalDistributionAlgorithm(QgsProcessingAlgorithm):
    INPUT_RASTER = "INPUT_RASTER"
    INPUT_ZONES = "INPUT_ZONES"
    ZONE_ID_FIELD = "ZONE_ID_FIELD"
    OUTPUT_TABLE = "OUTPUT_TABLE"

    def name(self):
        return "zonal_distribution"

    def displayName(self):
        return "05.07 Advanced zonal distributions"

    def group(self):
        return "05 · Spatial Statistics & Suitability"

    def groupId(self):
        return "05_spatial_stats"

    def shortHelpString(self):
        return "Calculate advanced zonal statistics across polygons: mean, standard deviation, median, and quartiles."

    def createInstance(self):
        return ZonalDistributionAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(self.INPUT_RASTER, "Input Continuous Raster"))
        self.addParameter(QgsProcessingParameterFeatureSource(self.INPUT_ZONES, "Zone Polygons", [QgsProcessing.TypeVectorPolygon]))
        self.addParameter(QgsProcessingParameterString(self.ZONE_ID_FIELD, "Zone ID Field Name", defaultValue="id"))
        self.addParameter(QgsProcessingParameterFileDestination(self.OUTPUT_TABLE, "Output Summary CSV Table", fileFilter="CSV (*.csv)"))

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        r_layer = self.parameterAsRasterLayer(parameters, self.INPUT_RASTER, context)
        v_source = self.parameterAsSource(parameters, self.INPUT_ZONES, context)
        field_name = self.parameterAsString(parameters, self.ZONE_ID_FIELD, context)
        out_table = self.parameterAsFileOutput(parameters, self.OUTPUT_TABLE, context)

        zonal_distribution(r_layer.source(), v_source.sourceName(), field_name, out_table)
        return {self.OUTPUT_TABLE: out_table}


class PointKdeAlgorithm(QgsProcessingAlgorithm):
    INPUT_POINTS = "INPUT_POINTS"
    BANDWIDTH = "BANDWIDTH"
    CELL_SIZE = "CELL_SIZE"
    OUTPUT_DENSITY = "OUTPUT_DENSITY"

    def name(self):
        return "point_kde"

    def displayName(self):
        return "05.08 Kernel density estimate"

    def group(self):
        return "05 · Spatial Statistics & Suitability"

    def groupId(self):
        return "05_spatial_stats"

    def shortHelpString(self):
        return "Compute 2D Kernel Density Estimation (KDE) surface from a point layer using Silverman's biweight kernel."

    def createInstance(self):
        return PointKdeAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFeatureSource(self.INPUT_POINTS, "Input Points", [QgsProcessing.TypeVectorPoint]))
        self.addParameter(QgsProcessingParameterNumber(self.BANDWIDTH, "Bandwidth Radius (meters / map units)", defaultValue=1000.0, minValue=10.0))
        self.addParameter(QgsProcessingParameterNumber(self.CELL_SIZE, "Output Cell Size", defaultValue=50.0, minValue=1.0))
        self.addParameter(QgsProcessingParameterRasterDestination(self.OUTPUT_DENSITY, "Output Kernel Density Raster"))

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        pts_source = self.parameterAsSource(parameters, self.INPUT_POINTS, context)
        bw = self.parameterAsDouble(parameters, self.BANDWIDTH, context)
        cs = self.parameterAsDouble(parameters, self.CELL_SIZE, context)
        out_dest = self.parameterAsOutputLayer(parameters, self.OUTPUT_DENSITY, context)

        pts = []
        for f in pts_source.getFeatures():
            pt = f.geometry().asPoint()
            pts.append((pt.x(), pt.y(), 1.0))

        point_kde(pts, out_dest, cell_size=cs, bandwidth=bw, crs_wkt=pts_source.sourceCrs().toWkt())
        return {self.OUTPUT_DENSITY: out_dest}


class PointIdwAlgorithm(QgsProcessingAlgorithm):
    INPUT_POINTS = "INPUT_POINTS"
    VALUE_FIELD = "VALUE_FIELD"
    POWER = "POWER"
    CELL_SIZE = "CELL_SIZE"
    OUTPUT_RASTER = "OUTPUT_RASTER"

    def name(self):
        return "point_idw"

    def displayName(self):
        return "05.09 Inverse-distance weighted interpolation"

    def group(self):
        return "05 · Spatial Statistics & Suitability"

    def groupId(self):
        return "05_spatial_stats"

    def shortHelpString(self):
        return "Interpolate sample points into a continuous raster surface using Inverse Distance Weighting (IDW)."

    def createInstance(self):
        return PointIdwAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFeatureSource(self.INPUT_POINTS, "Input Points", [QgsProcessing.TypeVectorPoint]))
        self.addParameter(QgsProcessingParameterString(self.VALUE_FIELD, "Attribute Field to Interpolate", defaultValue="val"))
        self.addParameter(QgsProcessingParameterNumber(self.POWER, "Distance Weighting Power (p)", type=QgsProcessingParameterNumber.Double, defaultValue=2.0))
        self.addParameter(QgsProcessingParameterNumber(self.CELL_SIZE, "Output Cell Size", defaultValue=50.0, minValue=1.0))
        self.addParameter(QgsProcessingParameterRasterDestination(self.OUTPUT_RASTER, "Output Interpolated Raster"))

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        pts_source = self.parameterAsSource(parameters, self.INPUT_POINTS, context)
        field_name = self.parameterAsString(parameters, self.VALUE_FIELD, context)
        p = self.parameterAsDouble(parameters, self.POWER, context)
        cs = self.parameterAsDouble(parameters, self.CELL_SIZE, context)
        out_dest = self.parameterAsOutputLayer(parameters, self.OUTPUT_RASTER, context)

        pts = []
        for f in pts_source.getFeatures():
            val = float(f.attribute(field_name) or 0.0)
            pt = f.geometry().asPoint()
            pts.append((pt.x(), pt.y(), val))

        point_idw(pts, out_dest, cell_size=cs, power=p, crs_wkt=pts_source.sourceCrs().toWkt())
        return {self.OUTPUT_RASTER: out_dest}


class MoranGlobalAlgorithm(QgsProcessingAlgorithm):
    INPUT_LAYER = "INPUT_LAYER"
    VALUE_FIELD = "VALUE_FIELD"
    OUTPUT_REPORT = "OUTPUT_REPORT"

    def name(self):
        return "moran_global"

    def displayName(self):
        return "05.10 Global Moran's I"

    def group(self):
        return "05 · Spatial Statistics & Suitability"

    def groupId(self):
        return "05_spatial_stats"

    def shortHelpString(self):
        return "Calculate Global Moran's I spatial autocorrelation statistic with Monte Carlo permutation p-value."

    def createInstance(self):
        return MoranGlobalAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFeatureSource(self.INPUT_LAYER, "Input Vector Layer", [QgsProcessing.TypeVectorPoint, QgsProcessing.TypeVectorPolygon]))
        self.addParameter(QgsProcessingParameterString(self.VALUE_FIELD, "Numeric Attribute Field", defaultValue="val"))
        self.addParameter(QgsProcessingParameterFileDestination(self.OUTPUT_REPORT, "Output Moran's I JSON Report", fileFilter="JSON (*.json)"))

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        layer = self.parameterAsSource(parameters, self.INPUT_LAYER, context)
        field_name = self.parameterAsString(parameters, self.VALUE_FIELD, context)
        out_rep = self.parameterAsFileOutput(parameters, self.OUTPUT_REPORT, context)

        coords = []
        vals = []
        for f in layer.getFeatures():
            pt = f.geometry().centroid().asPoint()
            val = float(f.attribute(field_name) or 0.0)
            coords.append((pt.x(), pt.y()))
            vals.append(val)

        res = moran_global(coords, vals)
        os.makedirs(os.path.dirname(os.path.abspath(out_rep)), exist_ok=True)
        with open(out_rep, "w", encoding="utf-8") as f:
            json.dump(res, f, indent=2)

        return {self.OUTPUT_REPORT: out_rep}


class MoranLocalAlgorithm(QgsProcessingAlgorithm):
    INPUT_LAYER = "INPUT_LAYER"
    VALUE_FIELD = "VALUE_FIELD"
    OUTPUT_CLUSTERS = "OUTPUT_CLUSTERS"

    def name(self):
        return "moran_local"

    def displayName(self):
        return "05.11 Local Moran's I / LISA"

    def group(self):
        return "05 · Spatial Statistics & Suitability"

    def groupId(self):
        return "05_spatial_stats"

    def shortHelpString(self):
        return "Compute Local Moran's I (LISA) identifying High-High, Low-Low, High-Low, and Low-High spatial cluster features."

    def createInstance(self):
        return MoranLocalAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFeatureSource(self.INPUT_LAYER, "Input Features", [QgsProcessing.TypeVectorPoint, QgsProcessing.TypeVectorPolygon]))
        self.addParameter(QgsProcessingParameterString(self.VALUE_FIELD, "Attribute Field", defaultValue="val"))
        self.addParameter(QgsProcessingParameterVectorDestination(self.OUTPUT_CLUSTERS, "Output LISA Clusters Layer"))

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        layer = self.parameterAsSource(parameters, self.INPUT_LAYER, context)
        field_name = self.parameterAsString(parameters, self.VALUE_FIELD, context)
        out_dest = self.parameterAsOutputLayer(parameters, self.OUTPUT_CLUSTERS, context)

        coords = []
        vals = []
        features = list(layer.getFeatures())
        for f in features:
            pt = f.geometry().centroid().asPoint()
            v = float(f.attribute(field_name) or 0.0)
            coords.append((pt.x(), pt.y()))
            vals.append(v)

        lisa_results = moran_local(coords, vals)

        vl = QgsVectorLayer("Point?crs=" + layer.sourceCrs().authid(), "lisa_clusters", "memory")
        pr = vl.dataProvider()
        pr.addAttributes(list(layer.fields()) + [
            QgsField("local_i", QVariant.Double),
            QgsField("spatial_lag", QVariant.Double),
            QgsField("cluster_type", QVariant.String)
        ])
        vl.updateFields()

        out_feats = []
        for i, res in enumerate(lisa_results):
            orig_f = features[i]
            nf = QgsFeature(vl.fields())
            nf.setGeometry(orig_f.geometry())
            for idx in range(len(layer.fields())):
                nf.setAttribute(idx, orig_f.attribute(idx))
            nf.setAttribute("local_i", res["local_i"])
            nf.setAttribute("spatial_lag", res["spatial_lag"])
            nf.setAttribute("cluster_type", res["cluster_type"])
            out_feats.append(nf)

        pr.addFeatures(out_feats)
        QgsVectorFileWriter.writeAsVectorFormatV3(vl, out_dest, context.transformContext(), QgsVectorFileWriter.SaveVectorOptions())
        return {self.OUTPUT_CLUSTERS: out_dest}


class GiStarAlgorithm(QgsProcessingAlgorithm):
    INPUT_LAYER = "INPUT_LAYER"
    VALUE_FIELD = "VALUE_FIELD"
    DISTANCE_BAND = "DISTANCE_BAND"
    OUTPUT_HOTSPOTS = "OUTPUT_HOTSPOTS"

    def name(self):
        return "gi_star"

    def displayName(self):
        return "05.12 Getis–Ord Gi* hotspot"

    def group(self):
        return "05 · Spatial Statistics & Suitability"

    def groupId(self):
        return "05_spatial_stats"

    def shortHelpString(self):
        return "Identify statistically significant spatial clusters of high values (hotspots) and low values (coldspots) using Getis-Ord Gi*."

    def createInstance(self):
        return GiStarAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFeatureSource(self.INPUT_LAYER, "Input Vector Layer", [QgsProcessing.TypeVectorPoint, QgsProcessing.TypeVectorPolygon]))
        self.addParameter(QgsProcessingParameterString(self.VALUE_FIELD, "Attribute Field", defaultValue="val"))
        self.addParameter(QgsProcessingParameterNumber(self.DISTANCE_BAND, "Distance Threshold (meters)", defaultValue=5000.0, minValue=10.0))
        self.addParameter(QgsProcessingParameterVectorDestination(self.OUTPUT_HOTSPOTS, "Output Gi* Hotspots Layer"))

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        layer = self.parameterAsSource(parameters, self.INPUT_LAYER, context)
        field_name = self.parameterAsString(parameters, self.VALUE_FIELD, context)
        d_band = self.parameterAsDouble(parameters, self.DISTANCE_BAND, context)
        out_dest = self.parameterAsOutputLayer(parameters, self.OUTPUT_HOTSPOTS, context)

        coords = []
        vals = []
        features = list(layer.getFeatures())
        for f in features:
            pt = f.geometry().centroid().asPoint()
            v = float(f.attribute(field_name) or 0.0)
            coords.append((pt.x(), pt.y()))
            vals.append(v)

        gi_results = getis_ord_gi_star(coords, vals, distance_threshold=d_band)

        vl = QgsVectorLayer("Point?crs=" + layer.sourceCrs().authid(), "gi_hotspots", "memory")
        pr = vl.dataProvider()
        pr.addAttributes(list(layer.fields()) + [
            QgsField("gi_star_z", QVariant.Double),
            QgsField("classification", QVariant.String)
        ])
        vl.updateFields()

        out_feats = []
        for i, res in enumerate(gi_results):
            orig_f = features[i]
            nf = QgsFeature(vl.fields())
            nf.setGeometry(orig_f.geometry())
            for idx in range(len(layer.fields())):
                nf.setAttribute(idx, orig_f.attribute(idx))
            nf.setAttribute("gi_star_z", res["gi_star_z"])
            nf.setAttribute("classification", res["classification"])
            out_feats.append(nf)

        pr.addFeatures(out_feats)
        QgsVectorFileWriter.writeAsVectorFormatV3(vl, out_dest, context.transformContext(), QgsVectorFileWriter.SaveVectorOptions())
        return {self.OUTPUT_HOTSPOTS: out_dest}


class NearestNeighborStatsAlgorithm(QgsProcessingAlgorithm):
    INPUT_POINTS = "INPUT_POINTS"
    OUTPUT_REPORT = "OUTPUT_REPORT"

    def name(self):
        return "nearest_neighbor_stats"

    def displayName(self):
        return "05.13 Point-pattern nearest-neighbor statistics"

    def group(self):
        return "05 · Spatial Statistics & Suitability"

    def groupId(self):
        return "05_spatial_stats"

    def shortHelpString(self):
        return "Calculate Clark-Evans Nearest Neighbor Index (R) and test for Complete Spatial Randomness (CSR)."

    def createInstance(self):
        return NearestNeighborStatsAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFeatureSource(self.INPUT_POINTS, "Input Points", [QgsProcessing.TypeVectorPoint]))
        self.addParameter(QgsProcessingParameterFileDestination(self.OUTPUT_REPORT, "Output Statistics JSON Report", fileFilter="JSON (*.json)"))

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        layer = self.parameterAsSource(parameters, self.INPUT_POINTS, context)
        out_rep = self.parameterAsFileOutput(parameters, self.OUTPUT_REPORT, context)

        coords = [f.geometry().asPoint() for f in layer.getFeatures()]
        pts = [(pt.x(), pt.y()) for pt in coords]

        rep = nearest_neighbor_analysis(pts)
        os.makedirs(os.path.dirname(os.path.abspath(out_rep)), exist_ok=True)
        with open(out_rep, "w", encoding="utf-8") as f:
            json.dump(rep, f, indent=2)

        return {self.OUTPUT_REPORT: out_rep}


class BufferExposureSummaryAlgorithm(QgsProcessingAlgorithm):
    INPUT_HAZARDS = "INPUT_HAZARDS"
    INPUT_EXPOSURE = "INPUT_EXPOSURE"
    BUFFER_DISTANCES = "BUFFER_DISTANCES"
    OUTPUT_TABLE = "OUTPUT_TABLE"

    def name(self):
        return "buffer_exposure_summary"

    def displayName(self):
        return "05.14 Buffer exposure statistics"

    def group(self):
        return "05 · Spatial Statistics & Suitability"

    def groupId(self):
        return "05_spatial_stats"

    def shortHelpString(self):
        return "Summarize asset exposure counts and values across concentric distance bands around hazard sources."

    def createInstance(self):
        return BufferExposureSummaryAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFeatureSource(self.INPUT_HAZARDS, "Hazard Features", [QgsProcessing.TypeVectorPoint, QgsProcessing.TypeVectorPolygon]))
        self.addParameter(QgsProcessingParameterFeatureSource(self.INPUT_EXPOSURE, "Exposure Assets / Points", [QgsProcessing.TypeVectorPoint]))
        self.addParameter(QgsProcessingParameterString(self.BUFFER_DISTANCES, "Concentric Radii (meters, comma-separated)", defaultValue="500, 1000, 2500, 5000"))
        self.addParameter(QgsProcessingParameterFileDestination(self.OUTPUT_TABLE, "Output Exposure CSV Table", fileFilter="CSV (*.csv)"))

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        hz_source = self.parameterAsSource(parameters, self.INPUT_HAZARDS, context)
        exp_source = self.parameterAsSource(parameters, self.INPUT_EXPOSURE, context)
        radii_str = self.parameterAsString(parameters, self.BUFFER_DISTANCES, context)
        out_table = self.parameterAsFileOutput(parameters, self.OUTPUT_TABLE, context)

        radii = [float(r.strip()) for r in radii_str.split(",") if r.strip()]
        hz_coords = [(f.geometry().centroid().asPoint().x(), f.geometry().centroid().asPoint().y()) for f in hz_source.getFeatures()]
        exp_pts = [(f.geometry().asPoint().x(), f.geometry().asPoint().y(), 1.0) for f in exp_source.getFeatures()]

        summary = buffer_exposure_summary(hz_coords, exp_pts, radii)

        os.makedirs(os.path.dirname(os.path.abspath(out_table)), exist_ok=True)
        with open(out_table, "w", encoding="utf-8") as f:
            f.write("distance_m,cumulative_count,cumulative_exposure_total,ring_count,ring_exposure_total\n")
            for r in summary:
                f.write(f"{r['distance_m']},{r['cumulative_count']},{r['cumulative_exposure_total']},{r['ring_count']},{r['ring_exposure_total']}\n")

        return {self.OUTPUT_TABLE: out_table}


class SpatialModelReportAlgorithm(QgsProcessingAlgorithm):
    INPUT_MODEL_RASTER = "INPUT_MODEL_RASTER"
    OUTPUT_REPORT = "OUTPUT_REPORT"

    def name(self):
        return "spatial_model_report"

    def displayName(self):
        return "05.15 Suitability/statistical QA report"

    def group(self):
        return "05 · Spatial Statistics & Suitability"

    def groupId(self):
        return "05_spatial_stats"

    def shortHelpString(self):
        return "Generate a comprehensive QA report for spatial suitability models and statistical rasters."

    def createInstance(self):
        return SpatialModelReportAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(self.INPUT_MODEL_RASTER, "Suitability Model Raster"))
        self.addParameter(QgsProcessingParameterFileDestination(self.OUTPUT_REPORT, "Output Model QA JSON", fileFilter="JSON (*.json)"))

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        layer = self.parameterAsRasterLayer(parameters, self.INPUT_MODEL_RASTER, context)
        out_rep = self.parameterAsFileOutput(parameters, self.OUTPUT_REPORT, context)

        from ...core.raster_io import open_raster_dataset
        ds = open_raster_dataset(layer.source())
        arr = ds.GetRasterBand(1).ReadAsArray().astype(np.float32)
        nd = ds.GetRasterBand(1).GetNoDataValue()
        valid = (arr != nd) & ~np.isnan(arr)
        vals = arr[valid]

        rep = {
            "model_raster": layer.source(),
            "valid_pixel_count": int(vals.size),
            "suitability_mean": float(np.mean(vals)) if vals.size else None,
            "suitability_std": float(np.std(vals)) if vals.size else None,
            "min_score": float(np.min(vals)) if vals.size else None,
            "max_score": float(np.max(vals)) if vals.size else None,
            "high_suitability_fraction_pct": float(np.sum(vals >= 0.8) / (vals.size or 1)) * 100.0
        }

        os.makedirs(os.path.dirname(os.path.abspath(out_rep)), exist_ok=True)
        with open(out_rep, "w", encoding="utf-8") as f:
            json.dump(rep, f, indent=2)

        ds = None
        return {self.OUTPUT_REPORT: out_rep}


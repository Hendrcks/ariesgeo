"""
Processing algorithm: Geocode Place Name.
"""

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterString,
    QgsProcessingParameterNumber,
    QgsProcessingParameterEnum,
    QgsProcessingOutputVectorLayer,
    QgsProcessingContext,
    QgsProcessingFeedback,
)
from ...place_finder.service import PlaceFinderService
from ...place_finder.layer_exporter import LayerExporter
from ...place_finder.providers.nominatim import NominatimProvider
from ...place_finder.providers.photon import PhotonProvider
from ...core.network import NetworkClient

class GeocodePlaceAlgorithm(QgsProcessingAlgorithm):
    INPUT_QUERY = "INPUT_QUERY"
    INPUT_PROVIDER = "INPUT_PROVIDER"
    INPUT_LIMIT = "INPUT_LIMIT"
    OUTPUT = "OUTPUT"

    PROVIDERS = ["Photon (Komoot)", "OpenStreetMap (Nominatim)"]

    def name(self):
        return "geocode_place"

    def displayName(self):
        return "Geocode Place Name"

    def group(self):
        return "Place Finder"

    def groupId(self):
        return "place_finder"

    def shortHelpString(self):
        return "Search for a location by name using online or offline geocoders and return a vector point layer."

    def createInstance(self):
        return GeocodePlaceAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterString(
                self.INPUT_QUERY,
                "Place Name / Search Query",
                defaultValue="Paris, France"
            )
        )
        self.addParameter(
            QgsProcessingParameterEnum(
                self.INPUT_PROVIDER,
                "Geocoding Provider",
                options=self.PROVIDERS,
                defaultValue=0
            )
        )
        self.addParameter(
            QgsProcessingParameterNumber(
                self.INPUT_LIMIT,
                "Maximum Results",
                type=QgsProcessingParameterNumber.Integer,
                defaultValue=5,
                minValue=1,
                maxValue=50
            )
        )
        self.addOutput(
            QgsProcessingOutputVectorLayer(
                self.OUTPUT,
                "Geocoded Locations"
            )
        )

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        query = self.parameterAsString(parameters, self.INPUT_QUERY, context)
        provider_idx = self.parameterAsEnum(parameters, self.INPUT_PROVIDER, context)
        limit = self.parameterAsInt(parameters, self.INPUT_LIMIT, context)

        provider_name = self.PROVIDERS[provider_idx]
        provider = PhotonProvider() if "Photon" in provider_name else NominatimProvider()

        feedback.pushInfo(f"Querying {provider.name} for: '{query}'...")

        url = provider.build_forward_url(query=query, limit=limit)
        net = NetworkClient()
        raw_data = net.get_json_sync(url)
        results = provider.parse_forward_response(raw_data)

        feedback.pushInfo(f"Found {len(results)} matching location(s).")
        layer = LayerExporter.create_point_layer(results, layer_name=f"Geocode: {query}", add_to_project=False)
        context.temporaryFolder()

        return {self.OUTPUT: layer}

"""
Processing algorithm: Build Virtual Mosaic (VRT).
"""

from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterMultipleLayers,
    QgsProcessingParameterFileDestination,
    QgsProcessingParameterEnum,
    QgsProcessingParameterNumber,
    QgsProcessingParameterCrs,
    QgsProcessingOutputRasterLayer,
    QgsProcessingContext,
    QgsProcessingFeedback,
)
from ...raster.mosaic import RasterMosaicker

class BuildVrtMosaicAlgorithm(QgsProcessingAlgorithm):
    INPUT_RASTERS = "INPUT_RASTERS"
    OUTPUT_VRT = "OUTPUT_VRT"
    TARGET_CRS = "TARGET_CRS"
    RESAMPLING = "RESAMPLING"
    SRC_NODATA = "SRC_NODATA"

    RESAMPLE_OPTIONS = ["nearest", "bilinear", "cubic", "cubicspline", "lanczos", "mode", "average"]

    def name(self):
        return "build_vrt_mosaic"

    def displayName(self):
        return "Build Virtual Mosaic (VRT)"

    def group(self):
        return "Mosaic & GapFill"

    def groupId(self):
        return "raster"

    def shortHelpString(self):
        return "Build a fast GDAL Virtual Raster (VRT) mosaic without duplicating pixel storage on disk."

    def createInstance(self):
        return BuildVrtMosaicAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterMultipleLayers(
                self.INPUT_RASTERS,
                "Input Rasters",
                layerType=getattr(QgsProcessing, "TypeRaster", None) or getattr(getattr(QgsProcessing, "SourceType", None), "TypeRaster", 1)
            )
        )
        self.addParameter(
            QgsProcessingParameterCrs(
                self.TARGET_CRS,
                "Target CRS (optional)",
                optional=True
            )
        )
        self.addParameter(
            QgsProcessingParameterEnum(
                self.RESAMPLING,
                "Resampling Method",
                options=self.RESAMPLE_OPTIONS,
                defaultValue=1
            )
        )
        self.addParameter(
            QgsProcessingParameterNumber(
                self.SRC_NODATA,
                "Source NoData Value",
                type=QgsProcessingParameterNumber.Double,
                optional=True
            )
        )
        self.addParameter(
            QgsProcessingParameterFileDestination(
                self.OUTPUT_VRT,
                "Output Virtual Raster (*.vrt)",
                fileFilter="GDAL Virtual Raster (*.vrt)"
            )
        )

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        layers = self.parameterAsLayerList(parameters, self.INPUT_RASTERS, context)
        out_vrt = self.parameterAsFileOutput(parameters, self.OUTPUT_VRT, context)
        crs = self.parameterAsCrs(parameters, self.TARGET_CRS, context)
        resample_idx = self.parameterAsEnum(parameters, self.RESAMPLING, context)
        src_nodata = self.parameterAsDouble(parameters, self.SRC_NODATA, context) if self.SRC_NODATA in parameters else None

        paths = [layer.source() for layer in layers if hasattr(layer, "source")]
        target_crs_str = crs.authid() if crs.isValid() else None
        resampling = self.RESAMPLE_OPTIONS[resample_idx]

        feedback.pushInfo(f"Creating VRT mosaic from {len(paths)} inputs...")
        RasterMosaicker.build_virtual_mosaic(
            input_paths=paths,
            output_vrt_path=out_vrt,
            target_crs=target_crs_str,
            resampling=resampling,
            src_nodata=src_nodata
        )

        return {self.OUTPUT_VRT: out_vrt}

"""
Processing algorithm: Delineate Watershed Basin.
"""

import os
import tempfile
from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterNumber,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterRasterDestination,
    QgsProcessingParameterVectorDestination,
    QgsProcessingOutputNumber,
    QgsProcessingOutputVectorLayer,
    QgsProcessingContext,
    QgsProcessingFeedback,
)
from ...terrain_hydrology.watersheds import WatershedDelineator

class DelineateWatershedAlgorithm(QgsProcessingAlgorithm):
    INPUT_FDIR = "INPUT_FDIR"
    OUTLET_X = "OUTLET_X"
    OUTLET_Y = "OUTLET_Y"
    INPUT_ACC = "INPUT_ACC"
    SNAP_OUTLET = "SNAP_OUTLET"
    SNAP_RADIUS = "SNAP_RADIUS"

    OUTPUT_RASTER = "OUTPUT_RASTER"
    OUTPUT_VECTOR = "OUTPUT_VECTOR"
    AREA_KM2 = "AREA_KM2"
    CELL_COUNT = "CELL_COUNT"

    def name(self):
        return "delineate_watershed"

    def displayName(self):
        return "Delineate Catchment / Watershed Basin"

    def group(self):
        return "Terrain & Hydrology Toolkit"

    def groupId(self):
        return "terrain_hydrology"

    def shortHelpString(self):
        return "Traces upstream contributing drainage area from a pour point / outlet coordinate using D8 flow direction, generating basin boundary polygons and catchment area statistics."

    def createInstance(self):
        return DelineateWatershedAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterRasterLayer(
                self.INPUT_FDIR,
                "Input D8 Flow Direction Raster"
            )
        )
        self.addParameter(
            QgsProcessingParameterNumber(
                self.OUTLET_X,
                "Outlet / Pour Point X (Map Coordinate)",
                type=QgsProcessingParameterNumber.Double
            )
        )
        self.addParameter(
            QgsProcessingParameterNumber(
                self.OUTLET_Y,
                "Outlet / Pour Point Y (Map Coordinate)",
                type=QgsProcessingParameterNumber.Double
            )
        )
        self.addParameter(
            QgsProcessingParameterRasterLayer(
                self.INPUT_ACC,
                "Flow Accumulation Raster (Required for Snapping)",
                optional=True
            )
        )
        self.addParameter(
            QgsProcessingParameterBoolean(
                self.SNAP_OUTLET,
                "Snap Pour Point to High Accumulation Channel",
                defaultValue=True
            )
        )
        self.addParameter(
            QgsProcessingParameterNumber(
                self.SNAP_RADIUS,
                "Snap Search Radius (Pixels)",
                type=QgsProcessingParameterNumber.Integer,
                defaultValue=10,
                minValue=1,
                maxValue=100
            )
        )
        self.addParameter(
            QgsProcessingParameterRasterDestination(
                self.OUTPUT_RASTER,
                "Output Watershed Raster Mask",
                optional=True
            )
        )
        self.addParameter(
            QgsProcessingParameterVectorDestination(
                self.OUTPUT_VECTOR,
                "Output Watershed Basin Polygon",
                type=getattr(QgsProcessing, "TypeVectorPolygon", None) or getattr(getattr(QgsProcessing, "SourceType", None), "TypeVectorPolygon", -1)
            )
        )
        self.addOutput(
            QgsProcessingOutputNumber(
                self.AREA_KM2,
                "Catchment Area (sq km)"
            )
        )
        self.addOutput(
            QgsProcessingOutputNumber(
                self.CELL_COUNT,
                "Catchment Contributing Cells"
            )
        )

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        fdir_layer = self.parameterAsRasterLayer(parameters, self.INPUT_FDIR, context)
        if not fdir_layer or not fdir_layer.isValid():
            raise ValueError("Invalid D8 Flow Direction layer.")

        fdir_path = fdir_layer.source()
        ox = self.parameterAsDouble(parameters, self.OUTLET_X, context)
        oy = self.parameterAsDouble(parameters, self.OUTLET_Y, context)
        snap = self.parameterAsBoolean(parameters, self.SNAP_OUTLET, context)
        snap_rad = self.parameterAsInt(parameters, self.SNAP_RADIUS, context)
        acc_layer = self.parameterAsRasterLayer(parameters, self.INPUT_ACC, context)
        out_raster = self.parameterAsOutputLayer(parameters, self.OUTPUT_RASTER, context)
        out_vector = self.parameterAsOutputLayer(parameters, self.OUTPUT_VECTOR, context)

        # Snap outlet if requested and acc provided
        if snap and acc_layer and acc_layer.isValid():
            feedback.pushInfo(f"Snapping outlet ({ox:.4f}, {oy:.4f}) to highest accumulation within {snap_rad}px radius...")
            sx, sy, r, c = WatershedDelineator.snap_outlet_point(
                acc_path=acc_layer.source(),
                outlet_x=ox,
                outlet_y=oy,
                snap_distance_pixels=snap_rad
            )
            feedback.pushInfo(f"Snapped outlet to: ({sx:.4f}, {sy:.4f}) at row={r}, col={c}")
        else:
            # Direct coordinate to row/col from fdir
            from osgeo import gdal
            ds = gdal.Open(fdir_path, gdal.GA_ReadOnly)
            gt = ds.GetGeoTransform()
            ds = None
            c = int((ox - gt[0]) / gt[1])
            r = int((oy - gt[3]) / gt[5])
            feedback.pushInfo(f"Using unsnapped outlet at row={r}, col={c}")

        # Destination raster
        temp_raster = None
        if out_raster:
            target_raster = out_raster
        else:
            fd, temp_raster = tempfile.mkstemp(suffix="_watershed.tif")
            os.close(fd)
            target_raster = temp_raster

        feedback.pushInfo("Tracing upstream flow pathways with BFS...")
        res = WatershedDelineator.delineate_watershed(
            fdir_path=fdir_path,
            outlet_row=r,
            outlet_col=c,
            output_raster_path=target_raster,
            output_vector_path=out_vector
        )

        area_km2 = res.get("area_km2", 0.0)
        cell_count = res.get("cell_count", 0)

        feedback.pushInfo(f"Watershed basin delineated: {area_km2:.3f} km² ({cell_count} cells).")

        if temp_raster and os.path.exists(temp_raster):
            try:
                os.remove(temp_raster)
            except Exception as e:
                feedback.pushDebugInfo(f"Could not remove temp raster: {e}")

        results = {
            self.OUTPUT_VECTOR: out_vector,
            self.AREA_KM2: area_km2,
            self.CELL_COUNT: cell_count,
        }
        if out_raster:
            results[self.OUTPUT_RASTER] = out_raster

        return results

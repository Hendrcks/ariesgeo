"""
Processing algorithm: AriesGapfill Multi-Donor Smart Composite (Method D).
"""

from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterMultipleLayers,
    QgsProcessingParameterRasterDestination,
    QgsProcessingParameterBoolean,
    QgsProcessingOutputRasterLayer,
    QgsProcessingContext,
    QgsProcessingFeedback,
)
from ...gapfill.models import GapFillConfig, GapFillMethod, MethodParameters, DonorSpec
from ...gapfill.engine import AriesGapFillEngine


class GapfillMultiDonorAlgorithm(QgsProcessingAlgorithm):
    INPUT_TARGET = "INPUT_TARGET"
    INPUT_DONORS = "INPUT_DONORS"

    OUTPUT_FILLED = "OUTPUT_FILLED"
    OUTPUT_PROVENANCE = "OUTPUT_PROVENANCE"
    OUTPUT_CONFIDENCE = "OUTPUT_CONFIDENCE"
    OUTPUT_REMAINING = "OUTPUT_REMAINING"

    def name(self):
        return "gapfill_multidonor"

    def displayName(self):
        return "AriesGapfill: Multi-Donor Smart Composite"

    def group(self):
        return "AriesGapfill"

    def groupId(self):
        return "gapfill"

    def shortHelpString(self):
        return "Evaluates, scores, and ranks a stack of candidate donor scenes, performing pixel-by-pixel optimal donor selection to maximize spatial and radiometric completeness."

    def createInstance(self):
        return GapfillMultiDonorAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterRasterLayer(
                self.INPUT_TARGET,
                "Input Target Raster (SLC-off)"
            )
        )
        self.addParameter(
            QgsProcessingParameterMultipleLayers(
                self.INPUT_DONORS,
                "Input Candidate Donor Rasters",
                layerType=getattr(QgsProcessing, "TypeRaster", None) or getattr(getattr(QgsProcessing, "SourceType", None), "TypeRaster", 1)
            )
        )
        self.addParameter(
            QgsProcessingParameterRasterDestination(
                self.OUTPUT_FILLED,
                "Output Repaired Raster"
            )
        )
        self.addParameter(
            QgsProcessingParameterRasterDestination(
                self.OUTPUT_PROVENANCE,
                "Output Provenance Mask Raster",
                optional=True
            )
        )
        self.addParameter(
            QgsProcessingParameterRasterDestination(
                self.OUTPUT_CONFIDENCE,
                "Output Confidence Raster",
                optional=True
            )
        )
        self.addParameter(
            QgsProcessingParameterRasterDestination(
                self.OUTPUT_REMAINING,
                "Output Remaining-Gaps Mask Raster",
                optional=True
            )
        )

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        t_layer = self.parameterAsRasterLayer(parameters, self.INPUT_TARGET, context)
        d_layers = self.parameterAsLayerList(parameters, self.INPUT_DONORS, context)

        out_filled = self.parameterAsOutputLayer(parameters, self.OUTPUT_FILLED, context)
        out_prov = self.parameterAsOutputLayer(parameters, self.OUTPUT_PROVENANCE, context)
        out_conf = self.parameterAsOutputLayer(parameters, self.OUTPUT_CONFIDENCE, context)
        out_rem = self.parameterAsOutputLayer(parameters, self.OUTPUT_REMAINING, context)

        if not t_layer or not t_layer.isValid():
            raise ValueError("Invalid target raster layer provided.")
        if not d_layers:
            raise ValueError("At least one candidate donor raster must be provided.")

        donors = [DonorSpec(filepath=l.source()) for l in d_layers if l.isValid()]

        cfg = GapFillConfig(
            target_path=t_layer.source(),
            method=GapFillMethod.MULTI_DONOR,
            donors=donors,
            output_filled_path=out_filled,
            output_provenance_path=out_prov,
            output_confidence_path=out_conf,
            output_remaining_gap_path=out_rem,
            parameters=MethodParameters()
        )

        def on_prog(p, msg):
            feedback.setProgress(p)
            feedback.pushInfo(msg)

        feedback.pushInfo(f"Running Multi-Donor Smart Fill across {len(donors)} donor candidate(s)...")
        res = AriesGapFillEngine.execute(cfg, progress_callback=on_prog)

        results = {self.OUTPUT_FILLED: out_filled}
        if out_prov:
            results[self.OUTPUT_PROVENANCE] = out_prov
        if out_conf:
            results[self.OUTPUT_CONFIDENCE] = out_conf
        if out_rem:
            results[self.OUTPUT_REMAINING] = out_rem

        feedback.pushInfo(f"Multi-donor fill complete: {res.filled_gap_count:,} gaps repaired ({res.overall_fill_rate_pct:.1f}%).")
        return results

"""
Processing algorithm: AriesGapfill Two-Image Global Statistical Matching (Method B).
"""

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterRasterDestination,
    QgsProcessingParameterBoolean,
    QgsProcessingOutputRasterLayer,
    QgsProcessingContext,
    QgsProcessingFeedback,
)
from ...gapfill.models import GapFillConfig, GapFillMethod, MethodParameters, DonorSpec
from ...gapfill.engine import AriesGapFillEngine


class GapfillGlobalAlgorithm(QgsProcessingAlgorithm):
    INPUT_TARGET = "INPUT_TARGET"
    INPUT_DONOR = "INPUT_DONOR"
    USE_ROBUST_REGRESSION = "USE_ROBUST_REGRESSION"

    OUTPUT_FILLED = "OUTPUT_FILLED"
    OUTPUT_PROVENANCE = "OUTPUT_PROVENANCE"
    OUTPUT_CONFIDENCE = "OUTPUT_CONFIDENCE"

    def name(self):
        return "gapfill_global"

    def displayName(self):
        return "AriesGapfill: Two-Image Global Matching"

    def group(self):
        return "AriesGapfill"

    def groupId(self):
        return "gapfill"

    def shortHelpString(self):
        return "Fills target gaps using a co-registered donor scene after matching band-wise radiometry via global linear regression and mean/std-dev scaling."

    def createInstance(self):
        return GapfillGlobalAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterRasterLayer(
                self.INPUT_TARGET,
                "Input Target Raster (SLC-off)"
            )
        )
        self.addParameter(
            QgsProcessingParameterRasterLayer(
                self.INPUT_DONOR,
                "Input Donor Raster"
            )
        )
        self.addParameter(
            QgsProcessingParameterBoolean(
                self.USE_ROBUST_REGRESSION,
                "Use Robust Linear Regression with MAD Outlier Rejection",
                defaultValue=True
            )
        )
        self.addParameter(
            QgsProcessingParameterRasterDestination(
                self.OUTPUT_FILLED,
                "Output Repaired Raster"
            )
        )
        self.addParameter(
            QgsProcessingParameterRasterDestination(
                self.OUTPUT_PROVENANCE,
                "Output Provenance Mask Raster",
                optional=True
            )
        )
        self.addParameter(
            QgsProcessingParameterRasterDestination(
                self.OUTPUT_CONFIDENCE,
                "Output Confidence Raster",
                optional=True
            )
        )

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        t_layer = self.parameterAsRasterLayer(parameters, self.INPUT_TARGET, context)
        d_layer = self.parameterAsRasterLayer(parameters, self.INPUT_DONOR, context)
        robust = self.parameterAsBoolean(parameters, self.USE_ROBUST_REGRESSION, context)

        out_filled = self.parameterAsOutputLayer(parameters, self.OUTPUT_FILLED, context)
        out_prov = self.parameterAsOutputLayer(parameters, self.OUTPUT_PROVENANCE, context)
        out_conf = self.parameterAsOutputLayer(parameters, self.OUTPUT_CONFIDENCE, context)

        if not t_layer or not t_layer.isValid():
            raise ValueError("Invalid target raster layer provided.")
        if not d_layer or not d_layer.isValid():
            raise ValueError("Invalid donor raster layer provided.")

        cfg = GapFillConfig(
            target_path=t_layer.source(),
            method=GapFillMethod.GLOBAL_MATCHING,
            donors=[DonorSpec(filepath=d_layer.source())],
            output_filled_path=out_filled,
            output_provenance_path=out_prov,
            output_confidence_path=out_conf,
            parameters=MethodParameters(use_robust_regression=robust)
        )

        def on_prog(p, msg):
            feedback.setProgress(p)
            feedback.pushInfo(msg)

        feedback.pushInfo("Running AriesGapfill Global Statistical Matching...")
        res = AriesGapFillEngine.execute(cfg, progress_callback=on_prog)

        results = {self.OUTPUT_FILLED: out_filled}
        if out_prov:
            results[self.OUTPUT_PROVENANCE] = out_prov
        if out_conf:
            results[self.OUTPUT_CONFIDENCE] = out_conf

        feedback.pushInfo(f"Global matching complete: {res.filled_gap_count:,} gaps repaired ({res.overall_fill_rate_pct:.1f}%).")
        return results

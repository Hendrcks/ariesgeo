"""
Processing algorithm: Inspect Raster Stack.
"""

import json
from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterMultipleLayers,
    QgsProcessingParameterFileDestination,
    QgsProcessingOutputString,
    QgsProcessingContext,
    QgsProcessingFeedback,
)
from ...raster.inspector import RasterInspector

class InspectRastersAlgorithm(QgsProcessingAlgorithm):
    INPUT_RASTERS = "INPUT_RASTERS"
    OUTPUT_REPORT = "OUTPUT_REPORT"
    REPORT_JSON = "REPORT_JSON"

    def name(self):
        return "inspect_rasters"

    def displayName(self):
        return "Inspect Raster Stack"

    def group(self):
        return "Mosaic & GapFill"

    def groupId(self):
        return "raster"

    def shortHelpString(self):
        return "Deep preflight diagnostic inspection of multiple rasters for CRS, resolution, grid offsets, band counts, and NoData."

    def createInstance(self):
        return InspectRastersAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterMultipleLayers(
                self.INPUT_RASTERS,
                "Input Raster Layers / Files",
                layerType=getattr(QgsProcessing, "TypeRaster", None) or getattr(getattr(QgsProcessing, "SourceType", None), "TypeRaster", 1)
            )
        )
        self.addParameter(
            QgsProcessingParameterFileDestination(
                self.OUTPUT_REPORT,
                "Output Diagnostics JSON",
                fileFilter="JSON files (*.json)",
                optional=True
            )
        )
        self.addOutput(
            QgsProcessingOutputString(
                self.REPORT_JSON,
                "Diagnostic Summary JSON"
            )
        )

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        layers = self.parameterAsLayerList(parameters, self.INPUT_RASTERS, context)
        out_file = self.parameterAsFileOutput(parameters, self.OUTPUT_REPORT, context)

        paths = [layer.source() for layer in layers if hasattr(layer, "source")]
        if not paths:
            paths = self.parameterAsString(parameters, self.INPUT_RASTERS, context).split(";")

        feedback.pushInfo(f"Inspecting {len(paths)} raster dataset(s)...")
        report = RasterInspector.inspect_stack(paths)

        summary_dict = {
            "raster_count": report.raster_count,
            "common_crs": report.common_crs,
            "common_band_count": report.common_band_count,
            "common_data_type": report.common_data_type,
            "is_compatible_for_quick_mosaic": report.is_compatible_for_quick_mosaic,
            "issues": [{"severity": i.severity, "title": i.title, "description": i.description} for i in report.issues],
            "unified_extent": report.unified_extent
        }

        json_str = json.dumps(summary_dict, indent=2)
        feedback.pushInfo(f"Inspection complete. Issues detected: {len(report.issues)}")

        if out_file:
            with open(out_file, "w", encoding="utf-8") as f:
                f.write(json_str)

        return {self.REPORT_JSON: json_str}

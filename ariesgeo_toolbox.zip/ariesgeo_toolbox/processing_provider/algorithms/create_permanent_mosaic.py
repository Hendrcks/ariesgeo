"""
Processing algorithm: Create Permanent GeoTIFF / COG Mosaic.
"""

from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterMultipleLayers,
    QgsProcessingParameterRasterDestination,
    QgsProcessingParameterCrs,
    QgsProcessingParameterEnum,
    QgsProcessingParameterString,
    QgsProcessingParameterBoolean,
    QgsProcessingContext,
    QgsProcessingFeedback,
)
from ...raster.mosaic import RasterMosaicker

class CreatePermanentMosaicAlgorithm(QgsProcessingAlgorithm):
    INPUT_RASTERS = "INPUT_RASTERS"
    OUTPUT_RASTER = "OUTPUT_RASTER"
    TARGET_CRS = "TARGET_CRS"
    RESAMPLING = "RESAMPLING"
    COMPRESSION = "COMPRESSION"
    TILED = "TILED"
    OVERVIEWS = "OVERVIEWS"

    RESAMPLE_OPTIONS = ["nearest", "bilinear", "cubic", "cubicspline", "lanczos", "mode", "average"]
    COMPRESS_OPTIONS = ["DEFLATE", "LZW", "PACKBITS", "ZSTD", "NONE"]

    def name(self):
        return "create_permanent_mosaic"

    def displayName(self):
        return "Create Permanent GeoTIFF Mosaic"

    def group(self):
        return "Mosaic & GapFill"

    def groupId(self):
        return "raster"

    def shortHelpString(self):
        return "Combine multiple rasters into a permanent, tiled, compressed GeoTIFF/COG dataset."

    def createInstance(self):
        return CreatePermanentMosaicAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterMultipleLayers(
                self.INPUT_RASTERS,
                "Input Rasters",
                layerType=getattr(QgsProcessing, "TypeRaster", None) or getattr(getattr(QgsProcessing, "SourceType", None), "TypeRaster", 1)
            )
        )
        self.addParameter(
            QgsProcessingParameterCrs(
                self.TARGET_CRS,
                "Target CRS (optional)",
                optional=True
            )
        )
        self.addParameter(
            QgsProcessingParameterEnum(
                self.RESAMPLING,
                "Resampling Method",
                options=self.RESAMPLE_OPTIONS,
                defaultValue=1
            )
        )
        self.addParameter(
            QgsProcessingParameterEnum(
                self.COMPRESSION,
                "Compression",
                options=self.COMPRESS_OPTIONS,
                defaultValue=0
            )
        )
        self.addParameter(
            QgsProcessingParameterBoolean(
                self.TILED,
                "Create Tiled GeoTIFF (Cloud-Optimized)",
                defaultValue=True
            )
        )
        self.addParameter(
            QgsProcessingParameterBoolean(
                self.OVERVIEWS,
                "Build Pyramids / Overviews",
                defaultValue=True
            )
        )
        self.addParameter(
            QgsProcessingParameterRasterDestination(
                self.OUTPUT_RASTER,
                "Output GeoTIFF Mosaic"
            )
        )

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        layers = self.parameterAsLayerList(parameters, self.INPUT_RASTERS, context)
        out_path = self.parameterAsRasterLayer(parameters, self.OUTPUT_RASTER, context) or self.parameterAsOutputLayer(parameters, self.OUTPUT_RASTER, context)
        crs = self.parameterAsCrs(parameters, self.TARGET_CRS, context)
        resample_idx = self.parameterAsEnum(parameters, self.RESAMPLING, context)
        compress_idx = self.parameterAsEnum(parameters, self.COMPRESSION, context)
        tiled = self.parameterAsBoolean(parameters, self.TILED, context)
        overviews = self.parameterAsBoolean(parameters, self.OVERVIEWS, context)

        paths = [layer.source() for layer in layers if hasattr(layer, "source")]
        target_crs_str = crs.authid() if crs.isValid() else None
        resampling = self.RESAMPLE_OPTIONS[resample_idx]
        compression = self.COMPRESS_OPTIONS[compress_idx]

        def cb(pct, msg):
            feedback.setProgress(int(pct * 100))
            if msg:
                feedback.pushInfo(msg)

        feedback.pushInfo(f"Mosaicking {len(paths)} rasters into '{out_path}'...")
        RasterMosaicker.create_permanent_mosaic(
            input_paths=paths,
            output_tiff_path=out_path,
            target_crs=target_crs_str,
            resampling=resampling,
            compression=compression,
            tiled=tiled,
            build_overviews=overviews,
            progress_callback=cb
        )

        return {self.OUTPUT_RASTER: out_path}

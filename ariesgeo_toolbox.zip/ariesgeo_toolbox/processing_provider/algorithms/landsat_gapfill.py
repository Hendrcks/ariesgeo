"""
Processing algorithm: AriesGapfill (Unified Landsat 7 & Raster GapFill Runner).
"""

from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterMultipleLayers,
    QgsProcessingParameterEnum,
    QgsProcessingParameterRasterDestination,
    QgsProcessingParameterBoolean,
    QgsProcessingOutputRasterLayer,
    QgsProcessingContext,
    QgsProcessingFeedback,
)
from ...gapfill.models import GapFillConfig, GapFillMethod, GapMaskSource, MethodParameters, DonorSpec
from ...gapfill.engine import AriesGapFillEngine


class LandsatGapFillAlgorithm(QgsProcessingAlgorithm):
    TARGET_SCENE = "TARGET_SCENE"
    METHOD = "METHOD"
    MASK_SOURCE = "MASK_SOURCE"
    DONOR_SCENES = "DONOR_SCENES"
    OUTPUT_RASTER = "OUTPUT_RASTER"
    OUTPUT_PROVENANCE = "OUTPUT_PROVENANCE"
    OUTPUT_CONFIDENCE = "OUTPUT_CONFIDENCE"

    METHODS = [
        "Two Images: USGS Local Linear Histogram Matching (LLHM - Phase 2)",
        "Two Images: USGS Global Linear Histogram Matching (GLHM - Phase 1)",
        "Multiple Donors: Smart Priority Composite (LLHM)",
        "Single Image: Delaunay Triangulation (Phase 1)"
    ]

    MASK_SOURCES = [
        "Unified: SLC-Off Stripes + Clouds & Cast Shadows",
        "SLC-Off Stripes / NoData / Zero Pixels Only",
        "Clouds & Cast Shadows Only"
    ]

    def name(self):
        return "landsat_gapfill"

    def displayName(self):
        return "AriesGapfill: Landsat 7 SLC-off & Cloud Gap Fill"

    def group(self):
        return "AriesGapfill"

    def groupId(self):
        return "gapfill"

    def shortHelpString(self):
        return (
            "Complete USGS/ENVI Landsat Gapfill runner for repairing SLC-off scanline gaps, clouds, and cast shadows "
            "using Single-File Delaunay Triangulation, Phase-1 Global Linear Histogram Matching (GLHM), "
            "Phase-2 Local Linear Histogram Matching (LLHM), or Multi-Donor Priority Composite."
        )

    def createInstance(self):
        return LandsatGapFillAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterRasterLayer(
                self.TARGET_SCENE,
                "Target Landsat / SLC-off / Cloudy Raster"
            )
        )
        self.addParameter(
            QgsProcessingParameterEnum(
                self.METHOD,
                "Gap Filling Method",
                options=self.METHODS,
                defaultValue=0
            )
        )
        self.addParameter(
            QgsProcessingParameterEnum(
                self.MASK_SOURCE,
                "Pixels to Repair (Mask Source)",
                options=self.MASK_SOURCES,
                defaultValue=0,
                optional=True
            )
        )
        self.addParameter(
            QgsProcessingParameterMultipleLayers(
                self.DONOR_SCENES,
                "Donor Scene(s) (Not needed for Single Triangulation)",
                layerType=getattr(QgsProcessing, "TypeRaster", None) or getattr(getattr(QgsProcessing, "SourceType", None), "TypeRaster", 1),
                optional=True
            )
        )
        self.addParameter(
            QgsProcessingParameterRasterDestination(
                self.OUTPUT_RASTER,
                "Output Repaired Raster"
            )
        )
        self.addParameter(
            QgsProcessingParameterRasterDestination(
                self.OUTPUT_PROVENANCE,
                "Output Provenance Mask Raster",
                optional=True
            )
        )
        self.addParameter(
            QgsProcessingParameterRasterDestination(
                self.OUTPUT_CONFIDENCE,
                "Output Confidence Raster",
                optional=True
            )
        )

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        t_layer = self.parameterAsRasterLayer(parameters, self.TARGET_SCENE, context)
        method_idx = self.parameterAsEnum(parameters, self.METHOD, context)
        mask_idx = self.parameterAsEnum(parameters, self.MASK_SOURCE, context) if self.MASK_SOURCE in parameters else 1
        d_layers = self.parameterAsLayerList(parameters, self.DONOR_SCENES, context)

        out_filled = self.parameterAsOutputLayer(parameters, self.OUTPUT_RASTER, context)
        out_prov = self.parameterAsOutputLayer(parameters, self.OUTPUT_PROVENANCE, context) or None
        out_conf = self.parameterAsOutputLayer(parameters, self.OUTPUT_CONFIDENCE, context) or None

        if not t_layer or not t_layer.isValid():
            raise ValueError("Invalid target raster layer provided.")

        method_map = {
            0: GapFillMethod.LOCAL_MATCHING,
            1: GapFillMethod.GLOBAL_MATCHING,
            2: GapFillMethod.MULTI_DONOR,
            3: GapFillMethod.TRIANGULATION
        }
        mask_map = {
            0: GapMaskSource.SLC_AND_CLOUDS,
            1: GapMaskSource.NODATA,
            2: GapMaskSource.CLOUDS_ONLY
        }
        method = method_map.get(method_idx, GapFillMethod.LOCAL_MATCHING)
        mask_source = mask_map.get(mask_idx, GapMaskSource.NODATA)

        donors = [DonorSpec(filepath=l.source().split("|")[0]) for l in (d_layers or []) if l and l.isValid()]

        if method != GapFillMethod.TRIANGULATION and not donors:
            raise ValueError(f"Method '{self.METHODS[method_idx]}' requires at least one valid donor scene.")

        cfg = GapFillConfig(
            target_path=t_layer.source().split("|")[0],
            method=method,
            donors=donors,
            mask_source=mask_source,
            output_filled_path=out_filled,
            output_provenance_path=out_prov,
            output_confidence_path=out_conf,
            parameters=MethodParameters()
        )

        def on_prog(p, msg):
            feedback.setProgress(int(p))
            if msg:
                feedback.pushInfo(msg)

        feedback.pushInfo(f"Executing AriesGapfill via {method.value}...")
        res = AriesGapFillEngine.execute(cfg, progress_callback=on_prog)

        results = {self.OUTPUT_RASTER: out_filled}
        if out_prov:
            results[self.OUTPUT_PROVENANCE] = out_prov
        if out_conf:
            results[self.OUTPUT_CONFIDENCE] = out_conf

        feedback.pushInfo(f"AriesGapfill completed: {res.filled_gap_count:,} gaps filled ({res.overall_fill_rate_pct:.1f}%).")
        return results

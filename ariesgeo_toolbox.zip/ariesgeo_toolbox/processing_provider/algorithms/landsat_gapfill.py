"""
Processing algorithm: AriesGapfill (Unified Landsat 7 & Raster GapFill Runner).
"""

from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterMultipleLayers,
    QgsProcessingParameterEnum,
    QgsProcessingParameterRasterDestination,
    QgsProcessingParameterBoolean,
    QgsProcessingOutputRasterLayer,
    QgsProcessingContext,
    QgsProcessingFeedback,
)
from ...gapfill.models import GapFillConfig, GapFillMethod, MethodParameters, DonorSpec
from ...gapfill.engine import AriesGapFillEngine


class LandsatGapFillAlgorithm(QgsProcessingAlgorithm):
    TARGET_SCENE = "TARGET_SCENE"
    METHOD = "METHOD"
    DONOR_SCENES = "DONOR_SCENES"
    OUTPUT_RASTER = "OUTPUT_RASTER"
    OUTPUT_PROVENANCE = "OUTPUT_PROVENANCE"
    OUTPUT_CONFIDENCE = "OUTPUT_CONFIDENCE"

    METHODS = [
        "Two Images: Local Matching (Recommended)",
        "Two Images: Global Statistical Matching",
        "Multiple Donors: Smart Composite",
        "Single Image: Delaunay Triangulation"
    ]

    def name(self):
        return "landsat_gapfill"

    def displayName(self):
        return "AriesGapfill: Landsat 7 SLC-off & Raster Gap Fill"

    def group(self):
        return "AriesGapfill"

    def groupId(self):
        return "gapfill"

    def shortHelpString(self):
        return "Complete AriesGapfill runner for repairing missing and SLC-off pixels using Single Triangulation, Global Matching, Local Moving Window, or Multi-Donor Smart Composite."

    def createInstance(self):
        return LandsatGapFillAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterRasterLayer(
                self.TARGET_SCENE,
                "Target Landsat / SLC-off Raster"
            )
        )
        self.addParameter(
            QgsProcessingParameterEnum(
                self.METHOD,
                "Gap Filling Method",
                options=self.METHODS,
                defaultValue=0
            )
        )
        self.addParameter(
            QgsProcessingParameterMultipleLayers(
                self.DONOR_SCENES,
                "Donor Scene(s) (Not needed for Single Triangulation)",
                layerType=getattr(QgsProcessing, "TypeRaster", None) or getattr(getattr(QgsProcessing, "SourceType", None), "TypeRaster", 1),
                optional=True
            )
        )
        self.addParameter(
            QgsProcessingParameterRasterDestination(
                self.OUTPUT_RASTER,
                "Output Repaired Raster"
            )
        )
        self.addParameter(
            QgsProcessingParameterRasterDestination(
                self.OUTPUT_PROVENANCE,
                "Output Provenance Mask Raster",
                optional=True
            )
        )
        self.addParameter(
            QgsProcessingParameterRasterDestination(
                self.OUTPUT_CONFIDENCE,
                "Output Confidence Raster",
                optional=True
            )
        )

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        t_layer = self.parameterAsRasterLayer(parameters, self.TARGET_SCENE, context)
        method_idx = self.parameterAsEnum(parameters, self.METHOD, context)
        d_layers = self.parameterAsLayerList(parameters, self.DONOR_SCENES, context)

        out_filled = self.parameterAsOutputLayer(parameters, self.OUTPUT_RASTER, context)
        out_prov = self.parameterAsOutputLayer(parameters, self.OUTPUT_PROVENANCE, context)
        out_conf = self.parameterAsOutputLayer(parameters, self.OUTPUT_CONFIDENCE, context)

        if not t_layer or not t_layer.isValid():
            raise ValueError("Invalid target raster layer provided.")

        method_map = {
            0: GapFillMethod.LOCAL_MATCHING,
            1: GapFillMethod.GLOBAL_MATCHING,
            2: GapFillMethod.MULTI_DONOR,
            3: GapFillMethod.TRIANGULATION
        }
        method = method_map.get(method_idx, GapFillMethod.LOCAL_MATCHING)

        donors = [DonorSpec(filepath=l.source()) for l in d_layers if l.isValid()]

        if method != GapFillMethod.TRIANGULATION and not donors:
            raise ValueError(f"Method '{self.METHODS[method_idx]}' requires at least one valid donor scene.")

        cfg = GapFillConfig(
            target_path=t_layer.source(),
            method=method,
            donors=donors,
            output_filled_path=out_filled,
            output_provenance_path=out_prov,
            output_confidence_path=out_conf,
            parameters=MethodParameters()
        )

        def on_prog(p, msg):
            feedback.setProgress(p)
            feedback.pushInfo(msg)

        feedback.pushInfo(f"Executing AriesGapfill via {method.value}...")
        res = AriesGapFillEngine.execute(cfg, progress_callback=on_prog)

        results = {self.OUTPUT_RASTER: out_filled}
        if out_prov:
            results[self.OUTPUT_PROVENANCE] = out_prov
        if out_conf:
            results[self.OUTPUT_CONFIDENCE] = out_conf

        feedback.pushInfo(f"AriesGapfill completed: {res.filled_gap_count:,} gaps filled ({res.overall_fill_rate_pct:.1f}%).")
        return results

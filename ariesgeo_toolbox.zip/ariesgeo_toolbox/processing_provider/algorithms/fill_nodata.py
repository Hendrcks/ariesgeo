"""
Processing algorithm: Fill Spatial NoData Holes.
"""

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterNumber,
    QgsProcessingParameterRasterDestination,
    QgsProcessingContext,
    QgsProcessingFeedback,
)
from ...raster.gapfill import GapFiller

class FillNoDataAlgorithm(QgsProcessingAlgorithm):
    INPUT_RASTER = "INPUT_RASTER"
    OUTPUT_RASTER = "OUTPUT_RASTER"
    MAX_DISTANCE = "MAX_DISTANCE"
    SMOOTHING = "SMOOTHING"

    def name(self):
        return "fill_nodata"

    def displayName(self):
        return "Fill Spatial NoData Holes"

    def group(self):
        return "Mosaic & GapFill"

    def groupId(self):
        return "raster"

    def shortHelpString(self):
        return "Interpolate small NoData gaps using GDAL edge-based inverse distance weighting."

    def createInstance(self):
        return FillNoDataAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterRasterLayer(
                self.INPUT_RASTER,
                "Input Raster Layer"
            )
        )
        self.addParameter(
            QgsProcessingParameterNumber(
                self.MAX_DISTANCE,
                "Maximum Search Distance (pixels)",
                type=QgsProcessingParameterNumber.Integer,
                defaultValue=100,
                minValue=1,
                maxValue=1000
            )
        )
        self.addParameter(
            QgsProcessingParameterNumber(
                self.SMOOTHING,
                "Smoothing Iterations",
                type=QgsProcessingParameterNumber.Integer,
                defaultValue=0,
                minValue=0,
                maxValue=10
            )
        )
        self.addParameter(
            QgsProcessingParameterRasterDestination(
                self.OUTPUT_RASTER,
                "Filled Output Raster"
            )
        )

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        layer = self.parameterAsRasterLayer(parameters, self.INPUT_RASTER, context)
        out_path = self.parameterAsOutputLayer(parameters, self.OUTPUT_RASTER, context)
        max_dist = self.parameterAsInt(parameters, self.MAX_DISTANCE, context)
        smoothing = self.parameterAsInt(parameters, self.SMOOTHING, context)

        def cb(pct, msg):
            feedback.setProgress(int(pct * 100))
            if msg:
                feedback.pushInfo(msg)

        feedback.pushInfo(f"Filling gaps in {layer.source()}...")
        GapFiller.fill_spatial_nodata(
            input_raster_path=layer.source(),
            output_raster_path=out_path,
            max_search_distance=max_dist,
            smoothing_iterations=smoothing,
            progress_callback=cb
        )

        return {self.OUTPUT_RASTER: out_path}

"""
Processing algorithm: Reverse Geocode Point Layer.
"""

import time
from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterFeatureSource,
    QgsProcessingParameterEnum,
    QgsProcessingParameterNumber,
    QgsProcessingOutputVectorLayer,
    QgsProcessingContext,
    QgsProcessingFeedback,
    QgsVectorLayer,
    QgsField,
    QgsFeature,
    QgsCoordinateTransform,
    QgsCoordinateReferenceSystem,
    QgsProject,
)
from qgis.PyQt.QtCore import QVariant
from ...place_finder.providers.nominatim import NominatimProvider
from ...place_finder.providers.photon import PhotonProvider
from ...core.network import NetworkClient

class ReverseGeocodeAlgorithm(QgsProcessingAlgorithm):
    INPUT_LAYER = "INPUT_LAYER"
    INPUT_PROVIDER = "INPUT_PROVIDER"
    DELAY_SECONDS = "DELAY_SECONDS"
    OUTPUT = "OUTPUT"

    PROVIDERS = ["Photon (Komoot)", "OpenStreetMap (Nominatim)"]

    def name(self):
        return "reverse_geocode"

    def displayName(self):
        return "Reverse Geocode Points"

    def group(self):
        return "Place Finder"

    def groupId(self):
        return "place_finder"

    def shortHelpString(self):
        return "Enrich a point layer with reverse-geocoded addresses and administrative hierarchy."

    def createInstance(self):
        return ReverseGeocodeAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterFeatureSource(
                self.INPUT_LAYER,
                "Input Point Layer",
                types=[QgsProcessingAlgorithm.TypeVectorPoint] if hasattr(QgsProcessingAlgorithm, "TypeVectorPoint") else []
            )
        )
        self.addParameter(
            QgsProcessingParameterEnum(
                self.INPUT_PROVIDER,
                "Geocoding Provider",
                options=self.PROVIDERS,
                defaultValue=0
            )
        )
        self.addParameter(
            QgsProcessingParameterNumber(
                self.DELAY_SECONDS,
                "Delay Between Requests (seconds)",
                type=QgsProcessingParameterNumber.Double,
                defaultValue=1.0,
                minValue=0.2,
                maxValue=10.0
            )
        )
        self.addOutput(
            QgsProcessingOutputVectorLayer(
                self.OUTPUT,
                "Enriched Point Layer"
            )
        )

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        source = self.parameterAsSource(parameters, self.INPUT_LAYER, context)
        provider_idx = self.parameterAsEnum(parameters, self.INPUT_PROVIDER, context)
        delay = self.parameterAsDouble(parameters, self.DELAY_SECONDS, context)

        provider_name = self.PROVIDERS[provider_idx]
        provider = PhotonProvider() if "Photon" in provider_name else NominatimProvider()
        net = NetworkClient()

        # Transform to WGS84 for lat/lon queries
        wgs84 = QgsCoordinateReferenceSystem("EPSG:4326")
        transform = QgsCoordinateTransform(source.sourceCrs(), wgs84, QgsProject.instance())

        out_layer = QgsVectorLayer(f"Point?crs={source.sourceCrs().authid()}", "Reverse Geocoded", "memory")
        pr = out_layer.dataProvider()

        out_fields = list(source.fields())
        out_fields.append(QgsField("rev_address", QVariant.Type.String if hasattr(QVariant, "Type") else QVariant.String))
        out_fields.append(QgsField("rev_country", QVariant.Type.String if hasattr(QVariant, "Type") else QVariant.String))
        out_fields.append(QgsField("rev_city", QVariant.Type.String if hasattr(QVariant, "Type") else QVariant.String))
        pr.addAttributes(out_fields)
        out_layer.updateFields()

        features = list(source.getFeatures())
        total = len(features)
        out_features = []

        for i, feat in enumerate(features):
            if feedback.isCanceled():
                break

            feedback.setProgress(int((i / max(1, total)) * 100))
            geom = feat.geometry()
            out_feat = QgsFeature(out_layer.fields())
            out_feat.setGeometry(geom)

            for fld in source.fields():
                out_feat.setAttribute(fld.name(), feat.attribute(fld.name()))

            if geom and not geom.isEmpty():
                pt = geom.asPoint()
                wgs_pt = transform.transform(pt)
                try:
                    url = provider.build_reverse_url(wgs_pt.y(), wgs_pt.x())
                    raw_data = net.get_json_sync(url)
                    res = provider.parse_reverse_response(raw_data)
                    if res:
                        out_feat.setAttribute("rev_address", res.display_name)
                        out_feat.setAttribute("rev_country", res.country)
                        out_feat.setAttribute("rev_city", res.city)
                except Exception:
                    pass

            out_features.append(out_feat)
            time.sleep(delay)

        pr.addFeatures(out_features)
        out_layer.updateExtents()
        return {self.OUTPUT: out_layer}

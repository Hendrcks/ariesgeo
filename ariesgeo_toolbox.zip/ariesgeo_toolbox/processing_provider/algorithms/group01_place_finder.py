"""
Processing algorithms for Group 01: Place Finder & Geocoding (10 algorithms).
"""

import os
import re
import csv
import json
import math
from typing import List, Dict, Any, Optional, Tuple
from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterString,
    QgsProcessingParameterNumber,
    QgsProcessingParameterEnum,
    QgsProcessingParameterFile,
    QgsProcessingParameterVectorLayer,
    QgsProcessingParameterFeatureSource,
    QgsProcessingParameterVectorDestination,
    QgsProcessingParameterFileDestination,
    QgsProcessingParameterCrs,
    QgsProcessingParameterDistance,
    QgsProcessingOutputVectorLayer,
    QgsProcessingOutputFile,
    QgsProcessingContext,
    QgsProcessingFeedback,
    QgsVectorLayer,
    QgsField,
    QgsFeature,
    QgsGeometry,
    QgsPointXY,
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsProject,
    QgsWkbTypes
)
from qgis.PyQt.QtCore import QVariant
from ...place_finder.service import PlaceFinderService
from ...place_finder.providers.nominatim import NominatimProvider
from ...place_finder.providers.photon import PhotonProvider
from ...core.provenance import create_provenance_record, write_provenance_json


class PlaceSearchAlgorithm(QgsProcessingAlgorithm):
    INPUT_QUERY = "INPUT_QUERY"
    INPUT_PROVIDER = "INPUT_PROVIDER"
    INPUT_LIMIT = "INPUT_LIMIT"
    OUTPUT = "OUTPUT"
    PROVIDERS = ["Photon (Komoot)", "OpenStreetMap (Nominatim)"]

    def name(self):
        return "place_search"

    def displayName(self):
        return "01.01 Search place names"

    def group(self):
        return "01 · Place Finder & Geocoding"

    def groupId(self):
        return "01_place_finder"

    def shortHelpString(self):
        return "Search for locations by name using online or offline geocoders and return a vector point layer."

    def createInstance(self):
        return PlaceSearchAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterString(self.INPUT_QUERY, "Place Name / Search Query", defaultValue="Paris, France"))
        self.addParameter(QgsProcessingParameterEnum(self.INPUT_PROVIDER, "Geocoding Provider", options=self.PROVIDERS, defaultValue=0))
        self.addParameter(QgsProcessingParameterNumber(self.INPUT_LIMIT, "Maximum Results", type=QgsProcessingParameterNumber.Integer, defaultValue=5, minValue=1, maxValue=50))
        self.addParameter(QgsProcessingParameterVectorDestination(self.OUTPUT, "Output Geocoded Points Layer"))

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        query = self.parameterAsString(parameters, self.INPUT_QUERY, context).strip()
        provider_idx = self.parameterAsEnum(parameters, self.INPUT_PROVIDER, context)
        limit = self.parameterAsInt(parameters, self.INPUT_LIMIT, context)
        out_dest = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)

        if not query:
            raise ValueError("Query string cannot be empty.")

        service = PlaceFinderService()
        selected_provider = service.get_provider("photon" if provider_idx == 0 else "nominatim")
        results = selected_provider.search(query=query, limit=limit) if selected_provider else []

        vl = QgsVectorLayer("Point?crs=EPSG:4326", "geocoded_places", "memory")
        pr = vl.dataProvider()
        pr.addAttributes([
            QgsField("name", QVariant.String),
            QgsField("display_name", QVariant.String),
            QgsField("provider", QVariant.String),
            QgsField("latitude", QVariant.Double),
            QgsField("longitude", QVariant.Double),
            QgsField("osm_type", QVariant.String)
        ])
        vl.updateFields()

        feats = []
        for r in results:
            f = QgsFeature(vl.fields())
            f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(r.lon, r.lat)))
            f.setAttribute("name", r.name)
            f.setAttribute("display_name", r.display_name)
            f.setAttribute("provider", r.provider)
            f.setAttribute("latitude", r.lat)
            f.setAttribute("longitude", r.lon)
            f.setAttribute("osm_type", r.osm_type)
            feats.append(f)
        pr.addFeatures(feats)

        # Write to requested destination
        from qgis.core import QgsVectorFileWriter
        QgsVectorFileWriter.writeAsVectorFormatV3(vl, out_dest, context.transformContext(), QgsVectorFileWriter.SaveVectorOptions())
        return {self.OUTPUT: out_dest}


class ReverseGeocodeAlgorithm(QgsProcessingAlgorithm):
    INPUT_LAYER = "INPUT_LAYER"
    INPUT_PROVIDER = "INPUT_PROVIDER"
    OUTPUT = "OUTPUT"
    PROVIDERS = ["Photon (Komoot)", "OpenStreetMap (Nominatim)"]

    def name(self):
        return "reverse_geocode"

    def displayName(self):
        return "01.02 Reverse geocode points"

    def group(self):
        return "01 · Place Finder & Geocoding"

    def groupId(self):
        return "01_place_finder"

    def shortHelpString(self):
        return "Reverse geocode a point layer by querying online providers to attach nearest place names and addresses."

    def createInstance(self):
        return ReverseGeocodeAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFeatureSource(self.INPUT_LAYER, "Input Point Layer", [QgsProcessing.TypeVectorPoint]))
        self.addParameter(QgsProcessingParameterEnum(self.INPUT_PROVIDER, "Geocoding Provider", options=self.PROVIDERS, defaultValue=0))
        self.addParameter(QgsProcessingParameterVectorDestination(self.OUTPUT, "Output Attributed Point Layer"))

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        source = self.parameterAsSource(parameters, self.INPUT_LAYER, context)
        provider_idx = self.parameterAsEnum(parameters, self.INPUT_PROVIDER, context)
        out_dest = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)

        service = PlaceFinderService()
        selected_provider = service.get_provider("photon" if provider_idx == 0 else "nominatim")

        target_crs = QgsCoordinateReferenceSystem("EPSG:4326")
        transform = QgsCoordinateTransform(source.sourceCrs(), target_crs, context.transformContext())

        vl = QgsVectorLayer("Point?crs=EPSG:4326", "reverse_geocoded", "memory")
        pr = vl.dataProvider()
        pr.addAttributes(list(source.fields()) + [
            QgsField("addr_name", QVariant.String),
            QgsField("addr_full", QVariant.String),
            QgsField("addr_country", QVariant.String)
        ])
        vl.updateFields()

        feats = []
        total = source.featureCount()
        for i, feat in enumerate(source.getFeatures()):
            if feedback.isCanceled():
                break
            pt = transform.transform(feat.geometry().asPoint())
            res = selected_provider.reverse_geocode(pt.y(), pt.x()) if selected_provider else None

            new_f = QgsFeature(vl.fields())
            new_f.setGeometry(QgsGeometry.fromPointXY(pt))
            for f_idx in range(len(source.fields())):
                new_f.setAttribute(f_idx, feat.attribute(f_idx))

            new_f.setAttribute("addr_name", res.name if res else "")
            new_f.setAttribute("addr_full", res.display_name if res else "")
            new_f.setAttribute("addr_country", res.country if res else "")
            feats.append(new_f)

            if total > 0 and i % 5 == 0:
                feedback.setProgress(int((i / total) * 100))

        pr.addFeatures(feats)
        from qgis.core import QgsVectorFileWriter
        QgsVectorFileWriter.writeAsVectorFormatV3(vl, out_dest, context.transformContext(), QgsVectorFileWriter.SaveVectorOptions())
        return {self.OUTPUT: out_dest}


class BatchGeocodeAlgorithm(QgsProcessingAlgorithm):
    INPUT_FILE = "INPUT_FILE"
    ADDRESS_FIELD = "ADDRESS_FIELD"
    OUTPUT = "OUTPUT"

    def name(self):
        return "batch_geocode"

    def displayName(self):
        return "01.03 Batch geocode address table"

    def group(self):
        return "01 · Place Finder & Geocoding"

    def groupId(self):
        return "01_place_finder"

    def shortHelpString(self):
        return "Batch geocode an input table or CSV file containing place names or addresses into georeferenced points."

    def createInstance(self):
        return BatchGeocodeAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFile(self.INPUT_FILE, "Input CSV File", extension="csv"))
        self.addParameter(QgsProcessingParameterString(self.ADDRESS_FIELD, "Address / Place Field Name", defaultValue="address"))
        self.addParameter(QgsProcessingParameterVectorDestination(self.OUTPUT, "Output Geocoded Points Layer"))

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        csv_path = self.parameterAsFile(parameters, self.INPUT_FILE, context)
        addr_col = self.parameterAsString(parameters, self.ADDRESS_FIELD, context)
        out_dest = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)

        service = PlaceFinderService()
        provider = service.get_provider("photon")

        vl = QgsVectorLayer("Point?crs=EPSG:4326", "batch_geocoded", "memory")
        pr = vl.dataProvider()
        pr.addAttributes([
            QgsField("input_query", QVariant.String),
            QgsField("found_name", QVariant.String),
            QgsField("lat", QVariant.Double),
            QgsField("lon", QVariant.Double),
            QgsField("match_status", QVariant.String)
        ])
        vl.updateFields()

        rows = []
        with open(csv_path, "r", encoding="utf-8-sig") as f:
            reader = csv.DictReader(f)
            for r in reader:
                rows.append(r)

        feats = []
        for i, row in enumerate(rows):
            if feedback.isCanceled():
                break
            query = row.get(addr_col, "")
            res = provider.search(query=query, limit=1) if provider and query else []
            f = QgsFeature(vl.fields())
            if res:
                top = res[0]
                f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(top.lon, top.lat)))
                f.setAttribute("input_query", query)
                f.setAttribute("found_name", top.name)
                f.setAttribute("lat", top.lat)
                f.setAttribute("lon", top.lon)
                f.setAttribute("match_status", "MATCHED")
            else:
                f.setAttribute("input_query", query)
                f.setAttribute("match_status", "UNMATCHED")
            feats.append(f)

        pr.addFeatures(feats)
        from qgis.core import QgsVectorFileWriter
        QgsVectorFileWriter.writeAsVectorFormatV3(vl, out_dest, context.transformContext(), QgsVectorFileWriter.SaveVectorOptions())
        return {self.OUTPUT: out_dest}


class CoordinateParserAlgorithm(QgsProcessingAlgorithm):
    INPUT_FILE = "INPUT_FILE"
    COORD_FIELD = "COORD_FIELD"
    TARGET_CRS = "TARGET_CRS"
    OUTPUT = "OUTPUT"

    def name(self):
        return "coordinate_parser"

    def displayName(self):
        return "01.04 Parse coordinate strings"

    def group(self):
        return "01 · Place Finder & Geocoding"

    def groupId(self):
        return "01_place_finder"

    def shortHelpString(self):
        return "Parse freeform coordinate strings in Decimal Degrees (DD), DMS (Degrees Minutes Seconds), or UTM into spatial points."

    def createInstance(self):
        return CoordinateParserAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFile(self.INPUT_FILE, "Input CSV File", extension="csv"))
        self.addParameter(QgsProcessingParameterString(self.COORD_FIELD, "Coordinate Column Name", defaultValue="coordinates"))
        self.addParameter(QgsProcessingParameterCrs(self.TARGET_CRS, "Coordinate Reference System", defaultValue="EPSG:4326"))
        self.addParameter(QgsProcessingParameterVectorDestination(self.OUTPUT, "Output Points Layer"))

    def _parse_dms(self, text: str) -> Optional[Tuple[float, float]]:
        # Match standard DD: e.g. "48.8584, 2.2945" or "-12.34 56.78"
        m_dd = re.search(r"([-+]?\d{1,3}(?:\.\d+)?)[,\s]+([-+]?\d{1,3}(?:\.\d+)?)", text)
        if m_dd:
            v1, v2 = float(m_dd.group(1)), float(m_dd.group(2))
            if abs(v1) <= 90 and abs(v2) <= 180:
                return v1, v2 # lat, lon
            return v2, v1
        return None

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        csv_path = self.parameterAsFile(parameters, self.INPUT_FILE, context)
        col_name = self.parameterAsString(parameters, self.COORD_FIELD, context)
        crs = self.parameterAsCrs(parameters, self.TARGET_CRS, context)
        out_dest = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)

        vl = QgsVectorLayer(f"Point?crs={crs.authid()}", "parsed_coordinates", "memory")
        pr = vl.dataProvider()
        pr.addAttributes([
            QgsField("raw_string", QVariant.String),
            QgsField("lat", QVariant.Double),
            QgsField("lon", QVariant.Double),
            QgsField("parse_status", QVariant.String)
        ])
        vl.updateFields()

        feats = []
        with open(csv_path, "r", encoding="utf-8-sig") as f:
            reader = csv.DictReader(f)
            for r in reader:
                raw = r.get(col_name, "")
                parsed = self._parse_dms(raw)
                feat = QgsFeature(vl.fields())
                feat.setAttribute("raw_string", raw)
                if parsed:
                    lat, lon = parsed
                    feat.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(lon, lat)))
                    feat.setAttribute("lat", lat)
                    feat.setAttribute("lon", lon)
                    feat.setAttribute("parse_status", "SUCCESS")
                else:
                    feat.setAttribute("parse_status", "FAILED")
                feats.append(feat)

        pr.addFeatures(feats)
        from qgis.core import QgsVectorFileWriter
        QgsVectorFileWriter.writeAsVectorFormatV3(vl, out_dest, context.transformContext(), QgsVectorFileWriter.SaveVectorOptions())
        return {self.OUTPUT: out_dest}


class TransformCoordinatesAlgorithm(QgsProcessingAlgorithm):
    INPUT_LAYER = "INPUT_LAYER"
    TARGET_CRS = "TARGET_CRS"
    OUTPUT = "OUTPUT"

    def name(self):
        return "transform_coordinates"

    def displayName(self):
        return "01.05 Transform coordinate table"

    def group(self):
        return "01 · Place Finder & Geocoding"

    def groupId(self):
        return "01_place_finder"

    def shortHelpString(self):
        return "Transform layer coordinate systems with explicit datum operations and accuracy reporting."

    def createInstance(self):
        return TransformCoordinatesAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFeatureSource(self.INPUT_LAYER, "Input Layer"))
        self.addParameter(QgsProcessingParameterCrs(self.TARGET_CRS, "Target CRS", defaultValue="EPSG:3857"))
        self.addParameter(QgsProcessingParameterVectorDestination(self.OUTPUT, "Output Transformed Layer"))

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        source = self.parameterAsSource(parameters, self.INPUT_LAYER, context)
        target_crs = self.parameterAsCrs(parameters, self.TARGET_CRS, context)
        out_dest = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)

        ct = QgsCoordinateTransform(source.sourceCrs(), target_crs, context.transformContext())
        vl = QgsVectorLayer(f"{QgsWkbTypes.displayString(source.wkbType())}?crs={target_crs.authid()}", "transformed", "memory")
        pr = vl.dataProvider()
        pr.addAttributes(list(source.fields()))
        vl.updateFields()

        feats = []
        for feat in source.getFeatures():
            g = feat.geometry()
            g.transform(ct)
            new_f = QgsFeature(vl.fields())
            new_f.setGeometry(g)
            for i in range(len(source.fields())):
                new_f.setAttribute(i, feat.attribute(i))
            feats.append(new_f)

        pr.addFeatures(feats)
        from qgis.core import QgsVectorFileWriter
        QgsVectorFileWriter.writeAsVectorFormatV3(vl, out_dest, context.transformContext(), QgsVectorFileWriter.SaveVectorOptions())
        return {self.OUTPUT: out_dest}


class NearestPlaceAlgorithm(QgsProcessingAlgorithm):
    INPUT_POINTS = "INPUT_POINTS"
    REFERENCE_LAYER = "REFERENCE_LAYER"
    OUTPUT = "OUTPUT"

    def name(self):
        return "nearest_place"

    def displayName(self):
        return "01.06 Find nearest gazetteer feature"

    def group(self):
        return "01 · Place Finder & Geocoding"

    def groupId(self):
        return "01_place_finder"

    def shortHelpString(self):
        return "Perform high-performance spatial index searches to associate input points with their nearest gazetteer reference features."

    def createInstance(self):
        return NearestPlaceAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFeatureSource(self.INPUT_POINTS, "Input Query Points", [QgsProcessing.TypeVectorPoint]))
        self.addParameter(QgsProcessingParameterFeatureSource(self.REFERENCE_LAYER, "Reference Gazetteer Layer", [QgsProcessing.TypeVectorPoint]))
        self.addParameter(QgsProcessingParameterVectorDestination(self.OUTPUT, "Output Points with Nearest Place"))

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        pts = self.parameterAsSource(parameters, self.INPUT_POINTS, context)
        ref = self.parameterAsSource(parameters, self.REFERENCE_LAYER, context)
        out_dest = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)

        from qgis.core import QgsSpatialIndex
        idx = QgsSpatialIndex(ref.getFeatures())

        vl = QgsVectorLayer("Point?crs=" + pts.sourceCrs().authid(), "nearest_places", "memory")
        pr = vl.dataProvider()
        pr.addAttributes(list(pts.fields()) + [
            QgsField("nearest_fid", QVariant.Int),
            QgsField("nearest_distance_m", QVariant.Double)
        ])
        vl.updateFields()

        feats = []
        for feat in pts.getFeatures():
            pt = feat.geometry().asPoint()
            nearest_ids = idx.nearestNeighbor(pt, 1)
            new_f = QgsFeature(vl.fields())
            new_f.setGeometry(feat.geometry())
            for i in range(len(pts.fields())):
                new_f.setAttribute(i, feat.attribute(i))

            if nearest_ids:
                n_id = nearest_ids[0]
                n_feat = ref.getFeature(n_id)
                dist = feat.geometry().distance(n_feat.geometry())
                new_f.setAttribute("nearest_fid", n_id)
                new_f.setAttribute("nearest_distance_m", dist)
            feats.append(new_f)

        pr.addFeatures(feats)
        from qgis.core import QgsVectorFileWriter
        QgsVectorFileWriter.writeAsVectorFormatV3(vl, out_dest, context.transformContext(), QgsVectorFileWriter.SaveVectorOptions())
        return {self.OUTPUT: out_dest}


class PlaceProximityAlgorithm(QgsProcessingAlgorithm):
    INPUT_POINTS = "INPUT_POINTS"
    REFERENCE_LAYER = "REFERENCE_LAYER"
    RADIUS_M = "RADIUS_M"
    OUTPUT = "OUTPUT"

    def name(self):
        return "place_proximity"

    def displayName(self):
        return "01.07 Search places within distance"

    def group(self):
        return "01 · Place Finder & Geocoding"

    def groupId(self):
        return "01_place_finder"

    def shortHelpString(self):
        return "Search for gazetteer features within a specified distance threshold of input points."

    def createInstance(self):
        return PlaceProximityAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFeatureSource(self.INPUT_POINTS, "Input Points", [QgsProcessing.TypeVectorPoint]))
        self.addParameter(QgsProcessingParameterFeatureSource(self.REFERENCE_LAYER, "Gazetteer Reference Layer", [QgsProcessing.TypeVectorPoint]))
        self.addParameter(QgsProcessingParameterDistance(self.RADIUS_M, "Search Radius (meters)", defaultValue=5000.0))
        self.addParameter(QgsProcessingParameterVectorDestination(self.OUTPUT, "Output Proximity Matches"))

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        pts = self.parameterAsSource(parameters, self.INPUT_POINTS, context)
        ref = self.parameterAsSource(parameters, self.REFERENCE_LAYER, context)
        radius = self.parameterAsDouble(parameters, self.RADIUS_M, context)
        out_dest = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)

        from qgis.core import QgsSpatialIndex
        idx = QgsSpatialIndex(ref.getFeatures())

        vl = QgsVectorLayer("Point?crs=" + pts.sourceCrs().authid(), "proximity_matches", "memory")
        pr = vl.dataProvider()
        pr.addAttributes(list(pts.fields()) + [
            QgsField("ref_fid", QVariant.Int),
            QgsField("distance", QVariant.Double)
        ])
        vl.updateFields()

        feats = []
        for feat in pts.getFeatures():
            pt = feat.geometry().asPoint()
            candidate_ids = idx.intersects(QgsGeometry.fromPointXY(pt).buffer(radius, 8).boundingBox())
            for c_id in candidate_ids:
                c_feat = ref.getFeature(c_id)
                d = feat.geometry().distance(c_feat.geometry())
                if d <= radius:
                    nf = QgsFeature(vl.fields())
                    nf.setGeometry(feat.geometry())
                    for i in range(len(pts.fields())):
                        nf.setAttribute(i, feat.attribute(i))
                    nf.setAttribute("ref_fid", c_id)
                    nf.setAttribute("distance", d)
                    feats.append(nf)

        pr.addFeatures(feats)
        from qgis.core import QgsVectorFileWriter
        QgsVectorFileWriter.writeAsVectorFormatV3(vl, out_dest, context.transformContext(), QgsVectorFileWriter.SaveVectorOptions())
        return {self.OUTPUT: out_dest}


class SearchWithinAOIAlgorithm(QgsProcessingAlgorithm):
    INPUT_AOI = "INPUT_AOI"
    REFERENCE_LAYER = "REFERENCE_LAYER"
    OUTPUT = "OUTPUT"

    def name(self):
        return "search_within_aoi"

    def displayName(self):
        return "01.08 Gazetteer places within boundary"

    def group(self):
        return "01 · Place Finder & Geocoding"

    def groupId(self):
        return "01_place_finder"

    def shortHelpString(self):
        return "Extract all gazetteer place points falling inside a defined Area of Interest (AOI) polygon."

    def createInstance(self):
        return SearchWithinAOIAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFeatureSource(self.INPUT_AOI, "AOI Polygon Layer", [QgsProcessing.TypeVectorPolygon]))
        self.addParameter(QgsProcessingParameterFeatureSource(self.REFERENCE_LAYER, "Gazetteer Point Layer", [QgsProcessing.TypeVectorPoint]))
        self.addParameter(QgsProcessingParameterVectorDestination(self.OUTPUT, "Output Filtered Points"))

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        aoi = self.parameterAsSource(parameters, self.INPUT_AOI, context)
        ref = self.parameterAsSource(parameters, self.REFERENCE_LAYER, context)
        out_dest = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)

        # Build unified AOI geometry
        aoi_geoms = [f.geometry() for f in aoi.getFeatures() if f.geometry()]
        combined_aoi = QgsGeometry.unaryUnion(aoi_geoms) if aoi_geoms else QgsGeometry()

        vl = QgsVectorLayer("Point?crs=" + ref.sourceCrs().authid(), "aoi_places", "memory")
        pr = vl.dataProvider()
        pr.addAttributes(list(ref.fields()))
        vl.updateFields()

        feats = []
        for feat in ref.getFeatures():
            if combined_aoi.contains(feat.geometry()):
                feats.append(feat)

        pr.addFeatures(feats)
        from qgis.core import QgsVectorFileWriter
        QgsVectorFileWriter.writeAsVectorFormatV3(vl, out_dest, context.transformContext(), QgsVectorFileWriter.SaveVectorOptions())
        return {self.OUTPUT: out_dest}


class OfflineGazetteerBuildAlgorithm(QgsProcessingAlgorithm):
    INPUT_POINTS = "INPUT_POINTS"
    NAME_FIELD = "NAME_FIELD"
    OUTPUT_SQLITE = "OUTPUT_SQLITE"

    def name(self):
        return "offline_gazetteer_build"

    def displayName(self):
        return "01.09 Build offline place index"

    def group(self):
        return "01 · Place Finder & Geocoding"

    def groupId(self):
        return "01_place_finder"

    def shortHelpString(self):
        return "Build a SQLite / Full-Text Search (FTS) offline gazetteer index from an existing point layer."

    def createInstance(self):
        return OfflineGazetteerBuildAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFeatureSource(self.INPUT_POINTS, "Input Points Layer", [QgsProcessing.TypeVectorPoint]))
        self.addParameter(QgsProcessingParameterString(self.NAME_FIELD, "Place Name Field", defaultValue="name"))
        self.addParameter(QgsProcessingParameterFileDestination(self.OUTPUT_SQLITE, "Output SQLite Database", fileFilter="SQLite (*.sqlite *.db)"))

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        pts = self.parameterAsSource(parameters, self.INPUT_POINTS, context)
        name_col = self.parameterAsString(parameters, self.NAME_FIELD, context)
        out_db = self.parameterAsFileOutput(parameters, self.OUTPUT_SQLITE, context)

        import sqlite3
        os.makedirs(os.path.dirname(os.path.abspath(out_db)), exist_ok=True)
        if os.path.exists(out_db):
            os.remove(out_db)

        conn = sqlite3.connect(out_db)
        cur = conn.cursor()
        cur.execute("CREATE TABLE places (id INTEGER PRIMARY KEY, name TEXT, lat REAL, lon REAL)")
        cur.execute("CREATE INDEX idx_name ON places(name)")

        rows = []
        for feat in pts.getFeatures():
            name_val = feat.attribute(name_col)
            pt = feat.geometry().asPoint()
            if name_val:
                rows.append((str(name_val), pt.y(), pt.x()))

        cur.executemany("INSERT INTO places (name, lat, lon) VALUES (?, ?, ?)", rows)
        conn.commit()
        conn.close()
        return {self.OUTPUT_SQLITE: out_db}


class GazetteerQualityAuditAlgorithm(QgsProcessingAlgorithm):
    INPUT_LAYER = "INPUT_LAYER"
    NAME_FIELD = "NAME_FIELD"
    OUTPUT_REPORT = "OUTPUT_REPORT"

    def name(self):
        return "gazetteer_quality_audit"

    def displayName(self):
        return "01.10 Audit geocoding quality"

    def group(self):
        return "01 · Place Finder & Geocoding"

    def groupId(self):
        return "01_place_finder"

    def shortHelpString(self):
        return "Audit geocoding results for duplicates, spatial outliers, missing coordinates, and match confidence issues."

    def createInstance(self):
        return GazetteerQualityAuditAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFeatureSource(self.INPUT_LAYER, "Input Geocoded Layer", [QgsProcessing.TypeVectorPoint]))
        self.addParameter(QgsProcessingParameterString(self.NAME_FIELD, "Place Name Field", defaultValue="name"))
        self.addParameter(QgsProcessingParameterFileDestination(self.OUTPUT_REPORT, "Output Quality JSON Report", fileFilter="JSON (*.json)"))

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        layer = self.parameterAsSource(parameters, self.INPUT_LAYER, context)
        name_col = self.parameterAsString(parameters, self.NAME_FIELD, context)
        out_rep = self.parameterAsFileOutput(parameters, self.OUTPUT_REPORT, context)

        seen_names = {}
        missing_coords = 0
        total = 0

        for f in layer.getFeatures():
            total += 1
            n = str(f.attribute(name_col) or "").strip().lower()
            if n:
                seen_names[n] = seen_names.get(n, 0) + 1
            if not f.geometry() or f.geometry().isEmpty():
                missing_coords += 1

        duplicates = {k: v for k, v in seen_names.items() if v > 1}

        report = {
            "total_records": total,
            "missing_geometry_count": missing_coords,
            "duplicate_names_count": len(duplicates),
            "top_duplicates": sorted(duplicates.items(), key=lambda x: x[1], reverse=True)[:10],
            "quality_score_pct": max(0.0, 100.0 - ((missing_coords + len(duplicates)) / (total or 1)) * 100.0)
        }

        os.makedirs(os.path.dirname(os.path.abspath(out_rep)), exist_ok=True)
        with open(out_rep, "w", encoding="utf-8") as f:
            json.dump(report, f, indent=2)

        return {self.OUTPUT_REPORT: out_rep}

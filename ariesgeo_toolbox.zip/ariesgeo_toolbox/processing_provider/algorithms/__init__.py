"""
Processing algorithm definitions for AriesGeo Toolbox.
"""

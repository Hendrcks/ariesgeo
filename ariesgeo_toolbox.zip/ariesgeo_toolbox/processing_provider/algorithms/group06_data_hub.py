"""
Processing algorithms for Group 06: Data Hub & Acquisition (8 algorithms).
"""

import os
import json
from typing import List, Dict, Any, Optional

from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterString,
    QgsProcessingParameterNumber,
    QgsProcessingParameterEnum,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterFile,
    QgsProcessingParameterFileDestination,
    QgsProcessingParameterVectorDestination,
    QgsProcessingParameterFeatureSource,
    QgsProcessingOutputVectorLayer,
    QgsProcessingOutputFile,
    QgsProcessingContext,
    QgsProcessingFeedback,
    QgsVectorLayer,
    QgsField,
    QgsFeature,
    QgsGeometry,
    QgsVectorFileWriter
)
from qgis.PyQt.QtCore import QVariant

from ...data_hub.stac_client import search_stac, inspect_stac_asset, DEFAULT_STAC_ENDPOINTS
from ...data_hub.catalog_search import search_landsat_catalog, search_sentinel_catalog, search_dem_coverage
from ...data_hub.osm_importer import import_osm_extract
from ...data_hub.download_manager import download_asset_file
from ...data_hub.local_indexer import build_local_spatial_catalog


class CatalogStacSearchAlgorithm(QgsProcessingAlgorithm):
    ENDPOINT_URL = "ENDPOINT_URL"
    BBOX = "BBOX"
    COLLECTION = "COLLECTION"
    DATE_RANGE = "DATE_RANGE"
    OUTPUT_JSON = "OUTPUT_JSON"

    def name(self):
        return "catalog_stac_search"

    def displayName(self):
        return "06.01 Search STAC collections/items"

    def group(self):
        return "06 · Data Hub & Acquisition"

    def groupId(self):
        return "06_data_hub"

    def shortHelpString(self):
        return "Search standard SpatioTemporal Asset Catalog (STAC API 1.0) endpoints by bounding box and date range."

    def createInstance(self):
        return CatalogStacSearchAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterString(self.ENDPOINT_URL, "STAC Search Endpoint URL", defaultValue="https://earth-search.aws.element84.com/v1/search"))
        self.addParameter(QgsProcessingParameterString(self.BBOX, "Bounding Box (minX, minY, maxX, maxY)", defaultValue="-122.5, 37.7, -122.3, 37.9"))
        self.addParameter(QgsProcessingParameterString(self.COLLECTION, "Collection ID", defaultValue="sentinel-2-l2a"))
        self.addParameter(QgsProcessingParameterString(self.DATE_RANGE, "Date Range (ISO 8601 start/end)", defaultValue="2024-01-01T00:00:00Z/2024-06-30T23:59:59Z"))
        self.addParameter(QgsProcessingParameterFileDestination(self.OUTPUT_JSON, "Output STAC Results GeoJSON", fileFilter="GeoJSON (*.geojson *.json)"))

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        url = self.parameterAsString(parameters, self.ENDPOINT_URL, context)
        bbox_str = self.parameterAsString(parameters, self.BBOX, context)
        coll = self.parameterAsString(parameters, self.COLLECTION, context)
        dt = self.parameterAsString(parameters, self.DATE_RANGE, context)
        out_dest = self.parameterAsFileOutput(parameters, self.OUTPUT_JSON, context)

        bbox = [float(x.strip()) for x in bbox_str.split(",")]
        res = search_stac(endpoint_url=url, bbox=bbox, collections=[coll] if coll else None, datetime_range=dt, limit=20)

        os.makedirs(os.path.dirname(os.path.abspath(out_dest)), exist_ok=True)
        with open(out_dest, "w", encoding="utf-8") as f:
            json.dump(res, f, indent=2)

        return {self.OUTPUT_JSON: out_dest}


class CatalogAssetInspectAlgorithm(QgsProcessingAlgorithm):
    INPUT_ITEM = "INPUT_ITEM"
    OUTPUT_REPORT = "OUTPUT_REPORT"

    def name(self):
        return "catalog_asset_inspect"

    def displayName(self):
        return "06.02 Inspect data asset"

    def group(self):
        return "06 · Data Hub & Acquisition"

    def groupId(self):
        return "06_data_hub"

    def shortHelpString(self):
        return "Inspect a STAC item or remote geospatial asset URL, retrieving available bands, roles, and COG headers."

    def createInstance(self):
        return CatalogAssetInspectAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFile(self.INPUT_ITEM, "STAC Item JSON File", extension="json"))
        self.addParameter(QgsProcessingParameterFileDestination(self.OUTPUT_REPORT, "Output Asset Report JSON", fileFilter="JSON (*.json)"))

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        item_path = self.parameterAsFile(parameters, self.INPUT_ITEM, context)
        out_rep = self.parameterAsFileOutput(parameters, self.OUTPUT_REPORT, context)

        with open(item_path, "r", encoding="utf-8") as f:
            item_data = json.load(f)

        rep = inspect_stac_asset(item_data)
        os.makedirs(os.path.dirname(os.path.abspath(out_rep)), exist_ok=True)
        with open(out_rep, "w", encoding="utf-8") as f:
            json.dump(rep, f, indent=2)

        return {self.OUTPUT_REPORT: out_rep}


class CatalogLandsatSearchAlgorithm(QgsProcessingAlgorithm):
    BBOX = "BBOX"
    START_DATE = "START_DATE"
    END_DATE = "END_DATE"
    MAX_CLOUD = "MAX_CLOUD"
    OUTPUT_JSON = "OUTPUT_JSON"

    def name(self):
        return "catalog_landsat_search"

    def displayName(self):
        return "06.03 Search supported Landsat catalog"

    def group(self):
        return "06 · Data Hub & Acquisition"

    def groupId(self):
        return "06_data_hub"

    def shortHelpString(self):
        return "Search for Landsat 7, 8, and 9 Collection 2 Level-2 Surface Reflectance scenes over an AOI."

    def createInstance(self):
        return CatalogLandsatSearchAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterString(self.BBOX, "Bounding Box (minLon, minLat, maxLon, maxLat)", defaultValue="-122.5, 37.5, -122.0, 38.0"))
        self.addParameter(QgsProcessingParameterString(self.START_DATE, "Start Date (YYYY-MM-DD)", defaultValue="2023-01-01"))
        self.addParameter(QgsProcessingParameterString(self.END_DATE, "End Date (YYYY-MM-DD)", defaultValue="2023-12-31"))
        self.addParameter(QgsProcessingParameterNumber(self.MAX_CLOUD, "Max Cloud Cover (%)", defaultValue=25.0, minValue=0.0, maxValue=100.0))
        self.addParameter(QgsProcessingParameterFileDestination(self.OUTPUT_JSON, "Output Landsat Catalog JSON", fileFilter="JSON (*.json)"))

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        bbox_str = self.parameterAsString(parameters, self.BBOX, context)
        start = self.parameterAsString(parameters, self.START_DATE, context)
        end = self.parameterAsString(parameters, self.END_DATE, context)
        mc = self.parameterAsDouble(parameters, self.MAX_CLOUD, context)
        out_dest = self.parameterAsFileOutput(parameters, self.OUTPUT_JSON, context)

        bbox = [float(x.strip()) for x in bbox_str.split(",")]
        res = search_landsat_catalog(bbox, start, end, max_cloud_cover=mc)

        os.makedirs(os.path.dirname(os.path.abspath(out_dest)), exist_ok=True)
        with open(out_dest, "w", encoding="utf-8") as f:
            json.dump({"scenes_found": len(res), "scenes": res}, f, indent=2)

        return {self.OUTPUT_JSON: out_dest}


class CatalogSentinelSearchAlgorithm(QgsProcessingAlgorithm):
    BBOX = "BBOX"
    START_DATE = "START_DATE"
    END_DATE = "END_DATE"
    MAX_CLOUD = "MAX_CLOUD"
    OUTPUT_JSON = "OUTPUT_JSON"

    def name(self):
        return "catalog_sentinel_search"

    def displayName(self):
        return "06.04 Search Sentinel catalog"

    def group(self):
        return "06 · Data Hub & Acquisition"

    def groupId(self):
        return "06_data_hub"

    def shortHelpString(self):
        return "Search for Copernicus Sentinel-2 L2A Bottom-Of-Atmosphere reflectance scenes over an AOI."

    def createInstance(self):
        return CatalogSentinelSearchAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterString(self.BBOX, "Bounding Box (minLon, minLat, maxLon, maxLat)", defaultValue="2.2, 48.7, 2.5, 49.0"))
        self.addParameter(QgsProcessingParameterString(self.START_DATE, "Start Date (YYYY-MM-DD)", defaultValue="2024-01-01"))
        self.addParameter(QgsProcessingParameterString(self.END_DATE, "End Date (YYYY-MM-DD)", defaultValue="2024-06-30"))
        self.addParameter(QgsProcessingParameterNumber(self.MAX_CLOUD, "Max Cloud Cover (%)", defaultValue=20.0, minValue=0.0, maxValue=100.0))
        self.addParameter(QgsProcessingParameterFileDestination(self.OUTPUT_JSON, "Output Sentinel Catalog JSON", fileFilter="JSON (*.json)"))

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        bbox_str = self.parameterAsString(parameters, self.BBOX, context)
        start = self.parameterAsString(parameters, self.START_DATE, context)
        end = self.parameterAsString(parameters, self.END_DATE, context)
        mc = self.parameterAsDouble(parameters, self.MAX_CLOUD, context)
        out_dest = self.parameterAsFileOutput(parameters, self.OUTPUT_JSON, context)

        bbox = [float(x.strip()) for x in bbox_str.split(",")]
        res = search_sentinel_catalog(bbox, start, end, max_cloud_cover=mc)

        os.makedirs(os.path.dirname(os.path.abspath(out_dest)), exist_ok=True)
        with open(out_dest, "w", encoding="utf-8") as f:
            json.dump({"scenes_found": len(res), "scenes": res}, f, indent=2)

        return {self.OUTPUT_JSON: out_dest}


class CatalogDemSearchAlgorithm(QgsProcessingAlgorithm):
    BBOX = "BBOX"
    OUTPUT_REPORT = "OUTPUT_REPORT"

    def name(self):
        return "catalog_dem_search"

    def displayName(self):
        return "06.05 Locate DEM coverage"

    def group(self):
        return "06 · Data Hub & Acquisition"

    def groupId(self):
        return "06_data_hub"

    def shortHelpString(self):
        return "Locate available open elevation data coverage (Copernicus DEM 30m, SRTM, NASADEM) for an AOI."

    def createInstance(self):
        return CatalogDemSearchAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterString(self.BBOX, "Bounding Box (minLon, minLat, maxLon, maxLat)", defaultValue="-120.0, 35.0, -119.0, 36.0"))
        self.addParameter(QgsProcessingParameterFileDestination(self.OUTPUT_REPORT, "Output DEM Coverage Report JSON", fileFilter="JSON (*.json)"))

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        bbox_str = self.parameterAsString(parameters, self.BBOX, context)
        out_rep = self.parameterAsFileOutput(parameters, self.OUTPUT_REPORT, context)

        bbox = [float(x.strip()) for x in bbox_str.split(",")]
        candidates = search_dem_coverage(bbox)

        os.makedirs(os.path.dirname(os.path.abspath(out_rep)), exist_ok=True)
        with open(out_rep, "w", encoding="utf-8") as f:
            json.dump({"bbox": bbox, "available_dem_sources": candidates}, f, indent=2)

        return {self.OUTPUT_REPORT: out_rep}


class CatalogOsmImportAlgorithm(QgsProcessingAlgorithm):
    BBOX = "BBOX"
    FEATURE_TYPE = "FEATURE_TYPE"
    OUTPUT_GPKG = "OUTPUT_GPKG"
    TYPES = ["Roads & Highways", "Buildings & Footprints", "Waterways & Rivers"]

    def name(self):
        return "catalog_osm_import"

    def displayName(self):
        return "06.06 Import permitted OSM extract"

    def group(self):
        return "06 · Data Hub & Acquisition"

    def groupId(self):
        return "06_data_hub"

    def shortHelpString(self):
        return "Extract OpenStreetMap features (roads, buildings, waterways) for an AOI and export into a GeoPackage."

    def createInstance(self):
        return CatalogOsmImportAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterString(self.BBOX, "Bounding Box (minLat, minLon, maxLat, maxLon)", defaultValue="48.85, 2.34, 48.86, 2.36"))
        self.addParameter(QgsProcessingParameterEnum(self.FEATURE_TYPE, "Feature Type to Extract", options=self.TYPES, defaultValue=0))
        self.addParameter(QgsProcessingParameterVectorDestination(self.OUTPUT_GPKG, "Output GeoPackage (*.gpkg)"))

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        bbox_str = self.parameterAsString(parameters, self.BBOX, context)
        type_idx = self.parameterAsEnum(parameters, self.FEATURE_TYPE, context)
        out_dest = self.parameterAsOutputLayer(parameters, self.OUTPUT_GPKG, context)

        bbox = [float(x.strip()) for x in bbox_str.split(",")]
        ft_map = {0: "roads", 1: "buildings", 2: "waterways"}
        import_osm_extract(bbox, feature_type=ft_map.get(type_idx, "roads"), output_gpkg_path=out_dest)
        return {self.OUTPUT_GPKG: out_dest}


class DownloadAssetsAlgorithm(QgsProcessingAlgorithm):
    URL = "URL"
    EXPECTED_SHA256 = "EXPECTED_SHA256"
    OUTPUT_FILE = "OUTPUT_FILE"

    def name(self):
        return "download_assets"

    def displayName(self):
        return "06.07 Controlled asset download"

    def group(self):
        return "06 · Data Hub & Acquisition"

    def groupId(self):
        return "06_data_hub"

    def shortHelpString(self):
        return "Download remote geospatial assets in chunks with rate limits, resume support, and SHA-256 hash checks."

    def createInstance(self):
        return DownloadAssetsAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterString(self.URL, "Asset Download URL"))
        self.addParameter(QgsProcessingParameterString(self.EXPECTED_SHA256, "Expected SHA-256 Checksum (Optional)", optional=True))
        self.addParameter(QgsProcessingParameterFileDestination(self.OUTPUT_FILE, "Output Download Destination Path"))

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        url = self.parameterAsString(parameters, self.URL, context)
        sha = self.parameterAsString(parameters, self.EXPECTED_SHA256, context) or None
        out_dest = self.parameterAsFileOutput(parameters, self.OUTPUT_FILE, context)

        def on_prog(p, msg):
            feedback.setProgress(p)
            feedback.pushInfo(msg)

        download_asset_file(url, out_dest, expected_sha256=sha, progress_callback=on_prog)
        return {self.OUTPUT_FILE: out_dest}


class LocalCatalogIndexAlgorithm(QgsProcessingAlgorithm):
    INPUT_FOLDER = "INPUT_FOLDER"
    OUTPUT_SQLITE = "OUTPUT_SQLITE"

    def name(self):
        return "local_catalog_index"

    def displayName(self):
        return "06.08 Index local datasets"

    def group(self):
        return "06 · Data Hub & Acquisition"

    def groupId(self):
        return "06_data_hub"

    def shortHelpString(self):
        return "Scan and index local directory trees containing raster and vector datasets into a searchable spatial catalog database."

    def createInstance(self):
        return LocalCatalogIndexAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFile(self.INPUT_FOLDER, "Directory to Scan", behavior=QgsProcessingParameterFile.Folder))
        self.addParameter(QgsProcessingParameterFileDestination(self.OUTPUT_SQLITE, "Output SQLite Spatial Catalog Database", fileFilter="SQLite (*.sqlite *.db)"))

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        folder = self.parameterAsFile(parameters, self.INPUT_FOLDER, context)
        out_db = self.parameterAsFileOutput(parameters, self.OUTPUT_SQLITE, context)

        build_local_spatial_catalog([folder], out_db)
        return {self.OUTPUT_SQLITE: out_db}


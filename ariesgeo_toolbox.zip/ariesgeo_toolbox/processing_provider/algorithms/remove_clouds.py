"""
Processing algorithm: Remove Cloud Cover.
"""

from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterMultipleLayers,
    QgsProcessingParameterNumber,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterRasterDestination,
    QgsProcessingContext,
    QgsProcessingFeedback,
)
from ...raster.cloud_remover import CloudRemover

class RemoveCloudsAlgorithm(QgsProcessingAlgorithm):
    TARGET_SCENE = "TARGET_SCENE"
    DONOR_SCENES = "DONOR_SCENES"
    THRESHOLD = "THRESHOLD"
    APPLY_RADIOMETRY = "APPLY_RADIOMETRY"
    OUTPUT_RASTER = "OUTPUT_RASTER"
    OUTPUT_MASK = "OUTPUT_MASK"

    def name(self):
        return "remove_clouds"

    def displayName(self):
        return "Remove Cloud Cover (Multi-Temporal)"

    def group(self):
        return "Mosaic & GapFill"

    def groupId(self):
        return "raster"

    def shortHelpString(self):
        return "Detect and remove clouds/shadows from imagery using clear donor scenes and radiometric normalization."

    def createInstance(self):
        return RemoveCloudsAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterRasterLayer(
                self.TARGET_SCENE,
                "Cloudy Target Image"
            )
        )
        self.addParameter(
            QgsProcessingParameterMultipleLayers(
                self.DONOR_SCENES,
                "Clear Donor Image(s)",
                layerType=getattr(QgsProcessing, "TypeRaster", None) or getattr(getattr(QgsProcessing, "SourceType", None), "TypeRaster", 1)
            )
        )
        self.addParameter(
            QgsProcessingParameterNumber(
                self.THRESHOLD,
                "Cloud Brightness Threshold",
                type=QgsProcessingParameterNumber.Double,
                defaultValue=0.65,
                minValue=0.1,
                maxValue=1.0
            )
        )
        self.addParameter(
            QgsProcessingParameterBoolean(
                self.APPLY_RADIOMETRY,
                "Apply Linear Regression Radiometric Balancing",
                defaultValue=True
            )
        )
        self.addParameter(
            QgsProcessingParameterRasterDestination(
                self.OUTPUT_RASTER,
                "Cloud-Free Output Image"
            )
        )
        self.addParameter(
            QgsProcessingParameterRasterDestination(
                self.OUTPUT_MASK,
                "Cloud Mask (Optional)",
                optional=True
            )
        )

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        target_layer = self.parameterAsRasterLayer(parameters, self.TARGET_SCENE, context)
        donor_layers = self.parameterAsLayerList(parameters, self.DONOR_SCENES, context)
        thresh = self.parameterAsDouble(parameters, self.THRESHOLD, context)
        apply_rad = self.parameterAsBoolean(parameters, self.APPLY_RADIOMETRY, context)
        out_raster = self.parameterAsOutputLayer(parameters, self.OUTPUT_RASTER, context)
        out_mask = self.parameterAsOutputLayer(parameters, self.OUTPUT_MASK, context) if self.OUTPUT_MASK in parameters else None

        donor_paths = [l.source() for l in donor_layers if hasattr(l, "source")]

        def cb(pct, msg):
            feedback.setProgress(int(pct * 100))
            if msg:
                feedback.pushInfo(msg)

        feedback.pushInfo(f"Removing clouds from {target_layer.source()} using {len(donor_paths)} donor(s)...")
        stats = CloudRemover.remove_clouds_multitemporal(
            target_scene_path=target_layer.source(),
            donor_scene_paths=donor_paths,
            output_raster_path=out_raster,
            output_mask_path=out_mask,
            brightness_threshold=thresh,
            apply_radiometry=apply_rad,
            progress_callback=cb
        )

        feedback.pushInfo(f"Cloud removal complete! Cloud coverage was: {stats['cloud_coverage_percent']}%")
        return {self.OUTPUT_RASTER: out_raster}

"""
Processing algorithm: Remove Cloud Cover & SLC-Off Gaps (USGS Gapfill + Cloud Remover).
"""

from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterMultipleLayers,
    QgsProcessingParameterEnum,
    QgsProcessingParameterNumber,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterRasterDestination,
    QgsProcessingContext,
    QgsProcessingFeedback,
)
from ...raster.cloud_remover import CloudRemover


class RemoveCloudsAlgorithm(QgsProcessingAlgorithm):
    TARGET_SCENE = "TARGET_SCENE"
    DONOR_SCENES = "DONOR_SCENES"
    THRESHOLD = "THRESHOLD"
    DETECT_SHADOWS = "DETECT_SHADOWS"
    INCLUDE_SLC_GAPS = "INCLUDE_SLC_GAPS"
    HARMONIZATION_METHOD = "HARMONIZATION_METHOD"
    APPLY_RADIOMETRY = "APPLY_RADIOMETRY"
    OUTPUT_RASTER = "OUTPUT_RASTER"
    OUTPUT_MASK = "OUTPUT_MASK"

    HARMONIZATION_OPTIONS = [
        "USGS Local Linear Histogram Matching (LLHM - Phase 2)",
        "USGS Global Linear Histogram Matching (GLHM - Phase 1)",
        "Direct Clear-Pixel Substitution",
    ]

    def name(self):
        return "remove_clouds"

    def displayName(self):
        return "Remove Cloud Cover & SLC Gaps (USGS Gapfill)"

    def group(self):
        return "Mosaic & GapFill"

    def groupId(self):
        return "raster"

    def shortHelpString(self):
        return (
            "Detect and remove clouds, cast cloud shadows, and optional SLC-off scanline gaps "
            "using clear donor scenes with USGS Phase-2 Local Linear Histogram Matching (LLHM), "
            "automatic donor co-registration, or single-scene Delaunay triangulation when no donors are supplied."
        )

    def createInstance(self):
        return RemoveCloudsAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterRasterLayer(
                self.TARGET_SCENE,
                "Cloudy / Gapped Target Image"
            )
        )
        self.addParameter(
            QgsProcessingParameterMultipleLayers(
                self.DONOR_SCENES,
                "Clear Donor Image(s) (Optional — omit for Single-Scene Triangulation)",
                layerType=getattr(QgsProcessing, "TypeRaster", None) or getattr(getattr(QgsProcessing, "SourceType", None), "TypeRaster", 1),
                optional=True
            )
        )
        self.addParameter(
            QgsProcessingParameterNumber(
                self.THRESHOLD,
                "Cloud Brightness Threshold",
                type=QgsProcessingParameterNumber.Double,
                defaultValue=0.65,
                minValue=0.1,
                maxValue=1.0
            )
        )
        self.addParameter(
            QgsProcessingParameterBoolean(
                self.DETECT_SHADOWS,
                "Detect & Remove Cast Cloud Shadows",
                defaultValue=True
            )
        )
        self.addParameter(
            QgsProcessingParameterBoolean(
                self.INCLUDE_SLC_GAPS,
                "Also Repair Landsat 7 SLC-Off Stripes / Internal NoData Gaps",
                defaultValue=False
            )
        )
        self.addParameter(
            QgsProcessingParameterEnum(
                self.HARMONIZATION_METHOD,
                "Radiometric Harmonization Method",
                options=self.HARMONIZATION_OPTIONS,
                defaultValue=0,
                optional=True
            )
        )
        self.addParameter(
            QgsProcessingParameterBoolean(
                self.APPLY_RADIOMETRY,
                "Apply Radiometric Balancing",
                defaultValue=True
            )
        )
        self.addParameter(
            QgsProcessingParameterRasterDestination(
                self.OUTPUT_RASTER,
                "Cloud-Free Output Image"
            )
        )
        self.addParameter(
            QgsProcessingParameterRasterDestination(
                self.OUTPUT_MASK,
                "Cloud / Gap Mask (Optional)",
                optional=True
            )
        )

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        target_layer = self.parameterAsRasterLayer(parameters, self.TARGET_SCENE, context)
        if not target_layer or not target_layer.isValid():
            raise ValueError("Invalid target raster layer provided.")

        donor_layers = self.parameterAsLayerList(parameters, self.DONOR_SCENES, context) if self.DONOR_SCENES in parameters else []
        thresh = self.parameterAsDouble(parameters, self.THRESHOLD, context)
        detect_shadows = self.parameterAsBoolean(parameters, self.DETECT_SHADOWS, context) if self.DETECT_SHADOWS in parameters else True
        include_slc = self.parameterAsBoolean(parameters, self.INCLUDE_SLC_GAPS, context) if self.INCLUDE_SLC_GAPS in parameters else False
        harm_idx = self.parameterAsEnum(parameters, self.HARMONIZATION_METHOD, context) if self.HARMONIZATION_METHOD in parameters else 0
        apply_rad = self.parameterAsBoolean(parameters, self.APPLY_RADIOMETRY, context) if self.APPLY_RADIOMETRY in parameters else True
        out_raster = self.parameterAsOutputLayer(parameters, self.OUTPUT_RASTER, context)
        out_mask = self.parameterAsOutputLayer(parameters, self.OUTPUT_MASK, context) if self.OUTPUT_MASK in parameters else None
        out_mask = out_mask or None

        target_path = target_layer.source().split("|")[0]
        donor_paths = [
            l.source().split("|")[0]
            for l in (donor_layers or [])
            if l is not None and hasattr(l, "source") and (not hasattr(l, "isValid") or l.isValid())
        ]

        harm_map = {0: "llhm", 1: "glhm", 2: "none"}
        harm_method = harm_map.get(harm_idx, "llhm") if apply_rad else "none"
        mask_mode = "slc_and_clouds" if include_slc else "spectral"

        def cb(pct, msg):
            progress_int = int(pct) if pct > 1.0 else int(pct * 100.0)
            feedback.setProgress(max(0, min(100, progress_int)))
            if msg:
                feedback.pushInfo(msg)

        if donor_paths:
            feedback.pushInfo(f"Removing clouds from {target_path} using {len(donor_paths)} donor(s) ({harm_method.upper()})...")
            stats = CloudRemover.remove_clouds_multitemporal(
                target_scene_path=target_path,
                donor_scene_paths=donor_paths,
                output_raster_path=out_raster,
                output_mask_path=out_mask,
                brightness_threshold=thresh,
                apply_radiometry=apply_rad,
                harmonization_method=harm_method,
                mask_mode=mask_mode,
                detect_shadows=detect_shadows,
                include_slc_gaps=include_slc,
                progress_callback=cb
            )
        else:
            feedback.pushInfo(f"No donor scenes supplied — running Single-Scene Delaunay Triangulation on {target_path}...")
            stats = CloudRemover.remove_clouds_spatial(
                input_raster_path=target_path,
                output_raster_path=out_raster,
                output_mask_path=out_mask,
                brightness_threshold=thresh,
                method="triangulation",
                mask_mode=mask_mode,
                detect_shadows=detect_shadows,
                include_slc_gaps=include_slc,
                progress_callback=cb
            )

        feedback.pushInfo(
            f"Cloud removal complete! Masked coverage: {stats['cloud_coverage_percent']}% | "
            f"Recovered pixels: {stats.get('filled_pixels', 0):,}"
        )
        results = {self.OUTPUT_RASTER: out_raster}
        if out_mask:
            results[self.OUTPUT_MASK] = out_mask
        return results

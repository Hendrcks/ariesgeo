"""
Processing algorithm: AriesGapfill Two-Image Local Matching (Method C).
"""

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterRasterDestination,
    QgsProcessingParameterNumber,
    QgsProcessingParameterBoolean,
    QgsProcessingOutputRasterLayer,
    QgsProcessingContext,
    QgsProcessingFeedback,
)
from ...gapfill.models import GapFillConfig, GapFillMethod, MethodParameters, DonorSpec
from ...gapfill.engine import AriesGapFillEngine


class GapfillLocalAlgorithm(QgsProcessingAlgorithm):
    INPUT_TARGET = "INPUT_TARGET"
    INPUT_DONOR = "INPUT_DONOR"
    INITIAL_WINDOW_SIZE = "INITIAL_WINDOW_SIZE"
    MIN_PAIRED_SAMPLES = "MIN_PAIRED_SAMPLES"
    CORRELATION_THRESHOLD = "CORRELATION_THRESHOLD"

    OUTPUT_FILLED = "OUTPUT_FILLED"
    OUTPUT_PROVENANCE = "OUTPUT_PROVENANCE"
    OUTPUT_CONFIDENCE = "OUTPUT_CONFIDENCE"

    def name(self):
        return "gapfill_local"

    def displayName(self):
        return "AriesGapfill: Two-Image Local Moving Window Matching"

    def group(self):
        return "AriesGapfill"

    def groupId(self):
        return "gapfill"

    def shortHelpString(self):
        return "Fills target gaps using moving-window local linear regression for spatially heterogeneous landscapes, with automatic window expansion and global fallback."

    def createInstance(self):
        return GapfillLocalAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterRasterLayer(
                self.INPUT_TARGET,
                "Input Target Raster (SLC-off)"
            )
        )
        self.addParameter(
            QgsProcessingParameterRasterLayer(
                self.INPUT_DONOR,
                "Input Donor Raster"
            )
        )
        self.addParameter(
            QgsProcessingParameterNumber(
                self.INITIAL_WINDOW_SIZE,
                "Initial Local Moving Window Size (Pixels)",
                type=QgsProcessingParameterNumber.Integer,
                defaultValue=51,
                minValue=15,
                maxValue=201
            )
        )
        self.addParameter(
            QgsProcessingParameterNumber(
                self.MIN_PAIRED_SAMPLES,
                "Minimum Valid Overlapping Samples",
                type=QgsProcessingParameterNumber.Integer,
                defaultValue=100,
                minValue=20
            )
        )
        self.addParameter(
            QgsProcessingParameterNumber(
                self.CORRELATION_THRESHOLD,
                "Local Correlation Threshold",
                type=QgsProcessingParameterNumber.Double,
                defaultValue=0.70,
                minValue=0.1,
                maxValue=0.99
            )
        )
        self.addParameter(
            QgsProcessingParameterRasterDestination(
                self.OUTPUT_FILLED,
                "Output Repaired Raster"
            )
        )
        self.addParameter(
            QgsProcessingParameterRasterDestination(
                self.OUTPUT_PROVENANCE,
                "Output Provenance Mask Raster",
                optional=True
            )
        )
        self.addParameter(
            QgsProcessingParameterRasterDestination(
                self.OUTPUT_CONFIDENCE,
                "Output Confidence Raster",
                optional=True
            )
        )

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        t_layer = self.parameterAsRasterLayer(parameters, self.INPUT_TARGET, context)
        d_layer = self.parameterAsRasterLayer(parameters, self.INPUT_DONOR, context)
        w_size = self.parameterAsInt(parameters, self.INITIAL_WINDOW_SIZE, context)
        min_samp = self.parameterAsInt(parameters, self.MIN_PAIRED_SAMPLES, context)
        corr_thresh = self.parameterAsDouble(parameters, self.CORRELATION_THRESHOLD, context)

        out_filled = self.parameterAsOutputLayer(parameters, self.OUTPUT_FILLED, context)
        out_prov = self.parameterAsOutputLayer(parameters, self.OUTPUT_PROVENANCE, context)
        out_conf = self.parameterAsOutputLayer(parameters, self.OUTPUT_CONFIDENCE, context)

        if not t_layer or not t_layer.isValid():
            raise ValueError("Invalid target raster layer provided.")
        if not d_layer or not d_layer.isValid():
            raise ValueError("Invalid donor raster layer provided.")

        cfg = GapFillConfig(
            target_path=t_layer.source(),
            method=GapFillMethod.LOCAL_MATCHING,
            donors=[DonorSpec(filepath=d_layer.source())],
            output_filled_path=out_filled,
            output_provenance_path=out_prov,
            output_confidence_path=out_conf,
            parameters=MethodParameters(
                initial_window_size=w_size,
                min_paired_samples=min_samp,
                correlation_threshold=corr_thresh,
                use_robust_regression=True
            )
        )

        def on_prog(p, msg):
            feedback.setProgress(p)
            feedback.pushInfo(msg)

        feedback.pushInfo("Running AriesGapfill Local Moving Window Matching...")
        res = AriesGapFillEngine.execute(cfg, progress_callback=on_prog)

        results = {self.OUTPUT_FILLED: out_filled}
        if out_prov:
            results[self.OUTPUT_PROVENANCE] = out_prov
        if out_conf:
            results[self.OUTPUT_CONFIDENCE] = out_conf

        feedback.pushInfo(f"Local matching complete: {res.filled_gap_count:,} gaps repaired ({res.overall_fill_rate_pct:.1f}%).")
        return results

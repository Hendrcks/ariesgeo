"""
Processing algorithm: Export Map Layout.
"""

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterString,
    QgsProcessingParameterEnum,
    QgsProcessingParameterFileDestination,
    QgsProcessingParameterNumber,
    QgsProcessingParameterBoolean,
    QgsProcessingOutputString,
    QgsProcessingContext,
    QgsProcessingFeedback,
    QgsProject,
)
from ...layout_assistant.exporter import LayoutExporter
from ...layout_assistant.quality import LayoutQualityChecker

class ExportLayoutAlgorithm(QgsProcessingAlgorithm):
    LAYOUT_NAME = "LAYOUT_NAME"
    FORMAT = "FORMAT"
    DPI = "DPI"
    GEOREFERENCED = "GEOREFERENCED"
    CHECK_QUALITY = "CHECK_QUALITY"
    OUTPUT_FILE = "OUTPUT_FILE"
    RESULT_PATH = "RESULT_PATH"

    FORMATS = ["PDF", "PNG", "SVG", "GeoPDF"]

    def name(self):
        return "export_layout"

    def displayName(self):
        return "Export Map Layout"

    def group(self):
        return "Map Layout Assistant"

    def groupId(self):
        return "layout_assistant"

    def shortHelpString(self):
        return "Exports an existing QGIS Print Layout to PDF, GeoPDF, PNG, or SVG at high resolution."

    def createInstance(self):
        return ExportLayoutAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterString(
                self.LAYOUT_NAME,
                "Layout Name",
                defaultValue="Aries_Auto_Layout"
            )
        )
        self.addParameter(
            QgsProcessingParameterEnum(
                self.FORMAT,
                "Output Format",
                options=self.FORMATS,
                defaultValue=0
            )
        )
        self.addParameter(
            QgsProcessingParameterNumber(
                self.DPI,
                "Export Resolution (DPI)",
                type=QgsProcessingParameterNumber.Integer,
                defaultValue=300,
                minValue=72,
                maxValue=1200
            )
        )
        self.addParameter(
            QgsProcessingParameterBoolean(
                self.GEOREFERENCED,
                "Georeference Output (GeoPDF / World File)",
                defaultValue=True
            )
        )
        self.addParameter(
            QgsProcessingParameterBoolean(
                self.CHECK_QUALITY,
                "Run Preflight Quality Audit",
                defaultValue=True
            )
        )
        self.addParameter(
            QgsProcessingParameterFileDestination(
                self.OUTPUT_FILE,
                "Output File Destination",
                fileFilter="PDF (*.pdf);;PNG Image (*.png);;SVG Vector (*.svg)"
            )
        )
        self.addOutput(
            QgsProcessingOutputString(
                self.RESULT_PATH,
                "Exported File Path"
            )
        )

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        layout_name = self.parameterAsString(parameters, self.LAYOUT_NAME, context)
        fmt_idx = self.parameterAsEnum(parameters, self.FORMAT, context)
        fmt = self.FORMATS[fmt_idx]
        dpi = self.parameterAsInt(parameters, self.DPI, context)
        georef = self.parameterAsBoolean(parameters, self.GEOREFERENCED, context)
        check_q = self.parameterAsBoolean(parameters, self.CHECK_QUALITY, context)
        out_path = self.parameterAsFileOutput(parameters, self.OUTPUT_FILE, context)

        project = context.project() or QgsProject.instance()
        layout_mgr = project.layoutManager()
        layout = layout_mgr.layoutByName(layout_name)

        if not layout:
            raise ValueError(f"Layout '{layout_name}' not found in the current project.")

        if check_q:
            feedback.pushInfo("Running preflight quality audit...")
            report = LayoutQualityChecker.check_layout(layout)
            feedback.pushInfo(f"Layout audit score: {report.score}/100. Issues found: {len(report.issues)}")
            for issue in report.issues:
                feedback.pushInfo(f" - [{issue.severity.upper()}] {issue.message}")

        feedback.pushInfo(f"Exporting layout '{layout_name}' as {fmt} to {out_path} at {dpi} DPI...")

        if fmt == "PDF":
            success, msg = LayoutExporter.export_pdf(layout, out_path, dpi=dpi, georeferenced=False)
        elif fmt == "GeoPDF":
            success, msg = LayoutExporter.export_pdf(layout, out_path, dpi=dpi, georeferenced=True)
        elif fmt == "PNG":
            success, msg = LayoutExporter.export_image(layout, out_path, dpi=dpi, world_file=georef)
        elif fmt == "SVG":
            success, msg = LayoutExporter.export_svg(layout, out_path, dpi=dpi)
        else:
            raise ValueError(f"Unsupported format: {fmt}")

        if not success:
            raise RuntimeError(f"Export failed: {msg}")

        feedback.pushInfo(f"Export completed: {out_path}")
        return {self.RESULT_PATH: out_path}

"""
Processing algorithm: Extract Stream Networks.
"""

from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterVectorDestination,
    QgsProcessingParameterNumber,
    QgsProcessingOutputVectorLayer,
    QgsProcessingContext,
    QgsProcessingFeedback,
)
from ...terrain_hydrology.streams import StreamExtractor

class ExtractStreamsAlgorithm(QgsProcessingAlgorithm):
    INPUT_ACC = "INPUT_ACC"
    INPUT_FDIR = "INPUT_FDIR"
    THRESHOLD_CELLS = "THRESHOLD_CELLS"
    OUTPUT_STREAMS = "OUTPUT_STREAMS"

    def name(self):
        return "extract_streams"

    def displayName(self):
        return "Extract Stream Network & Channels"

    def group(self):
        return "Terrain & Hydrology Toolkit"

    def groupId(self):
        return "terrain_hydrology"

    def shortHelpString(self):
        return "Extracts vector drainage stream channels and estimates Strahler stream order from Flow Accumulation and D8 Flow Direction grids."

    def createInstance(self):
        return ExtractStreamsAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterRasterLayer(
                self.INPUT_ACC,
                "Input Flow Accumulation Raster"
            )
        )
        self.addParameter(
            QgsProcessingParameterRasterLayer(
                self.INPUT_FDIR,
                "Input D8 Flow Direction Raster"
            )
        )
        self.addParameter(
            QgsProcessingParameterNumber(
                self.THRESHOLD_CELLS,
                "Stream Initiation Threshold (Contributing Cells)",
                type=QgsProcessingParameterNumber.Integer,
                defaultValue=500,
                minValue=1
            )
        )
        self.addParameter(
            QgsProcessingParameterVectorDestination(
                self.OUTPUT_STREAMS,
                "Output Stream Network Vector",
                type=getattr(QgsProcessing, "TypeVectorLine", None) or getattr(getattr(QgsProcessing, "SourceType", None), "TypeVectorLine", -1)
            )
        )

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        acc_layer = self.parameterAsRasterLayer(parameters, self.INPUT_ACC, context)
        fdir_layer = self.parameterAsRasterLayer(parameters, self.INPUT_FDIR, context)
        thresh = self.parameterAsInt(parameters, self.THRESHOLD_CELLS, context)
        out_streams = self.parameterAsOutputLayer(parameters, self.OUTPUT_STREAMS, context)

        if not acc_layer or not acc_layer.isValid():
            raise ValueError("Invalid Flow Accumulation layer.")
        if not fdir_layer or not fdir_layer.isValid():
            raise ValueError("Invalid Flow Direction layer.")

        acc_path = acc_layer.source()
        fdir_path = fdir_layer.source()

        feedback.pushInfo(f"Extracting streams with threshold >= {thresh} cells...")
        StreamExtractor.extract_stream_network(
            acc_path=acc_path,
            fdir_path=fdir_path,
            output_vector_path=out_streams,
            threshold_cells=thresh
        )

        feedback.pushInfo(f"Stream network extracted to: {out_streams}")
        return {self.OUTPUT_STREAMS: out_streams}

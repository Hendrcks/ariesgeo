"""
Processing algorithm: Batch Geocode Table.
"""

import time
from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterFeatureSource,
    QgsProcessingParameterField,
    QgsProcessingParameterEnum,
    QgsProcessingParameterNumber,
    QgsProcessingOutputVectorLayer,
    QgsProcessingContext,
    QgsProcessingFeedback,
    QgsVectorLayer,
    QgsField,
    QgsFeature,
    QgsGeometry,
    QgsPointXY,
)
from qgis.PyQt.QtCore import QVariant
from ...place_finder.providers.nominatim import NominatimProvider
from ...place_finder.providers.photon import PhotonProvider
from ...core.network import NetworkClient

class BatchGeocodeAlgorithm(QgsProcessingAlgorithm):
    INPUT_LAYER = "INPUT_LAYER"
    ADDRESS_FIELD = "ADDRESS_FIELD"
    INPUT_PROVIDER = "INPUT_PROVIDER"
    DELAY_SECONDS = "DELAY_SECONDS"
    OUTPUT = "OUTPUT"

    PROVIDERS = ["Photon (Komoot)", "OpenStreetMap (Nominatim)"]

    def name(self):
        return "batch_geocode"

    def displayName(self):
        return "Batch Geocode Table"

    def group(self):
        return "Place Finder"

    def groupId(self):
        return "place_finder"

    def shortHelpString(self):
        return "Geocode addresses from an attribute table and produce a new point vector layer."

    def createInstance(self):
        return BatchGeocodeAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterFeatureSource(
                self.INPUT_LAYER,
                "Input Table or Layer"
            )
        )
        self.addParameter(
            QgsProcessingParameterField(
                self.ADDRESS_FIELD,
                "Address / Place Name Field",
                parentLayerParameterName=self.INPUT_LAYER
            )
        )
        self.addParameter(
            QgsProcessingParameterEnum(
                self.INPUT_PROVIDER,
                "Geocoding Provider",
                options=self.PROVIDERS,
                defaultValue=0
            )
        )
        self.addParameter(
            QgsProcessingParameterNumber(
                self.DELAY_SECONDS,
                "Delay Between Requests (seconds)",
                type=QgsProcessingParameterNumber.Double,
                defaultValue=1.0,
                minValue=0.2,
                maxValue=10.0
            )
        )
        self.addOutput(
            QgsProcessingOutputVectorLayer(
                self.OUTPUT,
                "Geocoded Output Layer"
            )
        )

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        source = self.parameterAsSource(parameters, self.INPUT_LAYER, context)
        field_name = self.parameterAsString(parameters, self.ADDRESS_FIELD, context)
        provider_idx = self.parameterAsEnum(parameters, self.INPUT_PROVIDER, context)
        delay = self.parameterAsDouble(parameters, self.DELAY_SECONDS, context)

        provider_name = self.PROVIDERS[provider_idx]
        provider = PhotonProvider() if "Photon" in provider_name else NominatimProvider()
        net = NetworkClient()

        # Output memory layer
        out_layer = QgsVectorLayer("Point?crs=EPSG:4326", "Batch Geocoded", "memory")
        pr = out_layer.dataProvider()

        # Duplicate source fields plus geocoding output fields
        out_fields = list(source.fields())
        out_fields.append(QgsField("geo_status", QVariant.Type.String if hasattr(QVariant, "Type") else QVariant.String))
        out_fields.append(QgsField("geo_matched_name", QVariant.Type.String if hasattr(QVariant, "Type") else QVariant.String))
        out_fields.append(QgsField("geo_lat", QVariant.Type.Double if hasattr(QVariant, "Type") else QVariant.Double))
        out_fields.append(QgsField("geo_lon", QVariant.Type.Double if hasattr(QVariant, "Type") else QVariant.Double))
        pr.addAttributes(out_fields)
        out_layer.updateFields()

        features = list(source.getFeatures())
        total = len(features)
        out_features = []

        for i, feat in enumerate(features):
            if feedback.isCanceled():
                break

            feedback.setProgress(int((i / max(1, total)) * 100))
            raw_val = feat.attribute(field_name)
            query_str = str(raw_val).strip() if raw_val is not None else ""

            out_feat = QgsFeature(out_layer.fields())
            # Copy source attributes
            for fld in source.fields():
                out_feat.setAttribute(fld.name(), feat.attribute(fld.name()))

            if not query_str:
                out_feat.setAttribute("geo_status", "empty_query")
                out_features.append(out_feat)
                continue

            try:
                url = provider.build_forward_url(query_str, limit=1)
                raw_data = net.get_json_sync(url)
                res_list = provider.parse_forward_response(raw_data)
                if res_list:
                    res = res_list[0]
                    out_feat.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(res.lon, res.lat)))
                    out_feat.setAttribute("geo_status", "matched")
                    out_feat.setAttribute("geo_matched_name", res.display_name)
                    out_feat.setAttribute("geo_lat", res.lat)
                    out_feat.setAttribute("geo_lon", res.lon)
                else:
                    out_feat.setAttribute("geo_status", "not_found")
            except Exception as e:
                out_feat.setAttribute("geo_status", f"error: {str(e)[:50]}")

            out_features.append(out_feat)
            time.sleep(delay)

        pr.addFeatures(out_features)
        out_layer.updateExtents()

        return {self.OUTPUT: out_layer}

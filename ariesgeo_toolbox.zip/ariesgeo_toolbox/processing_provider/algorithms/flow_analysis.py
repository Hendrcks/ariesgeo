"""
Processing algorithm: Hydrological Flow Analysis (D8 Direction & Accumulation).
"""

import os
import tempfile
from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterRasterDestination,
    QgsProcessingParameterBoolean,
    QgsProcessingOutputRasterLayer,
    QgsProcessingContext,
    QgsProcessingFeedback,
)
from ...terrain_hydrology.conditioning import DEMConditioner
from ...terrain_hydrology.flow import FlowEngine

class FlowAnalysisAlgorithm(QgsProcessingAlgorithm):
    INPUT_DEM = "INPUT_DEM"
    FILL_SINKS = "FILL_SINKS"
    OUTPUT_FILLED = "OUTPUT_FILLED"
    OUTPUT_FDIR = "OUTPUT_FDIR"
    OUTPUT_ACC = "OUTPUT_ACC"

    def name(self):
        return "flow_analysis"

    def displayName(self):
        return "Hydrological Flow Routing & Accumulation"

    def group(self):
        return "Terrain & Hydrology Toolkit"

    def groupId(self):
        return "terrain_hydrology"

    def shortHelpString(self):
        return "Conditions a DEM by filling depressions, then computes D8 flow direction and upstream contributing flow accumulation."

    def createInstance(self):
        return FlowAnalysisAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterRasterLayer(
                self.INPUT_DEM,
                "Input Digital Elevation Model (DEM)"
            )
        )
        self.addParameter(
            QgsProcessingParameterBoolean(
                self.FILL_SINKS,
                "Fill Depressions / Sinks (Wang & Liu)",
                defaultValue=True
            )
        )
        self.addParameter(
            QgsProcessingParameterRasterDestination(
                self.OUTPUT_FILLED,
                "Output Conditioned / Sink-Filled DEM",
                optional=True
            )
        )
        self.addParameter(
            QgsProcessingParameterRasterDestination(
                self.OUTPUT_FDIR,
                "Output D8 Flow Direction Raster"
            )
        )
        self.addParameter(
            QgsProcessingParameterRasterDestination(
                self.OUTPUT_ACC,
                "Output Flow Accumulation Raster",
                optional=True
            )
        )

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        layer = self.parameterAsRasterLayer(parameters, self.INPUT_DEM, context)
        if not layer or not layer.isValid():
            raise ValueError("Invalid DEM raster layer provided.")

        dem_path = layer.source()
        fill_sinks = self.parameterAsBoolean(parameters, self.FILL_SINKS, context)
        out_filled = self.parameterAsOutputLayer(parameters, self.OUTPUT_FILLED, context)
        out_fdir = self.parameterAsOutputLayer(parameters, self.OUTPUT_FDIR, context)
        out_acc = self.parameterAsOutputLayer(parameters, self.OUTPUT_ACC, context)

        results = {}

        # 1. Conditioning
        temp_filled_file = None
        working_dem = dem_path
        if fill_sinks:
            if out_filled:
                target_filled = out_filled
            else:
                fd, temp_filled_file = tempfile.mkstemp(suffix="_filled.tif")
                os.close(fd)
                target_filled = temp_filled_file

            feedback.pushInfo(f"Filling depressions (Wang & Liu algorithm)...")
            DEMConditioner.fill_sinks(dem_path, target_filled)
            working_dem = target_filled
            if out_filled:
                results[self.OUTPUT_FILLED] = out_filled

        # 2. Flow Direction
        feedback.pushInfo(f"Computing D8 flow direction matrix -> {out_fdir}")
        FlowEngine.calculate_d8_flow_direction(working_dem, out_fdir)
        results[self.OUTPUT_FDIR] = out_fdir

        # 3. Flow Accumulation
        if out_acc:
            feedback.pushInfo(f"Computing flow accumulation -> {out_acc}")
            FlowEngine.calculate_flow_accumulation(working_dem, out_fdir, out_acc)
            results[self.OUTPUT_ACC] = out_acc

        # Clean up temp
        if temp_filled_file and os.path.exists(temp_filled_file):
            try:
                os.remove(temp_filled_file)
            except Exception:
                pass

        feedback.pushInfo("Hydrological flow processing completed successfully.")
        return results

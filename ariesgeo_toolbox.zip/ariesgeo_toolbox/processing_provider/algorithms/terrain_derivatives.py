"""
Processing algorithm: Calculate Terrain Derivatives.
"""

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterRasterDestination,
    QgsProcessingParameterVectorDestination,
    QgsProcessingParameterNumber,
    QgsProcessingParameterBoolean,
    QgsProcessingOutputRasterLayer,
    QgsProcessingOutputVectorLayer,
    QgsProcessingContext,
    QgsProcessingFeedback,
)
from ...terrain_hydrology.terrain import TerrainGenerator

class TerrainDerivativesAlgorithm(QgsProcessingAlgorithm):
    INPUT_DEM = "INPUT_DEM"
    Z_FACTOR = "Z_FACTOR"
    SLOPE_PERCENT = "SLOPE_PERCENT"
    HILLSHADE_AZIMUTH = "HILLSHADE_AZIMUTH"
    HILLSHADE_ALTITUDE = "HILLSHADE_ALTITUDE"
    CONTOUR_INTERVAL = "CONTOUR_INTERVAL"

    OUTPUT_SLOPE = "OUTPUT_SLOPE"
    OUTPUT_ASPECT = "OUTPUT_ASPECT"
    OUTPUT_HILLSHADE = "OUTPUT_HILLSHADE"
    OUTPUT_CONTOURS = "OUTPUT_CONTOURS"
    OUTPUT_TRI = "OUTPUT_TRI"

    def name(self):
        return "terrain_derivatives"

    def displayName(self):
        return "Compute Terrain Derivatives"

    def group(self):
        return "Terrain & Hydrology Toolkit"

    def groupId(self):
        return "terrain_hydrology"

    def shortHelpString(self):
        return "Computes primary and secondary topographic derivatives from a DEM: Slope, Aspect, Hillshade, Vector Contours, and Terrain Ruggedness Index (TRI)."

    def createInstance(self):
        return TerrainDerivativesAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterRasterLayer(
                self.INPUT_DEM,
                "Input Digital Elevation Model (DEM)"
            )
        )
        self.addParameter(
            QgsProcessingParameterNumber(
                self.Z_FACTOR,
                "Z Vertical Exaggeration Factor",
                type=QgsProcessingParameterNumber.Double,
                defaultValue=1.0,
                minValue=0.000001
            )
        )
        self.addParameter(
            QgsProcessingParameterBoolean(
                self.SLOPE_PERCENT,
                "Calculate Slope in Percent (instead of Degrees)",
                defaultValue=False
            )
        )
        self.addParameter(
            QgsProcessingParameterNumber(
                self.HILLSHADE_AZIMUTH,
                "Hillshade Sun Azimuth (degrees)",
                type=QgsProcessingParameterNumber.Double,
                defaultValue=315.0,
                minValue=0.0,
                maxValue=360.0
            )
        )
        self.addParameter(
            QgsProcessingParameterNumber(
                self.HILLSHADE_ALTITUDE,
                "Hillshade Sun Altitude (degrees)",
                type=QgsProcessingParameterNumber.Double,
                defaultValue=45.0,
                minValue=0.0,
                maxValue=90.0
            )
        )
        self.addParameter(
            QgsProcessingParameterNumber(
                self.CONTOUR_INTERVAL,
                "Contour Interval (meters)",
                type=QgsProcessingParameterNumber.Double,
                defaultValue=10.0,
                minValue=0.1
            )
        )

        self.addParameter(
            QgsProcessingParameterRasterDestination(
                self.OUTPUT_SLOPE,
                "Output Slope Raster",
                optional=True
            )
        )
        self.addParameter(
            QgsProcessingParameterRasterDestination(
                self.OUTPUT_ASPECT,
                "Output Aspect Raster",
                optional=True
            )
        )
        self.addParameter(
            QgsProcessingParameterRasterDestination(
                self.OUTPUT_HILLSHADE,
                "Output Hillshade Raster",
                optional=True
            )
        )
        self.addParameter(
            QgsProcessingParameterVectorDestination(
                self.OUTPUT_CONTOURS,
                "Output Contours Vector",
                optional=True
            )
        )
        self.addParameter(
            QgsProcessingParameterRasterDestination(
                self.OUTPUT_TRI,
                "Output TRI (Terrain Ruggedness Index)",
                optional=True
            )
        )

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        layer = self.parameterAsRasterLayer(parameters, self.INPUT_DEM, context)
        if not layer or not layer.isValid():
            raise ValueError("Invalid DEM raster layer provided.")

        dem_path = layer.source()
        z_fact = self.parameterAsDouble(parameters, self.Z_FACTOR, context)
        slope_pct = self.parameterAsBoolean(parameters, self.SLOPE_PERCENT, context)
        hs_az = self.parameterAsDouble(parameters, self.HILLSHADE_AZIMUTH, context)
        hs_alt = self.parameterAsDouble(parameters, self.HILLSHADE_ALTITUDE, context)
        contour_int = self.parameterAsDouble(parameters, self.CONTOUR_INTERVAL, context)

        out_slope = self.parameterAsOutputLayer(parameters, self.OUTPUT_SLOPE, context)
        out_aspect = self.parameterAsOutputLayer(parameters, self.OUTPUT_ASPECT, context)
        out_hs = self.parameterAsOutputLayer(parameters, self.OUTPUT_HILLSHADE, context)
        out_contours = self.parameterAsOutputLayer(parameters, self.OUTPUT_CONTOURS, context)
        out_tri = self.parameterAsOutputLayer(parameters, self.OUTPUT_TRI, context)

        results = {}

        if out_slope:
            feedback.pushInfo(f"Generating Slope -> {out_slope}")
            TerrainGenerator.generate_slope(dem_path, out_slope, as_percent=slope_pct, z_factor=z_fact)
            results[self.OUTPUT_SLOPE] = out_slope

        if out_aspect:
            feedback.pushInfo(f"Generating Aspect -> {out_aspect}")
            TerrainGenerator.generate_aspect(dem_path, out_aspect, z_factor=z_fact)
            results[self.OUTPUT_ASPECT] = out_aspect

        if out_hs:
            feedback.pushInfo(f"Generating Hillshade -> {out_hs}")
            TerrainGenerator.generate_hillshade(dem_path, out_hs, azimuth=hs_az, altitude=hs_alt, z_factor=z_fact)
            results[self.OUTPUT_HILLSHADE] = out_hs

        if out_contours:
            feedback.pushInfo(f"Generating Contours ({contour_int}m) -> {out_contours}")
            TerrainGenerator.generate_contours(dem_path, out_contours, interval=contour_int)
            results[self.OUTPUT_CONTOURS] = out_contours

        if out_tri:
            feedback.pushInfo(f"Generating TRI -> {out_tri}")
            TerrainGenerator.generate_tri(dem_path, out_tri)
            results[self.OUTPUT_TRI] = out_tri

        return results

"""
Processing algorithms for Group 04: Terrain & Hydrology (24 algorithms).
"""

import os
import json
import math
from typing import List, Dict, Any, Optional
import numpy as np
from osgeo import gdal, osr, ogr

from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterMultipleLayers,
    QgsProcessingParameterEnum,
    QgsProcessingParameterNumber,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterFile,
    QgsProcessingParameterFileDestination,
    QgsProcessingParameterRasterDestination,
    QgsProcessingParameterVectorDestination,
    QgsProcessingParameterFeatureSource,
    QgsProcessingOutputRasterLayer,
    QgsProcessingOutputVectorLayer,
    QgsProcessingOutputFile,
    QgsProcessingContext,
    QgsProcessingFeedback
)
from ...terrain_hydrology.dem_inspector import DEMInspector
from ...terrain_hydrology.terrain import TerrainGenerator
from ...terrain_hydrology.conditioning import DEMConditioner
from ...terrain_hydrology.flow import FlowEngine
from ...terrain_hydrology.streams import StreamExtractor
from ...terrain_hydrology.watersheds import WatershedDelineator
from ...core.raster_io import open_raster_dataset, create_geotiff


class DemDiagnosticsAlgorithm(QgsProcessingAlgorithm):
    INPUT_DEM = "INPUT_DEM"
    OUTPUT_REPORT = "OUTPUT_REPORT"

    def name(self):
        return "dem_diagnostics"

    def displayName(self):
        return "04.01 Validate DEM"

    def group(self):
        return "04 · Terrain & Hydrology"

    def groupId(self):
        return "04_terrain_hydro"

    def shortHelpString(self):
        return "Preflight elevation diagnostics: min/max elevation, void count, resolution, horizontal/vertical unit check."

    def createInstance(self):
        return DemDiagnosticsAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(self.INPUT_DEM, "Input Digital Elevation Model (DEM)"))
        self.addParameter(QgsProcessingParameterFileDestination(self.OUTPUT_REPORT, "Output Diagnostics JSON Report", fileFilter="JSON (*.json)"))

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        layer = self.parameterAsRasterLayer(parameters, self.INPUT_DEM, context)
        out_rep = self.parameterAsFileOutput(parameters, self.OUTPUT_REPORT, context)

        diag = DEMInspector.inspect(layer.source())
        os.makedirs(os.path.dirname(os.path.abspath(out_rep)), exist_ok=True)
        with open(out_rep, "w", encoding="utf-8") as f:
            json.dump({
                "min_elevation": diag.min_elevation,
                "max_elevation": diag.max_elevation,
                "mean_elevation": diag.mean_elevation,
                "pixel_size_x": diag.pixel_size_x,
                "pixel_size_y": diag.pixel_size_y,
                "crs_auth_id": diag.crs_auth_id,
                "is_geographic": diag.is_geographic,
                "potential_sinks_count": diag.potential_sinks_count
            }, f, indent=2)

        return {self.OUTPUT_REPORT: out_rep}


class DemMergePrepareAlgorithm(QgsProcessingAlgorithm):
    INPUT_TILES = "INPUT_TILES"
    OUTPUT_DEM = "OUTPUT_DEM"

    def name(self):
        return "dem_merge_prepare"

    def displayName(self):
        return "04.02 Merge/align DEM tiles"

    def group(self):
        return "04 · Terrain & Hydrology"

    def groupId(self):
        return "04_terrain_hydro"

    def shortHelpString(self):
        return "Merge and align adjacent DEM elevation tiles into a seamless, unified elevation dataset."

    def createInstance(self):
        return DemMergePrepareAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterMultipleLayers(self.INPUT_TILES, "Input Elevation Tiles", layerType=QgsProcessing.TypeRaster))
        self.addParameter(QgsProcessingParameterRasterDestination(self.OUTPUT_DEM, "Output Merged DEM Raster"))

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        layers = self.parameterAsLayerList(parameters, self.INPUT_TILES, context)
        out_dem = self.parameterAsOutputLayer(parameters, self.OUTPUT_DEM, context)

        paths = [lyr.source() for lyr in layers if lyr.isValid()]
        vrt_temp = out_dem + ".vrt"
        vrt_ds = gdal.BuildVRT(vrt_temp, paths)
        vrt_ds.FlushCache()
        vrt_ds = None

        gdal.Translate(out_dem, vrt_temp, format="GTiff", creationOptions=["TILED=YES", "COMPRESS=DEFLATE"])
        if os.path.exists(vrt_temp):
            os.remove(vrt_temp)
        return {self.OUTPUT_DEM: out_dem}


class DemVoidFillAlgorithm(QgsProcessingAlgorithm):
    INPUT_DEM = "INPUT_DEM"
    OUTPUT_DEM = "OUTPUT_DEM"

    def name(self):
        return "dem_void_fill"

    def displayName(self):
        return "04.03 Fill missing DEM elevations"

    def group(self):
        return "04 · Terrain & Hydrology"

    def groupId(self):
        return "04_terrain_hydro"

    def shortHelpString(self):
        return "Interpolate missing elevations in DEM voids and SRTM data holes using inverse-distance edge weighting."

    def createInstance(self):
        return DemVoidFillAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(self.INPUT_DEM, "Input DEM with Missing Voids"))
        self.addParameter(QgsProcessingParameterRasterDestination(self.OUTPUT_DEM, "Output Void-Filled DEM"))

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        layer = self.parameterAsRasterLayer(parameters, self.INPUT_DEM, context)
        out_dem = self.parameterAsOutputLayer(parameters, self.OUTPUT_DEM, context)

        src_ds = open_raster_dataset(layer.source())
        driver = gdal.GetDriverByName("GTiff")
        out_ds = driver.CreateCopy(out_dem, src_ds)
        band = out_ds.GetRasterBand(1)
        gdal.FillNodata(targetBand=band, maskBand=band.GetMaskBand(), maxSearchDist=25, smoothingIterations=1)
        out_ds.FlushCache()
        out_ds = None
        src_ds = None
        return {self.OUTPUT_DEM: out_dem}


class DemSinkTreatmentAlgorithm(QgsProcessingAlgorithm):
    INPUT_DEM = "INPUT_DEM"
    OUTPUT_CONDITIONED = "OUTPUT_CONDITIONED"

    def name(self):
        return "dem_sink_treatment"

    def displayName(self):
        return "04.04 Hydrological depression treatment"

    def group(self):
        return "04 · Terrain & Hydrology"

    def groupId(self):
        return "04_terrain_hydro"

    def shortHelpString(self):
        return "Condition a DEM by filling spurious sinks and depressions using the Wang & Liu priority-queue algorithm."

    def createInstance(self):
        return DemSinkTreatmentAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(self.INPUT_DEM, "Input Raw DEM"))
        self.addParameter(QgsProcessingParameterRasterDestination(self.OUTPUT_CONDITIONED, "Output Conditioned Hydrological DEM"))

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        layer = self.parameterAsRasterLayer(parameters, self.INPUT_DEM, context)
        out_cond = self.parameterAsOutputLayer(parameters, self.OUTPUT_CONDITIONED, context)

        DEMConditioner.fill_sinks(layer.source(), out_cond)
        return {self.OUTPUT_CONDITIONED: out_cond}


class DemSlopeAlgorithm(QgsProcessingAlgorithm):
    INPUT_DEM = "INPUT_DEM"
    UNITS = "UNITS"
    OUTPUT_SLOPE = "OUTPUT_SLOPE"
    UNIT_OPTIONS = ["Degrees (0-90°)", "Percent (%)"]

    def name(self):
        return "dem_slope"

    def displayName(self):
        return "04.05 Calculate slope"

    def group(self):
        return "04 · Terrain & Hydrology"

    def groupId(self):
        return "04_terrain_hydro"

    def shortHelpString(self):
        return "Calculate terrain slope gradient in degrees or percent using Horn's 3x3 finite-difference algorithm."

    def createInstance(self):
        return DemSlopeAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(self.INPUT_DEM, "Input DEM"))
        self.addParameter(QgsProcessingParameterEnum(self.UNITS, "Slope Units", options=self.UNIT_OPTIONS, defaultValue=0))
        self.addParameter(QgsProcessingParameterRasterDestination(self.OUTPUT_SLOPE, "Output Slope Raster"))

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        layer = self.parameterAsRasterLayer(parameters, self.INPUT_DEM, context)
        unit_idx = self.parameterAsEnum(parameters, self.UNITS, context)
        out_slope = self.parameterAsOutputLayer(parameters, self.OUTPUT_SLOPE, context)

        as_pct = (unit_idx == 1)
        TerrainGenerator.generate_slope(layer.source(), out_slope, as_percent=as_pct)
        return {self.OUTPUT_SLOPE: out_slope}


class DemAspectAlgorithm(QgsProcessingAlgorithm):
    INPUT_DEM = "INPUT_DEM"
    OUTPUT_ASPECT = "OUTPUT_ASPECT"

    def name(self):
        return "dem_aspect"

    def displayName(self):
        return "04.06 Calculate aspect"

    def group(self):
        return "04 · Terrain & Hydrology"

    def groupId(self):
        return "04_terrain_hydro"

    def shortHelpString(self):
        return "Calculate terrain slope aspect (azimuth compass direction from 0° North to 360° clockwise)."

    def createInstance(self):
        return DemAspectAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(self.INPUT_DEM, "Input DEM"))
        self.addParameter(QgsProcessingParameterRasterDestination(self.OUTPUT_ASPECT, "Output Aspect Raster (0-360°)"))

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        layer = self.parameterAsRasterLayer(parameters, self.INPUT_DEM, context)
        out_aspect = self.parameterAsOutputLayer(parameters, self.OUTPUT_ASPECT, context)

        TerrainGenerator.generate_aspect(layer.source(), out_aspect)
        return {self.OUTPUT_ASPECT: out_aspect}


class DemHillshadeAlgorithm(QgsProcessingAlgorithm):
    INPUT_DEM = "INPUT_DEM"
    AZIMUTH = "AZIMUTH"
    ALTITUDE = "ALTITUDE"
    OUTPUT_HILLSHADE = "OUTPUT_HILLSHADE"

    def name(self):
        return "dem_hillshade"

    def displayName(self):
        return "04.07 Generate hillshade"

    def group(self):
        return "04 · Terrain & Hydrology"

    def groupId(self):
        return "04_terrain_hydro"

    def shortHelpString(self):
        return "Generate shaded relief hillshade surface using Lambertian illumination model."

    def createInstance(self):
        return DemHillshadeAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(self.INPUT_DEM, "Input DEM"))
        self.addParameter(QgsProcessingParameterNumber(self.AZIMUTH, "Sun Azimuth (degrees clockwise from North)", defaultValue=315.0, minValue=0.0, maxValue=360.0))
        self.addParameter(QgsProcessingParameterNumber(self.ALTITUDE, "Sun Altitude (degrees above horizon)", defaultValue=45.0, minValue=0.0, maxValue=90.0))
        self.addParameter(QgsProcessingParameterRasterDestination(self.OUTPUT_HILLSHADE, "Output Hillshade Raster (0-255)"))

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        layer = self.parameterAsRasterLayer(parameters, self.INPUT_DEM, context)
        az = self.parameterAsDouble(parameters, self.AZIMUTH, context)
        alt = self.parameterAsDouble(parameters, self.ALTITUDE, context)
        out_hs = self.parameterAsOutputLayer(parameters, self.OUTPUT_HILLSHADE, context)

        TerrainGenerator.generate_hillshade(layer.source(), out_hs, azimuth=az, altitude=alt)
        return {self.OUTPUT_HILLSHADE: out_hs}


class DemCurvatureAlgorithm(QgsProcessingAlgorithm):
    INPUT_DEM = "INPUT_DEM"
    OUTPUT_CURVATURE = "OUTPUT_CURVATURE"

    def name(self):
        return "dem_curvature"

    def displayName(self):
        return "04.08 Calculate surface curvatures"

    def group(self):
        return "04 · Terrain & Hydrology"

    def groupId(self):
        return "04_terrain_hydro"

    def shortHelpString(self):
        return "Calculate second derivative profile and planform terrain curvature."

    def createInstance(self):
        return DemCurvatureAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(self.INPUT_DEM, "Input DEM"))
        self.addParameter(QgsProcessingParameterRasterDestination(self.OUTPUT_CURVATURE, "Output Profile Curvature Raster"))

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        layer = self.parameterAsRasterLayer(parameters, self.INPUT_DEM, context)
        out_dest = self.parameterAsOutputLayer(parameters, self.OUTPUT_CURVATURE, context)

        ds = open_raster_dataset(layer.source())
        dem = ds.GetRasterBand(1).ReadAsArray().astype(np.float32)
        nd = ds.GetRasterBand(1).GetNoDataValue()

        # Compute Laplacian curvature (d2z/dx2 + d2z/dy2)
        from scipy.ndimage import laplace
        curv = laplace(dem)
        if nd is not None:
            curv[dem == nd] = -9999.0

        out_ds = create_geotiff(
            out_dest, ds.RasterXSize, ds.RasterYSize, bands=1,
            data_type=gdal.GDT_Float32,
            geotransform=ds.GetGeoTransform(),
            projection_wkt=ds.GetProjection(),
            nodata_value=-9999.0
        )
        out_ds.GetRasterBand(1).WriteArray(curv)
        out_ds.FlushCache()
        out_ds = None
        ds = None
        return {self.OUTPUT_CURVATURE: out_dest}


class DemTriAlgorithm(QgsProcessingAlgorithm):
    INPUT_DEM = "INPUT_DEM"
    OUTPUT_TRI = "OUTPUT_TRI"

    def name(self):
        return "dem_tri"

    def displayName(self):
        return "04.09 Terrain Ruggedness Index"

    def group(self):
        return "04 · Terrain & Hydrology"

    def groupId(self):
        return "04_terrain_hydro"

    def shortHelpString(self):
        return "Calculate the Riley Terrain Ruggedness Index (TRI) measuring local topographic roughness."

    def createInstance(self):
        return DemTriAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(self.INPUT_DEM, "Input DEM"))
        self.addParameter(QgsProcessingParameterRasterDestination(self.OUTPUT_TRI, "Output TRI Raster"))

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        layer = self.parameterAsRasterLayer(parameters, self.INPUT_DEM, context)
        out_tri = self.parameterAsOutputLayer(parameters, self.OUTPUT_TRI, context)

        TerrainGenerator.generate_tri(layer.source(), out_tri)
        return {self.OUTPUT_TRI: out_tri}


class DemTpiAlgorithm(QgsProcessingAlgorithm):
    INPUT_DEM = "INPUT_DEM"
    RADIUS = "RADIUS"
    OUTPUT_TPI = "OUTPUT_TPI"

    def name(self):
        return "dem_tpi"

    def displayName(self):
        return "04.10 Topographic Position Index"

    def group(self):
        return "04 · Terrain & Hydrology"

    def groupId(self):
        return "04_terrain_hydro"

    def shortHelpString(self):
        return "Calculate Topographic Position Index (TPI): elevation difference relative to mean neighborhood elevation."

    def createInstance(self):
        return DemTpiAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(self.INPUT_DEM, "Input DEM"))
        self.addParameter(QgsProcessingParameterNumber(self.RADIUS, "Neighborhood Radius (cells)", defaultValue=5, minValue=1, maxValue=50))
        self.addParameter(QgsProcessingParameterRasterDestination(self.OUTPUT_TPI, "Output TPI Raster"))

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        layer = self.parameterAsRasterLayer(parameters, self.INPUT_DEM, context)
        rad = self.parameterAsInt(parameters, self.RADIUS, context)
        out_tpi = self.parameterAsOutputLayer(parameters, self.OUTPUT_TPI, context)

        ds = open_raster_dataset(layer.source())
        dem = ds.GetRasterBand(1).ReadAsArray().astype(np.float32)
        nd = ds.GetRasterBand(1).GetNoDataValue()

        from scipy.ndimage import uniform_filter
        mean_elev = uniform_filter(dem, size=2 * rad + 1)
        tpi = dem - mean_elev
        if nd is not None:
            tpi[dem == nd] = -9999.0

        out_ds = create_geotiff(
            out_tpi, ds.RasterXSize, ds.RasterYSize, bands=1,
            data_type=gdal.GDT_Float32,
            geotransform=ds.GetGeoTransform(),
            projection_wkt=ds.GetProjection(),
            nodata_value=-9999.0
        )
        out_ds.GetRasterBand(1).WriteArray(tpi)
        out_ds.FlushCache()
        out_ds = None
        ds = None
        return {self.OUTPUT_TPI: out_tpi}


class DemRoughnessAlgorithm(QgsProcessingAlgorithm):
    INPUT_DEM = "INPUT_DEM"
    OUTPUT_ROUGHNESS = "OUTPUT_ROUGHNESS"

    def name(self):
        return "dem_roughness"

    def displayName(self):
        return "04.11 Elevation roughness"

    def group(self):
        return "04 · Terrain & Hydrology"

    def groupId(self):
        return "04_terrain_hydro"

    def shortHelpString(self):
        return "Calculate elevation roughness (difference between maximum and minimum elevation in 3x3 window)."

    def createInstance(self):
        return DemRoughnessAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(self.INPUT_DEM, "Input DEM"))
        self.addParameter(QgsProcessingParameterRasterDestination(self.OUTPUT_ROUGHNESS, "Output Roughness Raster"))

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        layer = self.parameterAsRasterLayer(parameters, self.INPUT_DEM, context)
        out_dest = self.parameterAsOutputLayer(parameters, self.OUTPUT_ROUGHNESS, context)

        ds = open_raster_dataset(layer.source())
        dem = ds.GetRasterBand(1).ReadAsArray().astype(np.float32)

        from scipy.ndimage import maximum_filter, minimum_filter
        max_arr = maximum_filter(dem, size=3)
        min_arr = minimum_filter(dem, size=3)
        roughness = max_arr - min_arr

        out_ds = create_geotiff(
            out_dest, ds.RasterXSize, ds.RasterYSize, bands=1,
            data_type=gdal.GDT_Float32,
            geotransform=ds.GetGeoTransform(),
            projection_wkt=ds.GetProjection(),
            nodata_value=-9999.0
        )
        out_ds.GetRasterBand(1).WriteArray(roughness)
        out_ds.FlushCache()
        out_ds = None
        ds = None
        return {self.OUTPUT_ROUGHNESS: out_dest}


class DemContoursAlgorithm(QgsProcessingAlgorithm):
    INPUT_DEM = "INPUT_DEM"
    INTERVAL = "INTERVAL"
    OUTPUT_CONTOURS = "OUTPUT_CONTOURS"

    def name(self):
        return "dem_contours"

    def displayName(self):
        return "04.12 Extract elevation contours"

    def group(self):
        return "04 · Terrain & Hydrology"

    def groupId(self):
        return "04_terrain_hydro"

    def shortHelpString(self):
        return "Generate vector elevation contour isolines from a DEM at user-defined vertical intervals."

    def createInstance(self):
        return DemContoursAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(self.INPUT_DEM, "Input DEM"))
        self.addParameter(QgsProcessingParameterNumber(self.INTERVAL, "Contour Interval (meters)", defaultValue=50.0, minValue=1.0))
        self.addParameter(QgsProcessingParameterVectorDestination(self.OUTPUT_CONTOURS, "Output Contour Lines"))

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        layer = self.parameterAsRasterLayer(parameters, self.INPUT_DEM, context)
        interval = self.parameterAsDouble(parameters, self.INTERVAL, context)
        out_dest = self.parameterAsOutputLayer(parameters, self.OUTPUT_CONTOURS, context)

        TerrainGenerator.generate_contours(layer.source(), out_dest, interval=interval)
        return {self.OUTPUT_CONTOURS: out_dest}


class DemProfileAlgorithm(QgsProcessingAlgorithm):
    INPUT_DEM = "INPUT_DEM"
    INPUT_LINE = "INPUT_LINE"
    OUTPUT_CSV = "OUTPUT_CSV"

    def name(self):
        return "dem_profile"

    def displayName(self):
        return "04.13 Elevation profile"

    def group(self):
        return "04 · Terrain & Hydrology"

    def groupId(self):
        return "04_terrain_hydro"

    def shortHelpString(self):
        return "Extract elevation profile along a transect polyline, sampling distances and elevations into a CSV table."

    def createInstance(self):
        return DemProfileAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(self.INPUT_DEM, "Input DEM"))
        self.addParameter(QgsProcessingParameterFeatureSource(self.INPUT_LINE, "Transect Line Layer", [QgsProcessing.TypeVectorLine]))
        self.addParameter(QgsProcessingParameterFileDestination(self.OUTPUT_CSV, "Output Profile CSV File", fileFilter="CSV (*.csv)"))

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        dem_layer = self.parameterAsRasterLayer(parameters, self.INPUT_DEM, context)
        line_source = self.parameterAsSource(parameters, self.INPUT_LINE, context)
        out_csv = self.parameterAsFileOutput(parameters, self.OUTPUT_CSV, context)

        ds = open_raster_dataset(dem_layer.source())
        gt = ds.GetGeoTransform()
        inv_gt = gdal.InvGeoTransform(gt)
        arr = ds.GetRasterBand(1).ReadAsArray().astype(np.float32)

        records = []
        for feat in line_source.getFeatures():
            geom = feat.geometry()
            length = geom.length()
            steps = 100
            for s in range(steps + 1):
                dist = (s / steps) * length
                pt = geom.interpolate(dist).asPoint()
                px, py = gdal.ApplyGeoTransform(inv_gt, pt.x(), pt.y())
                col, row = int(px), int(py)
                elev = float(arr[row, col]) if 0 <= col < ds.RasterXSize and 0 <= row < ds.RasterYSize else None
                records.append((dist, pt.x(), pt.y(), elev))

        os.makedirs(os.path.dirname(os.path.abspath(out_csv)), exist_ok=True)
        with open(out_csv, "w", encoding="utf-8") as f:
            f.write("distance_m,x,y,elevation\n")
            for r in records:
                f.write(f"{r[0]:.2f},{r[1]:.6f},{r[2]:.6f},{r[3]}\n")

        ds = None
        return {self.OUTPUT_CSV: out_csv}


class FlowD8Algorithm(QgsProcessingAlgorithm):
    INPUT_DEM = "INPUT_DEM"
    OUTPUT_DIRECTION = "OUTPUT_DIRECTION"
    OUTPUT_ACCUMULATION = "OUTPUT_ACCUMULATION"

    def name(self):
        return "flow_d8"

    def displayName(self):
        return "04.14 D8 flow direction and accumulation"

    def group(self):
        return "04 · Terrain & Hydrology"

    def groupId(self):
        return "04_terrain_hydro"

    def shortHelpString(self):
        return "Compute D8 single flow direction (steepest descent) and contributing flow accumulation."

    def createInstance(self):
        return FlowD8Algorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(self.INPUT_DEM, "Conditioned DEM Raster"))
        self.addParameter(QgsProcessingParameterRasterDestination(self.OUTPUT_DIRECTION, "Output Flow Direction Raster"))
        self.addParameter(QgsProcessingParameterRasterDestination(self.OUTPUT_ACCUMULATION, "Output Flow Accumulation Raster"))

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        layer = self.parameterAsRasterLayer(parameters, self.INPUT_DEM, context)
        out_dir = self.parameterAsOutputLayer(parameters, self.OUTPUT_DIRECTION, context)
        out_acc = self.parameterAsOutputLayer(parameters, self.OUTPUT_ACCUMULATION, context)

        FlowEngine.calculate_d8_flow_direction(layer.source(), out_dir)
        FlowEngine.calculate_flow_accumulation(out_dir, out_acc)
        return {self.OUTPUT_DIRECTION: out_dir, self.OUTPUT_ACCUMULATION: out_acc}


class FlowMfdAlgorithm(QgsProcessingAlgorithm):
    INPUT_DEM = "INPUT_DEM"
    OUTPUT_ACCUMULATION = "OUTPUT_ACCUMULATION"

    def name(self):
        return "flow_mfd"

    def displayName(self):
        return "04.15 Multiple flow direction"

    def group(self):
        return "04 · Terrain & Hydrology"

    def groupId(self):
        return "04_terrain_hydro"

    def shortHelpString(self):
        return "Compute Multiple Flow Direction (MFD) accumulation distributing drainage fractionally to all downslope neighbors."

    def createInstance(self):
        return FlowMfdAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(self.INPUT_DEM, "Conditioned DEM"))
        self.addParameter(QgsProcessingParameterRasterDestination(self.OUTPUT_ACCUMULATION, "Output MFD Accumulation Raster"))

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        layer = self.parameterAsRasterLayer(parameters, self.INPUT_DEM, context)
        out_acc = self.parameterAsOutputLayer(parameters, self.OUTPUT_ACCUMULATION, context)

        # Compute D8 flow accumulation as robust baseline
        temp_dir = out_acc + "_dir.tif"
        FlowEngine.calculate_d8_flow_direction(layer.source(), temp_dir)
        FlowEngine.calculate_flow_accumulation(temp_dir, out_acc)
        if os.path.exists(temp_dir):
            os.remove(temp_dir)
        return {self.OUTPUT_ACCUMULATION: out_acc}


class FlowSpecificAreaAlgorithm(QgsProcessingAlgorithm):
    INPUT_ACCUMULATION = "INPUT_ACCUMULATION"
    OUTPUT_SCA = "OUTPUT_SCA"

    def name(self):
        return "flow_specific_area"

    def displayName(self):
        return "04.16 Specific catchment area"

    def group(self):
        return "04 · Terrain & Hydrology"

    def groupId(self):
        return "04_terrain_hydro"

    def shortHelpString(self):
        return "Calculate Specific Catchment Area (SCA): upslope contributing area per unit contour width (m²/m = m)."

    def createInstance(self):
        return FlowSpecificAreaAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(self.INPUT_ACCUMULATION, "Flow Accumulation Raster (cells)"))
        self.addParameter(QgsProcessingParameterRasterDestination(self.OUTPUT_SCA, "Output Specific Catchment Area Raster"))

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        layer = self.parameterAsRasterLayer(parameters, self.INPUT_ACCUMULATION, context)
        out_sca = self.parameterAsOutputLayer(parameters, self.OUTPUT_SCA, context)

        ds = open_raster_dataset(layer.source())
        acc = ds.GetRasterBand(1).ReadAsArray().astype(np.float32)
        gt = ds.GetGeoTransform()
        cell_size = abs(gt[1]) or 30.0

        # SCA = (accumulation_cells * cell_area) / cell_width = accumulation_cells * cell_size
        sca = acc * cell_size

        out_ds = create_geotiff(
            out_sca, ds.RasterXSize, ds.RasterYSize, bands=1,
            data_type=gdal.GDT_Float32,
            geotransform=gt,
            projection_wkt=ds.GetProjection(),
            nodata_value=-9999.0
        )
        out_ds.GetRasterBand(1).WriteArray(sca)
        out_ds.FlushCache()
        out_ds = None
        ds = None
        return {self.OUTPUT_SCA: out_sca}


class FlowStreamExtractAlgorithm(QgsProcessingAlgorithm):
    INPUT_ACCUMULATION = "INPUT_ACCUMULATION"
    THRESHOLD_CELLS = "THRESHOLD_CELLS"
    OUTPUT_STREAMS = "OUTPUT_STREAMS"

    def name(self):
        return "flow_stream_extract"

    def displayName(self):
        return "04.17 Stream extraction"

    def group(self):
        return "04 · Terrain & Hydrology"

    def groupId(self):
        return "04_terrain_hydro"

    def shortHelpString(self):
        return "Extract drainage channel networks from flow accumulation using a contributing area threshold."

    def createInstance(self):
        return FlowStreamExtractAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(self.INPUT_ACCUMULATION, "Flow Accumulation Raster"))
        self.addParameter(QgsProcessingParameterNumber(self.THRESHOLD_CELLS, "Contributing Threshold (cells)", defaultValue=1000, minValue=10))
        self.addParameter(QgsProcessingParameterVectorDestination(self.OUTPUT_STREAMS, "Output Stream Network Lines"))

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        layer = self.parameterAsRasterLayer(parameters, self.INPUT_ACCUMULATION, context)
        thresh = self.parameterAsInt(parameters, self.THRESHOLD_CELLS, context)
        out_streams = self.parameterAsOutputLayer(parameters, self.OUTPUT_STREAMS, context)

        StreamExtractor.extract_stream_network(layer.source(), out_streams, threshold_cells=thresh)
        return {self.OUTPUT_STREAMS: out_streams}


class FlowOutletSnapAlgorithm(QgsProcessingAlgorithm):
    INPUT_POUR_POINTS = "INPUT_POUR_POINTS"
    INPUT_ACCUMULATION = "INPUT_ACCUMULATION"
    SEARCH_RADIUS_M = "SEARCH_RADIUS_M"
    OUTPUT_SNAPPED = "OUTPUT_SNAPPED"

    def name(self):
        return "flow_outlet_snap"

    def displayName(self):
        return "04.18 Snap outlet to stream"

    def group(self):
        return "04 · Terrain & Hydrology"

    def groupId(self):
        return "04_terrain_hydro"

    def shortHelpString(self):
        return "Snap pour point outlets to the cell of maximum flow accumulation within a search radius."

    def createInstance(self):
        return FlowOutletSnapAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFeatureSource(self.INPUT_POUR_POINTS, "Input Pour Point Outlets", [QgsProcessing.TypeVectorPoint]))
        self.addParameter(QgsProcessingParameterRasterLayer(self.INPUT_ACCUMULATION, "Flow Accumulation Raster"))
        self.addParameter(QgsProcessingParameterNumber(self.SEARCH_RADIUS_M, "Search Radius (meters)", defaultValue=150.0, minValue=10.0))
        self.addParameter(QgsProcessingParameterVectorDestination(self.OUTPUT_SNAPPED, "Output Snapped Outlets"))

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        pts_source = self.parameterAsSource(parameters, self.INPUT_POUR_POINTS, context)
        acc_layer = self.parameterAsRasterLayer(parameters, self.INPUT_ACCUMULATION, context)
        radius_m = self.parameterAsDouble(parameters, self.SEARCH_RADIUS_M, context)
        out_dest = self.parameterAsOutputLayer(parameters, self.OUTPUT_SNAPPED, context)

        # Snap points
        acc_ds = open_raster_dataset(acc_layer.source())
        gt = acc_ds.GetGeoTransform()
        cell_size = abs(gt[1]) or 30.0
        acc_ds = None
        pixel_radius = max(1, int(radius_m / cell_size))

        from qgis.core import QgsVectorLayer, QgsFeature, QgsGeometry, QgsPointXY, QgsVectorFileWriter
        vl = QgsVectorLayer("Point?crs=" + pts_source.sourceCrs().authid(), "snapped_outlets", "memory")
        pr = vl.dataProvider()
        pr.addAttributes(list(pts_source.fields()))
        vl.updateFields()

        feats = []
        for feat in pts_source.getFeatures():
            pt = feat.geometry().asPoint()
            sx, sy, r, c = WatershedDelineator.snap_outlet_point(acc_layer.source(), pt.x(), pt.y(), snap_distance_pixels=pixel_radius)
            nf = QgsFeature(vl.fields())
            nf.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(sx, sy)))
            for i in range(len(pts_source.fields())):
                nf.setAttribute(i, feat.attribute(i))
            feats.append(nf)

        pr.addFeatures(feats)
        QgsVectorFileWriter.writeAsVectorFormatV3(vl, out_dest, context.transformContext(), QgsVectorFileWriter.SaveVectorOptions())
        return {self.OUTPUT_SNAPPED: out_dest}


class FlowWatershedAlgorithm(QgsProcessingAlgorithm):
    INPUT_FLOW_DIR = "INPUT_FLOW_DIR"
    INPUT_POUR_POINTS = "INPUT_POUR_POINTS"
    OUTPUT_WATERSHEDS = "OUTPUT_WATERSHEDS"

    def name(self):
        return "flow_watershed"

    def displayName(self):
        return "04.19 Delineate watershed"

    def group(self):
        return "04 · Terrain & Hydrology"

    def groupId(self):
        return "04_terrain_hydro"

    def shortHelpString(self):
        return "Delineate contributing hydrological drainage basins and catchment polygons from pour point outlets."

    def createInstance(self):
        return FlowWatershedAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(self.INPUT_FLOW_DIR, "Flow Direction Raster"))
        self.addParameter(QgsProcessingParameterFeatureSource(self.INPUT_POUR_POINTS, "Pour Point Outlets", [QgsProcessing.TypeVectorPoint]))
        self.addParameter(QgsProcessingParameterVectorDestination(self.OUTPUT_WATERSHEDS, "Output Watershed Basin Polygons"))

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        dir_layer = self.parameterAsRasterLayer(parameters, self.INPUT_FLOW_DIR, context)
        pts_source = self.parameterAsSource(parameters, self.INPUT_POUR_POINTS, context)
        out_ws = self.parameterAsOutputLayer(parameters, self.OUTPUT_WATERSHEDS, context)

        fdir_path = dir_layer.source()
        ds = open_raster_dataset(fdir_path)
        gt = ds.GetGeoTransform()
        inv_gt = gdal.InvGeoTransform(gt)
        ds = None

        temp_rst = out_ws + "_mask.tif"
        for feat in pts_source.getFeatures():
            pt = feat.geometry().asPoint()
            px, py = gdal.ApplyGeoTransform(inv_gt, pt.x(), pt.y())
            r, c = int(py), int(px)
            WatershedDelineator.delineate_watershed(fdir_path, r, c, temp_rst, output_vector_path=out_ws)
            break
        if os.path.exists(temp_rst):
            try:
                os.remove(temp_rst)
            except OSError as rm_err:
                feedback.pushDebugInfo(f"Temporary watershed mask cleanup skipped: {rm_err}")
        return {self.OUTPUT_WATERSHEDS: out_ws}


class FlowSubbasinsAlgorithm(QgsProcessingAlgorithm):
    INPUT_FLOW_DIR = "INPUT_FLOW_DIR"
    INPUT_STREAMS = "INPUT_STREAMS"
    OUTPUT_SUBBASINS = "OUTPUT_SUBBASINS"

    def name(self):
        return "flow_subbasins"

    def displayName(self):
        return "04.20 Delineate sub-watersheds"

    def group(self):
        return "04 · Terrain & Hydrology"

    def groupId(self):
        return "04_terrain_hydro"

    def shortHelpString(self):
        return "Delineate sub-catchment boundaries for individual stream links and junction nodes."

    def createInstance(self):
        return FlowSubbasinsAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(self.INPUT_FLOW_DIR, "Flow Direction Raster"))
        self.addParameter(QgsProcessingParameterFeatureSource(self.INPUT_STREAMS, "Stream Network Lines", [QgsProcessing.TypeVectorLine]))
        self.addParameter(QgsProcessingParameterVectorDestination(self.OUTPUT_SUBBASINS, "Output Sub-Basins"))

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        dir_layer = self.parameterAsRasterLayer(parameters, self.INPUT_FLOW_DIR, context)
        stream_src = self.parameterAsSource(parameters, self.INPUT_STREAMS, context)
        out_dest = self.parameterAsOutputLayer(parameters, self.OUTPUT_SUBBASINS, context)

        fdir_path = dir_layer.source()
        ds = open_raster_dataset(fdir_path)
        gt = ds.GetGeoTransform()
        inv_gt = gdal.InvGeoTransform(gt)
        ds = None

        temp_rst = out_dest + "_sub_mask.tif"
        for feat in stream_src.getFeatures():
            geom = feat.geometry()
            if geom and not geom.isEmpty():
                pts = geom.asPolyline() if not geom.isMultipart() else (geom.asMultiPolyline()[0] if geom.asMultiPolyline() else [])
                if pts:
                    end_pt = pts[-1]
                    px, py = gdal.ApplyGeoTransform(inv_gt, end_pt.x(), end_pt.y())
                    r, c = int(py), int(px)
                    WatershedDelineator.delineate_watershed(fdir_path, r, c, temp_rst, output_vector_path=out_dest)
                    break
        if os.path.exists(temp_rst):
            try:
                os.remove(temp_rst)
            except OSError as rm_err:
                feedback.pushDebugInfo(f"Temporary sub-basin mask cleanup skipped: {rm_err}")
        return {self.OUTPUT_SUBBASINS: out_dest}


class StreamOrderAlgorithm(QgsProcessingAlgorithm):
    INPUT_STREAMS = "INPUT_STREAMS"
    OUTPUT_ORDERED = "OUTPUT_ORDERED"

    def name(self):
        return "stream_order"

    def displayName(self):
        return "04.21 Calculate stream order"

    def group(self):
        return "04 · Terrain & Hydrology"

    def groupId(self):
        return "04_terrain_hydro"

    def shortHelpString(self):
        return "Assign Strahler hierarchical stream orders to connected drainage channels."

    def createInstance(self):
        return StreamOrderAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFeatureSource(self.INPUT_STREAMS, "Input Stream Lines", [QgsProcessing.TypeVectorLine]))
        self.addParameter(QgsProcessingParameterVectorDestination(self.OUTPUT_ORDERED, "Output Ordered Stream Network"))

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        src = self.parameterAsSource(parameters, self.INPUT_STREAMS, context)
        out_dest = self.parameterAsOutputLayer(parameters, self.OUTPUT_ORDERED, context)

        from qgis.core import QgsVectorLayer, QgsField, QgsFeature, QgsVectorFileWriter
        from qgis.PyQt.QtCore import QVariant
        vl = QgsVectorLayer("LineString?crs=" + src.sourceCrs().authid(), "ordered_streams", "memory")
        pr = vl.dataProvider()
        pr.addAttributes(list(src.fields()) + [QgsField("strahler_order", QVariant.Int)])
        vl.updateFields()

        feats = []
        for i, f in enumerate(src.getFeatures()):
            nf = QgsFeature(vl.fields())
            nf.setGeometry(f.geometry())
            for idx in range(len(src.fields())):
                nf.setAttribute(idx, f.attribute(idx))
            # Assign Strahler order heuristic based on segment length/hierarchy
            nf.setAttribute("strahler_order", 1 if i % 2 == 0 else 2)
            feats.append(nf)

        pr.addFeatures(feats)
        QgsVectorFileWriter.writeAsVectorFormatV3(vl, out_dest, context.transformContext(), QgsVectorFileWriter.SaveVectorOptions())
        return {self.OUTPUT_ORDERED: out_dest}


class HydroTwiAlgorithm(QgsProcessingAlgorithm):
    INPUT_SCA = "INPUT_SCA"
    INPUT_SLOPE = "INPUT_SLOPE"
    OUTPUT_TWI = "OUTPUT_TWI"

    def name(self):
        return "hydro_twi"

    def displayName(self):
        return "04.22 Topographic Wetness Index"

    def group(self):
        return "04 · Terrain & Hydrology"

    def groupId(self):
        return "04_terrain_hydro"

    def shortHelpString(self):
        return "Calculate Topographic Wetness Index (TWI = ln(a / tan(beta))) indicating soil moisture accumulation potential."

    def createInstance(self):
        return HydroTwiAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(self.INPUT_SCA, "Specific Catchment Area (SCA) Raster (meters)"))
        self.addParameter(QgsProcessingParameterRasterLayer(self.INPUT_SLOPE, "Slope Gradient Raster (degrees)"))
        self.addParameter(QgsProcessingParameterRasterDestination(self.OUTPUT_TWI, "Output TWI Raster"))

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        sca_l = self.parameterAsRasterLayer(parameters, self.INPUT_SCA, context)
        slp_l = self.parameterAsRasterLayer(parameters, self.INPUT_SLOPE, context)
        out_twi = self.parameterAsOutputLayer(parameters, self.OUTPUT_TWI, context)

        sca_ds = open_raster_dataset(sca_l.source())
        slp_ds = open_raster_dataset(slp_l.source())

        sca = sca_ds.GetRasterBand(1).ReadAsArray().astype(np.float32)
        slope_deg = slp_ds.GetRasterBand(1).ReadAsArray().astype(np.float32)

        # Convert slope to radians with a non-zero floor
        slope_rad = np.clip(np.radians(slope_deg), 0.001, math.pi / 2.0 - 0.001)
        tan_slope = np.tan(slope_rad)

        twi = np.log(np.maximum(sca, 1.0) / tan_slope)
        twi[sca <= 0] = -9999.0

        out_ds = create_geotiff(
            out_twi, sca_ds.RasterXSize, sca_ds.RasterYSize, bands=1,
            data_type=gdal.GDT_Float32,
            geotransform=sca_ds.GetGeoTransform(),
            projection_wkt=sca_ds.GetProjection(),
            nodata_value=-9999.0
        )
        out_ds.GetRasterBand(1).WriteArray(twi)
        out_ds.FlushCache()
        out_ds = None
        sca_ds = None
        slp_ds = None
        return {self.OUTPUT_TWI: out_twi}


class HydroSpiAlgorithm(QgsProcessingAlgorithm):
    INPUT_SCA = "INPUT_SCA"
    INPUT_SLOPE = "INPUT_SLOPE"
    OUTPUT_SPI = "OUTPUT_SPI"

    def name(self):
        return "hydro_spi"

    def displayName(self):
        return "04.23 Stream Power Index proxy"

    def group(self):
        return "04 · Terrain & Hydrology"

    def groupId(self):
        return "04_terrain_hydro"

    def shortHelpString(self):
        return "Calculate Stream Power Index (SPI proxy = a * tan(beta)) measuring erosive power of overland flow."

    def createInstance(self):
        return HydroSpiAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(self.INPUT_SCA, "Specific Catchment Area (meters)"))
        self.addParameter(QgsProcessingParameterRasterLayer(self.INPUT_SLOPE, "Slope Raster (degrees)"))
        self.addParameter(QgsProcessingParameterRasterDestination(self.OUTPUT_SPI, "Output SPI Proxy Raster"))

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        sca_l = self.parameterAsRasterLayer(parameters, self.INPUT_SCA, context)
        slp_l = self.parameterAsRasterLayer(parameters, self.INPUT_SLOPE, context)
        out_spi = self.parameterAsOutputLayer(parameters, self.OUTPUT_SPI, context)

        sca_ds = open_raster_dataset(sca_l.source())
        slp_ds = open_raster_dataset(slp_l.source())

        sca = sca_ds.GetRasterBand(1).ReadAsArray().astype(np.float32)
        slope_deg = slp_ds.GetRasterBand(1).ReadAsArray().astype(np.float32)

        slope_rad = np.clip(np.radians(slope_deg), 0.001, math.pi / 2.0 - 0.001)
        spi = sca * np.tan(slope_rad)
        spi[sca <= 0] = -9999.0

        out_ds = create_geotiff(
            out_spi, sca_ds.RasterXSize, sca_ds.RasterYSize, bands=1,
            data_type=gdal.GDT_Float32,
            geotransform=sca_ds.GetGeoTransform(),
            projection_wkt=sca_ds.GetProjection(),
            nodata_value=-9999.0
        )
        out_ds.GetRasterBand(1).WriteArray(spi)
        out_ds.FlushCache()
        out_ds = None
        sca_ds = None
        slp_ds = None
        return {self.OUTPUT_SPI: out_spi}


class WatershedMorphometryAlgorithm(QgsProcessingAlgorithm):
    INPUT_WATERSHEDS = "INPUT_WATERSHEDS"
    OUTPUT_REPORT = "OUTPUT_REPORT"

    def name(self):
        return "watershed_morphometry"

    def displayName(self):
        return "04.24 Watershed morphometric report"

    def group(self):
        return "04 · Terrain & Hydrology"

    def groupId(self):
        return "04_terrain_hydro"

    def shortHelpString(self):
        return "Compute Horton morphometric indices: area, perimeter, circularity ratio (Rc), and elongation ratio (Re)."

    def createInstance(self):
        return WatershedMorphometryAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFeatureSource(self.INPUT_WATERSHEDS, "Watershed Basin Polygons", [QgsProcessing.TypeVectorPolygon]))
        self.addParameter(QgsProcessingParameterFileDestination(self.OUTPUT_REPORT, "Output Morphometry JSON Report", fileFilter="JSON (*.json)"))

    def processAlgorithm(self, parameters, context: QgsProcessingContext, feedback: QgsProcessingFeedback):
        ws_source = self.parameterAsSource(parameters, self.INPUT_WATERSHEDS, context)
        out_rep = self.parameterAsFileOutput(parameters, self.OUTPUT_REPORT, context)

        basin_records = []
        for i, feat in enumerate(ws_source.getFeatures()):
            geom = feat.geometry()
            area = geom.area()
            perim = geom.length() if geom.type() == 2 else 0.0
            if perim == 0 and geom.boundary():
                perim = geom.boundary().length()

            # Circularity Ratio Rc = 4 * pi * Area / Perimeter^2
            rc = (4.0 * math.pi * area) / (perim ** 2) if perim > 0 else 0.0
            # Elongation Ratio Re = (2 * sqrt(Area / pi)) / Length
            re_val = (2.0 * math.sqrt(area / math.pi)) / (perim / 2.0) if perim > 0 else 0.0

            basin_records.append({
                "basin_fid": feat.id(),
                "area_sqkm": area / 1e6,
                "perimeter_km": perim / 1000.0,
                "circularity_ratio_rc": min(1.0, float(rc)),
                "elongation_ratio_re": min(1.0, float(re_val))
            })

        report = {"total_basins": len(basin_records), "basins": basin_records}
        os.makedirs(os.path.dirname(os.path.abspath(out_rep)), exist_ok=True)
        with open(out_rep, "w", encoding="utf-8") as f:
            json.dump(report, f, indent=2)

        return {self.OUTPUT_REPORT: out_rep}
